/*    */ package org.activiti.engine;
/*    */ 
/*    */ public class ActivitiClassLoadingException extends ActivitiException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String className;
/*    */ 
/*    */   public ActivitiClassLoadingException(String className, Throwable cause)
/*    */   {
/* 28 */     super(getExceptionMessageMessage(className, cause), cause);
/* 29 */     this.className = className;
/*    */   }
/*    */ 
/*    */   public String getClassName()
/*    */   {
/* 36 */     return this.className;
/*    */   }
/*    */ 
/*    */   private static String getExceptionMessageMessage(String className, Throwable cause) {
/* 40 */     if ((cause instanceof ClassNotFoundException)) {
/* 41 */       return "Class not found: " + className;
/*    */     }
/* 43 */     return "Could not load class: " + className;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.ActivitiClassLoadingException
 * JD-Core Version:    0.6.0
 */