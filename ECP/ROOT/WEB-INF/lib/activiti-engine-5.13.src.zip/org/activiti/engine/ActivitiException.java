/*    */ package org.activiti.engine;
/*    */ 
/*    */ public class ActivitiException extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public ActivitiException(String message, Throwable cause)
/*    */   {
/* 26 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public ActivitiException(String message) {
/* 30 */     super(message);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.ActivitiException
 * JD-Core Version:    0.6.0
 */