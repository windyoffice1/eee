/*    */ package org.activiti.engine;
/*    */ 
/*    */ public class ActivitiIllegalArgumentException extends ActivitiException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public ActivitiIllegalArgumentException(String message)
/*    */   {
/* 29 */     super(message);
/*    */   }
/*    */ 
/*    */   public ActivitiIllegalArgumentException(String message, Throwable cause) {
/* 33 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.ActivitiIllegalArgumentException
 * JD-Core Version:    0.6.0
 */