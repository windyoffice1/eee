/*    */ package org.activiti.engine;
/*    */ 
/*    */ public class ActivitiObjectNotFoundException extends ActivitiException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private Class<?> objectClass;
/*    */ 
/*    */   public ActivitiObjectNotFoundException(String message, Class<?> objectClass)
/*    */   {
/* 29 */     this(message, objectClass, null);
/*    */   }
/*    */ 
/*    */   public ActivitiObjectNotFoundException(Class<?> objectClass) {
/* 33 */     this(null, objectClass, null);
/*    */   }
/*    */ 
/*    */   public ActivitiObjectNotFoundException(String message, Class<?> objectClass, Throwable cause) {
/* 37 */     super(message, cause);
/* 38 */     this.objectClass = objectClass;
/*    */   }
/*    */ 
/*    */   public Class<?> getObjectClass()
/*    */   {
/* 46 */     return this.objectClass;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.ActivitiObjectNotFoundException
 * JD-Core Version:    0.6.0
 */