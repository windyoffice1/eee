/*    */ package org.activiti.engine;
/*    */ 
/*    */ public class ActivitiOptimisticLockingException extends ActivitiException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public ActivitiOptimisticLockingException(String message)
/*    */   {
/* 28 */     super(message);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.ActivitiOptimisticLockingException
 * JD-Core Version:    0.6.0
 */