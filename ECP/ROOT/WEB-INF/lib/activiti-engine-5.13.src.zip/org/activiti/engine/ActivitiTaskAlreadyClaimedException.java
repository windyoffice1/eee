/*    */ package org.activiti.engine;
/*    */ 
/*    */ public class ActivitiTaskAlreadyClaimedException extends ActivitiException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String taskId;
/*    */   private String taskAssignee;
/*    */ 
/*    */   public ActivitiTaskAlreadyClaimedException(String taskId, String taskAssignee)
/*    */   {
/* 22 */     super("Task '" + taskId + "' is already claimed by someone else.");
/* 23 */     this.taskId = taskId;
/* 24 */     this.taskAssignee = taskAssignee;
/*    */   }
/*    */ 
/*    */   public String getTaskId() {
/* 28 */     return this.taskId;
/*    */   }
/*    */ 
/*    */   public String getTaskAssignee() {
/* 32 */     return this.taskAssignee;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.ActivitiTaskAlreadyClaimedException
 * JD-Core Version:    0.6.0
 */