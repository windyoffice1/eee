/*    */ package org.activiti.engine;
/*    */ 
/*    */ public class ActivitiWrongDbException extends ActivitiException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   String libraryVersion;
/*    */   String dbVersion;
/*    */ 
/*    */   public ActivitiWrongDbException(String libraryVersion, String dbVersion)
/*    */   {
/* 32 */     super("version mismatch: activiti library version is '" + libraryVersion + "', db version is " + dbVersion + " Hint: Set <property name=\"databaseSchemaUpdate\" to value=\"true\" or value=\"create-drop\" (use create-drop for testing only!) in bean processEngineConfiguration in activiti.cfg.xml for automatic schema creation");
/* 33 */     this.libraryVersion = libraryVersion;
/* 34 */     this.dbVersion = dbVersion;
/*    */   }
/*    */ 
/*    */   public String getLibraryVersion()
/*    */   {
/* 41 */     return this.libraryVersion;
/*    */   }
/*    */ 
/*    */   public String getDbVersion()
/*    */   {
/* 48 */     return this.dbVersion;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.ActivitiWrongDbException
 * JD-Core Version:    0.6.0
 */