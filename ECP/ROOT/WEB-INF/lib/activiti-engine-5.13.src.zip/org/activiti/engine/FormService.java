package org.activiti.engine;

import java.util.Map;
import org.activiti.engine.form.StartFormData;
import org.activiti.engine.form.TaskFormData;
import org.activiti.engine.runtime.ProcessInstance;

public abstract interface FormService
{
  public abstract StartFormData getStartFormData(String paramString);

  public abstract Object getRenderedStartForm(String paramString);

  public abstract Object getRenderedStartForm(String paramString1, String paramString2);

  public abstract ProcessInstance submitStartFormData(String paramString, Map<String, String> paramMap);

  public abstract ProcessInstance submitStartFormData(String paramString1, String paramString2, Map<String, String> paramMap);

  public abstract TaskFormData getTaskFormData(String paramString);

  public abstract Object getRenderedTaskForm(String paramString);

  public abstract Object getRenderedTaskForm(String paramString1, String paramString2);

  public abstract void submitTaskFormData(String paramString, Map<String, String> paramMap);

  public abstract String getStartFormKey(String paramString);

  public abstract String getTaskFormKey(String paramString1, String paramString2);
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.FormService
 * JD-Core Version:    0.6.0
 */