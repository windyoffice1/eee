package org.activiti.engine;

import java.util.List;
import org.activiti.engine.history.HistoricActivityInstanceQuery;
import org.activiti.engine.history.HistoricDetailQuery;
import org.activiti.engine.history.HistoricIdentityLink;
import org.activiti.engine.history.HistoricProcessInstanceQuery;
import org.activiti.engine.history.HistoricTaskInstanceQuery;
import org.activiti.engine.history.HistoricVariableInstanceQuery;
import org.activiti.engine.history.NativeHistoricActivityInstanceQuery;
import org.activiti.engine.history.NativeHistoricDetailQuery;
import org.activiti.engine.history.NativeHistoricProcessInstanceQuery;
import org.activiti.engine.history.NativeHistoricTaskInstanceQuery;
import org.activiti.engine.history.NativeHistoricVariableInstanceQuery;

public abstract interface HistoryService
{
  public abstract HistoricProcessInstanceQuery createHistoricProcessInstanceQuery();

  public abstract HistoricActivityInstanceQuery createHistoricActivityInstanceQuery();

  public abstract HistoricTaskInstanceQuery createHistoricTaskInstanceQuery();

  public abstract HistoricDetailQuery createHistoricDetailQuery();

  public abstract NativeHistoricDetailQuery createNativeHistoricDetailQuery();

  public abstract HistoricVariableInstanceQuery createHistoricVariableInstanceQuery();

  public abstract NativeHistoricVariableInstanceQuery createNativeHistoricVariableInstanceQuery();

  public abstract void deleteHistoricTaskInstance(String paramString);

  public abstract void deleteHistoricProcessInstance(String paramString);

  public abstract NativeHistoricProcessInstanceQuery createNativeHistoricProcessInstanceQuery();

  public abstract NativeHistoricTaskInstanceQuery createNativeHistoricTaskInstanceQuery();

  public abstract NativeHistoricActivityInstanceQuery createNativeHistoricActivityInstanceQuery();

  public abstract List<HistoricIdentityLink> getHistoricIdentityLinksForTask(String paramString);

  public abstract List<HistoricIdentityLink> getHistoricIdentityLinksForProcessInstance(String paramString);
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.HistoryService
 * JD-Core Version:    0.6.0
 */