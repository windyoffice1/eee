/*    */ package org.activiti.engine.delegate;
/*    */ 
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ 
/*    */ public class BpmnError extends ActivitiException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String errorCode;
/*    */ 
/*    */   public BpmnError(String errorCode)
/*    */   {
/* 41 */     super("");
/* 42 */     setErrorCode(errorCode);
/*    */   }
/*    */ 
/*    */   public BpmnError(String errorCode, String message) {
/* 46 */     super(message + " (errorCode='" + errorCode + "')");
/* 47 */     setErrorCode(errorCode);
/*    */   }
/*    */ 
/*    */   protected void setErrorCode(String errorCode) {
/* 51 */     if (errorCode == null) {
/* 52 */       throw new ActivitiIllegalArgumentException("Error Code must not be null.");
/*    */     }
/* 54 */     if (errorCode.length() < 1) {
/* 55 */       throw new ActivitiIllegalArgumentException("Error Code must not be empty.");
/*    */     }
/* 57 */     this.errorCode = errorCode;
/*    */   }
/*    */ 
/*    */   public String getErrorCode() {
/* 61 */     return this.errorCode;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 65 */     return super.toString() + " (errorCode='" + this.errorCode + "')";
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.delegate.BpmnError
 * JD-Core Version:    0.6.0
 */