package org.activiti.engine.delegate;

import org.activiti.engine.EngineServices;

public abstract interface DelegateExecution extends VariableScope
{
  public abstract String getId();

  public abstract String getProcessInstanceId();

  public abstract String getEventName();

  /** @deprecated */
  public abstract String getBusinessKey();

  public abstract String getProcessBusinessKey();

  public abstract String getProcessDefinitionId();

  public abstract String getParentId();

  public abstract String getCurrentActivityId();

  public abstract String getCurrentActivityName();

  public abstract EngineServices getEngineServices();
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.delegate.DelegateExecution
 * JD-Core Version:    0.6.0
 */