package org.activiti.engine.delegate;

import java.util.Collection;
import java.util.Date;
import java.util.Set;
import org.activiti.engine.task.IdentityLink;

public abstract interface DelegateTask extends VariableScope
{
  public abstract String getId();

  public abstract String getName();

  public abstract void setName(String paramString);

  public abstract String getDescription();

  public abstract void setDescription(String paramString);

  public abstract int getPriority();

  public abstract void setPriority(int paramInt);

  public abstract String getProcessInstanceId();

  public abstract String getExecutionId();

  public abstract String getProcessDefinitionId();

  public abstract Date getCreateTime();

  public abstract String getTaskDefinitionKey();

  public abstract DelegateExecution getExecution();

  public abstract String getEventName();

  public abstract void addCandidateUser(String paramString);

  public abstract void addCandidateUsers(Collection<String> paramCollection);

  public abstract void addCandidateGroup(String paramString);

  public abstract void addCandidateGroups(Collection<String> paramCollection);

  public abstract String getOwner();

  public abstract void setOwner(String paramString);

  public abstract String getAssignee();

  public abstract void setAssignee(String paramString);

  public abstract Date getDueDate();

  public abstract void setDueDate(Date paramDate);

  public abstract void addUserIdentityLink(String paramString1, String paramString2);

  public abstract void addGroupIdentityLink(String paramString1, String paramString2);

  public abstract void deleteCandidateUser(String paramString);

  public abstract void deleteCandidateGroup(String paramString);

  public abstract void deleteUserIdentityLink(String paramString1, String paramString2);

  public abstract void deleteGroupIdentityLink(String paramString1, String paramString2);

  public abstract Set<IdentityLink> getCandidates();
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.delegate.DelegateTask
 * JD-Core Version:    0.6.0
 */