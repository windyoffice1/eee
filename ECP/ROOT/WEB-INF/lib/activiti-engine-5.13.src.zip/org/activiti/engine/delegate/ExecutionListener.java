package org.activiti.engine.delegate;

import java.io.Serializable;

public abstract interface ExecutionListener extends Serializable
{
  public static final String EVENTNAME_START = "start";
  public static final String EVENTNAME_END = "end";
  public static final String EVENTNAME_TAKE = "take";

  public abstract void notify(DelegateExecution paramDelegateExecution)
    throws Exception;
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.delegate.ExecutionListener
 * JD-Core Version:    0.6.0
 */