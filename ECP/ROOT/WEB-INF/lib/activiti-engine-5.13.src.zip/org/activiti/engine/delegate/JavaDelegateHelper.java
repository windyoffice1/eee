package org.activiti.engine.delegate;

public class JavaDelegateHelper
{
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.delegate.JavaDelegateHelper
 * JD-Core Version:    0.6.0
 */