package org.activiti.engine.delegate;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

public abstract interface VariableScope
{
  public abstract Map<String, Object> getVariables();

  public abstract Map<String, Object> getVariablesLocal();

  public abstract Object getVariable(String paramString);

  public abstract Object getVariableLocal(Object paramObject);

  public abstract Set<String> getVariableNames();

  public abstract Set<String> getVariableNamesLocal();

  public abstract void setVariable(String paramString, Object paramObject);

  public abstract Object setVariableLocal(String paramString, Object paramObject);

  public abstract void setVariables(Map<String, ? extends Object> paramMap);

  public abstract void setVariablesLocal(Map<String, ? extends Object> paramMap);

  public abstract boolean hasVariables();

  public abstract boolean hasVariablesLocal();

  public abstract boolean hasVariable(String paramString);

  public abstract boolean hasVariableLocal(String paramString);

  public abstract void createVariableLocal(String paramString, Object paramObject);

  public abstract void removeVariable(String paramString);

  public abstract void removeVariableLocal(String paramString);

  public abstract void removeVariables(Collection<String> paramCollection);

  public abstract void removeVariablesLocal(Collection<String> paramCollection);

  public abstract void removeVariables();

  public abstract void removeVariablesLocal();
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.delegate.VariableScope
 * JD-Core Version:    0.6.0
 */