package org.activiti.engine.form;

import java.util.List;

public abstract interface FormData
{
  public abstract String getFormKey();

  public abstract String getDeploymentId();

  public abstract List<FormProperty> getFormProperties();
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.form.FormData
 * JD-Core Version:    0.6.0
 */