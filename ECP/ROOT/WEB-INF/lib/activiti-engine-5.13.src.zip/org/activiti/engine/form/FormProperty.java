package org.activiti.engine.form;

import java.io.Serializable;

public abstract interface FormProperty extends Serializable
{
  public abstract String getId();

  public abstract String getName();

  public abstract FormType getType();

  public abstract String getValue();

  public abstract boolean isReadable();

  public abstract boolean isWritable();

  public abstract boolean isRequired();
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.form.FormProperty
 * JD-Core Version:    0.6.0
 */