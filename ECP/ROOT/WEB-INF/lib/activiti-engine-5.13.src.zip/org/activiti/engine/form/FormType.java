package org.activiti.engine.form;

public abstract interface FormType
{
  public abstract String getName();

  public abstract Object getInformation(String paramString);
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.form.FormType
 * JD-Core Version:    0.6.0
 */