package org.activiti.engine.form;

import org.activiti.engine.repository.ProcessDefinition;

public abstract interface StartFormData extends FormData
{
  public abstract ProcessDefinition getProcessDefinition();
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.form.StartFormData
 * JD-Core Version:    0.6.0
 */