package org.activiti.engine.history;

import java.util.Date;

public abstract interface HistoricActivityInstance
{
  public abstract String getId();

  public abstract String getActivityId();

  public abstract String getActivityName();

  public abstract String getActivityType();

  public abstract String getProcessDefinitionId();

  public abstract String getProcessInstanceId();

  public abstract String getExecutionId();

  public abstract String getTaskId();

  public abstract String getCalledProcessInstanceId();

  public abstract String getAssignee();

  public abstract Date getStartTime();

  public abstract Date getEndTime();

  public abstract Long getDurationInMillis();
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.history.HistoricActivityInstance
 * JD-Core Version:    0.6.0
 */