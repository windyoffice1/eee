package org.activiti.engine.history;

import org.activiti.engine.query.Query;

public abstract interface HistoricActivityInstanceQuery extends Query<HistoricActivityInstanceQuery, HistoricActivityInstance>
{
  public abstract HistoricActivityInstanceQuery activityInstanceId(String paramString);

  public abstract HistoricActivityInstanceQuery processInstanceId(String paramString);

  public abstract HistoricActivityInstanceQuery processDefinitionId(String paramString);

  public abstract HistoricActivityInstanceQuery executionId(String paramString);

  public abstract HistoricActivityInstanceQuery activityId(String paramString);

  public abstract HistoricActivityInstanceQuery activityName(String paramString);

  public abstract HistoricActivityInstanceQuery activityType(String paramString);

  public abstract HistoricActivityInstanceQuery taskAssignee(String paramString);

  public abstract HistoricActivityInstanceQuery finished();

  public abstract HistoricActivityInstanceQuery unfinished();

  public abstract HistoricActivityInstanceQuery orderByHistoricActivityInstanceId();

  public abstract HistoricActivityInstanceQuery orderByProcessInstanceId();

  public abstract HistoricActivityInstanceQuery orderByExecutionId();

  public abstract HistoricActivityInstanceQuery orderByActivityId();

  public abstract HistoricActivityInstanceQuery orderByActivityName();

  public abstract HistoricActivityInstanceQuery orderByActivityType();

  public abstract HistoricActivityInstanceQuery orderByHistoricActivityInstanceStartTime();

  public abstract HistoricActivityInstanceQuery orderByHistoricActivityInstanceEndTime();

  public abstract HistoricActivityInstanceQuery orderByHistoricActivityInstanceDuration();

  public abstract HistoricActivityInstanceQuery orderByProcessDefinitionId();
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.history.HistoricActivityInstanceQuery
 * JD-Core Version:    0.6.0
 */