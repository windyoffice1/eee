package org.activiti.engine.history;

import java.util.Date;

public abstract interface HistoricDetail
{
  public abstract String getId();

  public abstract String getProcessInstanceId();

  public abstract String getActivityInstanceId();

  public abstract String getExecutionId();

  public abstract String getTaskId();

  public abstract Date getTime();
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.history.HistoricDetail
 * JD-Core Version:    0.6.0
 */