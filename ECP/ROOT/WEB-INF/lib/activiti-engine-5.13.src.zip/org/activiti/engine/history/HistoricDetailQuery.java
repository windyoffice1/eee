package org.activiti.engine.history;

import org.activiti.engine.query.Query;

public abstract interface HistoricDetailQuery extends Query<HistoricDetailQuery, HistoricDetail>
{
  public abstract HistoricDetailQuery id(String paramString);

  public abstract HistoricDetailQuery processInstanceId(String paramString);

  public abstract HistoricDetailQuery executionId(String paramString);

  public abstract HistoricDetailQuery activityInstanceId(String paramString);

  public abstract HistoricDetailQuery taskId(String paramString);

  public abstract HistoricDetailQuery formProperties();

  public abstract HistoricDetailQuery variableUpdates();

  public abstract HistoricDetailQuery excludeTaskDetails();

  public abstract HistoricDetailQuery orderByProcessInstanceId();

  public abstract HistoricDetailQuery orderByVariableName();

  public abstract HistoricDetailQuery orderByFormPropertyId();

  public abstract HistoricDetailQuery orderByVariableType();

  public abstract HistoricDetailQuery orderByVariableRevision();

  public abstract HistoricDetailQuery orderByTime();
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.history.HistoricDetailQuery
 * JD-Core Version:    0.6.0
 */