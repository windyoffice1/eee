package org.activiti.engine.history;

public abstract interface HistoricIdentityLink
{
  public abstract String getType();

  public abstract String getUserId();

  public abstract String getGroupId();

  public abstract String getTaskId();

  public abstract String getProcessInstanceId();
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.history.HistoricIdentityLink
 * JD-Core Version:    0.6.0
 */