package org.activiti.engine.history;

import java.util.Date;
import java.util.Map;

public abstract interface HistoricProcessInstance
{
  public abstract String getId();

  public abstract String getBusinessKey();

  public abstract String getProcessDefinitionId();

  public abstract Date getStartTime();

  public abstract Date getEndTime();

  public abstract Long getDurationInMillis();

  @Deprecated
  public abstract String getEndActivityId();

  public abstract String getStartUserId();

  public abstract String getStartActivityId();

  public abstract String getDeleteReason();

  public abstract String getSuperProcessInstanceId();

  public abstract Map<String, Object> getProcessVariables();
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.history.HistoricProcessInstance
 * JD-Core Version:    0.6.0
 */