package org.activiti.engine.history;

import java.util.Date;
import java.util.List;
import java.util.Set;
import org.activiti.engine.query.Query;

public abstract interface HistoricProcessInstanceQuery extends Query<HistoricProcessInstanceQuery, HistoricProcessInstance>
{
  public abstract HistoricProcessInstanceQuery processInstanceId(String paramString);

  public abstract HistoricProcessInstanceQuery processInstanceIds(Set<String> paramSet);

  public abstract HistoricProcessInstanceQuery processDefinitionId(String paramString);

  public abstract HistoricProcessInstanceQuery processDefinitionKey(String paramString);

  public abstract HistoricProcessInstanceQuery processDefinitionKeyNotIn(List<String> paramList);

  public abstract HistoricProcessInstanceQuery processInstanceBusinessKey(String paramString);

  public abstract HistoricProcessInstanceQuery finished();

  public abstract HistoricProcessInstanceQuery unfinished();

  public abstract HistoricProcessInstanceQuery involvedUser(String paramString);

  public abstract HistoricProcessInstanceQuery variableValueEquals(String paramString, Object paramObject);

  public abstract HistoricProcessInstanceQuery variableValueEquals(Object paramObject);

  public abstract HistoricProcessInstanceQuery variableValueEqualsIgnoreCase(String paramString1, String paramString2);

  public abstract HistoricProcessInstanceQuery variableValueNotEquals(String paramString, Object paramObject);

  public abstract HistoricProcessInstanceQuery variableValueGreaterThan(String paramString, Object paramObject);

  public abstract HistoricProcessInstanceQuery variableValueGreaterThanOrEqual(String paramString, Object paramObject);

  public abstract HistoricProcessInstanceQuery variableValueLessThan(String paramString, Object paramObject);

  public abstract HistoricProcessInstanceQuery variableValueLessThanOrEqual(String paramString, Object paramObject);

  public abstract HistoricProcessInstanceQuery variableValueLike(String paramString1, String paramString2);

  public abstract HistoricProcessInstanceQuery startedBefore(Date paramDate);

  public abstract HistoricProcessInstanceQuery startedAfter(Date paramDate);

  public abstract HistoricProcessInstanceQuery finishedBefore(Date paramDate);

  public abstract HistoricProcessInstanceQuery finishedAfter(Date paramDate);

  public abstract HistoricProcessInstanceQuery startedBy(String paramString);

  public abstract HistoricProcessInstanceQuery orderByProcessInstanceId();

  public abstract HistoricProcessInstanceQuery orderByProcessDefinitionId();

  public abstract HistoricProcessInstanceQuery orderByProcessInstanceBusinessKey();

  public abstract HistoricProcessInstanceQuery orderByProcessInstanceStartTime();

  public abstract HistoricProcessInstanceQuery orderByProcessInstanceEndTime();

  public abstract HistoricProcessInstanceQuery orderByProcessInstanceDuration();

  public abstract HistoricProcessInstanceQuery superProcessInstanceId(String paramString);

  public abstract HistoricProcessInstanceQuery excludeSubprocesses(boolean paramBoolean);

  /** @deprecated */
  public abstract HistoricProcessInstanceQuery startDateBy(Date paramDate);

  /** @deprecated */
  public abstract HistoricProcessInstanceQuery startDateOn(Date paramDate);

  /** @deprecated */
  public abstract HistoricProcessInstanceQuery finishDateBy(Date paramDate);

  /** @deprecated */
  public abstract HistoricProcessInstanceQuery finishDateOn(Date paramDate);

  public abstract HistoricProcessInstanceQuery includeProcessVariables();
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.history.HistoricProcessInstanceQuery
 * JD-Core Version:    0.6.0
 */