package org.activiti.engine.history;

import java.util.Date;
import java.util.Map;

public abstract interface HistoricTaskInstance
{
  public abstract String getId();

  public abstract String getProcessDefinitionId();

  public abstract String getProcessInstanceId();

  public abstract String getExecutionId();

  public abstract String getName();

  public abstract String getDescription();

  public abstract String getDeleteReason();

  public abstract String getOwner();

  public abstract String getAssignee();

  public abstract Date getStartTime();

  public abstract Date getEndTime();

  public abstract Long getDurationInMillis();

  public abstract Long getWorkTimeInMillis();

  public abstract Date getClaimTime();

  public abstract String getTaskDefinitionKey();

  public abstract String getFormKey();

  public abstract int getPriority();

  public abstract Date getDueDate();

  public abstract String getParentTaskId();

  public abstract Map<String, Object> getTaskLocalVariables();

  public abstract Map<String, Object> getProcessVariables();
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.history.HistoricTaskInstance
 * JD-Core Version:    0.6.0
 */