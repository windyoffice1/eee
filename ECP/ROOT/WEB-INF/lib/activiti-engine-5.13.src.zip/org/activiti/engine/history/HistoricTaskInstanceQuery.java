package org.activiti.engine.history;

import java.util.Date;
import org.activiti.engine.query.Query;

public abstract interface HistoricTaskInstanceQuery extends Query<HistoricTaskInstanceQuery, HistoricTaskInstance>
{
  public abstract HistoricTaskInstanceQuery taskId(String paramString);

  public abstract HistoricTaskInstanceQuery processInstanceId(String paramString);

  public abstract HistoricTaskInstanceQuery processInstanceBusinessKey(String paramString);

  public abstract HistoricTaskInstanceQuery executionId(String paramString);

  public abstract HistoricTaskInstanceQuery processDefinitionId(String paramString);

  public abstract HistoricTaskInstanceQuery processDefinitionKey(String paramString);

  public abstract HistoricTaskInstanceQuery processDefinitionName(String paramString);

  public abstract HistoricTaskInstanceQuery taskName(String paramString);

  public abstract HistoricTaskInstanceQuery taskNameLike(String paramString);

  public abstract HistoricTaskInstanceQuery taskDescription(String paramString);

  public abstract HistoricTaskInstanceQuery taskDescriptionLike(String paramString);

  public abstract HistoricTaskInstanceQuery taskDefinitionKey(String paramString);

  public abstract HistoricTaskInstanceQuery taskDeleteReason(String paramString);

  public abstract HistoricTaskInstanceQuery taskDeleteReasonLike(String paramString);

  public abstract HistoricTaskInstanceQuery taskAssignee(String paramString);

  public abstract HistoricTaskInstanceQuery taskAssigneeLike(String paramString);

  public abstract HistoricTaskInstanceQuery taskOwner(String paramString);

  public abstract HistoricTaskInstanceQuery taskOwnerLike(String paramString);

  public abstract HistoricTaskInstanceQuery taskInvolvedUser(String paramString);

  public abstract HistoricTaskInstanceQuery taskPriority(Integer paramInteger);

  public abstract HistoricTaskInstanceQuery finished();

  public abstract HistoricTaskInstanceQuery unfinished();

  public abstract HistoricTaskInstanceQuery processFinished();

  public abstract HistoricTaskInstanceQuery processUnfinished();

  public abstract HistoricTaskInstanceQuery taskParentTaskId(String paramString);

  public abstract HistoricTaskInstanceQuery taskDueDate(Date paramDate);

  public abstract HistoricTaskInstanceQuery taskDueBefore(Date paramDate);

  public abstract HistoricTaskInstanceQuery taskDueAfter(Date paramDate);

  public abstract HistoricTaskInstanceQuery taskCreatedOn(Date paramDate);

  public abstract HistoricTaskInstanceQuery taskVariableValueEquals(String paramString, Object paramObject);

  public abstract HistoricTaskInstanceQuery taskVariableValueEquals(Object paramObject);

  public abstract HistoricTaskInstanceQuery taskVariableValueEqualsIgnoreCase(String paramString1, String paramString2);

  public abstract HistoricTaskInstanceQuery taskVariableValueNotEquals(String paramString, Object paramObject);

  public abstract HistoricTaskInstanceQuery taskVariableValueNotEqualsIgnoreCase(String paramString1, String paramString2);

  public abstract HistoricTaskInstanceQuery processVariableValueEquals(String paramString, Object paramObject);

  public abstract HistoricTaskInstanceQuery processVariableValueEquals(Object paramObject);

  public abstract HistoricTaskInstanceQuery processVariableValueEqualsIgnoreCase(String paramString1, String paramString2);

  public abstract HistoricTaskInstanceQuery processVariableValueNotEquals(String paramString, Object paramObject);

  public abstract HistoricTaskInstanceQuery processVariableValueNotEqualsIgnoreCase(String paramString1, String paramString2);

  public abstract HistoricTaskInstanceQuery includeTaskLocalVariables();

  public abstract HistoricTaskInstanceQuery includeProcessVariables();

  public abstract HistoricTaskInstanceQuery orderByTaskId();

  public abstract HistoricTaskInstanceQuery orderByHistoricActivityInstanceId();

  public abstract HistoricTaskInstanceQuery orderByProcessDefinitionId();

  public abstract HistoricTaskInstanceQuery orderByProcessInstanceId();

  public abstract HistoricTaskInstanceQuery orderByExecutionId();

  public abstract HistoricTaskInstanceQuery orderByHistoricTaskInstanceDuration();

  public abstract HistoricTaskInstanceQuery orderByHistoricTaskInstanceEndTime();

  @Deprecated
  public abstract HistoricTaskInstanceQuery orderByHistoricActivityInstanceStartTime();

  public abstract HistoricTaskInstanceQuery orderByHistoricTaskInstanceStartTime();

  public abstract HistoricTaskInstanceQuery orderByTaskName();

  public abstract HistoricTaskInstanceQuery orderByTaskDescription();

  public abstract HistoricTaskInstanceQuery orderByTaskAssignee();

  public abstract HistoricTaskInstanceQuery orderByTaskOwner();

  public abstract HistoricTaskInstanceQuery orderByTaskDueDate();

  public abstract HistoricTaskInstanceQuery orderByDeleteReason();

  public abstract HistoricTaskInstanceQuery orderByTaskDefinitionKey();

  public abstract HistoricTaskInstanceQuery orderByTaskPriority();
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.history.HistoricTaskInstanceQuery
 * JD-Core Version:    0.6.0
 */