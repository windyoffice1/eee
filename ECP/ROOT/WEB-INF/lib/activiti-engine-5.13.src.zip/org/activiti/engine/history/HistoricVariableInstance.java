package org.activiti.engine.history;

public abstract interface HistoricVariableInstance
{
  public abstract String getId();

  public abstract String getVariableName();

  public abstract String getVariableTypeName();

  public abstract Object getValue();

  public abstract String getProcessInstanceId();

  public abstract String getTaskId();
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.history.HistoricVariableInstance
 * JD-Core Version:    0.6.0
 */