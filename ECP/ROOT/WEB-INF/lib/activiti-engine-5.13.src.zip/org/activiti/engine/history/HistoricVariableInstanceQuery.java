package org.activiti.engine.history;

import org.activiti.engine.query.Query;

public abstract interface HistoricVariableInstanceQuery extends Query<HistoricVariableInstanceQuery, HistoricVariableInstance>
{
  public abstract HistoricVariableInstanceQuery id(String paramString);

  public abstract HistoricVariableInstanceQuery processInstanceId(String paramString);

  public abstract HistoricVariableInstanceQuery taskId(String paramString);

  public abstract HistoricVariableInstanceQuery variableName(String paramString);

  public abstract HistoricVariableInstanceQuery variableNameLike(String paramString);

  public abstract HistoricVariableInstanceQuery excludeTaskVariables();

  public abstract HistoricVariableInstanceQuery variableValueEquals(String paramString, Object paramObject);

  public abstract HistoricVariableInstanceQuery orderByProcessInstanceId();

  public abstract HistoricVariableInstanceQuery orderByVariableName();
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.history.HistoricVariableInstanceQuery
 * JD-Core Version:    0.6.0
 */