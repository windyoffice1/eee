package org.activiti.engine.history;

public abstract interface HistoricVariableUpdate extends HistoricDetail
{
  public abstract String getVariableName();

  public abstract String getVariableTypeName();

  public abstract Object getValue();

  public abstract int getRevision();
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.history.HistoricVariableUpdate
 * JD-Core Version:    0.6.0
 */