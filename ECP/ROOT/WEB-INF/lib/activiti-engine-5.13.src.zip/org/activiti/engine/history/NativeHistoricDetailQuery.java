package org.activiti.engine.history;

import org.activiti.engine.query.NativeQuery;

public abstract interface NativeHistoricDetailQuery extends NativeQuery<NativeHistoricDetailQuery, HistoricDetail>
{
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.history.NativeHistoricDetailQuery
 * JD-Core Version:    0.6.0
 */