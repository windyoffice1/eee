package org.activiti.engine.identity;

import java.io.Serializable;

public abstract interface Group extends Serializable
{
  public abstract String getId();

  public abstract void setId(String paramString);

  public abstract String getName();

  public abstract void setName(String paramString);

  public abstract String getType();

  public abstract void setType(String paramString);
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.identity.Group
 * JD-Core Version:    0.6.0
 */