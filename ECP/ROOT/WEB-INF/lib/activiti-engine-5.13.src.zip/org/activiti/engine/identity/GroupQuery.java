package org.activiti.engine.identity;

import org.activiti.engine.query.Query;

public abstract interface GroupQuery extends Query<GroupQuery, Group>
{
  public abstract GroupQuery groupId(String paramString);

  public abstract GroupQuery groupName(String paramString);

  public abstract GroupQuery groupNameLike(String paramString);

  public abstract GroupQuery groupType(String paramString);

  public abstract GroupQuery groupMember(String paramString);

  public abstract GroupQuery potentialStarter(String paramString);

  public abstract GroupQuery orderByGroupId();

  public abstract GroupQuery orderByGroupName();

  public abstract GroupQuery orderByGroupType();
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.identity.GroupQuery
 * JD-Core Version:    0.6.0
 */