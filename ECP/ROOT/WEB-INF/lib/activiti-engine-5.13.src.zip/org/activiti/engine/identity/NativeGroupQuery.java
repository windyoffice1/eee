package org.activiti.engine.identity;

import org.activiti.engine.query.NativeQuery;

public abstract interface NativeGroupQuery extends NativeQuery<NativeGroupQuery, Group>
{
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.identity.NativeGroupQuery
 * JD-Core Version:    0.6.0
 */