/*    */ package org.activiti.engine.identity;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.InputStream;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class Picture
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 2384375526314443322L;
/*    */   protected byte[] bytes;
/*    */   protected String mimeType;
/*    */ 
/*    */   public Picture(byte[] bytes, String mimeType)
/*    */   {
/* 32 */     this.bytes = bytes;
/* 33 */     this.mimeType = mimeType;
/*    */   }
/*    */ 
/*    */   public byte[] getBytes() {
/* 37 */     return this.bytes;
/*    */   }
/*    */ 
/*    */   public InputStream getInputStream() {
/* 41 */     return new ByteArrayInputStream(this.bytes);
/*    */   }
/*    */ 
/*    */   public String getMimeType() {
/* 45 */     return this.mimeType;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.identity.Picture
 * JD-Core Version:    0.6.0
 */