package org.activiti.engine.identity;

import java.io.Serializable;

public abstract interface User extends Serializable
{
  public abstract String getId();

  public abstract void setId(String paramString);

  public abstract String getFirstName();

  public abstract void setFirstName(String paramString);

  public abstract void setLastName(String paramString);

  public abstract String getLastName();

  public abstract void setEmail(String paramString);

  public abstract String getEmail();

  public abstract String getPassword();

  public abstract void setPassword(String paramString);
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.identity.User
 * JD-Core Version:    0.6.0
 */