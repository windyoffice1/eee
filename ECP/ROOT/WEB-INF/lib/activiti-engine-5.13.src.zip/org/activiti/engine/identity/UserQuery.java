package org.activiti.engine.identity;

import org.activiti.engine.query.Query;

public abstract interface UserQuery extends Query<UserQuery, User>
{
  public abstract UserQuery userId(String paramString);

  public abstract UserQuery userFirstName(String paramString);

  public abstract UserQuery userFirstNameLike(String paramString);

  public abstract UserQuery userLastName(String paramString);

  public abstract UserQuery userLastNameLike(String paramString);

  public abstract UserQuery userFullNameLike(String paramString);

  public abstract UserQuery userEmail(String paramString);

  public abstract UserQuery userEmailLike(String paramString);

  public abstract UserQuery memberOfGroup(String paramString);

  public abstract UserQuery potentialStarter(String paramString);

  public abstract UserQuery orderByUserId();

  public abstract UserQuery orderByUserFirstName();

  public abstract UserQuery orderByUserLastName();

  public abstract UserQuery orderByUserEmail();
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.identity.UserQuery
 * JD-Core Version:    0.6.0
 */