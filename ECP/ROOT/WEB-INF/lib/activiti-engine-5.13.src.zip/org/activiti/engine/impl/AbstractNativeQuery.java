/*     */ package org.activiti.engine.impl;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.activiti.engine.ActivitiException;
/*     */ import org.activiti.engine.impl.context.Context;
/*     */ import org.activiti.engine.impl.interceptor.Command;
/*     */ import org.activiti.engine.impl.interceptor.CommandContext;
/*     */ import org.activiti.engine.impl.interceptor.CommandExecutor;
/*     */ import org.activiti.engine.query.NativeQuery;
/*     */ import org.apache.commons.lang.ObjectUtils;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public abstract class AbstractNativeQuery<T extends NativeQuery<?, ?>, U>
/*     */   implements Command<Object>, NativeQuery<T, U>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected transient CommandExecutor commandExecutor;
/*     */   protected transient CommandContext commandContext;
/*  46 */   protected int maxResults = 2147483647;
/*  47 */   protected int firstResult = 0;
/*     */   protected ResultType resultType;
/*  50 */   private Map<String, Object> parameters = new HashMap();
/*     */   private String sqlStatement;
/*     */ 
/*     */   protected AbstractNativeQuery(CommandExecutor commandExecutor)
/*     */   {
/*  54 */     this.commandExecutor = commandExecutor;
/*     */   }
/*     */ 
/*     */   public AbstractNativeQuery(CommandContext commandContext) {
/*  58 */     this.commandContext = commandContext;
/*     */   }
/*     */ 
/*     */   public AbstractNativeQuery<T, U> setCommandExecutor(CommandExecutor commandExecutor) {
/*  62 */     this.commandExecutor = commandExecutor;
/*  63 */     return this;
/*     */   }
/*     */ 
/*     */   public T sql(String sqlStatement)
/*     */   {
/*  68 */     this.sqlStatement = sqlStatement;
/*  69 */     return this;
/*     */   }
/*     */ 
/*     */   public T parameter(String name, Object value)
/*     */   {
/*  74 */     this.parameters.put(name, value);
/*  75 */     return this;
/*     */   }
/*     */ 
/*     */   public U singleResult()
/*     */   {
/*  80 */     this.resultType = ResultType.SINGLE_RESULT;
/*  81 */     if (this.commandExecutor != null) {
/*  82 */       return this.commandExecutor.execute(this);
/*     */     }
/*  84 */     return executeSingleResult(Context.getCommandContext());
/*     */   }
/*     */ 
/*     */   public List<U> list()
/*     */   {
/*  89 */     this.resultType = ResultType.LIST;
/*  90 */     if (this.commandExecutor != null) {
/*  91 */       return (List)this.commandExecutor.execute(this);
/*     */     }
/*  93 */     return executeList(Context.getCommandContext(), getParameterMap(), 0, 2147483647);
/*     */   }
/*     */ 
/*     */   public List<U> listPage(int firstResult, int maxResults)
/*     */   {
/*  98 */     this.firstResult = firstResult;
/*  99 */     this.maxResults = maxResults;
/* 100 */     this.resultType = ResultType.LIST_PAGE;
/* 101 */     if (this.commandExecutor != null) {
/* 102 */       return (List)this.commandExecutor.execute(this);
/*     */     }
/* 104 */     return executeList(Context.getCommandContext(), getParameterMap(), firstResult, maxResults);
/*     */   }
/*     */ 
/*     */   public long count() {
/* 108 */     this.resultType = ResultType.COUNT;
/* 109 */     if (this.commandExecutor != null) {
/* 110 */       return ((Long)this.commandExecutor.execute(this)).longValue();
/*     */     }
/* 112 */     return executeCount(Context.getCommandContext(), getParameterMap());
/*     */   }
/*     */ 
/*     */   public Object execute(CommandContext commandContext) {
/* 116 */     if (this.resultType == ResultType.LIST)
/* 117 */       return executeList(commandContext, getParameterMap(), 0, 2147483647);
/* 118 */     if (this.resultType == ResultType.LIST_PAGE) {
/* 119 */       Map parameterMap = getParameterMap();
/* 120 */       parameterMap.put("resultType", "LIST_PAGE");
/* 121 */       parameterMap.put("firstResult", Integer.valueOf(this.firstResult));
/* 122 */       parameterMap.put("maxResults", Integer.valueOf(this.maxResults));
/* 123 */       if (StringUtils.isNotBlank(ObjectUtils.toString(parameterMap.get("orderBy"))))
/* 124 */         parameterMap.put("orderBy", "RES." + parameterMap.get("orderBy"));
/*     */       else {
/* 126 */         parameterMap.put("orderBy", "RES.ID_ asc");
/*     */       }
/*     */ 
/* 129 */       int firstRow = this.firstResult + 1;
/* 130 */       parameterMap.put("firstRow", Integer.valueOf(firstRow));
/* 131 */       int lastRow = 0;
/* 132 */       if (this.maxResults == 2147483647) {
/* 133 */         lastRow = this.maxResults;
/*     */       }
/* 135 */       lastRow = this.firstResult + this.maxResults + 1;
/* 136 */       parameterMap.put("lastRow", Integer.valueOf(lastRow));
/* 137 */       return executeList(commandContext, parameterMap, this.firstResult, this.maxResults);
/* 138 */     }if (this.resultType == ResultType.SINGLE_RESULT) {
/* 139 */       return executeSingleResult(commandContext);
/*     */     }
/* 141 */     return Long.valueOf(executeCount(commandContext, getParameterMap()));
/*     */   }
/*     */ 
/*     */   public abstract long executeCount(CommandContext paramCommandContext, Map<String, Object> paramMap);
/*     */ 
/*     */   public abstract List<U> executeList(CommandContext paramCommandContext, Map<String, Object> paramMap, int paramInt1, int paramInt2);
/*     */ 
/*     */   public U executeSingleResult(CommandContext commandContext)
/*     */   {
/* 159 */     List results = executeList(commandContext, getParameterMap(), 0, 2147483647);
/* 160 */     if (results.size() == 1)
/* 161 */       return results.get(0);
/* 162 */     if (results.size() > 1) {
/* 163 */       throw new ActivitiException("Query return " + results.size() + " results instead of max 1");
/*     */     }
/* 165 */     return null;
/*     */   }
/*     */ 
/*     */   private Map<String, Object> getParameterMap() {
/* 169 */     HashMap parameterMap = new HashMap();
/* 170 */     parameterMap.put("sql", this.sqlStatement);
/* 171 */     parameterMap.putAll(this.parameters);
/* 172 */     return parameterMap;
/*     */   }
/*     */ 
/*     */   public Map<String, Object> getParameters() {
/* 176 */     return this.parameters;
/*     */   }
/*     */ 
/*     */   private static enum ResultType
/*     */   {
/*  40 */     LIST, LIST_PAGE, SINGLE_RESULT, COUNT;
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.AbstractNativeQuery
 * JD-Core Version:    0.6.0
 */