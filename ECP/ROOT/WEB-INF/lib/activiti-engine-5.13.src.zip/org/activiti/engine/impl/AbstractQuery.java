/*     */ package org.activiti.engine.impl;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.List;
/*     */ import org.activiti.engine.ActivitiException;
/*     */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*     */ import org.activiti.engine.impl.context.Context;
/*     */ import org.activiti.engine.impl.db.ListQueryParameterObject;
/*     */ import org.activiti.engine.impl.interceptor.Command;
/*     */ import org.activiti.engine.impl.interceptor.CommandContext;
/*     */ import org.activiti.engine.impl.interceptor.CommandExecutor;
/*     */ import org.activiti.engine.query.Query;
/*     */ import org.activiti.engine.query.QueryProperty;
/*     */ 
/*     */ public abstract class AbstractQuery<T extends Query<?, ?>, U> extends ListQueryParameterObject
/*     */   implements Command<Object>, Query<T, U>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final String SORTORDER_ASC = "asc";
/*     */   public static final String SORTORDER_DESC = "desc";
/*     */   protected transient CommandExecutor commandExecutor;
/*     */   protected transient CommandContext commandContext;
/*     */   protected String orderBy;
/*     */   protected ResultType resultType;
/*     */   protected QueryProperty orderProperty;
/*     */ 
/*     */   protected AbstractQuery()
/*     */   {
/*  54 */     this.parameter = this;
/*     */   }
/*     */ 
/*     */   protected AbstractQuery(CommandExecutor commandExecutor) {
/*  58 */     this.commandExecutor = commandExecutor;
/*     */   }
/*     */ 
/*     */   public AbstractQuery(CommandContext commandContext) {
/*  62 */     this.commandContext = commandContext;
/*     */   }
/*     */ 
/*     */   public AbstractQuery<T, U> setCommandExecutor(CommandExecutor commandExecutor) {
/*  66 */     this.commandExecutor = commandExecutor;
/*  67 */     return this;
/*     */   }
/*     */ 
/*     */   public T orderBy(QueryProperty property)
/*     */   {
/*  72 */     this.orderProperty = property;
/*  73 */     return this;
/*     */   }
/*     */ 
/*     */   public T asc() {
/*  77 */     return direction(Direction.ASCENDING);
/*     */   }
/*     */ 
/*     */   public T desc() {
/*  81 */     return direction(Direction.DESCENDING);
/*     */   }
/*     */ 
/*     */   public T direction(Direction direction)
/*     */   {
/*  86 */     if (this.orderProperty == null) {
/*  87 */       throw new ActivitiIllegalArgumentException("You should call any of the orderBy methods first before specifying a direction");
/*     */     }
/*  89 */     addOrder(this.orderProperty.getName(), direction.getName());
/*  90 */     this.orderProperty = null;
/*  91 */     return this;
/*     */   }
/*     */ 
/*     */   protected void checkQueryOk() {
/*  95 */     if (this.orderProperty != null)
/*  96 */       throw new ActivitiIllegalArgumentException("Invalid query: call asc() or desc() after using orderByXX()");
/*     */   }
/*     */ 
/*     */   public U singleResult()
/*     */   {
/* 102 */     this.resultType = ResultType.SINGLE_RESULT;
/* 103 */     if (this.commandExecutor != null) {
/* 104 */       return this.commandExecutor.execute(this);
/*     */     }
/* 106 */     return executeSingleResult(Context.getCommandContext());
/*     */   }
/*     */ 
/*     */   public List<U> list()
/*     */   {
/* 111 */     this.resultType = ResultType.LIST;
/* 112 */     if (this.commandExecutor != null) {
/* 113 */       return (List)this.commandExecutor.execute(this);
/*     */     }
/* 115 */     return executeList(Context.getCommandContext(), null);
/*     */   }
/*     */ 
/*     */   public List<U> listPage(int firstResult, int maxResults)
/*     */   {
/* 120 */     this.firstResult = firstResult;
/* 121 */     this.maxResults = maxResults;
/* 122 */     this.resultType = ResultType.LIST_PAGE;
/* 123 */     if (this.commandExecutor != null) {
/* 124 */       return (List)this.commandExecutor.execute(this);
/*     */     }
/* 126 */     return executeList(Context.getCommandContext(), new Page(firstResult, maxResults));
/*     */   }
/*     */ 
/*     */   public long count() {
/* 130 */     this.resultType = ResultType.COUNT;
/* 131 */     if (this.commandExecutor != null) {
/* 132 */       return ((Long)this.commandExecutor.execute(this)).longValue();
/*     */     }
/* 134 */     return executeCount(Context.getCommandContext());
/*     */   }
/*     */ 
/*     */   public Object execute(CommandContext commandContext) {
/* 138 */     if (this.resultType == ResultType.LIST)
/* 139 */       return executeList(commandContext, null);
/* 140 */     if (this.resultType == ResultType.SINGLE_RESULT)
/* 141 */       return executeSingleResult(commandContext);
/* 142 */     if (this.resultType == ResultType.LIST_PAGE) {
/* 143 */       return executeList(commandContext, null);
/*     */     }
/* 145 */     return Long.valueOf(executeCount(commandContext));
/*     */   }
/*     */ 
/*     */   public abstract long executeCount(CommandContext paramCommandContext);
/*     */ 
/*     */   public abstract List<U> executeList(CommandContext paramCommandContext, Page paramPage);
/*     */ 
/*     */   public U executeSingleResult(CommandContext commandContext)
/*     */   {
/* 158 */     List results = executeList(commandContext, null);
/* 159 */     if (results.size() == 1)
/* 160 */       return results.get(0);
/* 161 */     if (results.size() > 1) {
/* 162 */       throw new ActivitiException("Query return " + results.size() + " results instead of max 1");
/*     */     }
/* 164 */     return null;
/*     */   }
/*     */ 
/*     */   protected void addOrder(String column, String sortOrder) {
/* 168 */     if (this.orderBy == null)
/* 169 */       this.orderBy = "";
/*     */     else {
/* 171 */       this.orderBy += ", ";
/*     */     }
/* 173 */     this.orderBy = (this.orderBy + column + " " + sortOrder);
/*     */   }
/*     */ 
/*     */   public String getOrderBy() {
/* 177 */     if (this.orderBy == null) {
/* 178 */       return super.getOrderBy();
/*     */     }
/* 180 */     return this.orderBy;
/*     */   }
/*     */ 
/*     */   private static enum ResultType
/*     */   {
/*  42 */     LIST, LIST_PAGE, SINGLE_RESULT, COUNT;
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.AbstractQuery
 * JD-Core Version:    0.6.0
 */