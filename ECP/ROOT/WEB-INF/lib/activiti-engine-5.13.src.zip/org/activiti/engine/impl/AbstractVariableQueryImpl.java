/*     */ package org.activiti.engine.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*     */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*     */ import org.activiti.engine.impl.context.Context;
/*     */ import org.activiti.engine.impl.interceptor.CommandContext;
/*     */ import org.activiti.engine.impl.interceptor.CommandExecutor;
/*     */ import org.activiti.engine.impl.variable.VariableTypes;
/*     */ import org.activiti.engine.query.Query;
/*     */ 
/*     */ public abstract class AbstractVariableQueryImpl<T extends Query<?, ?>, U> extends AbstractQuery<T, U>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  37 */   protected List<QueryVariableValue> queryVariableValues = new ArrayList();
/*     */ 
/*     */   public AbstractVariableQueryImpl() {
/*     */   }
/*     */ 
/*     */   public AbstractVariableQueryImpl(CommandContext commandContext) {
/*  43 */     super(commandContext);
/*     */   }
/*     */ 
/*     */   public AbstractVariableQueryImpl(CommandExecutor commandExecutor) {
/*  47 */     super(commandExecutor);
/*     */   }
/*     */ 
/*     */   public abstract long executeCount(CommandContext paramCommandContext);
/*     */ 
/*     */   public abstract List<U> executeList(CommandContext paramCommandContext, Page paramPage);
/*     */ 
/*     */   public T variableValueEquals(String name, Object value)
/*     */   {
/*  59 */     addVariable(name, value, QueryOperator.EQUALS, true);
/*  60 */     return this;
/*     */   }
/*     */ 
/*     */   public T variableValueEquals(Object value)
/*     */   {
/*  65 */     this.queryVariableValues.add(new QueryVariableValue(null, value, QueryOperator.EQUALS, true));
/*  66 */     return this;
/*     */   }
/*     */ 
/*     */   public T variableValueEqualsIgnoreCase(String name, String value)
/*     */   {
/*  71 */     if (value == null) {
/*  72 */       throw new ActivitiIllegalArgumentException("value is null");
/*     */     }
/*  74 */     addVariable(name, value.toLowerCase(), QueryOperator.EQUALS_IGNORE_CASE, true);
/*  75 */     return this;
/*     */   }
/*     */ 
/*     */   public T variableValueNotEqualsIgnoreCase(String name, String value)
/*     */   {
/*  80 */     if (value == null) {
/*  81 */       throw new ActivitiIllegalArgumentException("value is null");
/*     */     }
/*  83 */     addVariable(name, value.toLowerCase(), QueryOperator.NOT_EQUALS_IGNORE_CASE, true);
/*  84 */     return this;
/*     */   }
/*     */ 
/*     */   public T variableValueNotEquals(String name, Object value)
/*     */   {
/*  89 */     addVariable(name, value, QueryOperator.NOT_EQUALS, true);
/*  90 */     return this;
/*     */   }
/*     */ 
/*     */   public T variableValueGreaterThan(String name, Object value)
/*     */   {
/*  95 */     addVariable(name, value, QueryOperator.GREATER_THAN, true);
/*  96 */     return this;
/*     */   }
/*     */ 
/*     */   public T variableValueGreaterThanOrEqual(String name, Object value)
/*     */   {
/* 101 */     addVariable(name, value, QueryOperator.GREATER_THAN_OR_EQUAL, true);
/* 102 */     return this;
/*     */   }
/*     */ 
/*     */   public T variableValueLessThan(String name, Object value)
/*     */   {
/* 107 */     addVariable(name, value, QueryOperator.LESS_THAN, true);
/* 108 */     return this;
/*     */   }
/*     */ 
/*     */   public T variableValueLessThanOrEqual(String name, Object value)
/*     */   {
/* 113 */     addVariable(name, value, QueryOperator.LESS_THAN_OR_EQUAL, true);
/* 114 */     return this;
/*     */   }
/*     */ 
/*     */   public T variableValueLike(String name, String value)
/*     */   {
/* 119 */     addVariable(name, value, QueryOperator.LIKE, true);
/* 120 */     return this;
/*     */   }
/*     */ 
/*     */   public T processVariableValueEquals(String variableName, Object variableValue)
/*     */   {
/* 125 */     addVariable(variableName, variableValue, QueryOperator.EQUALS, false);
/* 126 */     return this;
/*     */   }
/*     */ 
/*     */   public T processVariableValueEquals(Object value)
/*     */   {
/* 131 */     this.queryVariableValues.add(new QueryVariableValue(null, value, QueryOperator.EQUALS, false));
/* 132 */     return this;
/*     */   }
/*     */ 
/*     */   public T processVariableValueNotEquals(String variableName, Object variableValue)
/*     */   {
/* 137 */     addVariable(variableName, variableValue, QueryOperator.NOT_EQUALS, false);
/* 138 */     return this;
/*     */   }
/*     */ 
/*     */   public T processVariableValueEqualsIgnoreCase(String name, String value)
/*     */   {
/* 143 */     if (value == null) {
/* 144 */       throw new ActivitiIllegalArgumentException("value is null");
/*     */     }
/* 146 */     addVariable(name, value.toLowerCase(), QueryOperator.EQUALS_IGNORE_CASE, false);
/* 147 */     return this;
/*     */   }
/*     */ 
/*     */   public T processVariableValueNotEqualsIgnoreCase(String name, String value)
/*     */   {
/* 152 */     if (value == null) {
/* 153 */       throw new ActivitiIllegalArgumentException("value is null");
/*     */     }
/* 155 */     addVariable(name, value.toLowerCase(), QueryOperator.NOT_EQUALS_IGNORE_CASE, false);
/* 156 */     return this;
/*     */   }
/*     */ 
/*     */   private void addVariable(String name, Object value, QueryOperator operator, boolean localScope)
/*     */   {
/* 161 */     if (name == null) {
/* 162 */       throw new ActivitiIllegalArgumentException("name is null");
/*     */     }
/* 164 */     if ((value == null) || (isBoolean(value)))
/*     */     {
/* 166 */       switch (1.$SwitchMap$org$activiti$engine$impl$QueryOperator[operator.ordinal()]) {
/*     */       case 1:
/* 168 */         throw new ActivitiIllegalArgumentException("Booleans and null cannot be used in 'greater than' condition");
/*     */       case 2:
/* 170 */         throw new ActivitiIllegalArgumentException("Booleans and null cannot be used in 'less than' condition");
/*     */       case 3:
/* 172 */         throw new ActivitiIllegalArgumentException("Booleans and null cannot be used in 'greater than or equal' condition");
/*     */       case 4:
/* 174 */         throw new ActivitiIllegalArgumentException("Booleans and null cannot be used in 'less than or equal' condition");
/*     */       }
/*     */ 
/* 177 */       if ((operator == QueryOperator.EQUALS_IGNORE_CASE) && ((value == null) || (!(value instanceof String))))
/*     */       {
/* 179 */         throw new ActivitiIllegalArgumentException("Only string values can be used with 'equals ignore case' condition");
/*     */       }
/*     */ 
/* 182 */       if ((operator == QueryOperator.NOT_EQUALS_IGNORE_CASE) && ((value == null) || (!(value instanceof String))))
/*     */       {
/* 184 */         throw new ActivitiIllegalArgumentException("Only string values can be used with 'not equals ignore case' condition");
/*     */       }
/*     */ 
/* 187 */       if ((operator == QueryOperator.LIKE) && ((value == null) || (!(value instanceof String))))
/*     */       {
/* 189 */         throw new ActivitiIllegalArgumentException("Only string values can be used with 'like' condition");
/*     */       }
/*     */     }
/* 192 */     this.queryVariableValues.add(new QueryVariableValue(name, value, operator, localScope));
/*     */   }
/*     */ 
/*     */   private boolean isBoolean(Object value) {
/* 196 */     if (value == null) {
/* 197 */       return false;
/*     */     }
/* 199 */     return (Boolean.class.isAssignableFrom(value.getClass())) || (Boolean.TYPE.isAssignableFrom(value.getClass()));
/*     */   }
/*     */ 
/*     */   protected void ensureVariablesInitialized()
/*     */   {
/*     */     VariableTypes variableTypes;
/* 203 */     if (!this.queryVariableValues.isEmpty()) {
/* 204 */       variableTypes = Context.getProcessEngineConfiguration().getVariableTypes();
/*     */ 
/* 207 */       for (QueryVariableValue queryVariableValue : this.queryVariableValues)
/* 208 */         queryVariableValue.initialize(variableTypes);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<QueryVariableValue> getQueryVariableValues()
/*     */   {
/* 214 */     return this.queryVariableValues;
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.AbstractVariableQueryImpl
 * JD-Core Version:    0.6.0
 */