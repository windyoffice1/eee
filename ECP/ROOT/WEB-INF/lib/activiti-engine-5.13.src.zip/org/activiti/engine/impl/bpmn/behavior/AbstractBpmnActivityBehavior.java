/*    */ package org.activiti.engine.impl.bpmn.behavior;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.activiti.engine.impl.bpmn.helper.ScopeUtil;
/*    */ import org.activiti.engine.impl.persistence.entity.CompensateEventSubscriptionEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ import org.activiti.engine.impl.pvm.PvmActivity;
/*    */ import org.activiti.engine.impl.pvm.PvmScope;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ import org.activiti.engine.impl.pvm.process.ProcessDefinitionImpl;
/*    */ import org.activiti.engine.impl.pvm.runtime.InterpretableExecution;
/*    */ 
/*    */ public class AbstractBpmnActivityBehavior extends FlowNodeActivityBehavior
/*    */ {
/*    */   protected MultiInstanceActivityBehavior multiInstanceActivityBehavior;
/*    */ 
/*    */   protected void leave(ActivityExecution execution)
/*    */   {
/* 43 */     if (hasCompensationHandler(execution)) {
/* 44 */       createCompensateEventSubscription(execution);
/*    */     }
/* 46 */     if (!hasLoopCharacteristics())
/* 47 */       super.leave(execution);
/* 48 */     else if (hasMultiInstanceCharacteristics())
/* 49 */       this.multiInstanceActivityBehavior.leave(execution);
/*    */   }
/*    */ 
/*    */   protected boolean hasCompensationHandler(ActivityExecution execution)
/*    */   {
/* 54 */     return execution.getActivity().getProperty("compensationHandler") != null;
/*    */   }
/*    */ 
/*    */   protected void createCompensateEventSubscription(ActivityExecution execution) {
/* 58 */     String compensationHandlerId = (String)execution.getActivity().getProperty("compensationHandler");
/*    */ 
/* 60 */     ExecutionEntity executionEntity = (ExecutionEntity)execution;
/* 61 */     ActivityImpl compensationHandlder = executionEntity.getProcessDefinition().findActivity(compensationHandlerId);
/* 62 */     PvmScope scopeActivitiy = compensationHandlder.getParent();
/* 63 */     ExecutionEntity scopeExecution = ScopeUtil.findScopeExecutionForScope(executionEntity, scopeActivitiy);
/*    */ 
/* 65 */     CompensateEventSubscriptionEntity compensateEventSubscriptionEntity = CompensateEventSubscriptionEntity.createAndInsert(scopeExecution);
/* 66 */     compensateEventSubscriptionEntity.setActivity(compensationHandlder);
/*    */   }
/*    */ 
/*    */   protected boolean hasLoopCharacteristics() {
/* 70 */     return hasMultiInstanceCharacteristics();
/*    */   }
/*    */ 
/*    */   protected boolean hasMultiInstanceCharacteristics() {
/* 74 */     return this.multiInstanceActivityBehavior != null;
/*    */   }
/*    */ 
/*    */   public MultiInstanceActivityBehavior getMultiInstanceActivityBehavior() {
/* 78 */     return this.multiInstanceActivityBehavior;
/*    */   }
/*    */ 
/*    */   public void setMultiInstanceActivityBehavior(MultiInstanceActivityBehavior multiInstanceActivityBehavior) {
/* 82 */     this.multiInstanceActivityBehavior = multiInstanceActivityBehavior;
/*    */   }
/*    */ 
/*    */   public void signal(ActivityExecution execution, String signalName, Object signalData) throws Exception
/*    */   {
/* 87 */     if ("compensationDone".equals(signalName))
/* 88 */       signalCompensationDone(execution, signalData);
/*    */     else
/* 90 */       super.signal(execution, signalName, signalData);
/*    */   }
/*    */ 
/*    */   protected void signalCompensationDone(ActivityExecution execution, Object signalData)
/*    */   {
/* 99 */     if (execution.getExecutions().isEmpty()) {
/* 100 */       if (execution.getParent() != null) {
/* 101 */         ActivityExecution parent = execution.getParent();
/* 102 */         ((InterpretableExecution)execution).remove();
/* 103 */         ((InterpretableExecution)parent).signal("compensationDone", signalData);
/*    */       }
/*    */     }
/* 106 */     else ((ExecutionEntity)execution).forceUpdate();
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.AbstractBpmnActivityBehavior
 * JD-Core Version:    0.6.0
 */