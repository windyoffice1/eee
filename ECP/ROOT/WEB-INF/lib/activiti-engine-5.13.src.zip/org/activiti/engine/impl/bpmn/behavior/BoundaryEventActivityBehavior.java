/*    */ package org.activiti.engine.impl.bpmn.behavior;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ import org.activiti.engine.impl.pvm.PvmActivity;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ import org.activiti.engine.impl.pvm.process.ProcessDefinitionImpl;
/*    */ 
/*    */ public class BoundaryEventActivityBehavior extends FlowNodeActivityBehavior
/*    */ {
/*    */   protected boolean interrupting;
/*    */   protected String activityId;
/*    */ 
/*    */   public BoundaryEventActivityBehavior()
/*    */   {
/*    */   }
/*    */ 
/*    */   public BoundaryEventActivityBehavior(boolean interrupting, String activityId)
/*    */   {
/* 38 */     this.interrupting = interrupting;
/* 39 */     this.activityId = activityId;
/*    */   }
/*    */ 
/*    */   public void execute(ActivityExecution execution) throws Exception
/*    */   {
/* 44 */     ExecutionEntity executionEntity = (ExecutionEntity)execution;
/* 45 */     ActivityImpl boundaryActivity = executionEntity.getProcessDefinition().findActivity(this.activityId);
/* 46 */     ActivityImpl interruptedActivity = executionEntity.getActivity();
/*    */ 
/* 48 */     executionEntity.setActivity(boundaryActivity);
/*    */ 
/* 50 */     List outgoingTransitions = boundaryActivity.getOutgoingTransitions();
/* 51 */     List interruptedExecutions = null;
/*    */ 
/* 53 */     if (this.interrupting) {
/* 54 */       if (executionEntity.getSubProcessInstance() != null) {
/* 55 */         executionEntity.getSubProcessInstance().deleteCascade(executionEntity.getDeleteReason());
/*    */       }
/*    */ 
/* 58 */       interruptedExecutions = new ArrayList(executionEntity.getExecutions());
/* 59 */       for (ExecutionEntity interruptedExecution : interruptedExecutions) {
/* 60 */         interruptedExecution.deleteCascade("interrupting boundary event '" + execution.getActivity().getId() + "' fired");
/*    */       }
/*    */ 
/* 63 */       execution.takeAll(outgoingTransitions, interruptedExecutions);
/*    */     }
/*    */     else
/*    */     {
/* 69 */       ExecutionEntity concurrentRoot = executionEntity.getParent().isConcurrent() ? executionEntity.getParent() : executionEntity;
/* 70 */       ExecutionEntity outgoingExecution = concurrentRoot.createExecution();
/*    */ 
/* 72 */       outgoingExecution.setActive(true);
/* 73 */       outgoingExecution.setScope(false);
/* 74 */       outgoingExecution.setConcurrent(true);
/*    */ 
/* 76 */       outgoingExecution.takeAll(outgoingTransitions, Collections.EMPTY_LIST);
/* 77 */       outgoingExecution.remove();
/*    */ 
/* 81 */       executionEntity.setActivity(interruptedActivity);
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean isInterrupting() {
/* 86 */     return this.interrupting;
/*    */   }
/*    */ 
/*    */   public void setInterrupting(boolean interrupting) {
/* 90 */     this.interrupting = interrupting;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.BoundaryEventActivityBehavior
 * JD-Core Version:    0.6.0
 */