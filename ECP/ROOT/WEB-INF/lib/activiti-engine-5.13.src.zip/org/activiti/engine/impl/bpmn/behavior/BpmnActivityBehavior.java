/*     */ package org.activiti.engine.impl.bpmn.behavior;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.activiti.engine.ActivitiException;
/*     */ import org.activiti.engine.impl.Condition;
/*     */ import org.activiti.engine.impl.pvm.PvmActivity;
/*     */ import org.activiti.engine.impl.pvm.PvmTransition;
/*     */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*     */ import org.activiti.engine.impl.pvm.runtime.InterpretableExecution;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class BpmnActivityBehavior
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  42 */   private static Logger log = LoggerFactory.getLogger(BpmnActivityBehavior.class);
/*     */ 
/*     */   public void performDefaultOutgoingBehavior(ActivityExecution activityExceution)
/*     */   {
/*  54 */     performOutgoingBehavior(activityExceution, true, false, null);
/*     */   }
/*     */ 
/*     */   public void performIgnoreConditionsOutgoingBehavior(ActivityExecution activityExecution)
/*     */   {
/*  68 */     performOutgoingBehavior(activityExecution, false, false, null);
/*     */   }
/*     */ 
/*     */   protected void performOutgoingBehavior(ActivityExecution execution, boolean checkConditions, boolean throwExceptionIfExecutionStuck, List<ActivityExecution> reusableExecutions)
/*     */   {
/*  86 */     if (log.isDebugEnabled()) {
/*  87 */       log.debug("Leaving activity '{}'", execution.getActivity().getId());
/*     */     }
/*     */ 
/*  90 */     String defaultSequenceFlow = (String)execution.getActivity().getProperty("default");
/*  91 */     List transitionsToTake = new ArrayList();
/*     */ 
/*  93 */     List outgoingTransitions = execution.getActivity().getOutgoingTransitions();
/*  94 */     for (PvmTransition outgoingTransition : outgoingTransitions) {
/*  95 */       if ((defaultSequenceFlow == null) || (!outgoingTransition.getId().equals(defaultSequenceFlow))) {
/*  96 */         Condition condition = (Condition)outgoingTransition.getProperty("condition");
/*  97 */         if ((condition == null) || (!checkConditions) || (condition.evaluate(execution))) {
/*  98 */           transitionsToTake.add(outgoingTransition);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 103 */     if (transitionsToTake.size() == 1)
/*     */     {
/* 105 */       execution.take((PvmTransition)transitionsToTake.get(0));
/*     */     }
/* 107 */     else if (transitionsToTake.size() >= 1)
/*     */     {
/* 109 */       execution.inactivate();
/* 110 */       if ((reusableExecutions == null) || (reusableExecutions.isEmpty()))
/* 111 */         execution.takeAll(transitionsToTake, Arrays.asList(new ActivityExecution[] { execution }));
/*     */       else {
/* 113 */         execution.takeAll(transitionsToTake, reusableExecutions);
/*     */       }
/*     */ 
/*     */     }
/* 118 */     else if (defaultSequenceFlow != null) {
/* 119 */       PvmTransition defaultTransition = execution.getActivity().findOutgoingTransition(defaultSequenceFlow);
/* 120 */       if (defaultTransition != null)
/* 121 */         execution.take(defaultTransition);
/*     */       else
/* 123 */         throw new ActivitiException("Default sequence flow '" + defaultSequenceFlow + "' could not be not found");
/*     */     }
/*     */     else
/*     */     {
/* 127 */       Object isForCompensation = execution.getActivity().getProperty("isForCompensation");
/* 128 */       if ((isForCompensation != null) && (((Boolean)isForCompensation).booleanValue()))
/*     */       {
/* 130 */         InterpretableExecution parentExecution = (InterpretableExecution)execution.getParent();
/* 131 */         ((InterpretableExecution)execution).remove();
/* 132 */         parentExecution.signal("compensationDone", null);
/*     */       }
/*     */       else
/*     */       {
/* 136 */         if (log.isDebugEnabled()) {
/* 137 */           log.debug("No outgoing sequence flow found for {}. Ending execution.", execution.getActivity().getId());
/*     */         }
/* 139 */         execution.end();
/*     */ 
/* 141 */         if (throwExceptionIfExecutionStuck)
/* 142 */           throw new ActivitiException("No outgoing sequence flow of the inclusive gateway '" + execution.getActivity().getId() + "' could be selected for continuing the process");
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.BpmnActivityBehavior
 * JD-Core Version:    0.6.0
 */