/*    */ package org.activiti.engine.impl.bpmn.behavior;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ import org.activiti.engine.delegate.Expression;
/*    */ import org.activiti.engine.impl.pvm.PvmActivity;
/*    */ import org.activiti.engine.impl.pvm.PvmProcessDefinition;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ import org.activiti.engine.impl.rules.RulesAgendaFilter;
/*    */ import org.activiti.engine.impl.rules.RulesHelper;
/*    */ import org.drools.KnowledgeBase;
/*    */ import org.drools.runtime.StatefulKnowledgeSession;
/*    */ 
/*    */ public class BusinessRuleTaskActivityBehavior extends TaskActivityBehavior
/*    */ {
/* 37 */   protected Set<Expression> variablesInputExpressions = new HashSet();
/* 38 */   protected Set<Expression> rulesExpressions = new HashSet();
/* 39 */   protected boolean exclude = false;
/*    */   protected String resultVariable;
/*    */ 
/*    */   public void execute(ActivityExecution execution)
/*    */     throws Exception
/*    */   {
/* 45 */     PvmProcessDefinition processDefinition = execution.getActivity().getProcessDefinition();
/* 46 */     String deploymentId = processDefinition.getDeploymentId();
/*    */ 
/* 48 */     KnowledgeBase knowledgeBase = RulesHelper.findKnowledgeBaseByDeploymentId(deploymentId);
/* 49 */     StatefulKnowledgeSession ksession = knowledgeBase.newStatefulKnowledgeSession();
/*    */ 
/* 51 */     if (this.variablesInputExpressions != null) {
/* 52 */       Iterator itVariable = this.variablesInputExpressions.iterator();
/* 53 */       while (itVariable.hasNext()) {
/* 54 */         Expression variable = (Expression)itVariable.next();
/* 55 */         ksession.insert(variable.getValue(execution));
/*    */       }
/*    */     }
/*    */ 
/* 59 */     if (this.rulesExpressions.size() > 0) {
/* 60 */       RulesAgendaFilter filter = new RulesAgendaFilter();
/* 61 */       Iterator itRuleNames = this.rulesExpressions.iterator();
/* 62 */       while (itRuleNames.hasNext()) {
/* 63 */         Expression ruleName = (Expression)itRuleNames.next();
/* 64 */         filter.addSuffic(ruleName.getValue(execution).toString());
/*    */       }
/* 66 */       filter.setAccept(!this.exclude);
/* 67 */       ksession.fireAllRules(filter);
/*    */     }
/*    */     else {
/* 70 */       ksession.fireAllRules();
/*    */     }
/*    */ 
/* 73 */     Collection ruleOutputObjects = ksession.getObjects();
/* 74 */     if ((ruleOutputObjects != null) && (ruleOutputObjects.size() > 0)) {
/* 75 */       Collection outputVariables = new ArrayList();
/* 76 */       for (Iterator i$ = ruleOutputObjects.iterator(); i$.hasNext(); ) { Object object = i$.next();
/* 77 */         outputVariables.add(object);
/*    */       }
/* 79 */       execution.setVariable(this.resultVariable, outputVariables);
/*    */     }
/* 81 */     ksession.dispose();
/* 82 */     leave(execution);
/*    */   }
/*    */ 
/*    */   public void addRuleVariableInputIdExpression(Expression inputId) {
/* 86 */     this.variablesInputExpressions.add(inputId);
/*    */   }
/*    */ 
/*    */   public void addRuleIdExpression(Expression inputId) {
/* 90 */     this.rulesExpressions.add(inputId);
/*    */   }
/*    */ 
/*    */   public void setExclude(boolean exclude) {
/* 94 */     this.exclude = exclude;
/*    */   }
/*    */ 
/*    */   public void setResultVariable(String resultVariableName) {
/* 98 */     this.resultVariable = resultVariableName;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.BusinessRuleTaskActivityBehavior
 * JD-Core Version:    0.6.0
 */