/*     */ package org.activiti.engine.impl.bpmn.behavior;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.activiti.engine.delegate.DelegateExecution;
/*     */ import org.activiti.engine.delegate.Expression;
/*     */ import org.activiti.engine.impl.bpmn.data.AbstractDataAssociation;
/*     */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*     */ import org.activiti.engine.impl.context.Context;
/*     */ import org.activiti.engine.impl.persistence.deploy.DeploymentManager;
/*     */ import org.activiti.engine.impl.pvm.PvmProcessInstance;
/*     */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*     */ import org.activiti.engine.impl.pvm.delegate.SubProcessActivityBehavior;
/*     */ import org.activiti.engine.impl.pvm.process.ProcessDefinitionImpl;
/*     */ 
/*     */ public class CallActivityBehavior extends AbstractBpmnActivityBehavior
/*     */   implements SubProcessActivityBehavior
/*     */ {
/*     */   protected String processDefinitonKey;
/*  38 */   private List<AbstractDataAssociation> dataInputAssociations = new ArrayList();
/*  39 */   private List<AbstractDataAssociation> dataOutputAssociations = new ArrayList();
/*     */   private Expression processDefinitionExpression;
/*     */ 
/*     */   public CallActivityBehavior(String processDefinitionKey)
/*     */   {
/*  43 */     this.processDefinitonKey = processDefinitionKey;
/*     */   }
/*     */ 
/*     */   public CallActivityBehavior(Expression processDefinitionExpression)
/*     */   {
/*  48 */     this.processDefinitionExpression = processDefinitionExpression;
/*     */   }
/*     */ 
/*     */   public void addDataInputAssociation(AbstractDataAssociation dataInputAssociation) {
/*  52 */     this.dataInputAssociations.add(dataInputAssociation);
/*     */   }
/*     */ 
/*     */   public void addDataOutputAssociation(AbstractDataAssociation dataOutputAssociation) {
/*  56 */     this.dataOutputAssociations.add(dataOutputAssociation);
/*     */   }
/*     */ 
/*     */   public void execute(ActivityExecution execution) throws Exception
/*     */   {
/*  61 */     String processDefinitonKey = this.processDefinitonKey;
/*  62 */     if (this.processDefinitionExpression != null) {
/*  63 */       processDefinitonKey = (String)this.processDefinitionExpression.getValue(execution);
/*     */     }
/*     */ 
/*  66 */     ProcessDefinitionImpl processDefinition = Context.getProcessEngineConfiguration().getDeploymentManager().findDeployedLatestProcessDefinitionByKey(processDefinitonKey);
/*     */ 
/*  71 */     PvmProcessInstance subProcessInstance = execution.createSubProcessInstance(processDefinition);
/*     */ 
/*  74 */     for (AbstractDataAssociation dataInputAssociation : this.dataInputAssociations) {
/*  75 */       Object value = null;
/*  76 */       if (dataInputAssociation.getSourceExpression() != null) {
/*  77 */         value = dataInputAssociation.getSourceExpression().getValue(execution);
/*     */       }
/*     */       else {
/*  80 */         value = execution.getVariable(dataInputAssociation.getSource());
/*     */       }
/*  82 */       subProcessInstance.setVariable(dataInputAssociation.getTarget(), value);
/*     */     }
/*     */ 
/*  85 */     subProcessInstance.start();
/*     */   }
/*     */ 
/*     */   public void setProcessDefinitonKey(String processDefinitonKey) {
/*  89 */     this.processDefinitonKey = processDefinitonKey;
/*     */   }
/*     */ 
/*     */   public String getProcessDefinitonKey() {
/*  93 */     return this.processDefinitonKey;
/*     */   }
/*     */ 
/*     */   public void completing(DelegateExecution execution, DelegateExecution subProcessInstance)
/*     */     throws Exception
/*     */   {
/* 100 */     for (AbstractDataAssociation dataOutputAssociation : this.dataOutputAssociations) {
/* 101 */       Object value = null;
/* 102 */       if (dataOutputAssociation.getSourceExpression() != null) {
/* 103 */         value = dataOutputAssociation.getSourceExpression().getValue(subProcessInstance);
/*     */       }
/*     */       else {
/* 106 */         value = subProcessInstance.getVariable(dataOutputAssociation.getSource());
/*     */       }
/*     */ 
/* 109 */       execution.setVariable(dataOutputAssociation.getTarget(), value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void completed(ActivityExecution execution) throws Exception
/*     */   {
/* 115 */     leave(execution);
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.CallActivityBehavior
 * JD-Core Version:    0.6.0
 */