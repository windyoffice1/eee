/*    */ package org.activiti.engine.impl.bpmn.behavior;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.activiti.engine.impl.bpmn.helper.ScopeUtil;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ 
/*    */ public class CancelBoundaryEventActivityBehavior extends FlowNodeActivityBehavior
/*    */ {
/*    */   public void execute(ActivityExecution execution)
/*    */     throws Exception
/*    */   {
/* 32 */     List eventSubscriptions = ((ExecutionEntity)execution).getCompensateEventSubscriptions();
/*    */ 
/* 34 */     if (eventSubscriptions.isEmpty()) {
/* 35 */       leave(execution);
/*    */     }
/*    */     else
/* 38 */       ScopeUtil.throwCompensationEvent(eventSubscriptions, execution, false);
/*    */   }
/*    */ 
/*    */   public void signal(ActivityExecution execution, String signalName, Object signalData)
/*    */     throws Exception
/*    */   {
/* 47 */     if (execution.getExecutions().isEmpty())
/* 48 */       leave(execution);
/*    */     else
/* 50 */       ((ExecutionEntity)execution).forceUpdate();
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.CancelBoundaryEventActivityBehavior
 * JD-Core Version:    0.6.0
 */