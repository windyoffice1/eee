/*    */ package org.activiti.engine.impl.bpmn.behavior;
/*    */ 
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.impl.bpmn.helper.ScopeUtil;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityBehavior;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ import org.activiti.engine.impl.pvm.runtime.InterpretableExecution;
/*    */ 
/*    */ public class CancelEndEventActivityBehavior extends FlowNodeActivityBehavior
/*    */ {
/*    */   public void execute(ActivityExecution execution)
/*    */     throws Exception
/*    */   {
/* 34 */     ActivityImpl cancelBoundaryEvent = ScopeUtil.findInParentScopesByBehaviorType((ActivityImpl)execution.getActivity(), CancelBoundaryEventActivityBehavior.class);
/*    */ 
/* 37 */     if (cancelBoundaryEvent == null) {
/* 38 */       throw new ActivitiException("Could not find cancel boundary event for cancel end event " + execution.getActivity());
/*    */     }
/*    */ 
/* 41 */     ActivityExecution scopeExecution = ScopeUtil.findScopeExecutionForScope((ExecutionEntity)execution, cancelBoundaryEvent.getParentActivity());
/*    */ 
/* 44 */     scopeExecution.destroyScope("cancel end event fired");
/*    */ 
/* 47 */     InterpretableExecution outgoingExecution = (InterpretableExecution)scopeExecution;
/* 48 */     outgoingExecution.setActivity(cancelBoundaryEvent);
/* 49 */     outgoingExecution.setActive(true);
/*    */ 
/* 52 */     cancelBoundaryEvent.getActivityBehavior().execute(outgoingExecution);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.CancelEndEventActivityBehavior
 * JD-Core Version:    0.6.0
 */