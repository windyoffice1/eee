/*    */ package org.activiti.engine.impl.bpmn.behavior;
/*    */ 
/*    */ import org.activiti.engine.impl.bpmn.helper.ErrorPropagation;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ 
/*    */ public class ErrorEndEventActivityBehavior extends FlowNodeActivityBehavior
/*    */ {
/*    */   protected String errorCode;
/*    */ 
/*    */   public ErrorEndEventActivityBehavior(String errorCode)
/*    */   {
/* 28 */     this.errorCode = errorCode;
/*    */   }
/*    */ 
/*    */   public void execute(ActivityExecution execution) throws Exception {
/* 32 */     ErrorPropagation.propagateError(this.errorCode, execution);
/*    */   }
/*    */ 
/*    */   public String getErrorCode() {
/* 36 */     return this.errorCode;
/*    */   }
/*    */   public void setErrorCode(String errorCode) {
/* 39 */     this.errorCode = errorCode;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.ErrorEndEventActivityBehavior
 * JD-Core Version:    0.6.0
 */