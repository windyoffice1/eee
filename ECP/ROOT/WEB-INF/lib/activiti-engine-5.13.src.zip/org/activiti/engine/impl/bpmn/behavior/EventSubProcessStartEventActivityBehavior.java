/*    */ package org.activiti.engine.impl.bpmn.behavior;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ import org.activiti.engine.impl.pvm.process.ProcessDefinitionImpl;
/*    */ import org.activiti.engine.impl.pvm.runtime.InterpretableExecution;
/*    */ 
/*    */ public class EventSubProcessStartEventActivityBehavior extends NoneStartEventActivityBehavior
/*    */ {
/* 34 */   protected boolean isInterrupting = true;
/*    */   protected String activityId;
/*    */ 
/*    */   public EventSubProcessStartEventActivityBehavior(String activityId)
/*    */   {
/* 38 */     this.activityId = activityId;
/*    */   }
/*    */ 
/*    */   public void execute(ActivityExecution execution)
/*    */     throws Exception
/*    */   {
/* 44 */     InterpretableExecution interpretableExecution = (InterpretableExecution)execution;
/* 45 */     ActivityImpl activity = interpretableExecution.getProcessDefinition().findActivity(this.activityId);
/*    */ 
/* 47 */     ActivityExecution outgoingExecution = execution;
/*    */ 
/* 49 */     if (this.isInterrupting) {
/* 50 */       execution.destroyScope("Event subprocess triggered using activity " + this.activityId);
/*    */     } else {
/* 52 */       outgoingExecution = execution.createExecution();
/* 53 */       outgoingExecution.setActive(true);
/* 54 */       outgoingExecution.setScope(false);
/* 55 */       outgoingExecution.setConcurrent(true);
/*    */     }
/*    */ 
/* 59 */     ((InterpretableExecution)outgoingExecution).setActivity(activity);
/*    */ 
/* 62 */     outgoingExecution.takeAll(activity.getOutgoingTransitions(), Collections.EMPTY_LIST);
/*    */   }
/*    */ 
/*    */   public void setInterrupting(boolean b) {
/* 66 */     this.isInterrupting = b;
/*    */   }
/*    */ 
/*    */   public boolean isInterrupting() {
/* 70 */     return this.isInterrupting;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.EventSubProcessStartEventActivityBehavior
 * JD-Core Version:    0.6.0
 */