/*    */ package org.activiti.engine.impl.bpmn.behavior;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.impl.Condition;
/*    */ import org.activiti.engine.impl.pvm.PvmActivity;
/*    */ import org.activiti.engine.impl.pvm.PvmTransition;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class ExclusiveGatewayActivityBehavior extends GatewayActivityBehavior
/*    */ {
/* 34 */   private static Logger log = LoggerFactory.getLogger(ExclusiveGatewayActivityBehavior.class);
/*    */ 
/*    */   protected void leave(ActivityExecution execution)
/*    */   {
/* 52 */     if (log.isDebugEnabled()) {
/* 53 */       log.debug("Leaving activity '{}'", execution.getActivity().getId());
/*    */     }
/*    */ 
/* 56 */     PvmTransition outgoingSeqFlow = null;
/* 57 */     String defaultSequenceFlow = (String)execution.getActivity().getProperty("default");
/* 58 */     Iterator transitionIterator = execution.getActivity().getOutgoingTransitions().iterator();
/* 59 */     while ((outgoingSeqFlow == null) && (transitionIterator.hasNext())) {
/* 60 */       PvmTransition seqFlow = (PvmTransition)transitionIterator.next();
/*    */ 
/* 62 */       Condition condition = (Condition)seqFlow.getProperty("condition");
/* 63 */       if (((condition == null) && ((defaultSequenceFlow == null) || (!defaultSequenceFlow.equals(seqFlow.getId())))) || ((condition != null) && (condition.evaluate(execution))))
/*    */       {
/* 65 */         if (log.isDebugEnabled()) {
/* 66 */           log.debug("Sequence flow '{}'selected as outgoing sequence flow.", seqFlow.getId());
/*    */         }
/* 68 */         outgoingSeqFlow = seqFlow;
/*    */       }
/*    */     }
/*    */ 
/* 72 */     if (outgoingSeqFlow != null) {
/* 73 */       execution.take(outgoingSeqFlow);
/*    */     }
/* 76 */     else if (defaultSequenceFlow != null) {
/* 77 */       PvmTransition defaultTransition = execution.getActivity().findOutgoingTransition(defaultSequenceFlow);
/* 78 */       if (defaultTransition != null)
/* 79 */         execution.take(defaultTransition);
/*    */       else
/* 81 */         throw new ActivitiException("Default sequence flow '" + defaultSequenceFlow + "' not found");
/*    */     }
/*    */     else
/*    */     {
/* 85 */       throw new ActivitiException("No outgoing sequence flow of the exclusive gateway '" + execution.getActivity().getId() + "' could be selected for continuing the process");
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.ExclusiveGatewayActivityBehavior
 * JD-Core Version:    0.6.0
 */