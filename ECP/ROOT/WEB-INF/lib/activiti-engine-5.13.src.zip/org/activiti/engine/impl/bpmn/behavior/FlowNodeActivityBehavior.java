/*    */ package org.activiti.engine.impl.bpmn.behavior;
/*    */ 
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ import org.activiti.engine.impl.pvm.delegate.SignallableActivityBehavior;
/*    */ 
/*    */ public abstract class FlowNodeActivityBehavior
/*    */   implements SignallableActivityBehavior
/*    */ {
/* 30 */   protected BpmnActivityBehavior bpmnActivityBehavior = new BpmnActivityBehavior();
/*    */ 
/*    */   public void execute(ActivityExecution execution)
/*    */     throws Exception
/*    */   {
/* 36 */     leave(execution);
/*    */   }
/*    */ 
/*    */   protected void leave(ActivityExecution execution)
/*    */   {
/* 44 */     this.bpmnActivityBehavior.performDefaultOutgoingBehavior(execution);
/*    */   }
/*    */ 
/*    */   protected void leaveIgnoreConditions(ActivityExecution activityContext) {
/* 48 */     this.bpmnActivityBehavior.performIgnoreConditionsOutgoingBehavior(activityContext);
/*    */   }
/*    */ 
/*    */   public void signal(ActivityExecution execution, String signalName, Object signalData) throws Exception
/*    */   {
/* 53 */     throw new ActivitiException("this activity doesn't accept signals");
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.FlowNodeActivityBehavior
 * JD-Core Version:    0.6.0
 */