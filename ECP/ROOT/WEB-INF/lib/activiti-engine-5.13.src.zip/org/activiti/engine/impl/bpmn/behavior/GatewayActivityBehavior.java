/*    */ package org.activiti.engine.impl.bpmn.behavior;
/*    */ 
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ 
/*    */ public abstract class GatewayActivityBehavior extends FlowNodeActivityBehavior
/*    */ {
/*    */   protected void lockConcurrentRoot(ActivityExecution execution)
/*    */   {
/* 27 */     ActivityExecution concurrentRoot = null;
/* 28 */     if (execution.isConcurrent())
/* 29 */       concurrentRoot = execution.getParent();
/*    */     else {
/* 31 */       concurrentRoot = execution;
/*    */     }
/* 33 */     ((ExecutionEntity)concurrentRoot).forceUpdate();
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.GatewayActivityBehavior
 * JD-Core Version:    0.6.0
 */