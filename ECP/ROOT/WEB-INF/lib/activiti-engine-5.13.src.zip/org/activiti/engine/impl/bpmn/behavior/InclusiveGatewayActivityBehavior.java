/*     */ package org.activiti.engine.impl.bpmn.behavior;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.activiti.engine.ActivitiException;
/*     */ import org.activiti.engine.impl.Condition;
/*     */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*     */ import org.activiti.engine.impl.pvm.PvmActivity;
/*     */ import org.activiti.engine.impl.pvm.PvmTransition;
/*     */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class InclusiveGatewayActivityBehavior extends GatewayActivityBehavior
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  42 */   private static Logger log = LoggerFactory.getLogger(InclusiveGatewayActivityBehavior.class.getName());
/*     */ 
/*     */   public void execute(ActivityExecution execution) throws Exception
/*     */   {
/*  46 */     execution.inactivate();
/*  47 */     lockConcurrentRoot(execution);
/*     */ 
/*  49 */     PvmActivity activity = execution.getActivity();
/*  50 */     if (!activeConcurrentExecutionsExist(execution))
/*     */     {
/*  52 */       if (log.isDebugEnabled()) {
/*  53 */         log.debug("inclusive gateway '{}' activates", activity.getId());
/*     */       }
/*     */ 
/*  56 */       List joinedExecutions = execution.findInactiveConcurrentExecutions(activity);
/*     */ 
/*  58 */       String defaultSequenceFlow = (String)execution.getActivity().getProperty("default");
/*     */ 
/*  60 */       List transitionsToTake = new ArrayList();
/*     */ 
/*  62 */       for (PvmTransition outgoingTransition : execution.getActivity().getOutgoingTransitions())
/*     */       {
/*  64 */         if ((defaultSequenceFlow == null) || (!outgoingTransition.getId().equals(defaultSequenceFlow)))
/*     */         {
/*  66 */           Condition condition = (Condition)outgoingTransition.getProperty("condition");
/*     */ 
/*  68 */           if ((condition == null) || (condition.evaluate(execution))) {
/*  69 */             transitionsToTake.add(outgoingTransition);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  74 */       if (transitionsToTake.size() > 0) {
/*  75 */         execution.takeAll(transitionsToTake, joinedExecutions);
/*     */       }
/*  79 */       else if (defaultSequenceFlow != null) {
/*  80 */         PvmTransition defaultTransition = execution.getActivity().findOutgoingTransition(defaultSequenceFlow);
/*     */ 
/*  82 */         if (defaultTransition != null)
/*  83 */           execution.take(defaultTransition);
/*     */         else {
/*  85 */           throw new ActivitiException("Default sequence flow '" + defaultSequenceFlow + "' could not be not found");
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*  90 */         throw new ActivitiException("No outgoing sequence flow of the inclusive gateway '" + execution.getActivity().getId() + "' could be selected for continuing the process");
/*     */       }
/*     */ 
/*     */     }
/*  98 */     else if (log.isDebugEnabled()) {
/*  99 */       log.debug("Inclusive gateway '{}' does not activate", activity.getId());
/*     */     }
/*     */   }
/*     */ 
/*     */   List<? extends ActivityExecution> getLeaveExecutions(ActivityExecution parent)
/*     */   {
/* 105 */     List executionlist = new ArrayList();
/* 106 */     List subExecutions = parent.getExecutions();
/* 107 */     if (subExecutions.size() == 0)
/* 108 */       executionlist.add(parent);
/*     */     else {
/* 110 */       for (ActivityExecution concurrentExecution : subExecutions) {
/* 111 */         executionlist.addAll(getLeaveExecutions(concurrentExecution));
/*     */       }
/*     */     }
/* 114 */     return executionlist;
/*     */   }
/*     */ 
/*     */   public boolean activeConcurrentExecutionsExist(ActivityExecution execution) {
/* 118 */     PvmActivity activity = execution.getActivity();
/* 119 */     if (execution.isConcurrent()) {
/* 120 */       for (ActivityExecution concurrentExecution : getLeaveExecutions(execution.getParent()))
/* 121 */         if ((concurrentExecution.isActive()) && (concurrentExecution.getActivity() != activity))
/*     */         {
/* 123 */           boolean reachable = false;
/* 124 */           PvmTransition pvmTransition = ((ExecutionEntity)concurrentExecution).getTransitionBeingTaken();
/* 125 */           if (pvmTransition != null)
/* 126 */             reachable = isReachable(pvmTransition.getDestination(), activity, new HashSet());
/*     */           else {
/* 128 */             reachable = isReachable(concurrentExecution.getActivity(), activity, new HashSet());
/*     */           }
/*     */ 
/* 131 */           if (reachable) {
/* 132 */             if (log.isDebugEnabled()) {
/* 133 */               log.debug("an active concurrent execution found: '{}'", concurrentExecution.getActivity());
/*     */             }
/* 135 */             return true;
/*     */           }
/*     */         }
/*     */     }
/* 139 */     else if (execution.isActive()) {
/* 140 */       if (log.isDebugEnabled()) {
/* 141 */         log.debug("an active concurrent execution found: '{}'", execution.getActivity());
/*     */       }
/*     */ 
/* 144 */       return true;
/*     */     }
/*     */ 
/* 147 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean isReachable(PvmActivity srcActivity, PvmActivity targetActivity, Set<PvmActivity> visitedActivities)
/*     */   {
/* 154 */     if (srcActivity.getOutgoingTransitions().size() == 0) {
/* 155 */       visitedActivities.add(srcActivity);
/* 156 */       if ((srcActivity.getParent() == null) || (!(srcActivity.getParent() instanceof PvmActivity))) {
/* 157 */         return false;
/*     */       }
/* 159 */       srcActivity = (PvmActivity)srcActivity.getParent();
/*     */     }
/*     */ 
/* 162 */     if (srcActivity.equals(targetActivity)) {
/* 163 */       return true;
/*     */     }
/*     */ 
/* 169 */     visitedActivities.add(srcActivity);
/*     */ 
/* 171 */     List transitionList = srcActivity.getOutgoingTransitions();
/* 172 */     if ((transitionList != null) && (transitionList.size() > 0)) {
/* 173 */       for (PvmTransition pvmTransition : transitionList) {
/* 174 */         PvmActivity destinationActivity = pvmTransition.getDestination();
/* 175 */         if ((destinationActivity != null) && (!visitedActivities.contains(destinationActivity))) {
/* 176 */           boolean reachable = isReachable(destinationActivity, targetActivity, visitedActivities);
/*     */ 
/* 181 */           if (reachable) {
/* 182 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 188 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.InclusiveGatewayActivityBehavior
 * JD-Core Version:    0.6.0
 */