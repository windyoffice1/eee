/*    */ package org.activiti.engine.impl.bpmn.behavior;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.activiti.engine.impl.bpmn.helper.ScopeUtil;
/*    */ import org.activiti.engine.impl.bpmn.parser.CompensateEventDefinition;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ 
/*    */ public class IntermediateThrowCompensationEventActivityBehavior extends FlowNodeActivityBehavior
/*    */ {
/*    */   protected final CompensateEventDefinition compensateEventDefinition;
/*    */ 
/*    */   public IntermediateThrowCompensationEventActivityBehavior(CompensateEventDefinition compensateEventDefinition)
/*    */   {
/* 34 */     this.compensateEventDefinition = compensateEventDefinition;
/*    */   }
/*    */ 
/*    */   public void execute(ActivityExecution execution) throws Exception
/*    */   {
/* 39 */     String activityRef = this.compensateEventDefinition.getActivityRef();
/*    */ 
/* 41 */     ExecutionEntity scopeExecution = ScopeUtil.findScopeExecutionForScope((ExecutionEntity)execution, (ActivityImpl)execution.getActivity());
/*    */     List eventSubscriptions;
/*    */     List eventSubscriptions;
/* 45 */     if (activityRef != null)
/* 46 */       eventSubscriptions = scopeExecution.getCompensateEventSubscriptions(activityRef);
/*    */     else {
/* 48 */       eventSubscriptions = scopeExecution.getCompensateEventSubscriptions();
/*    */     }
/*    */ 
/* 51 */     if (eventSubscriptions.isEmpty()) {
/* 52 */       leave(execution);
/*    */     }
/*    */     else
/* 55 */       ScopeUtil.throwCompensationEvent(eventSubscriptions, execution, false);
/*    */   }
/*    */ 
/*    */   public void signal(ActivityExecution execution, String signalName, Object signalData)
/*    */     throws Exception
/*    */   {
/* 63 */     if (execution.getExecutions().isEmpty())
/* 64 */       leave(execution);
/*    */     else
/* 66 */       ((ExecutionEntity)execution).forceUpdate();
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.IntermediateThrowCompensationEventActivityBehavior
 * JD-Core Version:    0.6.0
 */