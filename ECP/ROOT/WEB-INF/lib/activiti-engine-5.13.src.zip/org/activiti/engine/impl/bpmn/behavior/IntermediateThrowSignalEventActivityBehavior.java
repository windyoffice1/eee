/*    */ package org.activiti.engine.impl.bpmn.behavior;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.activiti.bpmn.model.Signal;
/*    */ import org.activiti.bpmn.model.ThrowEvent;
/*    */ import org.activiti.engine.impl.bpmn.parser.EventSubscriptionDeclaration;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.EventSubscriptionEntityManager;
/*    */ import org.activiti.engine.impl.persistence.entity.SignalEventSubscriptionEntity;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ 
/*    */ public class IntermediateThrowSignalEventActivityBehavior extends AbstractBpmnActivityBehavior
/*    */ {
/*    */   private static final long serialVersionUID = -2961893934810190972L;
/*    */   protected final boolean processInstanceScope;
/*    */   protected final EventSubscriptionDeclaration signalDefinition;
/*    */ 
/*    */   public IntermediateThrowSignalEventActivityBehavior(ThrowEvent throwEvent, Signal signal, EventSubscriptionDeclaration signalDefinition)
/*    */   {
/* 38 */     this.processInstanceScope = "processInstance".equals(signal.getScope());
/* 39 */     this.signalDefinition = signalDefinition;
/*    */   }
/*    */ 
/*    */   public void execute(ActivityExecution execution) throws Exception
/*    */   {
/* 44 */     CommandContext commandContext = Context.getCommandContext();
/*    */ 
/* 46 */     List subscriptionEntities = null;
/* 47 */     if (this.processInstanceScope) {
/* 48 */       subscriptionEntities = commandContext.getEventSubscriptionEntityManager().findSignalEventSubscriptionsByProcessInstanceAndEventName(execution.getProcessInstanceId(), this.signalDefinition.getEventName());
/*    */     }
/*    */     else
/*    */     {
/* 52 */       subscriptionEntities = commandContext.getEventSubscriptionEntityManager().findSignalEventSubscriptionsByEventName(this.signalDefinition.getEventName());
/*    */     }
/*    */ 
/* 57 */     for (SignalEventSubscriptionEntity signalEventSubscriptionEntity : subscriptionEntities) {
/* 58 */       signalEventSubscriptionEntity.eventReceived(null, this.signalDefinition.isAsync());
/*    */     }
/*    */ 
/* 61 */     leave(execution);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.IntermediateThrowSignalEventActivityBehavior
 * JD-Core Version:    0.6.0
 */