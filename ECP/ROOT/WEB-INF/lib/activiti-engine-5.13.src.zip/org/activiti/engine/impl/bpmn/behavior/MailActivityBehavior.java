/*     */ package org.activiti.engine.impl.bpmn.behavior;
/*     */ 
/*     */ import org.activiti.engine.ActivitiException;
/*     */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*     */ import org.activiti.engine.delegate.DelegateExecution;
/*     */ import org.activiti.engine.delegate.Expression;
/*     */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*     */ import org.activiti.engine.impl.context.Context;
/*     */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*     */ import org.apache.commons.mail.Email;
/*     */ import org.apache.commons.mail.EmailException;
/*     */ import org.apache.commons.mail.HtmlEmail;
/*     */ import org.apache.commons.mail.SimpleEmail;
/*     */ 
/*     */ public class MailActivityBehavior extends AbstractBpmnActivityBehavior
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected Expression to;
/*     */   protected Expression from;
/*     */   protected Expression cc;
/*     */   protected Expression bcc;
/*     */   protected Expression subject;
/*     */   protected Expression text;
/*     */   protected Expression html;
/*     */   protected Expression charset;
/*     */ 
/*     */   public void execute(ActivityExecution execution)
/*     */   {
/*  46 */     String toStr = getStringFromField(this.to, execution);
/*  47 */     String fromStr = getStringFromField(this.from, execution);
/*  48 */     String ccStr = getStringFromField(this.cc, execution);
/*  49 */     String bccStr = getStringFromField(this.bcc, execution);
/*  50 */     String subjectStr = getStringFromField(this.subject, execution);
/*  51 */     String textStr = getStringFromField(this.text, execution);
/*  52 */     String htmlStr = getStringFromField(this.html, execution);
/*  53 */     String charSetStr = getStringFromField(this.charset, execution);
/*     */ 
/*  55 */     Email email = createEmail(textStr, htmlStr);
/*     */ 
/*  57 */     addTo(email, toStr);
/*  58 */     setFrom(email, fromStr);
/*  59 */     addCc(email, ccStr);
/*  60 */     addBcc(email, bccStr);
/*  61 */     setSubject(email, subjectStr);
/*  62 */     setMailServerProperties(email);
/*  63 */     setCharset(email, charSetStr);
/*     */     try
/*     */     {
/*  66 */       email.send();
/*     */     } catch (EmailException e) {
/*  68 */       throw new ActivitiException("Could not send e-mail", e);
/*     */     }
/*  70 */     leave(execution);
/*     */   }
/*     */ 
/*     */   protected Email createEmail(String text, String html) {
/*  74 */     if (html != null)
/*  75 */       return createHtmlEmail(text, html);
/*  76 */     if (text != null) {
/*  77 */       return createTextOnlyEmail(text);
/*     */     }
/*  79 */     throw new ActivitiIllegalArgumentException("'html' or 'text' is required to be defined when using the mail activity");
/*     */   }
/*     */ 
/*     */   protected HtmlEmail createHtmlEmail(String text, String html)
/*     */   {
/*  84 */     HtmlEmail email = new HtmlEmail();
/*     */     try {
/*  86 */       email.setHtmlMsg(html);
/*  87 */       if (text != null) {
/*  88 */         email.setTextMsg(text);
/*     */       }
/*  90 */       return email; } catch (EmailException e) {
/*     */     }
/*  92 */     throw new ActivitiException("Could not create HTML email", e);
/*     */   }
/*     */ 
/*     */   protected SimpleEmail createTextOnlyEmail(String text)
/*     */   {
/*  97 */     SimpleEmail email = new SimpleEmail();
/*     */     try {
/*  99 */       email.setMsg(text);
/* 100 */       return email; } catch (EmailException e) {
/*     */     }
/* 102 */     throw new ActivitiException("Could not create text-only email", e);
/*     */   }
/*     */ 
/*     */   protected void addTo(Email email, String to)
/*     */   {
/* 107 */     String[] tos = splitAndTrim(to);
/* 108 */     if (tos != null) {
/* 109 */       for (String t : tos)
/*     */         try {
/* 111 */           email.addTo(t);
/*     */         } catch (EmailException e) {
/* 113 */           throw new ActivitiException("Could not add " + t + " as recipient", e);
/*     */         }
/*     */     }
/*     */     else
/* 117 */       throw new ActivitiException("No recipient could be found for sending email");
/*     */   }
/*     */ 
/*     */   protected void setFrom(Email email, String from)
/*     */   {
/* 122 */     String fromAddres = null;
/*     */ 
/* 124 */     if (from != null)
/* 125 */       fromAddres = from;
/*     */     else {
/* 127 */       fromAddres = Context.getProcessEngineConfiguration().getMailServerDefaultFrom();
/*     */     }
/*     */     try
/*     */     {
/* 131 */       email.setFrom(fromAddres);
/*     */     } catch (EmailException e) {
/* 133 */       throw new ActivitiException("Could not set " + from + " as from address in email", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void addCc(Email email, String cc) {
/* 138 */     String[] ccs = splitAndTrim(cc);
/* 139 */     if (ccs != null)
/* 140 */       for (String c : ccs)
/*     */         try {
/* 142 */           email.addCc(c);
/*     */         } catch (EmailException e) {
/* 144 */           throw new ActivitiException("Could not add " + c + " as cc recipient", e);
/*     */         }
/*     */   }
/*     */ 
/*     */   protected void addBcc(Email email, String bcc)
/*     */   {
/* 151 */     String[] bccs = splitAndTrim(bcc);
/* 152 */     if (bccs != null)
/* 153 */       for (String b : bccs)
/*     */         try {
/* 155 */           email.addBcc(b);
/*     */         } catch (EmailException e) {
/* 157 */           throw new ActivitiException("Could not add " + b + " as bcc recipient", e);
/*     */         }
/*     */   }
/*     */ 
/*     */   protected void setSubject(Email email, String subject)
/*     */   {
/* 164 */     email.setSubject(subject != null ? subject : "");
/*     */   }
/*     */ 
/*     */   protected void setMailServerProperties(Email email) {
/* 168 */     ProcessEngineConfigurationImpl processEngineConfiguration = Context.getProcessEngineConfiguration();
/*     */ 
/* 170 */     String host = processEngineConfiguration.getMailServerHost();
/* 171 */     if (host == null) {
/* 172 */       throw new ActivitiException("Could not send email: no SMTP host is configured");
/*     */     }
/* 174 */     email.setHostName(host);
/*     */ 
/* 176 */     int port = processEngineConfiguration.getMailServerPort();
/* 177 */     email.setSmtpPort(port);
/*     */ 
/* 179 */     email.setSSL(processEngineConfiguration.getMailServerUseSSL());
/* 180 */     email.setTLS(processEngineConfiguration.getMailServerUseTLS());
/*     */ 
/* 182 */     String user = processEngineConfiguration.getMailServerUsername();
/* 183 */     String password = processEngineConfiguration.getMailServerPassword();
/* 184 */     if ((user != null) && (password != null))
/* 185 */       email.setAuthentication(user, password);
/*     */   }
/*     */ 
/*     */   protected void setCharset(Email email, String charSetStr)
/*     */   {
/* 190 */     if (this.charset != null)
/* 191 */       email.setCharset(charSetStr);
/*     */   }
/*     */ 
/*     */   protected String[] splitAndTrim(String str)
/*     */   {
/* 196 */     if (str != null) {
/* 197 */       String[] splittedStrings = str.split(",");
/* 198 */       for (int i = 0; i < splittedStrings.length; i++) {
/* 199 */         splittedStrings[i] = splittedStrings[i].trim();
/*     */       }
/* 201 */       return splittedStrings;
/*     */     }
/* 203 */     return null;
/*     */   }
/*     */ 
/*     */   protected String getStringFromField(Expression expression, DelegateExecution execution) {
/* 207 */     if (expression != null) {
/* 208 */       Object value = expression.getValue(execution);
/* 209 */       if (value != null) {
/* 210 */         return value.toString();
/*     */       }
/*     */     }
/* 213 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.MailActivityBehavior
 * JD-Core Version:    0.6.0
 */