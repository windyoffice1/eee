/*     */ package org.activiti.engine.impl.bpmn.behavior;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.activiti.engine.ActivitiException;
/*     */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*     */ import org.activiti.engine.delegate.BpmnError;
/*     */ import org.activiti.engine.delegate.DelegateExecution;
/*     */ import org.activiti.engine.delegate.ExecutionListener;
/*     */ import org.activiti.engine.delegate.Expression;
/*     */ import org.activiti.engine.impl.bpmn.helper.ErrorPropagation;
/*     */ import org.activiti.engine.impl.bpmn.helper.ScopeUtil;
/*     */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*     */ import org.activiti.engine.impl.context.Context;
/*     */ import org.activiti.engine.impl.delegate.ExecutionListenerInvocation;
/*     */ import org.activiti.engine.impl.interceptor.DelegateInterceptor;
/*     */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*     */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*     */ import org.activiti.engine.impl.pvm.delegate.CompositeActivityBehavior;
/*     */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public abstract class MultiInstanceActivityBehavior extends FlowNodeActivityBehavior
/*     */   implements CompositeActivityBehavior, org.activiti.engine.impl.pvm.delegate.SubProcessActivityBehavior
/*     */ {
/*  56 */   protected static final Logger LOGGER = LoggerFactory.getLogger(MultiInstanceActivityBehavior.class);
/*     */ 
/*  59 */   protected final String NUMBER_OF_INSTANCES = "nrOfInstances";
/*  60 */   protected final String NUMBER_OF_ACTIVE_INSTANCES = "nrOfActiveInstances";
/*  61 */   protected final String NUMBER_OF_COMPLETED_INSTANCES = "nrOfCompletedInstances";
/*     */ 
/*  64 */   protected final String LOOP_COUNTER = "loopCounter";
/*     */   protected ActivityImpl activity;
/*     */   protected AbstractBpmnActivityBehavior innerActivityBehavior;
/*     */   protected Expression loopCardinalityExpression;
/*     */   protected Expression completionConditionExpression;
/*     */   protected Expression collectionExpression;
/*     */   protected String collectionVariable;
/*     */   protected String collectionElementVariable;
/*     */ 
/*     */   public MultiInstanceActivityBehavior(ActivityImpl activity, AbstractBpmnActivityBehavior innerActivityBehavior)
/*     */   {
/*  82 */     this.activity = activity;
/*  83 */     setInnerActivityBehavior(innerActivityBehavior);
/*     */   }
/*     */ 
/*     */   public void execute(ActivityExecution execution) throws Exception {
/*  87 */     if (getLocalLoopVariable(execution, "loopCounter") == null)
/*     */       try {
/*  89 */         createInstances(execution);
/*     */       } catch (BpmnError error) {
/*  91 */         ErrorPropagation.propagateError(error, execution);
/*     */       }
/*     */     else
/*  94 */       this.innerActivityBehavior.execute(execution);
/*     */   }
/*     */ 
/*     */   protected abstract void createInstances(ActivityExecution paramActivityExecution) throws Exception;
/*     */ 
/*     */   public void signal(ActivityExecution execution, String signalName, Object signalData) throws Exception
/*     */   {
/* 102 */     this.innerActivityBehavior.signal(execution, signalName, signalData);
/*     */   }
/*     */ 
/*     */   public void lastExecutionEnded(ActivityExecution execution)
/*     */   {
/* 107 */     ScopeUtil.createEventScopeExecution((ExecutionEntity)execution);
/* 108 */     leave(execution);
/*     */   }
/*     */ 
/*     */   public void completing(DelegateExecution execution, DelegateExecution subProcessInstance) throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   public void completed(ActivityExecution execution) throws Exception
/*     */   {
/* 117 */     leave(execution);
/*     */   }
/*     */ 
/*     */   protected int resolveNrOfInstances(ActivityExecution execution)
/*     */   {
/* 124 */     int nrOfInstances = -1;
/* 125 */     if (this.loopCardinalityExpression != null) {
/* 126 */       nrOfInstances = resolveLoopCardinality(execution);
/* 127 */     } else if (this.collectionExpression != null) {
/* 128 */       Object obj = this.collectionExpression.getValue(execution);
/* 129 */       if (!(obj instanceof Collection)) {
/* 130 */         throw new ActivitiIllegalArgumentException(this.collectionExpression.getExpressionText() + "' didn't resolve to a Collection");
/*     */       }
/* 132 */       nrOfInstances = ((Collection)obj).size();
/* 133 */     } else if (this.collectionVariable != null) {
/* 134 */       Object obj = execution.getVariable(this.collectionVariable);
/* 135 */       if (obj == null) {
/* 136 */         throw new ActivitiIllegalArgumentException("Variable " + this.collectionVariable + " is not found");
/*     */       }
/* 138 */       if (!(obj instanceof Collection)) {
/* 139 */         throw new ActivitiIllegalArgumentException("Variable " + this.collectionVariable + "' is not a Collection");
/*     */       }
/* 141 */       nrOfInstances = ((Collection)obj).size();
/*     */     } else {
/* 143 */       throw new ActivitiIllegalArgumentException("Couldn't resolve collection expression nor variable reference");
/*     */     }
/* 145 */     return nrOfInstances;
/*     */   }
/*     */ 
/*     */   protected void executeOriginalBehavior(ActivityExecution execution, int loopCounter) throws Exception
/*     */   {
/* 150 */     if ((usesCollection()) && (this.collectionElementVariable != null)) {
/* 151 */       Collection collection = null;
/* 152 */       if (this.collectionExpression != null)
/* 153 */         collection = (Collection)this.collectionExpression.getValue(execution);
/* 154 */       else if (this.collectionVariable != null) {
/* 155 */         collection = (Collection)execution.getVariable(this.collectionVariable);
/*     */       }
/*     */ 
/* 158 */       Object value = null;
/* 159 */       int index = 0;
/* 160 */       Iterator it = collection.iterator();
/* 161 */       while (index <= loopCounter) {
/* 162 */         value = it.next();
/* 163 */         index++;
/*     */       }
/* 165 */       setLoopVariable(execution, this.collectionElementVariable, value);
/*     */     }
/*     */ 
/* 170 */     if (loopCounter == 0)
/* 171 */       this.innerActivityBehavior.execute(execution);
/*     */     else
/* 173 */       execution.executeActivity(this.activity);
/*     */   }
/*     */ 
/*     */   protected boolean usesCollection()
/*     */   {
/* 178 */     return (this.collectionExpression != null) || (this.collectionVariable != null);
/*     */   }
/*     */ 
/*     */   protected boolean isExtraScopeNeeded()
/*     */   {
/* 184 */     return this.innerActivityBehavior instanceof SubProcessActivityBehavior;
/*     */   }
/*     */ 
/*     */   protected int resolveLoopCardinality(ActivityExecution execution)
/*     */   {
/* 189 */     Object value = this.loopCardinalityExpression.getValue(execution);
/* 190 */     if ((value instanceof Number))
/* 191 */       return ((Number)value).intValue();
/* 192 */     if ((value instanceof String)) {
/* 193 */       return Integer.valueOf((String)value).intValue();
/*     */     }
/* 195 */     throw new ActivitiIllegalArgumentException("Could not resolve loopCardinality expression '" + this.loopCardinalityExpression.getExpressionText() + "': not a number nor number String");
/*     */   }
/*     */ 
/*     */   protected boolean completionConditionSatisfied(ActivityExecution execution)
/*     */   {
/* 201 */     if (this.completionConditionExpression != null) {
/* 202 */       Object value = this.completionConditionExpression.getValue(execution);
/* 203 */       if (!(value instanceof Boolean)) {
/* 204 */         throw new ActivitiIllegalArgumentException("completionCondition '" + this.completionConditionExpression.getExpressionText() + "' does not evaluate to a boolean value");
/*     */       }
/*     */ 
/* 208 */       Boolean booleanValue = (Boolean)value;
/* 209 */       if (LOGGER.isDebugEnabled()) {
/* 210 */         LOGGER.debug("Completion condition of multi-instance satisfied: {}", booleanValue);
/*     */       }
/* 212 */       return booleanValue.booleanValue();
/*     */     }
/* 214 */     return false;
/*     */   }
/*     */ 
/*     */   protected void setLoopVariable(ActivityExecution execution, String variableName, Object value) {
/* 218 */     execution.setVariableLocal(variableName, value);
/*     */   }
/*     */ 
/*     */   protected Integer getLoopVariable(ActivityExecution execution, String variableName) {
/* 222 */     Object value = execution.getVariableLocal(variableName);
/* 223 */     ActivityExecution parent = execution.getParent();
/* 224 */     while ((value == null) && (parent != null)) {
/* 225 */       value = parent.getVariableLocal(variableName);
/* 226 */       parent = parent.getParent();
/*     */     }
/* 228 */     return (Integer)value;
/*     */   }
/*     */ 
/*     */   protected Integer getLocalLoopVariable(ActivityExecution execution, String variableName) {
/* 232 */     return (Integer)execution.getVariableLocal(variableName);
/*     */   }
/*     */ 
/*     */   protected void callActivityEndListeners(ActivityExecution execution)
/*     */   {
/* 241 */     List listeners = this.activity.getExecutionListeners("end");
/* 242 */     for (ExecutionListener executionListener : listeners)
/*     */       try {
/* 244 */         Context.getProcessEngineConfiguration().getDelegateInterceptor().handleInvocation(new ExecutionListenerInvocation(executionListener, execution));
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 248 */         throw new ActivitiException("Couldn't execute end listener", e);
/*     */       }
/*     */   }
/*     */ 
/*     */   protected void logLoopDetails(ActivityExecution execution, String custom, int loopCounter, int nrOfCompletedInstances, int nrOfActiveInstances, int nrOfInstances)
/*     */   {
/* 255 */     if (LOGGER.isDebugEnabled())
/* 256 */       LOGGER.debug("Multi-instance '{}' {}. Details: loopCounter={}, nrOrCompletedInstances={},nrOfActiveInstances={},nrOfInstances={}", new Object[] { execution.getActivity(), custom, Integer.valueOf(loopCounter), Integer.valueOf(nrOfCompletedInstances), Integer.valueOf(nrOfActiveInstances), Integer.valueOf(nrOfInstances) });
/*     */   }
/*     */ 
/*     */   public Expression getLoopCardinalityExpression()
/*     */   {
/* 265 */     return this.loopCardinalityExpression;
/*     */   }
/*     */   public void setLoopCardinalityExpression(Expression loopCardinalityExpression) {
/* 268 */     this.loopCardinalityExpression = loopCardinalityExpression;
/*     */   }
/*     */   public Expression getCompletionConditionExpression() {
/* 271 */     return this.completionConditionExpression;
/*     */   }
/*     */   public void setCompletionConditionExpression(Expression completionConditionExpression) {
/* 274 */     this.completionConditionExpression = completionConditionExpression;
/*     */   }
/*     */   public Expression getCollectionExpression() {
/* 277 */     return this.collectionExpression;
/*     */   }
/*     */   public void setCollectionExpression(Expression collectionExpression) {
/* 280 */     this.collectionExpression = collectionExpression;
/*     */   }
/*     */   public String getCollectionVariable() {
/* 283 */     return this.collectionVariable;
/*     */   }
/*     */   public void setCollectionVariable(String collectionVariable) {
/* 286 */     this.collectionVariable = collectionVariable;
/*     */   }
/*     */   public String getCollectionElementVariable() {
/* 289 */     return this.collectionElementVariable;
/*     */   }
/*     */   public void setCollectionElementVariable(String collectionElementVariable) {
/* 292 */     this.collectionElementVariable = collectionElementVariable;
/*     */   }
/*     */   public void setInnerActivityBehavior(AbstractBpmnActivityBehavior innerActivityBehavior) {
/* 295 */     this.innerActivityBehavior = innerActivityBehavior;
/* 296 */     this.innerActivityBehavior.setMultiInstanceActivityBehavior(this);
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.MultiInstanceActivityBehavior
 * JD-Core Version:    0.6.0
 */