/*    */ package org.activiti.engine.impl.bpmn.behavior;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.activiti.engine.impl.pvm.PvmActivity;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class ParallelGatewayActivityBehavior extends GatewayActivityBehavior
/*    */ {
/* 54 */   private static Logger log = LoggerFactory.getLogger(ParallelGatewayActivityBehavior.class);
/*    */ 
/*    */   public void execute(ActivityExecution execution)
/*    */     throws Exception
/*    */   {
/* 59 */     PvmActivity activity = execution.getActivity();
/* 60 */     List outgoingTransitions = execution.getActivity().getOutgoingTransitions();
/*    */ 
/* 62 */     execution.inactivate();
/* 63 */     lockConcurrentRoot(execution);
/*    */ 
/* 65 */     List joinedExecutions = execution.findInactiveConcurrentExecutions(activity);
/* 66 */     int nbrOfExecutionsToJoin = execution.getActivity().getIncomingTransitions().size();
/* 67 */     int nbrOfExecutionsJoined = joinedExecutions.size();
/*    */ 
/* 69 */     if (nbrOfExecutionsJoined == nbrOfExecutionsToJoin)
/*    */     {
/* 72 */       if (log.isDebugEnabled()) {
/* 73 */         log.debug("parallel gateway '{}' activates: {} of {} joined", new Object[] { activity.getId(), Integer.valueOf(nbrOfExecutionsJoined), Integer.valueOf(nbrOfExecutionsToJoin) });
/*    */       }
/* 75 */       execution.takeAll(outgoingTransitions, joinedExecutions);
/*    */     }
/* 77 */     else if (log.isDebugEnabled()) {
/* 78 */       log.debug("parallel gateway '{}' does not activate: {} of {} joined", new Object[] { activity.getId(), Integer.valueOf(nbrOfExecutionsJoined), Integer.valueOf(nbrOfExecutionsToJoin) });
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.ParallelGatewayActivityBehavior
 * JD-Core Version:    0.6.0
 */