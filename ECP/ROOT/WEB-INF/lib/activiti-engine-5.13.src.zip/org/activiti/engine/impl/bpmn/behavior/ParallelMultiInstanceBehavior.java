/*     */ package org.activiti.engine.impl.bpmn.behavior;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*     */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*     */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*     */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*     */ import org.slf4j.Logger;
/*     */ 
/*     */ public class ParallelMultiInstanceBehavior extends MultiInstanceActivityBehavior
/*     */ {
/*     */   public ParallelMultiInstanceBehavior(ActivityImpl activity, AbstractBpmnActivityBehavior originalActivityBehavior)
/*     */   {
/*  31 */     super(activity, originalActivityBehavior);
/*     */   }
/*     */ 
/*     */   protected void createInstances(ActivityExecution execution)
/*     */     throws Exception
/*     */   {
/*  39 */     int nrOfInstances = resolveNrOfInstances(execution);
/*  40 */     if (nrOfInstances <= 0) {
/*  41 */       throw new ActivitiIllegalArgumentException("Invalid number of instances: must be positive integer value, but was " + nrOfInstances);
/*     */     }
/*     */ 
/*  45 */     setLoopVariable(execution, "nrOfInstances", Integer.valueOf(nrOfInstances));
/*  46 */     setLoopVariable(execution, "nrOfCompletedInstances", Integer.valueOf(0));
/*  47 */     setLoopVariable(execution, "nrOfActiveInstances", Integer.valueOf(nrOfInstances));
/*     */ 
/*  49 */     List concurrentExecutions = new ArrayList();
/*  50 */     for (int loopCounter = 0; loopCounter < nrOfInstances; loopCounter++) {
/*  51 */       ActivityExecution concurrentExecution = execution.createExecution();
/*  52 */       concurrentExecution.setActive(true);
/*  53 */       concurrentExecution.setConcurrent(true);
/*  54 */       concurrentExecution.setScope(false);
/*     */ 
/*  59 */       if (isExtraScopeNeeded()) {
/*  60 */         ActivityExecution extraScopedExecution = concurrentExecution.createExecution();
/*  61 */         extraScopedExecution.setActive(true);
/*  62 */         extraScopedExecution.setConcurrent(false);
/*  63 */         extraScopedExecution.setScope(true);
/*  64 */         concurrentExecution = extraScopedExecution;
/*     */       }
/*     */ 
/*  67 */       concurrentExecutions.add(concurrentExecution);
/*  68 */       logLoopDetails(concurrentExecution, "initialized", loopCounter, 0, nrOfInstances, nrOfInstances);
/*     */     }
/*     */ 
/*  74 */     for (int loopCounter = 0; loopCounter < nrOfInstances; loopCounter++) {
/*  75 */       ActivityExecution concurrentExecution = (ActivityExecution)concurrentExecutions.get(loopCounter);
/*     */ 
/*  78 */       if ((!concurrentExecution.isActive()) || (concurrentExecution.isEnded()) || (!concurrentExecution.getParent().isActive()) || (concurrentExecution.getParent().isEnded())) {
/*     */         continue;
/*     */       }
/*  81 */       setLoopVariable(concurrentExecution, "loopCounter", Integer.valueOf(loopCounter));
/*  82 */       executeOriginalBehavior(concurrentExecution, loopCounter);
/*     */     }
/*     */ 
/*  90 */     if (!concurrentExecutions.isEmpty()) {
/*  91 */       ExecutionEntity executionEntity = (ExecutionEntity)execution;
/*  92 */       executionEntity.setActive(false);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void leave(ActivityExecution execution)
/*     */   {
/* 102 */     callActivityEndListeners(execution);
/*     */ 
/* 104 */     int loopCounter = getLoopVariable(execution, "loopCounter").intValue();
/* 105 */     int nrOfInstances = getLoopVariable(execution, "nrOfInstances").intValue();
/* 106 */     int nrOfCompletedInstances = getLoopVariable(execution, "nrOfCompletedInstances").intValue() + 1;
/* 107 */     int nrOfActiveInstances = getLoopVariable(execution, "nrOfActiveInstances").intValue() - 1;
/*     */ 
/* 109 */     if (isExtraScopeNeeded())
/*     */     {
/* 111 */       ExecutionEntity extraScope = (ExecutionEntity)execution;
/* 112 */       execution = execution.getParent();
/* 113 */       extraScope.remove();
/*     */     }
/*     */ 
/* 116 */     setLoopVariable(execution.getParent(), "nrOfCompletedInstances", Integer.valueOf(nrOfCompletedInstances));
/* 117 */     setLoopVariable(execution.getParent(), "nrOfActiveInstances", Integer.valueOf(nrOfActiveInstances));
/* 118 */     logLoopDetails(execution, "instance completed", loopCounter, nrOfCompletedInstances, nrOfActiveInstances, nrOfInstances);
/*     */ 
/* 120 */     ExecutionEntity executionEntity = (ExecutionEntity)execution;
/* 121 */     executionEntity.inactivate();
/* 122 */     executionEntity.getParent().forceUpdate();
/*     */ 
/* 124 */     List joinedExecutions = executionEntity.findInactiveConcurrentExecutions(execution.getActivity());
/* 125 */     if ((joinedExecutions.size() == nrOfInstances) || (completionConditionSatisfied(execution)))
/*     */     {
/* 128 */       List executionsToRemove = new ArrayList();
/* 129 */       for (ActivityExecution childExecution : executionEntity.getParent().getExecutions()) {
/* 130 */         if (childExecution.isActive()) {
/* 131 */           executionsToRemove.add((ExecutionEntity)childExecution);
/*     */         }
/*     */       }
/* 134 */       for (ExecutionEntity executionToRemove : executionsToRemove) {
/* 135 */         if (LOGGER.isDebugEnabled()) {
/* 136 */           LOGGER.debug("Execution {} still active, but multi-instance is completed. Removing this execution.", executionToRemove);
/*     */         }
/* 138 */         executionToRemove.inactivate();
/* 139 */         executionToRemove.deleteCascade("multi-instance completed");
/*     */       }
/* 141 */       executionEntity.takeAll(executionEntity.getActivity().getOutgoingTransitions(), joinedExecutions);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.ParallelMultiInstanceBehavior
 * JD-Core Version:    0.6.0
 */