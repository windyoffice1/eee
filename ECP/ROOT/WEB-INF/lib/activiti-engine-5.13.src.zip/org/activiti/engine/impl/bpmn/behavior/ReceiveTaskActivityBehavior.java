/*    */ package org.activiti.engine.impl.bpmn.behavior;
/*    */ 
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ 
/*    */ public class ReceiveTaskActivityBehavior extends TaskActivityBehavior
/*    */ {
/*    */   public void execute(ActivityExecution execution)
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ 
/*    */   public void signal(ActivityExecution execution, String signalName, Object data)
/*    */     throws Exception
/*    */   {
/* 35 */     leave(execution);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.ReceiveTaskActivityBehavior
 * JD-Core Version:    0.6.0
 */