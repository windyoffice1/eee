/*    */ package org.activiti.engine.impl.bpmn.behavior;
/*    */ 
/*    */ import javax.script.ScriptException;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.delegate.BpmnError;
/*    */ import org.activiti.engine.impl.bpmn.helper.ErrorPropagation;
/*    */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.pvm.PvmActivity;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ import org.activiti.engine.impl.scripting.ScriptingEngines;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class ScriptTaskActivityBehavior extends TaskActivityBehavior
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 38 */   private static final Logger LOGGER = LoggerFactory.getLogger(ScriptTaskActivityBehavior.class);
/*    */   protected String script;
/*    */   protected String language;
/*    */   protected String resultVariable;
/* 43 */   protected boolean storeScriptVariables = false;
/*    */ 
/*    */   public ScriptTaskActivityBehavior(String script, String language, String resultVariable) {
/* 46 */     this.script = script;
/* 47 */     this.language = language;
/* 48 */     this.resultVariable = resultVariable;
/*    */   }
/*    */ 
/*    */   public ScriptTaskActivityBehavior(String script, String language, String resultVariable, boolean storeScriptVariables) {
/* 52 */     this(script, language, resultVariable);
/* 53 */     this.storeScriptVariables = storeScriptVariables;
/*    */   }
/*    */ 
/*    */   public void execute(ActivityExecution execution) throws Exception {
/* 57 */     ScriptingEngines scriptingEngines = Context.getProcessEngineConfiguration().getScriptingEngines();
/*    */ 
/* 61 */     boolean noErrors = true;
/*    */     try {
/* 63 */       Object result = scriptingEngines.evaluate(this.script, this.language, execution, this.storeScriptVariables);
/*    */ 
/* 65 */       if (this.resultVariable != null) {
/* 66 */         execution.setVariable(this.resultVariable, result);
/*    */       }
/*    */     }
/*    */     catch (ActivitiException e)
/*    */     {
/* 71 */       LOGGER.warn("Exception while executing " + execution.getActivity().getId() + " : " + e.getMessage());
/*    */ 
/* 73 */       noErrors = false;
/* 74 */       if (((e.getCause() instanceof ScriptException)) && ((e.getCause().getCause() instanceof ScriptException)) && ((e.getCause().getCause().getCause() instanceof BpmnError)))
/*    */       {
/* 77 */         ErrorPropagation.propagateError((BpmnError)e.getCause().getCause().getCause(), execution);
/*    */       }
/* 79 */       else throw e;
/*    */     }
/*    */ 
/* 82 */     if (noErrors)
/* 83 */       leave(execution);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.ScriptTaskActivityBehavior
 * JD-Core Version:    0.6.0
 */