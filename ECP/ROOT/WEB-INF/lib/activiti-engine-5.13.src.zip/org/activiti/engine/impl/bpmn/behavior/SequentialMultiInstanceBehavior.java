/*    */ package org.activiti.engine.impl.bpmn.behavior;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.delegate.BpmnError;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ 
/*    */ public class SequentialMultiInstanceBehavior extends MultiInstanceActivityBehavior
/*    */ {
/*    */   public SequentialMultiInstanceBehavior(ActivityImpl activity, AbstractBpmnActivityBehavior innerActivityBehavior)
/*    */   {
/* 30 */     super(activity, innerActivityBehavior);
/*    */   }
/*    */ 
/*    */   protected void createInstances(ActivityExecution execution)
/*    */     throws Exception
/*    */   {
/* 38 */     int nrOfInstances = resolveNrOfInstances(execution);
/* 39 */     if (nrOfInstances <= 0) {
/* 40 */       throw new ActivitiIllegalArgumentException("Invalid number of instances: must be positive integer value, but was " + nrOfInstances);
/*    */     }
/*    */ 
/* 44 */     setLoopVariable(execution, "nrOfInstances", Integer.valueOf(nrOfInstances));
/* 45 */     setLoopVariable(execution, "nrOfCompletedInstances", Integer.valueOf(0));
/* 46 */     setLoopVariable(execution, "loopCounter", Integer.valueOf(0));
/* 47 */     setLoopVariable(execution, "nrOfActiveInstances", Integer.valueOf(1));
/* 48 */     logLoopDetails(execution, "initialized", 0, 0, 1, nrOfInstances);
/*    */ 
/* 50 */     executeOriginalBehavior(execution, 0);
/*    */   }
/*    */ 
/*    */   public void leave(ActivityExecution execution)
/*    */   {
/* 59 */     callActivityEndListeners(execution);
/*    */ 
/* 61 */     int loopCounter = getLoopVariable(execution, "loopCounter").intValue() + 1;
/* 62 */     int nrOfInstances = getLoopVariable(execution, "nrOfInstances").intValue();
/* 63 */     int nrOfCompletedInstances = getLoopVariable(execution, "nrOfCompletedInstances").intValue() + 1;
/* 64 */     int nrOfActiveInstances = getLoopVariable(execution, "nrOfActiveInstances").intValue();
/*    */ 
/* 66 */     setLoopVariable(execution, "loopCounter", Integer.valueOf(loopCounter));
/* 67 */     setLoopVariable(execution, "nrOfCompletedInstances", Integer.valueOf(nrOfCompletedInstances));
/* 68 */     logLoopDetails(execution, "instance completed", loopCounter, nrOfCompletedInstances, nrOfActiveInstances, nrOfInstances);
/*    */ 
/* 70 */     if ((loopCounter == nrOfInstances) || (completionConditionSatisfied(execution)))
/* 71 */       super.leave(execution);
/*    */     else
/*    */       try {
/* 74 */         executeOriginalBehavior(execution, loopCounter);
/*    */       }
/*    */       catch (BpmnError error) {
/* 77 */         throw error;
/*    */       } catch (Exception e) {
/* 79 */         throw new ActivitiException("Could not execute inner activity behavior of multi instance behavior", e);
/*    */       }
/*    */   }
/*    */ 
/*    */   public void execute(ActivityExecution execution)
/*    */     throws Exception
/*    */   {
/* 86 */     super.execute(execution);
/*    */ 
/* 88 */     if ((this.innerActivityBehavior instanceof SubProcessActivityBehavior))
/*    */     {
/* 90 */       if ((!execution.isActive()) && (execution.isEnded()) && ((execution.getExecutions() == null) || (execution.getExecutions().size() == 0)))
/* 91 */         execution.setActive(true);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.SequentialMultiInstanceBehavior
 * JD-Core Version:    0.6.0
 */