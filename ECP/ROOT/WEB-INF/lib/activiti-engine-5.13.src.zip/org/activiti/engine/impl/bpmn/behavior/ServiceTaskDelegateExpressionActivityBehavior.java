/*    */ package org.activiti.engine.impl.bpmn.behavior;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.delegate.BpmnError;
/*    */ import org.activiti.engine.delegate.Expression;
/*    */ import org.activiti.engine.delegate.JavaDelegate;
/*    */ import org.activiti.engine.impl.bpmn.helper.ClassDelegate;
/*    */ import org.activiti.engine.impl.bpmn.helper.ErrorPropagation;
/*    */ import org.activiti.engine.impl.bpmn.parser.FieldDeclaration;
/*    */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.delegate.ActivityBehaviorInvocation;
/*    */ import org.activiti.engine.impl.delegate.JavaDelegateInvocation;
/*    */ import org.activiti.engine.impl.interceptor.DelegateInterceptor;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityBehavior;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ import org.activiti.engine.impl.pvm.delegate.SignallableActivityBehavior;
/*    */ 
/*    */ public class ServiceTaskDelegateExpressionActivityBehavior extends TaskActivityBehavior
/*    */ {
/*    */   protected Expression expression;
/*    */   private final List<FieldDeclaration> fieldDeclarations;
/*    */ 
/*    */   public ServiceTaskDelegateExpressionActivityBehavior(Expression expression, List<FieldDeclaration> fieldDeclarations)
/*    */   {
/* 47 */     this.expression = expression;
/* 48 */     this.fieldDeclarations = fieldDeclarations;
/*    */   }
/*    */ 
/*    */   public void signal(ActivityExecution execution, String signalName, Object signalData) throws Exception
/*    */   {
/* 53 */     Object delegate = this.expression.getValue(execution);
/* 54 */     if ((delegate instanceof SignallableActivityBehavior))
/* 55 */       ((SignallableActivityBehavior)delegate).signal(execution, signalName, signalData);
/*    */   }
/*    */ 
/*    */   public void execute(ActivityExecution execution)
/*    */     throws Exception
/*    */   {
/*    */     try
/*    */     {
/* 65 */       Object delegate = this.expression.getValue(execution);
/* 66 */       ClassDelegate.applyFieldDeclaration(this.fieldDeclarations, delegate);
/*    */ 
/* 68 */       if ((delegate instanceof ActivityBehavior)) {
/* 69 */         Context.getProcessEngineConfiguration().getDelegateInterceptor().handleInvocation(new ActivityBehaviorInvocation((ActivityBehavior)delegate, execution));
/*    */       }
/* 73 */       else if ((delegate instanceof JavaDelegate)) {
/* 74 */         Context.getProcessEngineConfiguration().getDelegateInterceptor().handleInvocation(new JavaDelegateInvocation((JavaDelegate)delegate, execution));
/*    */ 
/* 77 */         leave(execution);
/*    */       }
/*    */       else {
/* 80 */         throw new ActivitiIllegalArgumentException("Delegate expression " + this.expression + " did neither resolve to an implementation of " + ActivityBehavior.class + " nor " + JavaDelegate.class);
/*    */       }
/*    */ 
/*    */     }
/*    */     catch (Exception exc)
/*    */     {
/* 86 */       Throwable cause = exc;
/* 87 */       BpmnError error = null;
/* 88 */       while (cause != null) {
/* 89 */         if ((cause instanceof BpmnError)) {
/* 90 */           error = (BpmnError)cause;
/* 91 */           break;
/*    */         }
/* 93 */         cause = cause.getCause();
/*    */       }
/*    */ 
/* 96 */       if (error != null)
/* 97 */         ErrorPropagation.propagateError(error, execution);
/*    */       else
/* 99 */         throw exc;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.ServiceTaskDelegateExpressionActivityBehavior
 * JD-Core Version:    0.6.0
 */