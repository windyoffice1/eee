/*    */ package org.activiti.engine.impl.bpmn.behavior;
/*    */ 
/*    */ import org.activiti.engine.delegate.BpmnError;
/*    */ import org.activiti.engine.delegate.Expression;
/*    */ import org.activiti.engine.impl.bpmn.helper.ErrorPropagation;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ 
/*    */ public class ServiceTaskExpressionActivityBehavior extends TaskActivityBehavior
/*    */ {
/*    */   protected Expression expression;
/*    */   protected String resultVariable;
/*    */ 
/*    */   public ServiceTaskExpressionActivityBehavior(Expression expression, String resultVariable)
/*    */   {
/* 38 */     this.expression = expression;
/* 39 */     this.resultVariable = resultVariable;
/*    */   }
/*    */ 
/*    */   public void execute(ActivityExecution execution) throws Exception {
/* 43 */     Object value = null;
/*    */     try {
/* 45 */       value = this.expression.getValue(execution);
/* 46 */       if (this.resultVariable != null) {
/* 47 */         execution.setVariable(this.resultVariable, value);
/*    */       }
/* 49 */       leave(execution);
/*    */     }
/*    */     catch (Exception exc) {
/* 52 */       Throwable cause = exc;
/* 53 */       BpmnError error = null;
/* 54 */       while (cause != null) {
/* 55 */         if ((cause instanceof BpmnError)) {
/* 56 */           error = (BpmnError)cause;
/* 57 */           break;
/*    */         }
/* 59 */         cause = cause.getCause();
/*    */       }
/*    */ 
/* 62 */       if (error != null)
/* 63 */         ErrorPropagation.propagateError(error, execution);
/*    */       else
/* 65 */         throw exc;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.ServiceTaskExpressionActivityBehavior
 * JD-Core Version:    0.6.0
 */