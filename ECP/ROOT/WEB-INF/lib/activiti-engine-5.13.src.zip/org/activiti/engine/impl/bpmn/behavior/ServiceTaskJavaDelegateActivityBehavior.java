/*    */ package org.activiti.engine.impl.bpmn.behavior;
/*    */ 
/*    */ import org.activiti.engine.delegate.DelegateExecution;
/*    */ import org.activiti.engine.delegate.ExecutionListener;
/*    */ import org.activiti.engine.delegate.JavaDelegate;
/*    */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.delegate.JavaDelegateInvocation;
/*    */ import org.activiti.engine.impl.interceptor.DelegateInterceptor;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityBehavior;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ 
/*    */ public class ServiceTaskJavaDelegateActivityBehavior extends TaskActivityBehavior
/*    */   implements ActivityBehavior, ExecutionListener
/*    */ {
/*    */   protected JavaDelegate javaDelegate;
/*    */ 
/*    */   protected ServiceTaskJavaDelegateActivityBehavior()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ServiceTaskJavaDelegateActivityBehavior(JavaDelegate javaDelegate)
/*    */   {
/* 36 */     this.javaDelegate = javaDelegate;
/*    */   }
/*    */ 
/*    */   public void execute(ActivityExecution execution) throws Exception {
/* 40 */     execute(execution);
/* 41 */     leave(execution);
/*    */   }
/*    */ 
/*    */   public void notify(DelegateExecution execution) throws Exception {
/* 45 */     execute(execution);
/*    */   }
/*    */ 
/*    */   public void execute(DelegateExecution execution) throws Exception {
/* 49 */     Context.getProcessEngineConfiguration().getDelegateInterceptor().handleInvocation(new JavaDelegateInvocation(this.javaDelegate, execution));
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.ServiceTaskJavaDelegateActivityBehavior
 * JD-Core Version:    0.6.0
 */