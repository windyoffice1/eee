/*     */ package org.activiti.engine.impl.bpmn.behavior;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.activiti.engine.ActivitiException;
/*     */ import org.activiti.engine.delegate.DelegateExecution;
/*     */ import org.activiti.engine.delegate.Expression;
/*     */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*     */ 
/*     */ public class ShellActivityBehavior extends AbstractBpmnActivityBehavior
/*     */ {
/*     */   protected Expression command;
/*     */   protected Expression wait;
/*     */   protected Expression arg1;
/*     */   protected Expression arg2;
/*     */   protected Expression arg3;
/*     */   protected Expression arg4;
/*     */   protected Expression arg5;
/*     */   protected Expression outputVariable;
/*     */   protected Expression errorCodeVariable;
/*     */   protected Expression redirectError;
/*     */   protected Expression cleanEnv;
/*     */   protected Expression directory;
/*     */   String commandStr;
/*     */   String arg1Str;
/*     */   String arg2Str;
/*     */   String arg3Str;
/*     */   String arg4Str;
/*     */   String arg5Str;
/*     */   String waitStr;
/*     */   String resultVariableStr;
/*     */   String errorCodeVariableStr;
/*     */   Boolean waitFlag;
/*     */   Boolean redirectErrorFlag;
/*     */   Boolean cleanEnvBoolan;
/*     */   String directoryStr;
/*     */ 
/*     */   private void readFields(ActivityExecution execution)
/*     */   {
/*  50 */     this.commandStr = getStringFromField(this.command, execution);
/*  51 */     this.arg1Str = getStringFromField(this.arg1, execution);
/*  52 */     this.arg2Str = getStringFromField(this.arg2, execution);
/*  53 */     this.arg3Str = getStringFromField(this.arg3, execution);
/*  54 */     this.arg4Str = getStringFromField(this.arg4, execution);
/*  55 */     this.arg5Str = getStringFromField(this.arg5, execution);
/*  56 */     this.waitStr = getStringFromField(this.wait, execution);
/*  57 */     this.resultVariableStr = getStringFromField(this.outputVariable, execution);
/*  58 */     this.errorCodeVariableStr = getStringFromField(this.errorCodeVariable, execution);
/*     */ 
/*  60 */     String redirectErrorStr = getStringFromField(this.redirectError, execution);
/*  61 */     String cleanEnvStr = getStringFromField(this.cleanEnv, execution);
/*     */ 
/*  63 */     this.waitFlag = Boolean.valueOf((this.waitStr == null) || (this.waitStr.equals("true")));
/*  64 */     this.redirectErrorFlag = Boolean.valueOf((redirectErrorStr != null) && (redirectErrorStr.equals("true")));
/*  65 */     this.cleanEnvBoolan = Boolean.valueOf((cleanEnvStr != null) && (cleanEnvStr.equals("true")));
/*  66 */     this.directoryStr = getStringFromField(this.directory, execution);
/*     */   }
/*     */ 
/*     */   public void execute(ActivityExecution execution)
/*     */   {
/*  72 */     readFields(execution);
/*     */ 
/*  74 */     List argList = new ArrayList();
/*  75 */     argList.add(this.commandStr);
/*     */ 
/*  77 */     if (this.arg1Str != null)
/*  78 */       argList.add(this.arg1Str);
/*  79 */     if (this.arg2Str != null)
/*  80 */       argList.add(this.arg2Str);
/*  81 */     if (this.arg3Str != null)
/*  82 */       argList.add(this.arg3Str);
/*  83 */     if (this.arg4Str != null)
/*  84 */       argList.add(this.arg4Str);
/*  85 */     if (this.arg5Str != null) {
/*  86 */       argList.add(this.arg5Str);
/*     */     }
/*  88 */     ProcessBuilder processBuilder = new ProcessBuilder(argList);
/*     */     try
/*     */     {
/*  91 */       processBuilder.redirectErrorStream(this.redirectErrorFlag.booleanValue());
/*  92 */       if (this.cleanEnvBoolan.booleanValue()) {
/*  93 */         Map env = processBuilder.environment();
/*  94 */         env.clear();
/*     */       }
/*  96 */       if ((this.directoryStr != null) && (this.directoryStr.length() > 0)) {
/*  97 */         processBuilder.directory(new File(this.directoryStr));
/*     */       }
/*  99 */       Process process = processBuilder.start();
/*     */ 
/* 101 */       if (this.waitFlag.booleanValue()) {
/* 102 */         int errorCode = process.waitFor();
/*     */ 
/* 104 */         if (this.resultVariableStr != null) {
/* 105 */           String result = convertStreamToStr(process.getInputStream());
/* 106 */           execution.setVariable(this.resultVariableStr, result);
/*     */         }
/*     */ 
/* 109 */         if (this.errorCodeVariableStr != null) {
/* 110 */           execution.setVariable(this.errorCodeVariableStr, Integer.toString(errorCode));
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 116 */       throw new ActivitiException("Could not execute shell command ", e);
/*     */     }
/*     */ 
/* 119 */     leave(execution);
/*     */   }
/*     */ 
/*     */   public static String convertStreamToStr(InputStream is) throws IOException
/*     */   {
/* 124 */     if (is != null) {
/* 125 */       Writer writer = new StringWriter();
/*     */ 
/* 127 */       char[] buffer = new char[1024];
/*     */       try {
/* 129 */         Reader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
/*     */         int n;
/* 131 */         while ((n = reader.read(buffer)) != -1)
/* 132 */           writer.write(buffer, 0, n);
/*     */       }
/*     */       finally {
/* 135 */         is.close();
/*     */       }
/* 137 */       return writer.toString();
/*     */     }
/* 139 */     return "";
/*     */   }
/*     */ 
/*     */   protected String getStringFromField(Expression expression, DelegateExecution execution)
/*     */   {
/* 144 */     if (expression != null) {
/* 145 */       Object value = expression.getValue(execution);
/* 146 */       if (value != null) {
/* 147 */         return value.toString();
/*     */       }
/*     */     }
/* 150 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.ShellActivityBehavior
 * JD-Core Version:    0.6.0
 */