/*    */ package org.activiti.engine.impl.bpmn.behavior;
/*    */ 
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.impl.bpmn.helper.ScopeUtil;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ import org.activiti.engine.impl.pvm.PvmActivity;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ import org.activiti.engine.impl.pvm.delegate.CompositeActivityBehavior;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ 
/*    */ public class SubProcessActivityBehavior extends AbstractBpmnActivityBehavior
/*    */   implements CompositeActivityBehavior
/*    */ {
/*    */   public void execute(ActivityExecution execution)
/*    */     throws Exception
/*    */   {
/* 35 */     PvmActivity activity = execution.getActivity();
/* 36 */     ActivityImpl initialActivity = (ActivityImpl)activity.getProperty("initial");
/*    */ 
/* 38 */     if (initialActivity == null) {
/* 39 */       throw new ActivitiException("No initial activity found for subprocess " + execution.getActivity().getId());
/*    */     }
/*    */ 
/* 43 */     execution.executeActivity(initialActivity);
/*    */   }
/*    */ 
/*    */   public void lastExecutionEnded(ActivityExecution execution) {
/* 47 */     ScopeUtil.createEventScopeExecution((ExecutionEntity)execution);
/* 48 */     this.bpmnActivityBehavior.performDefaultOutgoingBehavior(execution);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.SubProcessActivityBehavior
 * JD-Core Version:    0.6.0
 */