/*     */ package org.activiti.engine.impl.bpmn.behavior;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.activiti.engine.ActivitiException;
/*     */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*     */ import org.activiti.engine.delegate.Expression;
/*     */ import org.activiti.engine.impl.calendar.DueDateBusinessCalendar;
/*     */ import org.activiti.engine.impl.persistence.entity.TaskEntity;
/*     */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*     */ import org.activiti.engine.impl.task.TaskDefinition;
/*     */ 
/*     */ public class UserTaskActivityBehavior extends TaskActivityBehavior
/*     */ {
/*     */   protected TaskDefinition taskDefinition;
/*     */ 
/*     */   public UserTaskActivityBehavior(TaskDefinition taskDefinition)
/*     */   {
/*  39 */     this.taskDefinition = taskDefinition;
/*     */   }
/*     */ 
/*     */   public void execute(ActivityExecution execution) throws Exception {
/*  43 */     TaskEntity task = TaskEntity.createAndInsert(execution);
/*  44 */     task.setExecution(execution);
/*  45 */     task.setTaskDefinition(this.taskDefinition);
/*     */ 
/*  47 */     if (this.taskDefinition.getNameExpression() != null) {
/*  48 */       String name = (String)this.taskDefinition.getNameExpression().getValue(execution);
/*  49 */       task.setName(name);
/*     */     }
/*     */ 
/*  52 */     if (this.taskDefinition.getDescriptionExpression() != null) {
/*  53 */       String description = (String)this.taskDefinition.getDescriptionExpression().getValue(execution);
/*  54 */       task.setDescription(description);
/*     */     }
/*     */ 
/*  57 */     if (this.taskDefinition.getDueDateExpression() != null) {
/*  58 */       Object dueDate = this.taskDefinition.getDueDateExpression().getValue(execution);
/*  59 */       if (dueDate != null) {
/*  60 */         if ((dueDate instanceof Date))
/*  61 */           task.setDueDate((Date)dueDate);
/*  62 */         else if ((dueDate instanceof String))
/*  63 */           task.setDueDate(new DueDateBusinessCalendar().resolveDuedate((String)dueDate));
/*     */         else {
/*  65 */           throw new ActivitiIllegalArgumentException("Due date expression does not resolve to a Date or Date string: " + this.taskDefinition.getDueDateExpression().getExpressionText());
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  71 */     if (this.taskDefinition.getPriorityExpression() != null) {
/*  72 */       Object priority = this.taskDefinition.getPriorityExpression().getValue(execution);
/*  73 */       if (priority != null) {
/*  74 */         if ((priority instanceof String))
/*     */           try {
/*  76 */             task.setPriority(Integer.valueOf((String)priority).intValue());
/*     */           } catch (NumberFormatException e) {
/*  78 */             throw new ActivitiIllegalArgumentException("Priority does not resolve to a number: " + priority, e);
/*     */           }
/*  80 */         else if ((priority instanceof Number))
/*  81 */           task.setPriority(((Number)priority).intValue());
/*     */         else {
/*  83 */           throw new ActivitiIllegalArgumentException("Priority expression does not resolve to a number: " + this.taskDefinition.getPriorityExpression().getExpressionText());
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  89 */     handleAssignments(task, execution);
/*     */ 
/*  92 */     task.fireEvent("create");
/*     */   }
/*     */ 
/*     */   public void signal(ActivityExecution execution, String signalName, Object signalData) throws Exception {
/*  96 */     leave(execution);
/*     */   }
/*     */ 
/*     */   protected void handleAssignments(TaskEntity task, ActivityExecution execution)
/*     */   {
/* 101 */     if (this.taskDefinition.getAssigneeExpression() != null) {
/* 102 */       task.setAssignee((String)this.taskDefinition.getAssigneeExpression().getValue(execution));
/*     */     }
/*     */ 
/* 105 */     if (!this.taskDefinition.getCandidateGroupIdExpressions().isEmpty()) {
/* 106 */       for (Expression groupIdExpr : this.taskDefinition.getCandidateGroupIdExpressions()) {
/* 107 */         Object value = groupIdExpr.getValue(execution);
/* 108 */         if ((value instanceof String)) {
/* 109 */           List candiates = extractCandidates((String)value);
/* 110 */           task.addCandidateGroups(candiates);
/* 111 */         } else if ((value instanceof Collection)) {
/* 112 */           task.addCandidateGroups((Collection)value);
/*     */         } else {
/* 114 */           throw new ActivitiIllegalArgumentException("Expression did not resolve to a string or collection of strings");
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 119 */     if (!this.taskDefinition.getCandidateUserIdExpressions().isEmpty())
/* 120 */       for (Expression userIdExpr : this.taskDefinition.getCandidateUserIdExpressions()) {
/* 121 */         Object value = userIdExpr.getValue(execution);
/* 122 */         if ((value instanceof String)) {
/* 123 */           List candiates = extractCandidates((String)value);
/* 124 */           task.addCandidateUsers(candiates);
/* 125 */         } else if ((value instanceof Collection)) {
/* 126 */           task.addCandidateUsers((Collection)value);
/*     */         } else {
/* 128 */           throw new ActivitiException("Expression did not resolve to a string or collection of strings");
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   protected List<String> extractCandidates(String str)
/*     */   {
/* 141 */     return Arrays.asList(str.split("[\\s]*,[\\s]*"));
/*     */   }
/*     */ 
/*     */   public TaskDefinition getTaskDefinition()
/*     */   {
/* 147 */     return this.taskDefinition;
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.UserTaskActivityBehavior
 * JD-Core Version:    0.6.0
 */