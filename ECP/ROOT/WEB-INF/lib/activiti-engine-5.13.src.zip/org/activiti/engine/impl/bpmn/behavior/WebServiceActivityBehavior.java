/*     */ package org.activiti.engine.impl.bpmn.behavior;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.activiti.engine.impl.bpmn.data.AbstractDataAssociation;
/*     */ import org.activiti.engine.impl.bpmn.data.IOSpecification;
/*     */ import org.activiti.engine.impl.bpmn.data.ItemInstance;
/*     */ import org.activiti.engine.impl.bpmn.data.StructureInstance;
/*     */ import org.activiti.engine.impl.bpmn.webservice.MessageDefinition;
/*     */ import org.activiti.engine.impl.bpmn.webservice.MessageInstance;
/*     */ import org.activiti.engine.impl.bpmn.webservice.Operation;
/*     */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*     */ 
/*     */ public class WebServiceActivityBehavior extends AbstractBpmnActivityBehavior
/*     */ {
/*     */   public static final String CURRENT_MESSAGE = "org.activiti.engine.impl.bpmn.CURRENT_MESSAGE";
/*     */   protected Operation operation;
/*     */   protected IOSpecification ioSpecification;
/*     */   protected List<AbstractDataAssociation> dataInputAssociations;
/*     */   protected List<AbstractDataAssociation> dataOutputAssociations;
/*     */ 
/*     */   public WebServiceActivityBehavior()
/*     */   {
/*  45 */     this.dataInputAssociations = new ArrayList();
/*  46 */     this.dataOutputAssociations = new ArrayList();
/*     */   }
/*     */ 
/*     */   public void addDataInputAssociation(AbstractDataAssociation dataAssociation) {
/*  50 */     this.dataInputAssociations.add(dataAssociation);
/*     */   }
/*     */ 
/*     */   public void addDataOutputAssociation(AbstractDataAssociation dataAssociation) {
/*  54 */     this.dataOutputAssociations.add(dataAssociation);
/*     */   }
/*     */ 
/*     */   public void execute(ActivityExecution execution)
/*     */     throws Exception
/*     */   {
/*     */     MessageInstance message;
/*     */     MessageInstance message;
/*  63 */     if (this.ioSpecification != null) {
/*  64 */       this.ioSpecification.initialize(execution);
/*  65 */       ItemInstance inputItem = (ItemInstance)execution.getVariable(this.ioSpecification.getFirstDataInputName());
/*  66 */       message = new MessageInstance(this.operation.getInMessage(), inputItem);
/*     */     } else {
/*  68 */       message = this.operation.getInMessage().createInstance();
/*     */     }
/*     */ 
/*  71 */     execution.setVariable("org.activiti.engine.impl.bpmn.CURRENT_MESSAGE", message);
/*     */ 
/*  73 */     fillMessage(message, execution);
/*     */ 
/*  75 */     MessageInstance receivedMessage = this.operation.sendMessage(message);
/*     */ 
/*  77 */     execution.setVariable("org.activiti.engine.impl.bpmn.CURRENT_MESSAGE", receivedMessage);
/*     */ 
/*  79 */     if (this.ioSpecification != null) {
/*  80 */       String firstDataOutputName = this.ioSpecification.getFirstDataOutputName();
/*  81 */       if (firstDataOutputName != null) {
/*  82 */         ItemInstance outputItem = (ItemInstance)execution.getVariable(firstDataOutputName);
/*  83 */         outputItem.getStructureInstance().loadFrom(receivedMessage.getStructureInstance().toArray());
/*     */       }
/*     */     }
/*     */ 
/*  87 */     returnMessage(receivedMessage, execution);
/*     */ 
/*  89 */     execution.setVariable("org.activiti.engine.impl.bpmn.CURRENT_MESSAGE", null);
/*  90 */     leave(execution);
/*     */   }
/*     */ 
/*     */   private void returnMessage(MessageInstance message, ActivityExecution execution) {
/*  94 */     for (AbstractDataAssociation dataAssociation : this.dataOutputAssociations)
/*  95 */       dataAssociation.evaluate(execution);
/*     */   }
/*     */ 
/*     */   private void fillMessage(MessageInstance message, ActivityExecution execution)
/*     */   {
/* 100 */     for (AbstractDataAssociation dataAssociation : this.dataInputAssociations)
/* 101 */       dataAssociation.evaluate(execution);
/*     */   }
/*     */ 
/*     */   public void setIoSpecification(IOSpecification ioSpecification)
/*     */   {
/* 106 */     this.ioSpecification = ioSpecification;
/*     */   }
/*     */ 
/*     */   public void setOperation(Operation operation) {
/* 110 */     this.operation = operation;
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.behavior.WebServiceActivityBehavior
 * JD-Core Version:    0.6.0
 */