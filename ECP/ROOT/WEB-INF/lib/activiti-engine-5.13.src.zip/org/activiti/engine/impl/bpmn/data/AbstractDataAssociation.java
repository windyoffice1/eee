/*    */ package org.activiti.engine.impl.bpmn.data;
/*    */ 
/*    */ import org.activiti.engine.delegate.Expression;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ 
/*    */ public abstract class AbstractDataAssociation
/*    */ {
/*    */   protected String source;
/*    */   protected Expression sourceExpression;
/*    */   protected String target;
/*    */ 
/*    */   protected AbstractDataAssociation(String source, String target)
/*    */   {
/* 32 */     this.source = source;
/* 33 */     this.target = target;
/*    */   }
/*    */ 
/*    */   protected AbstractDataAssociation(Expression sourceExpression, String target) {
/* 37 */     this.sourceExpression = sourceExpression;
/* 38 */     this.target = target;
/*    */   }
/*    */   public abstract void evaluate(ActivityExecution paramActivityExecution);
/*    */ 
/*    */   public String getSource() {
/* 44 */     return this.source;
/*    */   }
/*    */ 
/*    */   public String getTarget() {
/* 48 */     return this.target;
/*    */   }
/*    */ 
/*    */   public Expression getSourceExpression()
/*    */   {
/* 53 */     return this.sourceExpression;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.data.AbstractDataAssociation
 * JD-Core Version:    0.6.0
 */