/*    */ package org.activiti.engine.impl.bpmn.data;
/*    */ 
/*    */ import org.activiti.engine.delegate.Expression;
/*    */ import org.activiti.engine.delegate.VariableScope;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ 
/*    */ public class Assignment
/*    */ {
/*    */   protected Expression fromExpression;
/*    */   protected Expression toExpression;
/*    */ 
/*    */   public Assignment(Expression fromExpression, Expression toExpression)
/*    */   {
/* 31 */     this.fromExpression = fromExpression;
/* 32 */     this.toExpression = toExpression;
/*    */   }
/*    */ 
/*    */   public void evaluate(ActivityExecution execution) {
/* 36 */     VariableScope variableScope = execution;
/* 37 */     Object value = this.fromExpression.getValue(variableScope);
/* 38 */     this.toExpression.setValue(value, variableScope);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.data.Assignment
 * JD-Core Version:    0.6.0
 */