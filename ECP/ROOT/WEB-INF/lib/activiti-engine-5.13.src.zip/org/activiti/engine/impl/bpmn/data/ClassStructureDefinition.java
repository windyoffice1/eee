/*    */ package org.activiti.engine.impl.bpmn.data;
/*    */ 
/*    */ public class ClassStructureDefinition
/*    */   implements FieldBaseStructureDefinition
/*    */ {
/*    */   protected String id;
/*    */   protected Class<?> classStructure;
/*    */ 
/*    */   public ClassStructureDefinition(Class<?> classStructure)
/*    */   {
/* 27 */     this(classStructure.getName(), classStructure);
/*    */   }
/*    */ 
/*    */   public ClassStructureDefinition(String id, Class<?> classStructure) {
/* 31 */     this.id = id;
/* 32 */     this.classStructure = classStructure;
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 36 */     return this.id;
/*    */   }
/*    */ 
/*    */   public int getFieldSize()
/*    */   {
/* 41 */     return 0;
/*    */   }
/*    */ 
/*    */   public String getFieldNameAt(int index)
/*    */   {
/* 46 */     return null;
/*    */   }
/*    */ 
/*    */   public Class<?> getFieldTypeAt(int index)
/*    */   {
/* 51 */     return null;
/*    */   }
/*    */ 
/*    */   public StructureInstance createInstance() {
/* 55 */     return new FieldBaseStructureInstance(this);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.data.ClassStructureDefinition
 * JD-Core Version:    0.6.0
 */