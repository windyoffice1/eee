/*    */ package org.activiti.engine.impl.bpmn.data;
/*    */ 
/*    */ public class Data
/*    */ {
/*    */   protected String id;
/*    */   protected String name;
/*    */   protected ItemDefinition definition;
/*    */ 
/*    */   public Data(String id, String name, ItemDefinition definition)
/*    */   {
/* 30 */     this.id = id;
/* 31 */     this.name = name;
/* 32 */     this.definition = definition;
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 36 */     return this.id;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 40 */     return this.name;
/*    */   }
/*    */ 
/*    */   public ItemDefinition getDefinition() {
/* 44 */     return this.definition;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.data.Data
 * JD-Core Version:    0.6.0
 */