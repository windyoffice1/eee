/*    */ package org.activiti.engine.impl.bpmn.data;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class FieldBaseStructureInstance
/*    */   implements StructureInstance
/*    */ {
/*    */   protected FieldBaseStructureDefinition structureDefinition;
/*    */   protected Map<String, Object> fieldValues;
/*    */ 
/*    */   public FieldBaseStructureInstance(FieldBaseStructureDefinition structureDefinition)
/*    */   {
/* 30 */     this.structureDefinition = structureDefinition;
/* 31 */     this.fieldValues = new HashMap();
/*    */   }
/*    */ 
/*    */   public Object getFieldValue(String fieldName) {
/* 35 */     return this.fieldValues.get(fieldName);
/*    */   }
/*    */ 
/*    */   public void setFieldValue(String fieldName, Object value) {
/* 39 */     this.fieldValues.put(fieldName, value);
/*    */   }
/*    */ 
/*    */   public int getFieldSize() {
/* 43 */     return this.structureDefinition.getFieldSize();
/*    */   }
/*    */ 
/*    */   public String getFieldNameAt(int index) {
/* 47 */     return this.structureDefinition.getFieldNameAt(index);
/*    */   }
/*    */ 
/*    */   public Object[] toArray() {
/* 51 */     int fieldSize = getFieldSize();
/* 52 */     Object[] arguments = new Object[fieldSize];
/* 53 */     for (int i = 0; i < fieldSize; i++) {
/* 54 */       String fieldName = getFieldNameAt(i);
/* 55 */       Object argument = getFieldValue(fieldName);
/* 56 */       arguments[i] = argument;
/*    */     }
/* 58 */     return arguments;
/*    */   }
/*    */ 
/*    */   public void loadFrom(Object[] array) {
/* 62 */     int fieldSize = getFieldSize();
/* 63 */     for (int i = 0; i < fieldSize; i++) {
/* 64 */       String fieldName = getFieldNameAt(i);
/* 65 */       Object fieldValue = array[i];
/* 66 */       setFieldValue(fieldName, fieldValue);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.data.FieldBaseStructureInstance
 * JD-Core Version:    0.6.0
 */