/*    */ package org.activiti.engine.impl.bpmn.data;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ 
/*    */ public class IOSpecification
/*    */ {
/*    */   protected List<Data> dataInputs;
/*    */   protected List<Data> dataOutputs;
/*    */   protected List<DataRef> dataInputRefs;
/*    */   protected List<DataRef> dataOutputRefs;
/*    */ 
/*    */   public IOSpecification()
/*    */   {
/* 38 */     this.dataInputs = new ArrayList();
/* 39 */     this.dataOutputs = new ArrayList();
/* 40 */     this.dataInputRefs = new ArrayList();
/* 41 */     this.dataOutputRefs = new ArrayList();
/*    */   }
/*    */ 
/*    */   public void initialize(ActivityExecution execution) {
/* 45 */     for (Data data : this.dataInputs) {
/* 46 */       execution.setVariable(data.getName(), data.getDefinition().createInstance());
/*    */     }
/*    */ 
/* 49 */     for (Data data : this.dataOutputs)
/* 50 */       execution.setVariable(data.getName(), data.getDefinition().createInstance());
/*    */   }
/*    */ 
/*    */   public List<Data> getDataInputs()
/*    */   {
/* 55 */     return Collections.unmodifiableList(this.dataInputs);
/*    */   }
/*    */ 
/*    */   public List<Data> getDataOutputs() {
/* 59 */     return Collections.unmodifiableList(this.dataOutputs);
/*    */   }
/*    */ 
/*    */   public void addInput(Data data) {
/* 63 */     this.dataInputs.add(data);
/*    */   }
/*    */ 
/*    */   public void addOutput(Data data) {
/* 67 */     this.dataOutputs.add(data);
/*    */   }
/*    */ 
/*    */   public void addInputRef(DataRef dataRef) {
/* 71 */     this.dataInputRefs.add(dataRef);
/*    */   }
/*    */ 
/*    */   public void addOutputRef(DataRef dataRef) {
/* 75 */     this.dataOutputRefs.add(dataRef);
/*    */   }
/*    */ 
/*    */   public String getFirstDataInputName() {
/* 79 */     return ((Data)this.dataInputs.get(0)).getName();
/*    */   }
/*    */ 
/*    */   public String getFirstDataOutputName() {
/* 83 */     if ((this.dataOutputs != null) && (!this.dataOutputs.isEmpty())) {
/* 84 */       return ((Data)this.dataOutputs.get(0)).getName();
/*    */     }
/* 86 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.data.IOSpecification
 * JD-Core Version:    0.6.0
 */