/*    */ package org.activiti.engine.impl.bpmn.data;
/*    */ 
/*    */ public class ItemDefinition
/*    */ {
/*    */   protected String id;
/*    */   protected StructureDefinition structure;
/*    */   protected boolean isCollection;
/*    */   protected ItemKind itemKind;
/*    */ 
/*    */   private ItemDefinition()
/*    */   {
/* 33 */     this.isCollection = false;
/* 34 */     this.itemKind = ItemKind.Information;
/*    */   }
/*    */ 
/*    */   public ItemDefinition(String id, StructureDefinition structure) {
/* 38 */     this();
/* 39 */     this.id = id;
/* 40 */     this.structure = structure;
/*    */   }
/*    */ 
/*    */   public ItemInstance createInstance() {
/* 44 */     return new ItemInstance(this, this.structure.createInstance());
/*    */   }
/*    */ 
/*    */   public StructureDefinition getStructureDefinition() {
/* 48 */     return this.structure;
/*    */   }
/*    */ 
/*    */   public boolean isCollection() {
/* 52 */     return this.isCollection;
/*    */   }
/*    */ 
/*    */   public void setCollection(boolean isCollection) {
/* 56 */     this.isCollection = isCollection;
/*    */   }
/*    */ 
/*    */   public ItemKind getItemKind() {
/* 60 */     return this.itemKind;
/*    */   }
/*    */ 
/*    */   public void setItemKind(ItemKind itemKind) {
/* 64 */     this.itemKind = itemKind;
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 68 */     return this.id;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.data.ItemDefinition
 * JD-Core Version:    0.6.0
 */