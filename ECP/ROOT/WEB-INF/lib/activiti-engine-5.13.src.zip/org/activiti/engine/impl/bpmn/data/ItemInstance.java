/*    */ package org.activiti.engine.impl.bpmn.data;
/*    */ 
/*    */ public class ItemInstance
/*    */ {
/*    */   protected ItemDefinition item;
/*    */   protected StructureInstance structureInstance;
/*    */ 
/*    */   public ItemInstance(ItemDefinition item, StructureInstance structureInstance)
/*    */   {
/* 28 */     this.item = item;
/* 29 */     this.structureInstance = structureInstance;
/*    */   }
/*    */ 
/*    */   public ItemDefinition getItem() {
/* 33 */     return this.item;
/*    */   }
/*    */ 
/*    */   public StructureInstance getStructureInstance() {
/* 37 */     return this.structureInstance;
/*    */   }
/*    */ 
/*    */   private FieldBaseStructureInstance getFieldBaseStructureInstance() {
/* 41 */     return (FieldBaseStructureInstance)this.structureInstance;
/*    */   }
/*    */ 
/*    */   public Object getFieldValue(String fieldName) {
/* 45 */     return getFieldBaseStructureInstance().getFieldValue(fieldName);
/*    */   }
/*    */ 
/*    */   public void setFieldValue(String fieldName, Object value) {
/* 49 */     getFieldBaseStructureInstance().setFieldValue(fieldName, value);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.data.ItemInstance
 * JD-Core Version:    0.6.0
 */