/*    */ package org.activiti.engine.impl.bpmn.data;
/*    */ 
/*    */ public class PrimitiveStructureDefinition
/*    */   implements StructureDefinition
/*    */ {
/*    */   protected String id;
/*    */   protected Class<?> primitiveClass;
/*    */ 
/*    */   public PrimitiveStructureDefinition(String id, Class<?> primitiveClass)
/*    */   {
/* 27 */     this.id = id;
/* 28 */     this.primitiveClass = primitiveClass;
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 32 */     return this.id;
/*    */   }
/*    */ 
/*    */   public Class<?> getPrimitiveClass() {
/* 36 */     return this.primitiveClass;
/*    */   }
/*    */ 
/*    */   public StructureInstance createInstance() {
/* 40 */     return new PrimitiveStructureInstance(this);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.data.PrimitiveStructureDefinition
 * JD-Core Version:    0.6.0
 */