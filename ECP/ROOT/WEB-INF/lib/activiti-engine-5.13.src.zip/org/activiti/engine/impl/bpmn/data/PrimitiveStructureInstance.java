/*    */ package org.activiti.engine.impl.bpmn.data;
/*    */ 
/*    */ public class PrimitiveStructureInstance
/*    */   implements StructureInstance
/*    */ {
/*    */   protected Object primitive;
/*    */   protected PrimitiveStructureDefinition definition;
/*    */ 
/*    */   public PrimitiveStructureInstance(PrimitiveStructureDefinition definition)
/*    */   {
/* 27 */     this(definition, null);
/*    */   }
/*    */ 
/*    */   public PrimitiveStructureInstance(PrimitiveStructureDefinition definition, Object primitive) {
/* 31 */     this.definition = definition;
/* 32 */     this.primitive = primitive;
/*    */   }
/*    */ 
/*    */   public Object getPrimitive() {
/* 36 */     return this.primitive;
/*    */   }
/*    */ 
/*    */   public Object[] toArray() {
/* 40 */     return new Object[] { this.primitive };
/*    */   }
/*    */ 
/*    */   public void loadFrom(Object[] array) {
/* 44 */     for (int i = 0; i < array.length; i++) {
/* 45 */       Object object = array[i];
/* 46 */       if (this.definition.getPrimitiveClass().isInstance(object)) {
/* 47 */         this.primitive = object;
/* 48 */         return;
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.data.PrimitiveStructureInstance
 * JD-Core Version:    0.6.0
 */