/*    */ package org.activiti.engine.impl.bpmn.data;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.activiti.engine.delegate.Expression;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ 
/*    */ public class SimpleDataInputAssociation extends AbstractDataAssociation
/*    */ {
/* 28 */   protected List<Assignment> assignments = new ArrayList();
/*    */ 
/*    */   public SimpleDataInputAssociation(Expression sourceExpression, String target) {
/* 31 */     super(sourceExpression, target);
/*    */   }
/*    */ 
/*    */   public SimpleDataInputAssociation(String source, String target) {
/* 35 */     super(source, target);
/*    */   }
/*    */ 
/*    */   public void addAssignment(Assignment assignment) {
/* 39 */     this.assignments.add(assignment);
/*    */   }
/*    */ 
/*    */   public void evaluate(ActivityExecution execution) {
/* 43 */     for (Assignment assignment : this.assignments)
/* 44 */       assignment.evaluate(execution);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.data.SimpleDataInputAssociation
 * JD-Core Version:    0.6.0
 */