/*    */ package org.activiti.engine.impl.bpmn.data;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class SimpleStructureDefinition
/*    */   implements FieldBaseStructureDefinition
/*    */ {
/*    */   protected String id;
/*    */   protected List<String> fieldNames;
/*    */   protected List<Class<?>> fieldTypes;
/*    */ 
/*    */   public SimpleStructureDefinition(String id)
/*    */   {
/* 32 */     this.id = id;
/* 33 */     this.fieldNames = new ArrayList();
/* 34 */     this.fieldTypes = new ArrayList();
/*    */   }
/*    */ 
/*    */   public int getFieldSize() {
/* 38 */     return this.fieldNames.size();
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 42 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setFieldName(int index, String fieldName, Class<?> type) {
/* 46 */     growListToContain(index, this.fieldNames);
/* 47 */     growListToContain(index, this.fieldTypes);
/* 48 */     this.fieldNames.set(index, fieldName);
/* 49 */     this.fieldTypes.set(index, type);
/*    */   }
/*    */ 
/*    */   private void growListToContain(int index, List<?> list) {
/* 53 */     if (list.size() - 1 < index)
/* 54 */       for (int i = list.size(); i <= index; i++)
/* 55 */         list.add(null);
/*    */   }
/*    */ 
/*    */   public String getFieldNameAt(int index)
/*    */   {
/* 61 */     return (String)this.fieldNames.get(index);
/*    */   }
/*    */ 
/*    */   public Class<?> getFieldTypeAt(int index) {
/* 65 */     return (Class)this.fieldTypes.get(index);
/*    */   }
/*    */ 
/*    */   public StructureInstance createInstance() {
/* 69 */     return new FieldBaseStructureInstance(this);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.data.SimpleStructureDefinition
 * JD-Core Version:    0.6.0
 */