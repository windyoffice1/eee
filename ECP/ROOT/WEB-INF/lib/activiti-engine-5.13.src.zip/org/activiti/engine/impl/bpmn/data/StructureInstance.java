package org.activiti.engine.impl.bpmn.data;

public abstract interface StructureInstance
{
  public abstract Object[] toArray();

  public abstract void loadFrom(Object[] paramArrayOfObject);
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.data.StructureInstance
 * JD-Core Version:    0.6.0
 */