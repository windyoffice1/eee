/*    */ package org.activiti.engine.impl.bpmn.data;
/*    */ 
/*    */ import org.activiti.engine.delegate.Expression;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ 
/*    */ public class TransformationDataOutputAssociation extends AbstractDataAssociation
/*    */ {
/*    */   protected Expression transformation;
/*    */ 
/*    */   public TransformationDataOutputAssociation(String sourceRef, String targetRef, Expression transformation)
/*    */   {
/* 28 */     super(sourceRef, targetRef);
/* 29 */     this.transformation = transformation;
/*    */   }
/*    */ 
/*    */   public void evaluate(ActivityExecution execution) {
/* 33 */     Object value = this.transformation.getValue(execution);
/* 34 */     execution.setVariable(getTarget(), value);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.data.TransformationDataOutputAssociation
 * JD-Core Version:    0.6.0
 */