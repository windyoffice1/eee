/*     */ package org.activiti.engine.impl.bpmn.deployer;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.activiti.engine.ActivitiException;
/*     */ import org.activiti.engine.delegate.Expression;
/*     */ import org.activiti.engine.impl.bpmn.diagram.ProcessDiagramGenerator;
/*     */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*     */ import org.activiti.engine.impl.bpmn.parser.BpmnParser;
/*     */ import org.activiti.engine.impl.bpmn.parser.EventSubscriptionDeclaration;
/*     */ import org.activiti.engine.impl.cfg.IdGenerator;
/*     */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*     */ import org.activiti.engine.impl.cmd.DeleteJobsCmd;
/*     */ import org.activiti.engine.impl.context.Context;
/*     */ import org.activiti.engine.impl.db.DbSqlSession;
/*     */ import org.activiti.engine.impl.el.ExpressionManager;
/*     */ import org.activiti.engine.impl.interceptor.CommandContext;
/*     */ import org.activiti.engine.impl.jobexecutor.TimerDeclarationImpl;
/*     */ import org.activiti.engine.impl.persistence.deploy.Deployer;
/*     */ import org.activiti.engine.impl.persistence.deploy.DeploymentCache;
/*     */ import org.activiti.engine.impl.persistence.deploy.DeploymentManager;
/*     */ import org.activiti.engine.impl.persistence.entity.DeploymentEntity;
/*     */ import org.activiti.engine.impl.persistence.entity.EventSubscriptionEntity;
/*     */ import org.activiti.engine.impl.persistence.entity.EventSubscriptionEntityManager;
/*     */ import org.activiti.engine.impl.persistence.entity.IdentityLinkEntity;
/*     */ import org.activiti.engine.impl.persistence.entity.JobEntityManager;
/*     */ import org.activiti.engine.impl.persistence.entity.MessageEventSubscriptionEntity;
/*     */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*     */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntityManager;
/*     */ import org.activiti.engine.impl.persistence.entity.ResourceEntity;
/*     */ import org.activiti.engine.impl.persistence.entity.TimerEntity;
/*     */ import org.activiti.engine.impl.util.IoUtil;
/*     */ import org.activiti.engine.runtime.Job;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class BpmnDeployer
/*     */   implements Deployer
/*     */ {
/*  58 */   private static final Logger LOG = LoggerFactory.getLogger(BpmnDeployer.class);
/*     */ 
/*  60 */   public static final String[] BPMN_RESOURCE_SUFFIXES = { "bpmn20.xml", "bpmn" };
/*  61 */   public static final String[] DIAGRAM_SUFFIXES = { "png", "jpg", "gif", "svg" };
/*     */   protected ExpressionManager expressionManager;
/*     */   protected BpmnParser bpmnParser;
/*     */   protected IdGenerator idGenerator;
/*     */ 
/*     */   public void deploy(DeploymentEntity deployment)
/*     */   {
/*  68 */     LOG.debug("Processing deployment {}", deployment.getName());
/*     */ 
/*  70 */     List processDefinitions = new ArrayList();
/*  71 */     Map resources = deployment.getResources();
/*     */ 
/*  73 */     for (Iterator i$ = resources.keySet().iterator(); i$.hasNext(); ) { resourceName = (String)i$.next();
/*     */ 
/*  75 */       LOG.info("Processing resource {}", resourceName);
/*  76 */       if (isBpmnResource(resourceName)) {
/*  77 */         ResourceEntity resource = (ResourceEntity)resources.get(resourceName);
/*  78 */         byte[] bytes = resource.getBytes();
/*  79 */         ByteArrayInputStream inputStream = new ByteArrayInputStream(bytes);
/*     */ 
/*  81 */         bpmnParse = this.bpmnParser.createParse().sourceInputStream(inputStream).deployment(deployment).name(resourceName);
/*     */ 
/*  86 */         bpmnParse.execute();
/*     */ 
/*  88 */         for (ProcessDefinitionEntity processDefinition : bpmnParse.getProcessDefinitions()) {
/*  89 */           processDefinition.setResourceName(resourceName);
/*     */ 
/*  91 */           String diagramResourceName = getDiagramResourceForProcess(resourceName, processDefinition.getKey(), resources);
/*     */ 
/*  96 */           if ((deployment.isNew()) && 
/*  97 */             (Context.getProcessEngineConfiguration().isCreateDiagramOnDeploy()) && (diagramResourceName == null) && (processDefinition.isGraphicalNotationDefined())) {
/*     */             try
/*     */             {
/* 100 */               byte[] diagramBytes = IoUtil.readInputStream(ProcessDiagramGenerator.generatePngDiagram(bpmnParse.getBpmnModel()), null);
/* 101 */               diagramResourceName = getProcessImageResourceName(resourceName, processDefinition.getKey(), "png");
/* 102 */               createResource(diagramResourceName, diagramBytes, deployment);
/*     */             } catch (Throwable t) {
/* 104 */               LOG.warn("Error while generating process diagram, image will not be stored in repository", t);
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 109 */           processDefinition.setDiagramResourceName(diagramResourceName);
/* 110 */           processDefinitions.add(processDefinition);
/*     */         }
/*     */       }
/*     */     }
/*     */     String resourceName;
/*     */     BpmnParse bpmnParse;
/* 116 */     List keyList = new ArrayList();
/* 117 */     for (ProcessDefinitionEntity processDefinition : processDefinitions) {
/* 118 */       if (keyList.contains(processDefinition.getKey())) {
/* 119 */         throw new ActivitiException("The deployment contains process definitions with the same key (process id atrribute), this is not allowed");
/*     */       }
/* 121 */       keyList.add(processDefinition.getKey());
/*     */     }
/*     */ 
/* 124 */     CommandContext commandContext = Context.getCommandContext();
/* 125 */     ProcessDefinitionEntityManager processDefinitionManager = commandContext.getProcessDefinitionEntityManager();
/* 126 */     DbSqlSession dbSqlSession = (DbSqlSession)commandContext.getSession(DbSqlSession.class);
/* 127 */     for (ProcessDefinitionEntity processDefinition : processDefinitions)
/*     */     {
/* 129 */       if (deployment.isNew())
/*     */       {
/* 132 */         ProcessDefinitionEntity latestProcessDefinition = processDefinitionManager.findLatestProcessDefinitionByKey(processDefinition.getKey());
/*     */         int processDefinitionVersion;
/*     */         int processDefinitionVersion;
/* 133 */         if (latestProcessDefinition != null)
/* 134 */           processDefinitionVersion = latestProcessDefinition.getVersion() + 1;
/*     */         else {
/* 136 */           processDefinitionVersion = 1;
/*     */         }
/*     */ 
/* 139 */         processDefinition.setVersion(processDefinitionVersion);
/* 140 */         processDefinition.setDeploymentId(deployment.getId());
/*     */ 
/* 142 */         String nextId = this.idGenerator.getNextId();
/* 143 */         String processDefinitionId = processDefinition.getKey() + ":" + processDefinition.getVersion() + ":" + nextId;
/*     */ 
/* 148 */         if (processDefinitionId.length() > 64) {
/* 149 */           processDefinitionId = nextId;
/*     */         }
/* 151 */         processDefinition.setId(processDefinitionId);
/*     */ 
/* 153 */         removeObsoleteTimers(processDefinition);
/* 154 */         addTimerDeclarations(processDefinition);
/*     */ 
/* 156 */         removeObsoleteMessageEventSubscriptions(processDefinition, latestProcessDefinition);
/* 157 */         addMessageEventSubscriptions(processDefinition);
/*     */ 
/* 159 */         dbSqlSession.insert(processDefinition);
/* 160 */         addAuthorizations(processDefinition);
/*     */       }
/*     */       else
/*     */       {
/* 164 */         String deploymentId = deployment.getId();
/* 165 */         processDefinition.setDeploymentId(deploymentId);
/* 166 */         ProcessDefinitionEntity persistedProcessDefinition = processDefinitionManager.findProcessDefinitionByDeploymentAndKey(deploymentId, processDefinition.getKey());
/* 167 */         processDefinition.setId(persistedProcessDefinition.getId());
/* 168 */         processDefinition.setVersion(persistedProcessDefinition.getVersion());
/* 169 */         processDefinition.setSuspensionState(persistedProcessDefinition.getSuspensionState());
/*     */       }
/*     */ 
/* 173 */       Context.getProcessEngineConfiguration().getDeploymentManager().getProcessDefinitionCache().add(processDefinition.getId(), processDefinition);
/*     */ 
/* 180 */       deployment.addDeployedArtifact(processDefinition);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void addTimerDeclarations(ProcessDefinitionEntity processDefinition)
/*     */   {
/* 186 */     List timerDeclarations = (List)processDefinition.getProperty("timerStart");
/* 187 */     if (timerDeclarations != null)
/* 188 */       for (TimerDeclarationImpl timerDeclaration : timerDeclarations) {
/* 189 */         TimerEntity timer = timerDeclaration.prepareTimerEntity(null);
/* 190 */         timer.setProcessDefinitionId(processDefinition.getId());
/* 191 */         Context.getCommandContext().getJobEntityManager().schedule(timer);
/*     */       }
/*     */   }
/*     */ 
/*     */   protected void removeObsoleteTimers(ProcessDefinitionEntity processDefinition)
/*     */   {
/* 200 */     List jobsToDelete = Context.getCommandContext().getJobEntityManager().findJobsByConfiguration("timer-start-event", processDefinition.getKey());
/*     */ 
/* 205 */     for (Job job : jobsToDelete)
/* 206 */       new DeleteJobsCmd(job.getId()).execute(Context.getCommandContext());
/*     */   }
/*     */ 
/*     */   protected void removeObsoleteMessageEventSubscriptions(ProcessDefinitionEntity processDefinition, ProcessDefinitionEntity latestProcessDefinition)
/*     */   {
/* 212 */     if (latestProcessDefinition != null) {
/* 213 */       CommandContext commandContext = Context.getCommandContext();
/*     */ 
/* 215 */       List subscriptionsToDelete = commandContext.getEventSubscriptionEntityManager().findEventSubscriptionsByConfiguration("message", latestProcessDefinition.getId());
/*     */ 
/* 219 */       for (EventSubscriptionEntity eventSubscriptionEntity : subscriptionsToDelete)
/* 220 */         eventSubscriptionEntity.delete();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void addMessageEventSubscriptions(ProcessDefinitionEntity processDefinition)
/*     */   {
/* 228 */     CommandContext commandContext = Context.getCommandContext();
/* 229 */     List messageEventDefinitions = (List)processDefinition.getProperty("eventDefinitions");
/* 230 */     if (messageEventDefinitions != null)
/* 231 */       for (EventSubscriptionDeclaration messageEventDefinition : messageEventDefinitions)
/* 232 */         if (messageEventDefinition.isStartEvent())
/*     */         {
/* 234 */           List subscriptionsForSameMessageName = commandContext.getEventSubscriptionEntityManager().findEventSubscriptionsByName("message", messageEventDefinition.getEventName());
/*     */ 
/* 238 */           List cachedSubscriptions = commandContext.getDbSqlSession().findInCache(MessageEventSubscriptionEntity.class);
/*     */ 
/* 241 */           for (MessageEventSubscriptionEntity cachedSubscription : cachedSubscriptions) {
/* 242 */             if ((messageEventDefinition.getEventName().equals(cachedSubscription.getEventName())) && (!subscriptionsForSameMessageName.contains(cachedSubscription)))
/*     */             {
/* 244 */               subscriptionsForSameMessageName.add(cachedSubscription);
/*     */             }
/*     */           }
/*     */ 
/* 248 */           subscriptionsForSameMessageName = commandContext.getDbSqlSession().pruneDeletedEntities(subscriptionsForSameMessageName);
/*     */ 
/* 252 */           if (!subscriptionsForSameMessageName.isEmpty()) {
/* 253 */             throw new ActivitiException("Cannot deploy process definition '" + processDefinition.getResourceName() + "': there already is a message event subscription for the message with name '" + messageEventDefinition.getEventName() + "'.");
/*     */           }
/*     */ 
/* 257 */           MessageEventSubscriptionEntity newSubscription = new MessageEventSubscriptionEntity();
/* 258 */           newSubscription.setEventName(messageEventDefinition.getEventName());
/* 259 */           newSubscription.setActivityId(messageEventDefinition.getActivityId());
/* 260 */           newSubscription.setConfiguration(processDefinition.getId());
/*     */ 
/* 262 */           newSubscription.insert();
/*     */         }
/*     */   }
/*     */ 
/*     */   private void addAuthorizationsFromIterator(Set<Expression> exprSet, ProcessDefinitionEntity processDefinition, ExprType exprType)
/*     */   {
/* 273 */     if (exprSet != null) {
/* 274 */       Iterator iterator = exprSet.iterator();
/* 275 */       while (iterator.hasNext()) {
/* 276 */         Expression expr = (Expression)iterator.next();
/* 277 */         IdentityLinkEntity identityLink = new IdentityLinkEntity();
/* 278 */         identityLink.setProcessDef(processDefinition);
/* 279 */         if (exprType.equals(ExprType.USER))
/* 280 */           identityLink.setUserId(expr.toString());
/* 281 */         else if (exprType.equals(ExprType.GROUP)) {
/* 282 */           identityLink.setGroupId(expr.toString());
/*     */         }
/* 284 */         identityLink.setType("candidate");
/* 285 */         identityLink.insert();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void addAuthorizations(ProcessDefinitionEntity processDefinition) {
/* 291 */     addAuthorizationsFromIterator(processDefinition.getCandidateStarterUserIdExpressions(), processDefinition, ExprType.USER);
/* 292 */     addAuthorizationsFromIterator(processDefinition.getCandidateStarterGroupIdExpressions(), processDefinition, ExprType.GROUP);
/*     */   }
/*     */ 
/*     */   protected String getDiagramResourceForProcess(String bpmnFileResource, String processKey, Map<String, ResourceEntity> resources)
/*     */   {
/* 317 */     for (String diagramSuffix : DIAGRAM_SUFFIXES) {
/* 318 */       String diagramForBpmnFileResource = getBpmnFileImageResourceName(bpmnFileResource, diagramSuffix);
/* 319 */       String processDiagramResource = getProcessImageResourceName(bpmnFileResource, processKey, diagramSuffix);
/* 320 */       if (resources.containsKey(processDiagramResource))
/* 321 */         return processDiagramResource;
/* 322 */       if (resources.containsKey(diagramForBpmnFileResource)) {
/* 323 */         return diagramForBpmnFileResource;
/*     */       }
/*     */     }
/* 326 */     return null;
/*     */   }
/*     */ 
/*     */   protected String getBpmnFileImageResourceName(String bpmnFileResource, String diagramSuffix) {
/* 330 */     String bpmnFileResourceBase = stripBpmnFileSuffix(bpmnFileResource);
/* 331 */     return bpmnFileResourceBase + diagramSuffix;
/*     */   }
/*     */ 
/*     */   protected String getProcessImageResourceName(String bpmnFileResource, String processKey, String diagramSuffix) {
/* 335 */     String bpmnFileResourceBase = stripBpmnFileSuffix(bpmnFileResource);
/* 336 */     return bpmnFileResourceBase + processKey + "." + diagramSuffix;
/*     */   }
/*     */ 
/*     */   protected String stripBpmnFileSuffix(String bpmnFileResource) {
/* 340 */     for (String suffix : BPMN_RESOURCE_SUFFIXES) {
/* 341 */       if (bpmnFileResource.endsWith(suffix)) {
/* 342 */         return bpmnFileResource.substring(0, bpmnFileResource.length() - suffix.length());
/*     */       }
/*     */     }
/* 345 */     return bpmnFileResource;
/*     */   }
/*     */ 
/*     */   protected void createResource(String name, byte[] bytes, DeploymentEntity deploymentEntity) {
/* 349 */     ResourceEntity resource = new ResourceEntity();
/* 350 */     resource.setName(name);
/* 351 */     resource.setBytes(bytes);
/* 352 */     resource.setDeploymentId(deploymentEntity.getId());
/*     */ 
/* 355 */     resource.setGenerated(true);
/*     */ 
/* 357 */     Context.getCommandContext().getDbSqlSession().insert(resource);
/*     */   }
/*     */ 
/*     */   protected boolean isBpmnResource(String resourceName)
/*     */   {
/* 364 */     for (String suffix : BPMN_RESOURCE_SUFFIXES) {
/* 365 */       if (resourceName.endsWith(suffix)) {
/* 366 */         return true;
/*     */       }
/*     */     }
/* 369 */     return false;
/*     */   }
/*     */ 
/*     */   public ExpressionManager getExpressionManager() {
/* 373 */     return this.expressionManager;
/*     */   }
/*     */ 
/*     */   public void setExpressionManager(ExpressionManager expressionManager) {
/* 377 */     this.expressionManager = expressionManager;
/*     */   }
/*     */ 
/*     */   public BpmnParser getBpmnParser() {
/* 381 */     return this.bpmnParser;
/*     */   }
/*     */ 
/*     */   public void setBpmnParser(BpmnParser bpmnParser) {
/* 385 */     this.bpmnParser = bpmnParser;
/*     */   }
/*     */ 
/*     */   public IdGenerator getIdGenerator() {
/* 389 */     return this.idGenerator;
/*     */   }
/*     */ 
/*     */   public void setIdGenerator(IdGenerator idGenerator) {
/* 393 */     this.idGenerator = idGenerator;
/*     */   }
/*     */ 
/*     */   static enum ExprType
/*     */   {
/* 269 */     USER, GROUP;
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.deployer.BpmnDeployer
 * JD-Core Version:    0.6.0
 */