/*    */ package org.activiti.engine.impl.bpmn.diagram;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ import javax.xml.namespace.NamespaceContext;
/*    */ 
/*    */ public class Bpmn20NamespaceContext
/*    */   implements NamespaceContext
/*    */ {
/*    */   public static final String BPMN = "bpmn";
/*    */   public static final String BPMNDI = "bpmndi";
/*    */   public static final String OMGDC = "omgdc";
/*    */   public static final String OMGDI = "omgdi";
/* 44 */   protected Map<String, String> namespaceUris = new HashMap();
/*    */ 
/*    */   public Bpmn20NamespaceContext() {
/* 47 */     this.namespaceUris.put("bpmn", "http://www.omg.org/spec/BPMN/20100524/MODEL");
/* 48 */     this.namespaceUris.put("bpmndi", "http://www.omg.org/spec/BPMN/20100524/DI");
/* 49 */     this.namespaceUris.put("omgdc", "http://www.omg.org/spec/DD/20100524/DI");
/* 50 */     this.namespaceUris.put("omgdi", "http://www.omg.org/spec/DD/20100524/DC");
/*    */   }
/*    */ 
/*    */   public String getNamespaceURI(String prefix) {
/* 54 */     return (String)this.namespaceUris.get(prefix);
/*    */   }
/*    */ 
/*    */   public String getPrefix(String namespaceURI) {
/* 58 */     return (String)getKeyByValue(this.namespaceUris, namespaceURI);
/*    */   }
/*    */ 
/*    */   public Iterator<String> getPrefixes(String namespaceURI) {
/* 62 */     return getKeysByValue(this.namespaceUris, namespaceURI).iterator();
/*    */   }
/*    */ 
/*    */   private static <T, E> Set<T> getKeysByValue(Map<T, E> map, E value) {
/* 66 */     Set keys = new HashSet();
/* 67 */     for (Map.Entry entry : map.entrySet()) {
/* 68 */       if (value.equals(entry.getValue())) {
/* 69 */         keys.add(entry.getKey());
/*    */       }
/*    */     }
/* 72 */     return keys;
/*    */   }
/*    */ 
/*    */   private static <T, E> T getKeyByValue(Map<T, E> map, E value) {
/* 76 */     for (Map.Entry entry : map.entrySet()) {
/* 77 */       if (value.equals(entry.getValue())) {
/* 78 */         return entry.getKey();
/*    */       }
/*    */     }
/* 81 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.diagram.Bpmn20NamespaceContext
 * JD-Core Version:    0.6.0
 */