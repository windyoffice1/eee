/*     */ package org.activiti.engine.impl.bpmn.diagram;
/*     */ 
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.GradientPaint;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.awt.Paint;
/*     */ import java.awt.Polygon;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.font.LineBreakMeasurer;
/*     */ import java.awt.font.TextAttribute;
/*     */ import java.awt.font.TextLayout;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.geom.Ellipse2D;
/*     */ import java.awt.geom.Ellipse2D.Double;
/*     */ import java.awt.geom.Line2D.Double;
/*     */ import java.awt.geom.Path2D;
/*     */ import java.awt.geom.Path2D.Double;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.geom.RoundRectangle2D;
/*     */ import java.awt.geom.RoundRectangle2D.Double;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.text.AttributedCharacterIterator;
/*     */ import java.text.AttributedString;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.imageio.ImageIO;
/*     */ import org.activiti.engine.ActivitiException;
/*     */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*     */ import org.activiti.engine.impl.context.Context;
/*     */ import org.activiti.engine.impl.util.IoUtil;
/*     */ import org.activiti.engine.impl.util.ReflectUtil;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class ProcessDiagramCanvas
/*     */ {
/*  66 */   protected static final Logger LOGGER = LoggerFactory.getLogger(ProcessDiagramCanvas.class);
/*     */   protected static final int ARROW_WIDTH = 5;
/*     */   protected static final int CONDITIONAL_INDICATOR_WIDTH = 16;
/*     */   protected static final int DEFAULT_INDICATOR_WIDTH = 10;
/*     */   protected static final int MARKER_WIDTH = 12;
/*     */   protected static final int FONT_SIZE = 11;
/*     */   protected static final int FONT_SPACING = 2;
/*     */   protected static final int TEXT_PADDING = 3;
/*     */   protected static final int LINE_HEIGHT = 13;
/*  80 */   protected static Color TASK_BOX_COLOR = new Color(255, 255, 204);
/*  81 */   protected static Color BOUNDARY_EVENT_COLOR = new Color(255, 255, 255);
/*  82 */   protected static Color CONDITIONAL_INDICATOR_COLOR = new Color(255, 255, 255);
/*  83 */   protected static Color HIGHLIGHT_COLOR = Color.RED;
/*  84 */   protected static Color LABEL_COLOR = new Color(112, 146, 190);
/*     */ 
/*  87 */   protected static Font LABEL_FONT = null;
/*     */ 
/*  90 */   protected static Stroke THICK_TASK_BORDER_STROKE = new BasicStroke(3.0F);
/*  91 */   protected static Stroke GATEWAY_TYPE_STROKE = new BasicStroke(3.0F);
/*  92 */   protected static Stroke END_EVENT_STROKE = new BasicStroke(3.0F);
/*  93 */   protected static Stroke MULTI_INSTANCE_STROKE = new BasicStroke(1.3F);
/*  94 */   protected static Stroke EVENT_SUBPROCESS_STROKE = new BasicStroke(1.0F, 0, 0, 1.0F, new float[] { 1.0F }, 0.0F);
/*  95 */   protected static Stroke INTERRUPTING_EVENT_STROKE = new BasicStroke(1.0F, 0, 0, 1.0F, new float[] { 4.0F, 3.0F }, 0.0F);
/*  96 */   protected static Stroke HIGHLIGHT_FLOW_STROKE = new BasicStroke(1.3F);
/*     */ 
/*  99 */   protected static int ICON_SIZE = 16;
/* 100 */   protected static int ICON_PADDING = 3;
/*     */   protected static Image USERTASK_IMAGE;
/*     */   protected static Image SCRIPTTASK_IMAGE;
/*     */   protected static Image SERVICETASK_IMAGE;
/*     */   protected static Image RECEIVETASK_IMAGE;
/*     */   protected static Image SENDTASK_IMAGE;
/*     */   protected static Image MANUALTASK_IMAGE;
/*     */   protected static Image BUSINESS_RULE_TASK_IMAGE;
/*     */   protected static Image TIMER_IMAGE;
/*     */   protected static Image ERROR_THROW_IMAGE;
/*     */   protected static Image ERROR_CATCH_IMAGE;
/*     */   protected static Image SIGNAL_CATCH_IMAGE;
/*     */   protected static Image SIGNAL_THROW_IMAGE;
/* 134 */   protected int canvasWidth = -1;
/* 135 */   protected int canvasHeight = -1;
/* 136 */   protected int minX = -1;
/* 137 */   protected int minY = -1;
/*     */   protected BufferedImage processDiagram;
/*     */   protected Graphics2D g;
/*     */   protected FontMetrics fontMetrics;
/*     */   protected boolean closed;
/* 142 */   protected String activityFontName = "Arial";
/* 143 */   protected String labelFontName = "Arial";
/*     */ 
/*     */   public ProcessDiagramCanvas(int width, int height)
/*     */   {
/* 149 */     this.canvasWidth = width;
/* 150 */     this.canvasHeight = height;
/*     */ 
/* 152 */     if (Context.getProcessEngineConfiguration() != null) {
/* 153 */       this.activityFontName = Context.getProcessEngineConfiguration().getActivityFontName();
/*     */     }
/*     */ 
/* 156 */     if (Context.getProcessEngineConfiguration() != null) {
/* 157 */       this.labelFontName = Context.getProcessEngineConfiguration().getLabelFontName();
/*     */     }
/*     */ 
/* 160 */     this.processDiagram = new BufferedImage(width, height, 2);
/* 161 */     this.g = this.processDiagram.createGraphics();
/* 162 */     this.g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 163 */     this.g.setPaint(Color.black);
/*     */ 
/* 165 */     Font font = new Font(this.activityFontName, 1, 11);
/* 166 */     this.g.setFont(font);
/* 167 */     this.fontMetrics = this.g.getFontMetrics();
/*     */ 
/* 169 */     LABEL_FONT = new Font(this.labelFontName, 2, 10);
/*     */   }
/*     */ 
/*     */   public ProcessDiagramCanvas(int width, int height, int minX, int minY)
/*     */   {
/* 187 */     this(width, height);
/* 188 */     this.minX = minX;
/* 189 */     this.minY = minY;
/*     */   }
/*     */ 
/*     */   public InputStream generateImage(String imageType)
/*     */   {
/* 199 */     if (this.closed) {
/* 200 */       throw new ActivitiException("ProcessDiagramGenerator already closed");
/*     */     }
/*     */ 
/* 203 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/*     */     try
/*     */     {
/* 206 */       this.minX = (this.minX <= 5 ? 5 : this.minX);
/* 207 */       this.minY = (this.minY <= 5 ? 5 : this.minY);
/* 208 */       BufferedImage imageToSerialize = this.processDiagram;
/* 209 */       if ((this.minX >= 0) && (this.minY >= 0)) {
/* 210 */         imageToSerialize = this.processDiagram.getSubimage(this.minX - 5, this.minY - 5, this.canvasWidth - this.minX + 5, this.canvasHeight - this.minY + 5);
/*     */       }
/* 212 */       ImageIO.write(imageToSerialize, imageType, out);
/*     */     } catch (IOException e) {
/* 214 */       throw new ActivitiException("Error while generating process image", e);
/*     */     } finally {
/* 216 */       IoUtil.closeSilently(out);
/*     */     }
/* 218 */     return new ByteArrayInputStream(out.toByteArray());
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/* 226 */     this.g.dispose();
/* 227 */     this.closed = true;
/*     */   }
/*     */ 
/*     */   public void drawNoneStartEvent(int x, int y, int width, int height) {
/* 231 */     drawStartEvent(x, y, width, height, null);
/*     */   }
/*     */ 
/*     */   public void drawTimerStartEvent(int x, int y, int width, int height) {
/* 235 */     drawStartEvent(x, y, width, height, TIMER_IMAGE);
/*     */   }
/*     */ 
/*     */   public void drawStartEvent(int x, int y, int width, int height, Image image) {
/* 239 */     this.g.draw(new Ellipse2D.Double(x, y, width, height));
/* 240 */     if (image != null)
/* 241 */       this.g.drawImage(image, x, y, width, height, null);
/*     */   }
/*     */ 
/*     */   public void drawNoneEndEvent(int x, int y, int width, int height)
/*     */   {
/* 247 */     Stroke originalStroke = this.g.getStroke();
/* 248 */     this.g.setStroke(END_EVENT_STROKE);
/* 249 */     this.g.draw(new Ellipse2D.Double(x, y, width, height));
/* 250 */     this.g.setStroke(originalStroke);
/*     */   }
/*     */ 
/*     */   public void drawErrorEndEvent(String name, int x, int y, int width, int height) {
/* 254 */     drawErrorEndEvent(x, y, width, height);
/* 255 */     drawLabel(name, x, y, width, height);
/*     */   }
/*     */ 
/*     */   public void drawErrorEndEvent(int x, int y, int width, int height) {
/* 259 */     drawNoneEndEvent(x, y, width, height);
/* 260 */     this.g.drawImage(ERROR_THROW_IMAGE, x + 3, y + 3, width - 6, height - 6, null);
/*     */   }
/*     */ 
/*     */   public void drawErrorStartEvent(int x, int y, int width, int height) {
/* 264 */     drawNoneStartEvent(x, y, width, height);
/* 265 */     this.g.drawImage(ERROR_CATCH_IMAGE, x + 3, y + 3, width - 6, height - 6, null);
/*     */   }
/*     */ 
/*     */   public void drawCatchingEvent(int x, int y, int width, int height, boolean isInterrupting, Image image)
/*     */   {
/* 270 */     Ellipse2D outerCircle = new Ellipse2D.Double(x, y, width, height);
/* 271 */     int innerCircleX = x + 3;
/* 272 */     int innerCircleY = y + 3;
/* 273 */     int innerCircleWidth = width - 6;
/* 274 */     int innerCircleHeight = height - 6;
/* 275 */     Ellipse2D innerCircle = new Ellipse2D.Double(innerCircleX, innerCircleY, innerCircleWidth, innerCircleHeight);
/*     */ 
/* 277 */     Paint originalPaint = this.g.getPaint();
/* 278 */     Stroke originalStroke = this.g.getStroke();
/* 279 */     this.g.setPaint(BOUNDARY_EVENT_COLOR);
/* 280 */     this.g.fill(outerCircle);
/*     */ 
/* 282 */     this.g.setPaint(originalPaint);
/* 283 */     if (isInterrupting)
/* 284 */       this.g.setStroke(INTERRUPTING_EVENT_STROKE);
/* 285 */     this.g.draw(outerCircle);
/* 286 */     this.g.setStroke(originalStroke);
/* 287 */     this.g.draw(innerCircle);
/*     */ 
/* 289 */     this.g.drawImage(image, innerCircleX, innerCircleY, innerCircleWidth, innerCircleHeight, null);
/*     */   }
/*     */ 
/*     */   public void drawCatchingTimerEvent(String name, int x, int y, int width, int height, boolean isInterrupting) {
/* 293 */     drawCatchingTimerEvent(x, y, width, height, isInterrupting);
/* 294 */     drawLabel(name, x, y, width, height);
/*     */   }
/*     */ 
/*     */   public void drawCatchingTimerEvent(int x, int y, int width, int height, boolean isInterrupting) {
/* 298 */     drawCatchingEvent(x, y, width, height, isInterrupting, TIMER_IMAGE);
/*     */   }
/*     */ 
/*     */   public void drawCatchingErrorEvent(String name, int x, int y, int width, int height, boolean isInterrupting) {
/* 302 */     drawCatchingErrorEvent(x, y, width, height, isInterrupting);
/* 303 */     drawLabel(name, x, y, width, height);
/*     */   }
/*     */ 
/*     */   public void drawCatchingErrorEvent(int x, int y, int width, int height, boolean isInterrupting) {
/* 307 */     drawCatchingEvent(x, y, width, height, isInterrupting, ERROR_CATCH_IMAGE);
/*     */   }
/*     */ 
/*     */   public void drawCatchingSignalEvent(String name, int x, int y, int width, int height, boolean isInterrupting) {
/* 311 */     drawCatchingSignalEvent(x, y, width, height, isInterrupting);
/* 312 */     drawLabel(name, x, y, width, height);
/*     */   }
/*     */ 
/*     */   public void drawCatchingSignalEvent(int x, int y, int width, int height, boolean isInterrupting) {
/* 316 */     drawCatchingEvent(x, y, width, height, isInterrupting, SIGNAL_CATCH_IMAGE);
/*     */   }
/*     */ 
/*     */   public void drawThrowingSignalEvent(int x, int y, int width, int height) {
/* 320 */     drawCatchingEvent(x, y, width, height, false, SIGNAL_THROW_IMAGE);
/*     */   }
/*     */ 
/*     */   public void drawThrowingNoneEvent(int x, int y, int width, int height) {
/* 324 */     drawCatchingEvent(x, y, width, height, false, null);
/*     */   }
/*     */ 
/*     */   public void drawSequenceflow(int srcX, int srcY, int targetX, int targetY, boolean conditional) {
/* 328 */     drawSequenceflow(srcX, srcY, targetX, targetY, conditional, false);
/*     */   }
/*     */ 
/*     */   public void drawSequenceflow(int srcX, int srcY, int targetX, int targetY, boolean conditional, boolean highLighted) {
/* 332 */     Paint originalPaint = this.g.getPaint();
/* 333 */     if (highLighted) {
/* 334 */       this.g.setPaint(HIGHLIGHT_COLOR);
/*     */     }
/* 336 */     Line2D.Double line = new Line2D.Double(srcX, srcY, targetX, targetY);
/* 337 */     this.g.draw(line);
/* 338 */     drawArrowHead(line);
/*     */ 
/* 340 */     if (conditional) {
/* 341 */       drawConditionalSequenceFlowIndicator(line);
/*     */     }
/*     */ 
/* 344 */     if (highLighted)
/* 345 */       this.g.setPaint(originalPaint);
/*     */   }
/*     */ 
/*     */   public void drawSequenceflow(int[] xPoints, int[] yPoints, boolean conditional, boolean isDefault, boolean highLighted) {
/* 349 */     Paint originalPaint = this.g.getPaint();
/* 350 */     Stroke originalStroke = this.g.getStroke();
/*     */ 
/* 352 */     if (highLighted) {
/* 353 */       this.g.setPaint(HIGHLIGHT_COLOR);
/* 354 */       this.g.setStroke(HIGHLIGHT_FLOW_STROKE);
/*     */     }
/*     */ 
/* 357 */     int radius = 15;
/*     */ 
/* 359 */     Path2D path = new Path2D.Double();
/*     */ 
/* 361 */     boolean isDefaultConditionAvailable = false;
/*     */ 
/* 364 */     for (int i = 0; i < xPoints.length; i++) {
/* 365 */       Integer anchorX = Integer.valueOf(xPoints[i]);
/* 366 */       Integer anchorY = Integer.valueOf(yPoints[i]);
/*     */ 
/* 368 */       double targetX = anchorX.intValue(); double targetY = anchorY.intValue();
/*     */ 
/* 370 */       double ax = 0.0D; double ay = 0.0D; double bx = 0.0D; double by = 0.0D; double zx = 0.0D; double zy = 0.0D;
/*     */ 
/* 372 */       if ((i > 0) && (i < xPoints.length - 1)) {
/* 373 */         Integer cx = anchorX; Integer cy = anchorY;
/*     */ 
/* 376 */         double lineLengthY = yPoints[i] - yPoints[(i - 1)];
/* 377 */         double lineLengthX = xPoints[i] - xPoints[(i - 1)];
/* 378 */         double lineLength = Math.sqrt(Math.pow(lineLengthY, 2.0D) + Math.pow(lineLengthX, 2.0D));
/* 379 */         double dx = lineLengthX * radius / lineLength;
/* 380 */         double dy = lineLengthY * radius / lineLength;
/* 381 */         targetX -= dx;
/* 382 */         targetY -= dy;
/*     */ 
/* 384 */         isDefaultConditionAvailable = (isDefault) && (i == 1) && (lineLength > 10.0D);
/*     */ 
/* 386 */         if ((lineLength < 2 * radius) && (i > 1)) {
/* 387 */           targetX = xPoints[i] - lineLengthX / 2.0D;
/* 388 */           targetY = yPoints[i] - lineLengthY / 2.0D;
/*     */         }
/*     */ 
/* 392 */         lineLengthY = yPoints[(i + 1)] - yPoints[i];
/* 393 */         lineLengthX = xPoints[(i + 1)] - xPoints[i];
/* 394 */         lineLength = Math.sqrt(Math.pow(lineLengthY, 2.0D) + Math.pow(lineLengthX, 2.0D));
/* 395 */         if (lineLength < radius) {
/* 396 */           lineLength = radius;
/*     */         }
/* 398 */         dx = lineLengthX * radius / lineLength;
/* 399 */         dy = lineLengthY * radius / lineLength;
/*     */ 
/* 401 */         double nextSrcX = xPoints[i] + dx;
/* 402 */         double nextSrcY = yPoints[i] + dy;
/*     */ 
/* 404 */         if ((lineLength < 2 * radius) && (i < xPoints.length - 2)) {
/* 405 */           nextSrcX = xPoints[i] + lineLengthX / 2.0D;
/* 406 */           nextSrcY = yPoints[i] + lineLengthY / 2.0D;
/*     */         }
/*     */ 
/* 409 */         double dx0 = (cx.intValue() - targetX) / 3.0D;
/* 410 */         double dy0 = (cy.intValue() - targetY) / 3.0D;
/* 411 */         ax = cx.intValue() - dx0;
/* 412 */         ay = cy.intValue() - dy0;
/*     */ 
/* 414 */         double dx1 = (cx.intValue() - nextSrcX) / 3.0D;
/* 415 */         double dy1 = (cy.intValue() - nextSrcY) / 3.0D;
/* 416 */         bx = cx.intValue() - dx1;
/* 417 */         by = cy.intValue() - dy1;
/*     */ 
/* 419 */         zx = nextSrcX;
/* 420 */         zy = nextSrcY;
/*     */       }
/*     */ 
/* 423 */       if (i == 0)
/* 424 */         path.moveTo(targetX, targetY);
/*     */       else {
/* 426 */         path.lineTo(targetX, targetY);
/*     */       }
/*     */ 
/* 429 */       if ((i > 0) && (i < xPoints.length - 1))
/*     */       {
/* 431 */         path.curveTo(ax, ay, bx, by, zx, zy);
/*     */       }
/*     */ 
/* 434 */       if (i == xPoints.length - 1) {
/* 435 */         Line2D.Double lineDouble = new Line2D.Double(xPoints[(i - 1)], yPoints[(i - 1)], xPoints[i], yPoints[i]);
/* 436 */         drawArrowHead(lineDouble);
/*     */       }
/*     */     }
/* 439 */     this.g.draw(path);
/*     */ 
/* 441 */     if (isDefaultConditionAvailable) {
/* 442 */       Line2D.Double line = new Line2D.Double(xPoints[0], yPoints[0], xPoints[1], yPoints[1]);
/* 443 */       drawDefaultSequenceFlowIndicator(line);
/*     */     }
/*     */ 
/* 446 */     if (conditional) {
/* 447 */       Line2D.Double line = new Line2D.Double(xPoints[0], yPoints[0], xPoints[1], yPoints[1]);
/* 448 */       drawConditionalSequenceFlowIndicator(line);
/*     */     }
/*     */ 
/* 451 */     this.g.setPaint(originalPaint);
/* 452 */     this.g.setStroke(originalStroke);
/*     */   }
/*     */ 
/*     */   public void drawSequenceflowWithoutArrow(int srcX, int srcY, int targetX, int targetY, boolean conditional) {
/* 456 */     drawSequenceflowWithoutArrow(srcX, srcY, targetX, targetY, conditional, false);
/*     */   }
/*     */ 
/*     */   public void drawSequenceflowWithoutArrow(int srcX, int srcY, int targetX, int targetY, boolean conditional, boolean highLighted) {
/* 460 */     Paint originalPaint = this.g.getPaint();
/* 461 */     if (highLighted) {
/* 462 */       this.g.setPaint(HIGHLIGHT_COLOR);
/*     */     }
/* 464 */     Line2D.Double line = new Line2D.Double(srcX, srcY, targetX, targetY);
/* 465 */     this.g.draw(line);
/*     */ 
/* 467 */     if (conditional) {
/* 468 */       drawConditionalSequenceFlowIndicator(line);
/*     */     }
/*     */ 
/* 471 */     if (highLighted)
/* 472 */       this.g.setPaint(originalPaint);
/*     */   }
/*     */ 
/*     */   public void drawArrowHead(Line2D.Double line) {
/* 476 */     int doubleArrowWidth = 10;
/* 477 */     Polygon arrowHead = new Polygon();
/* 478 */     arrowHead.addPoint(0, 0);
/* 479 */     arrowHead.addPoint(-5, -doubleArrowWidth);
/* 480 */     arrowHead.addPoint(5, -doubleArrowWidth);
/*     */ 
/* 482 */     AffineTransform transformation = new AffineTransform();
/* 483 */     transformation.setToIdentity();
/* 484 */     double angle = Math.atan2(line.y2 - line.y1, line.x2 - line.x1);
/* 485 */     transformation.translate(line.x2, line.y2);
/* 486 */     transformation.rotate(angle - 1.570796326794897D);
/*     */ 
/* 488 */     AffineTransform originalTransformation = this.g.getTransform();
/* 489 */     this.g.setTransform(transformation);
/* 490 */     this.g.fill(arrowHead);
/* 491 */     this.g.setTransform(originalTransformation);
/*     */   }
/*     */ 
/*     */   public void drawDefaultSequenceFlowIndicator(Line2D.Double line) {
/* 495 */     double length = 10.0D; double halfOfLength = length / 2.0D; double f = 8.0D;
/* 496 */     Line2D.Double defaultIndicator = new Line2D.Double(-halfOfLength, 0.0D, halfOfLength, 0.0D);
/*     */ 
/* 498 */     double angle = Math.atan2(line.y2 - line.y1, line.x2 - line.x1);
/* 499 */     double dx = f * Math.cos(angle); double dy = f * Math.sin(angle);
/* 500 */     double x1 = line.x1 + dx; double y1 = line.y1 + dy;
/*     */ 
/* 502 */     AffineTransform transformation = new AffineTransform();
/* 503 */     transformation.setToIdentity();
/* 504 */     transformation.translate(x1, y1);
/* 505 */     transformation.rotate(angle - 2.356194490192345D);
/*     */ 
/* 507 */     AffineTransform originalTransformation = this.g.getTransform();
/* 508 */     this.g.setTransform(transformation);
/* 509 */     this.g.draw(defaultIndicator);
/*     */ 
/* 511 */     this.g.setTransform(originalTransformation);
/*     */   }
/*     */ 
/*     */   public void drawConditionalSequenceFlowIndicator(Line2D.Double line) {
/* 515 */     int horizontal = 11;
/* 516 */     int halfOfHorizontal = horizontal / 2;
/* 517 */     int halfOfVertical = 8;
/*     */ 
/* 519 */     Polygon conditionalIndicator = new Polygon();
/* 520 */     conditionalIndicator.addPoint(0, 0);
/* 521 */     conditionalIndicator.addPoint(-halfOfHorizontal, halfOfVertical);
/* 522 */     conditionalIndicator.addPoint(0, 16);
/* 523 */     conditionalIndicator.addPoint(halfOfHorizontal, halfOfVertical);
/*     */ 
/* 525 */     AffineTransform transformation = new AffineTransform();
/* 526 */     transformation.setToIdentity();
/* 527 */     double angle = Math.atan2(line.y2 - line.y1, line.x2 - line.x1);
/* 528 */     transformation.translate(line.x1, line.y1);
/* 529 */     transformation.rotate(angle - 1.570796326794897D);
/*     */ 
/* 531 */     AffineTransform originalTransformation = this.g.getTransform();
/* 532 */     this.g.setTransform(transformation);
/* 533 */     this.g.draw(conditionalIndicator);
/*     */ 
/* 535 */     Paint originalPaint = this.g.getPaint();
/* 536 */     this.g.setPaint(CONDITIONAL_INDICATOR_COLOR);
/* 537 */     this.g.fill(conditionalIndicator);
/*     */ 
/* 539 */     this.g.setPaint(originalPaint);
/* 540 */     this.g.setTransform(originalTransformation);
/*     */   }
/*     */ 
/*     */   public void drawTask(String name, int x, int y, int width, int height) {
/* 544 */     drawTask(name, x, y, width, height, false);
/*     */   }
/*     */ 
/*     */   public void drawPoolOrLane(String name, int x, int y, int width, int height) {
/* 548 */     this.g.drawRect(x, y, width, height);
/*     */ 
/* 551 */     if ((name != null) && (name.length() > 0))
/*     */     {
/* 553 */       int availableTextSpace = height - 6;
/*     */ 
/* 556 */       AffineTransform transformation = new AffineTransform();
/* 557 */       transformation.setToIdentity();
/* 558 */       transformation.rotate(4.71238898038469D);
/*     */ 
/* 560 */       Font currentFont = this.g.getFont();
/* 561 */       Font theDerivedFont = currentFont.deriveFont(transformation);
/* 562 */       this.g.setFont(theDerivedFont);
/*     */ 
/* 564 */       String truncated = fitTextToWidth(name, availableTextSpace);
/* 565 */       int realWidth = this.fontMetrics.stringWidth(truncated);
/*     */ 
/* 567 */       this.g.drawString(truncated, x + 2 + this.fontMetrics.getHeight(), 3 + y + availableTextSpace - (availableTextSpace - realWidth) / 2);
/* 568 */       this.g.setFont(currentFont);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void drawTask(String name, int x, int y, int width, int height, boolean thickBorder) {
/* 573 */     Paint originalPaint = this.g.getPaint();
/*     */ 
/* 576 */     this.g.setPaint(new GradientPaint(x + 50, y, Color.white, x + 50, y + 50, TASK_BOX_COLOR));
/*     */ 
/* 579 */     RoundRectangle2D rect = new RoundRectangle2D.Double(x, y, width, height, 20.0D, 20.0D);
/* 580 */     this.g.fill(rect);
/* 581 */     this.g.setPaint(originalPaint);
/*     */ 
/* 583 */     if (thickBorder) {
/* 584 */       Stroke originalStroke = this.g.getStroke();
/* 585 */       this.g.setStroke(THICK_TASK_BORDER_STROKE);
/* 586 */       this.g.draw(rect);
/* 587 */       this.g.setStroke(originalStroke);
/*     */     } else {
/* 589 */       this.g.draw(rect);
/*     */     }
/*     */ 
/* 593 */     if ((name != null) && (name.length() > 0))
/* 594 */       drawMultilineText(name, x, y, width, height);
/*     */   }
/*     */ 
/*     */   protected void drawMultilineText(String text, int x, int y, int boxWidth, int boxHeight)
/*     */   {
/* 599 */     int availableHeight = boxHeight - ICON_SIZE - ICON_PADDING;
/*     */ 
/* 602 */     AttributedString attributedString = new AttributedString(text);
/* 603 */     attributedString.addAttribute(TextAttribute.FONT, this.g.getFont());
/* 604 */     attributedString.addAttribute(TextAttribute.FOREGROUND, Color.black);
/*     */ 
/* 606 */     AttributedCharacterIterator characterIterator = attributedString.getIterator();
/*     */ 
/* 608 */     int width = boxWidth - 6;
/*     */ 
/* 610 */     int currentHeight = 0;
/*     */ 
/* 612 */     List layouts = new ArrayList();
/* 613 */     String lastLine = null;
/*     */ 
/* 615 */     LineBreakMeasurer measurer = new LineBreakMeasurer(characterIterator, this.g.getFontRenderContext());
/*     */ 
/* 617 */     TextLayout layout = null;
/* 618 */     while ((measurer.getPosition() < characterIterator.getEndIndex()) && (currentHeight <= availableHeight))
/*     */     {
/* 620 */       int previousPosition = measurer.getPosition();
/*     */ 
/* 623 */       layout = measurer.nextLayout(width);
/*     */ 
/* 625 */       int height = Float.valueOf(layout.getDescent() + layout.getAscent() + layout.getLeading()).intValue();
/*     */ 
/* 627 */       if (currentHeight + height > availableHeight)
/*     */       {
/* 630 */         layouts.remove(layouts.size() - 1);
/*     */ 
/* 632 */         if (lastLine.length() >= 4) {
/* 633 */           lastLine = lastLine.substring(0, lastLine.length() - 4) + "...";
/*     */         }
/* 635 */         layouts.add(new TextLayout(lastLine, this.g.getFont(), this.g.getFontRenderContext()));
/*     */       } else {
/* 637 */         layouts.add(layout);
/* 638 */         lastLine = text.substring(previousPosition, measurer.getPosition());
/* 639 */         currentHeight += height;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 644 */     int currentY = y + ICON_SIZE + (availableHeight - currentHeight) / 2;
/* 645 */     int currentX = 0;
/*     */ 
/* 648 */     for (TextLayout textLayout : layouts)
/*     */     {
/* 650 */       currentY = (int)(currentY + textLayout.getAscent());
/* 651 */       currentX = 3 + x + (width - Double.valueOf(textLayout.getBounds().getWidth()).intValue()) / 2;
/*     */ 
/* 653 */       textLayout.draw(this.g, currentX, currentY);
/* 654 */       currentY = (int)(currentY + (textLayout.getDescent() + textLayout.getLeading()));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String fitTextToWidth(String original, int width)
/*     */   {
/* 661 */     String text = original;
/*     */ 
/* 664 */     int maxWidth = width - 10;
/*     */ 
/* 666 */     while ((this.fontMetrics.stringWidth(text + "...") > maxWidth) && (text.length() > 0)) {
/* 667 */       text = text.substring(0, text.length() - 1);
/*     */     }
/*     */ 
/* 670 */     if (!text.equals(original)) {
/* 671 */       text = text + "...";
/*     */     }
/*     */ 
/* 674 */     return text;
/*     */   }
/*     */ 
/*     */   public void drawUserTask(String name, int x, int y, int width, int height) {
/* 678 */     drawTask(name, x, y, width, height);
/* 679 */     this.g.drawImage(USERTASK_IMAGE, x + ICON_PADDING, y + ICON_PADDING, ICON_SIZE, ICON_SIZE, null);
/*     */   }
/*     */ 
/*     */   public void drawScriptTask(String name, int x, int y, int width, int height) {
/* 683 */     drawTask(name, x, y, width, height);
/* 684 */     this.g.drawImage(SCRIPTTASK_IMAGE, x + ICON_PADDING, y + ICON_PADDING, ICON_SIZE, ICON_SIZE, null);
/*     */   }
/*     */ 
/*     */   public void drawServiceTask(String name, int x, int y, int width, int height) {
/* 688 */     drawTask(name, x, y, width, height);
/* 689 */     this.g.drawImage(SERVICETASK_IMAGE, x + ICON_PADDING, y + ICON_PADDING, ICON_SIZE, ICON_SIZE, null);
/*     */   }
/*     */ 
/*     */   public void drawReceiveTask(String name, int x, int y, int width, int height) {
/* 693 */     drawTask(name, x, y, width, height);
/* 694 */     this.g.drawImage(RECEIVETASK_IMAGE, x + ICON_PADDING, y + ICON_PADDING, ICON_SIZE, ICON_SIZE, null);
/*     */   }
/*     */ 
/*     */   public void drawSendTask(String name, int x, int y, int width, int height) {
/* 698 */     drawTask(name, x, y, width, height);
/* 699 */     this.g.drawImage(SENDTASK_IMAGE, x + ICON_PADDING, y + ICON_PADDING, ICON_SIZE, ICON_SIZE, null);
/*     */   }
/*     */ 
/*     */   public void drawManualTask(String name, int x, int y, int width, int height) {
/* 703 */     drawTask(name, x, y, width, height);
/* 704 */     this.g.drawImage(MANUALTASK_IMAGE, x + ICON_PADDING, y + ICON_PADDING, ICON_SIZE, ICON_SIZE, null);
/*     */   }
/*     */ 
/*     */   public void drawBusinessRuleTask(String name, int x, int y, int width, int height) {
/* 708 */     drawTask(name, x, y, width, height);
/* 709 */     this.g.drawImage(BUSINESS_RULE_TASK_IMAGE, x + ICON_PADDING, y + ICON_PADDING, ICON_SIZE, ICON_SIZE, null);
/*     */   }
/*     */ 
/*     */   public void drawExpandedSubProcess(String name, int x, int y, int width, int height, Boolean isTriggeredByEvent) {
/* 713 */     RoundRectangle2D rect = new RoundRectangle2D.Double(x, y, width, height, 20.0D, 20.0D);
/*     */ 
/* 716 */     if (isTriggeredByEvent.booleanValue()) {
/* 717 */       Stroke originalStroke = this.g.getStroke();
/* 718 */       this.g.setStroke(EVENT_SUBPROCESS_STROKE);
/* 719 */       this.g.draw(rect);
/* 720 */       this.g.setStroke(originalStroke);
/*     */     } else {
/* 722 */       this.g.draw(rect);
/*     */     }
/*     */ 
/* 725 */     String text = fitTextToWidth(name, width);
/* 726 */     this.g.drawString(text, x + 10, y + 15);
/*     */   }
/*     */ 
/*     */   public void drawCollapsedSubProcess(String name, int x, int y, int width, int height, Boolean isTriggeredByEvent) {
/* 730 */     drawCollapsedTask(name, x, y, width, height, false);
/*     */   }
/*     */ 
/*     */   public void drawCollapsedCallActivity(String name, int x, int y, int width, int height) {
/* 734 */     drawCollapsedTask(name, x, y, width, height, true);
/*     */   }
/*     */ 
/*     */   protected void drawCollapsedTask(String name, int x, int y, int width, int height, boolean thickBorder)
/*     */   {
/* 739 */     drawTask(name, x, y, width, height, thickBorder);
/*     */   }
/*     */ 
/*     */   public void drawCollapsedMarker(int x, int y, int width, int height)
/*     */   {
/* 744 */     int rectangleWidth = 12;
/* 745 */     int rectangleHeight = 12;
/* 746 */     Rectangle rect = new Rectangle(x + (width - rectangleWidth) / 2, y + height - rectangleHeight - 3, rectangleWidth, rectangleHeight);
/* 747 */     this.g.draw(rect);
/*     */ 
/* 750 */     Line2D.Double line = new Line2D.Double(rect.getCenterX(), rect.getY() + 2.0D, rect.getCenterX(), rect.getMaxY() - 2.0D);
/* 751 */     this.g.draw(line);
/* 752 */     line = new Line2D.Double(rect.getMinX() + 2.0D, rect.getCenterY(), rect.getMaxX() - 2.0D, rect.getCenterY());
/* 753 */     this.g.draw(line);
/*     */   }
/*     */ 
/*     */   public void drawActivityMarkers(int x, int y, int width, int height, boolean multiInstanceSequential, boolean multiInstanceParallel, boolean collapsed) {
/* 757 */     if (collapsed) {
/* 758 */       if ((!multiInstanceSequential) && (!multiInstanceParallel)) {
/* 759 */         drawCollapsedMarker(x, y, width, height);
/*     */       } else {
/* 761 */         drawCollapsedMarker(x - 6 - 2, y, width, height);
/* 762 */         if (multiInstanceSequential)
/* 763 */           drawMultiInstanceMarker(true, x + 6 + 2, y, width, height);
/* 764 */         else if (multiInstanceParallel) {
/* 765 */           drawMultiInstanceMarker(false, x + 6 + 2, y, width, height);
/*     */         }
/*     */       }
/*     */     }
/* 769 */     else if (multiInstanceSequential)
/* 770 */       drawMultiInstanceMarker(true, x, y, width, height);
/* 771 */     else if (multiInstanceParallel)
/* 772 */       drawMultiInstanceMarker(false, x, y, width, height);
/*     */   }
/*     */ 
/*     */   public void drawGateway(int x, int y, int width, int height)
/*     */   {
/* 778 */     Polygon rhombus = new Polygon();
/* 779 */     rhombus.addPoint(x, y + height / 2);
/* 780 */     rhombus.addPoint(x + width / 2, y + height);
/* 781 */     rhombus.addPoint(x + width, y + height / 2);
/* 782 */     rhombus.addPoint(x + width / 2, y);
/* 783 */     this.g.draw(rhombus);
/*     */   }
/*     */ 
/*     */   public void drawParallelGateway(int x, int y, int width, int height)
/*     */   {
/* 788 */     drawGateway(x, y, width, height);
/*     */ 
/* 791 */     Stroke orginalStroke = this.g.getStroke();
/* 792 */     this.g.setStroke(GATEWAY_TYPE_STROKE);
/* 793 */     Line2D.Double line = new Line2D.Double(x + 10, y + height / 2, x + width - 10, y + height / 2);
/* 794 */     this.g.draw(line);
/* 795 */     line = new Line2D.Double(x + width / 2, y + height - 10, x + width / 2, y + 10);
/* 796 */     this.g.draw(line);
/* 797 */     this.g.setStroke(orginalStroke);
/*     */   }
/*     */ 
/*     */   public void drawExclusiveGateway(int x, int y, int width, int height)
/*     */   {
/* 802 */     drawGateway(x, y, width, height);
/*     */ 
/* 804 */     int quarterWidth = width / 4;
/* 805 */     int quarterHeight = height / 4;
/*     */ 
/* 808 */     Stroke orginalStroke = this.g.getStroke();
/* 809 */     this.g.setStroke(GATEWAY_TYPE_STROKE);
/* 810 */     Line2D.Double line = new Line2D.Double(x + quarterWidth + 3, y + quarterHeight + 3, x + 3 * quarterWidth - 3, y + 3 * quarterHeight - 3);
/* 811 */     this.g.draw(line);
/* 812 */     line = new Line2D.Double(x + quarterWidth + 3, y + 3 * quarterHeight - 3, x + 3 * quarterWidth - 3, y + quarterHeight + 3);
/* 813 */     this.g.draw(line);
/*     */ 
/* 815 */     this.g.setStroke(orginalStroke);
/*     */   }
/*     */ 
/*     */   public void drawInclusiveGateway(int x, int y, int width, int height)
/*     */   {
/* 820 */     drawGateway(x, y, width, height);
/*     */ 
/* 822 */     int diameter = width / 2;
/*     */ 
/* 825 */     Stroke orginalStroke = this.g.getStroke();
/* 826 */     this.g.setStroke(GATEWAY_TYPE_STROKE);
/* 827 */     Ellipse2D.Double circle = new Ellipse2D.Double((width - diameter) / 2 + x, (height - diameter) / 2 + y, diameter, diameter);
/* 828 */     this.g.draw(circle);
/* 829 */     this.g.setStroke(orginalStroke);
/*     */   }
/*     */ 
/*     */   public void drawEventBasedGateway(int x, int y, int width, int height)
/*     */   {
/* 834 */     drawGateway(x, y, width, height);
/* 835 */     double scale = 0.6D;
/*     */ 
/* 837 */     drawCatchingEvent((int)(x + width * (1.0D - scale) / 2.0D), (int)(y + height * (1.0D - scale) / 2.0D), (int)(width * scale), (int)(height * scale), false, null);
/*     */ 
/* 839 */     double r = width / 6.0D;
/*     */ 
/* 842 */     int topX = (int)(0.95D * r);
/* 843 */     int topY = (int)(-0.31D * r);
/* 844 */     int bottomX = (int)(0.59D * r);
/* 845 */     int bottomY = (int)(0.8100000000000001D * r);
/*     */ 
/* 847 */     int[] xPoints = { 0, topX, bottomX, -bottomX, -topX };
/* 848 */     int[] yPoints = { -(int)r, topY, bottomY, bottomY, topY };
/* 849 */     Polygon pentagon = new Polygon(xPoints, yPoints, 5);
/* 850 */     pentagon.translate(x + width / 2, y + width / 2);
/*     */ 
/* 853 */     this.g.drawPolygon(pentagon);
/*     */   }
/*     */ 
/*     */   public void drawMultiInstanceMarker(boolean sequential, int x, int y, int width, int height) {
/* 857 */     int rectangleWidth = 12;
/* 858 */     int rectangleHeight = 12;
/* 859 */     int lineX = x + (width - rectangleWidth) / 2;
/* 860 */     int lineY = y + height - rectangleHeight - 3;
/*     */ 
/* 862 */     Stroke orginalStroke = this.g.getStroke();
/* 863 */     this.g.setStroke(MULTI_INSTANCE_STROKE);
/*     */ 
/* 865 */     if (sequential) {
/* 866 */       this.g.draw(new Line2D.Double(lineX, lineY, lineX + rectangleWidth, lineY));
/* 867 */       this.g.draw(new Line2D.Double(lineX, lineY + rectangleHeight / 2, lineX + rectangleWidth, lineY + rectangleHeight / 2));
/* 868 */       this.g.draw(new Line2D.Double(lineX, lineY + rectangleHeight, lineX + rectangleWidth, lineY + rectangleHeight));
/*     */     } else {
/* 870 */       this.g.draw(new Line2D.Double(lineX, lineY, lineX, lineY + rectangleHeight));
/* 871 */       this.g.draw(new Line2D.Double(lineX + rectangleWidth / 2, lineY, lineX + rectangleWidth / 2, lineY + rectangleHeight));
/* 872 */       this.g.draw(new Line2D.Double(lineX + rectangleWidth, lineY, lineX + rectangleWidth, lineY + rectangleHeight));
/*     */     }
/*     */ 
/* 875 */     this.g.setStroke(orginalStroke);
/*     */   }
/*     */ 
/*     */   public void drawHighLight(int x, int y, int width, int height) {
/* 879 */     Paint originalPaint = this.g.getPaint();
/* 880 */     Stroke originalStroke = this.g.getStroke();
/*     */ 
/* 882 */     this.g.setPaint(HIGHLIGHT_COLOR);
/* 883 */     this.g.setStroke(THICK_TASK_BORDER_STROKE);
/*     */ 
/* 885 */     RoundRectangle2D rect = new RoundRectangle2D.Double(x, y, width, height, 20.0D, 20.0D);
/* 886 */     this.g.draw(rect);
/*     */ 
/* 888 */     this.g.setPaint(originalPaint);
/* 889 */     this.g.setStroke(originalStroke);
/*     */   }
/*     */ 
/*     */   public void drawLabel(String name, int x, int y, int width, int height)
/*     */   {
/* 894 */     if (name != null) {
/* 895 */       Paint originalPaint = this.g.getPaint();
/* 896 */       Font originalFont = this.g.getFont();
/*     */ 
/* 898 */       this.g.setPaint(LABEL_COLOR);
/* 899 */       this.g.setFont(LABEL_FONT);
/*     */ 
/* 901 */       int textX = x + width / 2 - this.fontMetrics.stringWidth(name) / 2;
/* 902 */       int textY = y + height + this.fontMetrics.getHeight();
/*     */ 
/* 904 */       this.g.drawString(name, textX, textY);
/*     */ 
/* 907 */       this.g.setFont(originalFont);
/* 908 */       this.g.setPaint(originalPaint);
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/* 117 */       USERTASK_IMAGE = ImageIO.read(ReflectUtil.getResourceAsStream("org/activiti/engine/impl/bpmn/deployer/user.png"));
/* 118 */       SCRIPTTASK_IMAGE = ImageIO.read(ReflectUtil.getResourceAsStream("org/activiti/engine/impl/bpmn/deployer/script.png"));
/* 119 */       SERVICETASK_IMAGE = ImageIO.read(ReflectUtil.getResourceAsStream("org/activiti/engine/impl/bpmn/deployer/service.png"));
/* 120 */       RECEIVETASK_IMAGE = ImageIO.read(ReflectUtil.getResourceAsStream("org/activiti/engine/impl/bpmn/deployer/receive.png"));
/* 121 */       SENDTASK_IMAGE = ImageIO.read(ReflectUtil.getResourceAsStream("org/activiti/engine/impl/bpmn/deployer/send.png"));
/* 122 */       MANUALTASK_IMAGE = ImageIO.read(ReflectUtil.getResourceAsStream("org/activiti/engine/impl/bpmn/deployer/manual.png"));
/* 123 */       BUSINESS_RULE_TASK_IMAGE = ImageIO.read(ReflectUtil.getResourceAsStream("org/activiti/engine/impl/bpmn/deployer/business_rule.png"));
/* 124 */       TIMER_IMAGE = ImageIO.read(ReflectUtil.getResourceAsStream("org/activiti/engine/impl/bpmn/deployer/timer.png"));
/* 125 */       ERROR_THROW_IMAGE = ImageIO.read(ReflectUtil.getResourceAsStream("org/activiti/engine/impl/bpmn/deployer/error_throw.png"));
/* 126 */       ERROR_CATCH_IMAGE = ImageIO.read(ReflectUtil.getResourceAsStream("org/activiti/engine/impl/bpmn/deployer/error_catch.png"));
/* 127 */       SIGNAL_CATCH_IMAGE = ImageIO.read(ReflectUtil.getResourceAsStream("org/activiti/engine/impl/bpmn/deployer/signal_catch.png"));
/* 128 */       SIGNAL_THROW_IMAGE = ImageIO.read(ReflectUtil.getResourceAsStream("org/activiti/engine/impl/bpmn/deployer/signal_throw.png"));
/*     */     } catch (IOException e) {
/* 130 */       LOGGER.warn("Could not load image for process diagram creation: {}", e.getMessage());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.diagram.ProcessDiagramCanvas
 * JD-Core Version:    0.6.0
 */