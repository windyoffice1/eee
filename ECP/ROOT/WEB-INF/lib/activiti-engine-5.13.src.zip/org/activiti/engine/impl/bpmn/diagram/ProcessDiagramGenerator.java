/*     */ package org.activiti.engine.impl.bpmn.diagram;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.activiti.bpmn.model.Activity;
/*     */ import org.activiti.bpmn.model.BaseElement;
/*     */ import org.activiti.bpmn.model.BoundaryEvent;
/*     */ import org.activiti.bpmn.model.BpmnModel;
/*     */ import org.activiti.bpmn.model.BusinessRuleTask;
/*     */ import org.activiti.bpmn.model.CallActivity;
/*     */ import org.activiti.bpmn.model.EndEvent;
/*     */ import org.activiti.bpmn.model.ErrorEventDefinition;
/*     */ import org.activiti.bpmn.model.EventGateway;
/*     */ import org.activiti.bpmn.model.EventSubProcess;
/*     */ import org.activiti.bpmn.model.ExclusiveGateway;
/*     */ import org.activiti.bpmn.model.FlowElement;
/*     */ import org.activiti.bpmn.model.FlowElementsContainer;
/*     */ import org.activiti.bpmn.model.FlowNode;
/*     */ import org.activiti.bpmn.model.Gateway;
/*     */ import org.activiti.bpmn.model.GraphicInfo;
/*     */ import org.activiti.bpmn.model.InclusiveGateway;
/*     */ import org.activiti.bpmn.model.IntermediateCatchEvent;
/*     */ import org.activiti.bpmn.model.Lane;
/*     */ import org.activiti.bpmn.model.ManualTask;
/*     */ import org.activiti.bpmn.model.MultiInstanceLoopCharacteristics;
/*     */ import org.activiti.bpmn.model.ParallelGateway;
/*     */ import org.activiti.bpmn.model.Pool;
/*     */ import org.activiti.bpmn.model.Process;
/*     */ import org.activiti.bpmn.model.ReceiveTask;
/*     */ import org.activiti.bpmn.model.ScriptTask;
/*     */ import org.activiti.bpmn.model.SendTask;
/*     */ import org.activiti.bpmn.model.SequenceFlow;
/*     */ import org.activiti.bpmn.model.ServiceTask;
/*     */ import org.activiti.bpmn.model.SignalEventDefinition;
/*     */ import org.activiti.bpmn.model.StartEvent;
/*     */ import org.activiti.bpmn.model.SubProcess;
/*     */ import org.activiti.bpmn.model.Task;
/*     */ import org.activiti.bpmn.model.ThrowEvent;
/*     */ import org.activiti.bpmn.model.TimerEventDefinition;
/*     */ import org.activiti.bpmn.model.UserTask;
/*     */ 
/*     */ public class ProcessDiagramGenerator
/*     */ {
/*  68 */   protected static final Map<Class<? extends BaseElement>, ActivityDrawInstruction> activityDrawInstructions = new HashMap();
/*     */ 
/*     */   public static InputStream generatePngDiagram(BpmnModel bpmnModel)
/*     */   {
/* 321 */     return generateDiagram(bpmnModel, "png", Collections.emptyList());
/*     */   }
/*     */ 
/*     */   public static InputStream generateJpgDiagram(BpmnModel bpmnModel)
/*     */   {
/* 329 */     return generateDiagram(bpmnModel, "jpg", Collections.emptyList());
/*     */   }
/*     */ 
/*     */   protected static ProcessDiagramCanvas generateDiagram(BpmnModel bpmnModel, List<String> highLightedActivities) {
/* 333 */     return generateDiagram(bpmnModel, highLightedActivities, Collections.emptyList());
/*     */   }
/*     */ 
/*     */   protected static ProcessDiagramCanvas generateDiagram(BpmnModel bpmnModel, List<String> highLightedActivities, List<String> highLightedFlows) {
/* 337 */     ProcessDiagramCanvas processDiagramCanvas = initProcessDiagramCanvas(bpmnModel);
/*     */ 
/* 340 */     for (Pool pool : bpmnModel.getPools()) {
/* 341 */       GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(pool.getId());
/* 342 */       processDiagramCanvas.drawPoolOrLane(pool.getName(), (int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight());
/*     */     }
/*     */ 
/* 347 */     for (Process process : bpmnModel.getProcesses()) {
/* 348 */       for (Lane lane : process.getLanes()) {
/* 349 */         GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(lane.getId());
/* 350 */         processDiagramCanvas.drawPoolOrLane(lane.getName(), (int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 356 */     for (FlowNode flowNode : ((Process)bpmnModel.getProcesses().get(0)).findFlowElementsOfType(FlowNode.class)) {
/* 357 */       drawActivity(processDiagramCanvas, bpmnModel, flowNode, highLightedActivities, highLightedFlows);
/*     */     }
/* 359 */     return processDiagramCanvas;
/*     */   }
/*     */ 
/*     */   public static InputStream generateDiagram(BpmnModel bpmnModel, String imageType, List<String> highLightedActivities) {
/* 363 */     ProcessDiagramCanvas canvas = generateDiagram(bpmnModel, highLightedActivities, Collections.emptyList());
/* 364 */     return canvas.generateImage(imageType);
/*     */   }
/*     */ 
/*     */   public static InputStream generateDiagram(BpmnModel bpmnModel, String imageType, List<String> highLightedActivities, List<String> highLightedFlows) {
/* 368 */     return generateDiagram(bpmnModel, highLightedActivities, highLightedFlows).generateImage(imageType);
/*     */   }
/*     */ 
/*     */   protected static void drawActivity(ProcessDiagramCanvas processDiagramCanvas, BpmnModel bpmnModel, FlowNode flowNode, List<String> highLightedActivities, List<String> highLightedFlows)
/*     */   {
/* 373 */     ActivityDrawInstruction drawInstruction = (ActivityDrawInstruction)activityDrawInstructions.get(flowNode.getClass());
/* 374 */     if (drawInstruction != null)
/*     */     {
/* 376 */       drawInstruction.draw(processDiagramCanvas, bpmnModel, flowNode);
/*     */ 
/* 379 */       boolean multiInstanceSequential = false; boolean multiInstanceParallel = false; boolean collapsed = false;
/* 380 */       if ((flowNode instanceof Activity)) {
/* 381 */         Activity activity = (Activity)flowNode;
/* 382 */         MultiInstanceLoopCharacteristics multiInstanceLoopCharacteristics = activity.getLoopCharacteristics();
/* 383 */         if (multiInstanceLoopCharacteristics != null) {
/* 384 */           multiInstanceSequential = multiInstanceLoopCharacteristics.isSequential();
/* 385 */           multiInstanceParallel = !multiInstanceSequential;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 390 */       GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(flowNode.getId());
/* 391 */       if ((flowNode instanceof SubProcess))
/* 392 */         collapsed = !graphicInfo.isExpanded();
/* 393 */       else if ((flowNode instanceof CallActivity)) {
/* 394 */         collapsed = true;
/*     */       }
/*     */ 
/* 398 */       processDiagramCanvas.drawActivityMarkers((int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight(), multiInstanceSequential, multiInstanceParallel, collapsed);
/*     */ 
/* 402 */       if (highLightedActivities.contains(flowNode.getId())) {
/* 403 */         drawHighLight(processDiagramCanvas, bpmnModel.getGraphicInfo(flowNode.getId()));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 409 */     for (SequenceFlow sequenceFlow : flowNode.getOutgoingFlows()) {
/* 410 */       List graphicInfoList = bpmnModel.getFlowLocationGraphicInfo(sequenceFlow.getId());
/* 411 */       boolean drawedLabel = false;
/* 412 */       for (int i = 1; i < graphicInfoList.size(); i++)
/*     */       {
/* 414 */         GraphicInfo graphicInfo = (GraphicInfo)graphicInfoList.get(i);
/* 415 */         GraphicInfo previousGraphicInfo = (GraphicInfo)graphicInfoList.get(i - 1);
/*     */ 
/* 417 */         boolean highLighted = highLightedFlows.contains(sequenceFlow.getId());
/* 418 */         boolean drawConditionalIndicator = (i == 1) && (sequenceFlow.getConditionExpression() != null) && (!(flowNode instanceof Gateway));
/*     */ 
/* 420 */         if (i < graphicInfoList.size() - 1) {
/* 421 */           processDiagramCanvas.drawSequenceflowWithoutArrow((int)previousGraphicInfo.getX(), (int)previousGraphicInfo.getY(), (int)graphicInfo.getX(), (int)graphicInfo.getY(), drawConditionalIndicator, highLighted);
/*     */         }
/*     */         else {
/* 424 */           processDiagramCanvas.drawSequenceflow((int)previousGraphicInfo.getX(), (int)previousGraphicInfo.getY(), (int)graphicInfo.getX(), (int)graphicInfo.getY(), drawConditionalIndicator, highLighted);
/*     */ 
/* 426 */           if (!drawedLabel) {
/* 427 */             GraphicInfo labelGraphicInfo = bpmnModel.getLabelGraphicInfo(sequenceFlow.getId());
/* 428 */             if (labelGraphicInfo != null) {
/* 429 */               int middleX = (int)((previousGraphicInfo.getX() + labelGraphicInfo.getX() + (graphicInfo.getX() + labelGraphicInfo.getX())) / 2.0D);
/* 430 */               int middleY = (int)((previousGraphicInfo.getY() + labelGraphicInfo.getY() + (graphicInfo.getY() + labelGraphicInfo.getY())) / 2.0D);
/* 431 */               middleX += 15;
/* 432 */               processDiagramCanvas.drawLabel(sequenceFlow.getName(), middleX, middleY, (int)labelGraphicInfo.getWidth(), (int)labelGraphicInfo.getHeight());
/*     */ 
/* 434 */               drawedLabel = true;
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 464 */     if ((flowNode instanceof FlowElementsContainer))
/* 465 */       for (FlowElement nestedFlowElement : ((FlowElementsContainer)flowNode).getFlowElements())
/* 466 */         if ((nestedFlowElement instanceof FlowNode))
/* 467 */           drawActivity(processDiagramCanvas, bpmnModel, (FlowNode)nestedFlowElement, highLightedActivities, highLightedFlows);
/*     */   }
/*     */ 
/*     */   private static void drawHighLight(ProcessDiagramCanvas processDiagramCanvas, GraphicInfo graphicInfo)
/*     */   {
/* 474 */     processDiagramCanvas.drawHighLight((int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight());
/*     */   }
/*     */ 
/*     */   protected static ProcessDiagramCanvas initProcessDiagramCanvas(BpmnModel bpmnModel)
/*     */   {
/* 481 */     double minX = 1.7976931348623157E+308D;
/* 482 */     double maxX = 0.0D;
/* 483 */     double minY = 1.7976931348623157E+308D;
/* 484 */     double maxY = 0.0D;
/*     */ 
/* 486 */     for (Pool pool : bpmnModel.getPools()) {
/* 487 */       GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(pool.getId());
/* 488 */       minX = graphicInfo.getX();
/* 489 */       maxX = graphicInfo.getX() + graphicInfo.getWidth();
/* 490 */       minY = graphicInfo.getY();
/* 491 */       maxY = graphicInfo.getY() + graphicInfo.getHeight();
/*     */     }
/*     */ 
/* 494 */     List flowNodes = gatherAllFlowNodes(bpmnModel);
/* 495 */     for (FlowNode flowNode : flowNodes)
/*     */     {
/* 497 */       GraphicInfo flowNodeGraphicInfo = bpmnModel.getGraphicInfo(flowNode.getId());
/*     */ 
/* 500 */       if (flowNodeGraphicInfo.getX() + flowNodeGraphicInfo.getWidth() > maxX) {
/* 501 */         maxX = flowNodeGraphicInfo.getX() + flowNodeGraphicInfo.getWidth();
/*     */       }
/* 503 */       if (flowNodeGraphicInfo.getX() < minX) {
/* 504 */         minX = flowNodeGraphicInfo.getX();
/*     */       }
/*     */ 
/* 507 */       if (flowNodeGraphicInfo.getY() + flowNodeGraphicInfo.getHeight() > maxY) {
/* 508 */         maxY = flowNodeGraphicInfo.getY() + flowNodeGraphicInfo.getHeight();
/*     */       }
/* 510 */       if (flowNodeGraphicInfo.getY() < minY) {
/* 511 */         minY = flowNodeGraphicInfo.getY();
/*     */       }
/*     */ 
/* 514 */       for (SequenceFlow sequenceFlow : flowNode.getOutgoingFlows()) {
/* 515 */         List graphicInfoList = bpmnModel.getFlowLocationGraphicInfo(sequenceFlow.getId());
/* 516 */         for (GraphicInfo graphicInfo : graphicInfoList)
/*     */         {
/* 518 */           if (graphicInfo.getX() > maxX) {
/* 519 */             maxX = graphicInfo.getX();
/*     */           }
/* 521 */           if (graphicInfo.getX() < minX) {
/* 522 */             minX = graphicInfo.getX();
/*     */           }
/*     */ 
/* 525 */           if (graphicInfo.getY() > maxY) {
/* 526 */             maxY = graphicInfo.getY();
/*     */           }
/* 528 */           if (graphicInfo.getY() < minY) {
/* 529 */             minY = graphicInfo.getY();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 535 */     int nrOfLanes = 0;
/* 536 */     for (Process process : bpmnModel.getProcesses()) {
/* 537 */       for (Lane l : process.getLanes())
/*     */       {
/* 539 */         nrOfLanes++;
/*     */ 
/* 541 */         GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(l.getId());
/*     */ 
/* 543 */         if (graphicInfo.getX() + graphicInfo.getWidth() > maxX) {
/* 544 */           maxX = graphicInfo.getX() + graphicInfo.getWidth();
/*     */         }
/* 546 */         if (graphicInfo.getX() < minX) {
/* 547 */           minX = graphicInfo.getX();
/*     */         }
/*     */ 
/* 550 */         if (graphicInfo.getY() + graphicInfo.getHeight() > maxY) {
/* 551 */           maxY = graphicInfo.getY() + graphicInfo.getHeight();
/*     */         }
/* 553 */         if (graphicInfo.getY() < minY) {
/* 554 */           minY = graphicInfo.getY();
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 560 */     if ((flowNodes.size() == 0) && (bpmnModel.getPools().size() == 0) && (nrOfLanes == 0))
/*     */     {
/* 562 */       minX = 0.0D;
/* 563 */       minY = 0.0D;
/*     */     }
/*     */ 
/* 566 */     return new ProcessDiagramCanvas((int)maxX + 10, (int)maxY + 10, (int)minX, (int)minY);
/*     */   }
/*     */ 
/*     */   protected static List<FlowNode> gatherAllFlowNodes(BpmnModel bpmnModel) {
/* 570 */     List flowNodes = new ArrayList();
/* 571 */     for (Process process : bpmnModel.getProcesses()) {
/* 572 */       flowNodes.addAll(gatherAllFlowNodes(process));
/*     */     }
/* 574 */     return flowNodes;
/*     */   }
/*     */ 
/*     */   protected static List<FlowNode> gatherAllFlowNodes(FlowElementsContainer flowElementsContainer) {
/* 578 */     List flowNodes = new ArrayList();
/* 579 */     for (FlowElement flowElement : flowElementsContainer.getFlowElements()) {
/* 580 */       if ((flowElement instanceof FlowNode)) {
/* 581 */         flowNodes.add((FlowNode)flowElement);
/*     */       }
/* 583 */       if ((flowElement instanceof FlowElementsContainer)) {
/* 584 */         flowNodes.addAll(gatherAllFlowNodes((FlowElementsContainer)flowElement));
/*     */       }
/*     */     }
/* 587 */     return flowNodes;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  74 */     activityDrawInstructions.put(StartEvent.class, new ActivityDrawInstruction()
/*     */     {
/*     */       public void draw(ProcessDiagramCanvas processDiagramCanvas, BpmnModel bpmnModel, FlowNode flowNode) {
/*  77 */         GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(flowNode.getId());
/*  78 */         StartEvent startEvent = (StartEvent)flowNode;
/*  79 */         if ((startEvent.getEventDefinitions() != null) && (startEvent.getEventDefinitions().size() > 0)) {
/*  80 */           if ((startEvent.getEventDefinitions().get(0) instanceof TimerEventDefinition))
/*  81 */             processDiagramCanvas.drawTimerStartEvent((int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight());
/*  82 */           else if ((startEvent.getEventDefinitions().get(0) instanceof ErrorEventDefinition))
/*  83 */             processDiagramCanvas.drawErrorStartEvent((int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight());
/*     */         }
/*     */         else
/*  86 */           processDiagramCanvas.drawNoneStartEvent((int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight());
/*     */       }
/*     */     });
/*  92 */     activityDrawInstructions.put(IntermediateCatchEvent.class, new ActivityDrawInstruction()
/*     */     {
/*     */       public void draw(ProcessDiagramCanvas processDiagramCanvas, BpmnModel bpmnModel, FlowNode flowNode) {
/*  95 */         GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(flowNode.getId());
/*  96 */         IntermediateCatchEvent intermediateCatchEvent = (IntermediateCatchEvent)flowNode;
/*  97 */         if ((intermediateCatchEvent.getEventDefinitions() != null) && (intermediateCatchEvent.getEventDefinitions().size() > 0))
/*  98 */           if ((intermediateCatchEvent.getEventDefinitions().get(0) instanceof SignalEventDefinition))
/*  99 */             processDiagramCanvas.drawCatchingSignalEvent(flowNode.getName(), (int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight(), false);
/* 100 */           else if ((intermediateCatchEvent.getEventDefinitions().get(0) instanceof TimerEventDefinition))
/* 101 */             processDiagramCanvas.drawCatchingTimerEvent(flowNode.getName(), (int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight(), false);
/*     */       }
/*     */     });
/* 108 */     activityDrawInstructions.put(ThrowEvent.class, new ActivityDrawInstruction()
/*     */     {
/*     */       public void draw(ProcessDiagramCanvas processDiagramCanvas, BpmnModel bpmnModel, FlowNode flowNode) {
/* 111 */         GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(flowNode.getId());
/* 112 */         ThrowEvent throwEvent = (ThrowEvent)flowNode;
/* 113 */         if ((throwEvent.getEventDefinitions() != null) && (throwEvent.getEventDefinitions().size() > 0)) {
/* 114 */           if ((throwEvent.getEventDefinitions().get(0) instanceof SignalEventDefinition))
/* 115 */             processDiagramCanvas.drawThrowingSignalEvent((int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight());
/*     */         }
/*     */         else
/* 118 */           processDiagramCanvas.drawThrowingNoneEvent((int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight());
/*     */       }
/*     */     });
/* 124 */     activityDrawInstructions.put(EndEvent.class, new ActivityDrawInstruction()
/*     */     {
/*     */       public void draw(ProcessDiagramCanvas processDiagramCanvas, BpmnModel bpmnModel, FlowNode flowNode) {
/* 127 */         GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(flowNode.getId());
/* 128 */         EndEvent endEvent = (EndEvent)flowNode;
/* 129 */         if ((endEvent.getEventDefinitions() != null) && (endEvent.getEventDefinitions().size() > 0)) {
/* 130 */           if ((endEvent.getEventDefinitions().get(0) instanceof ErrorEventDefinition))
/* 131 */             processDiagramCanvas.drawErrorEndEvent(flowNode.getName(), (int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight());
/*     */         }
/*     */         else
/* 134 */           processDiagramCanvas.drawNoneEndEvent((int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight());
/*     */       }
/*     */     });
/* 140 */     activityDrawInstructions.put(Task.class, new ActivityDrawInstruction()
/*     */     {
/*     */       public void draw(ProcessDiagramCanvas processDiagramCanvas, BpmnModel bpmnModel, FlowNode flowNode) {
/* 143 */         GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(flowNode.getId());
/* 144 */         processDiagramCanvas.drawTask(flowNode.getName(), (int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight());
/*     */       }
/*     */     });
/* 149 */     activityDrawInstructions.put(UserTask.class, new ActivityDrawInstruction()
/*     */     {
/*     */       public void draw(ProcessDiagramCanvas processDiagramCanvas, BpmnModel bpmnModel, FlowNode flowNode) {
/* 152 */         GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(flowNode.getId());
/* 153 */         processDiagramCanvas.drawUserTask(flowNode.getName(), (int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight());
/*     */       }
/*     */     });
/* 158 */     activityDrawInstructions.put(ScriptTask.class, new ActivityDrawInstruction()
/*     */     {
/*     */       public void draw(ProcessDiagramCanvas processDiagramCanvas, BpmnModel bpmnModel, FlowNode flowNode) {
/* 161 */         GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(flowNode.getId());
/* 162 */         processDiagramCanvas.drawScriptTask(flowNode.getName(), (int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight());
/*     */       }
/*     */     });
/* 167 */     activityDrawInstructions.put(ServiceTask.class, new ActivityDrawInstruction()
/*     */     {
/*     */       public void draw(ProcessDiagramCanvas processDiagramCanvas, BpmnModel bpmnModel, FlowNode flowNode) {
/* 170 */         GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(flowNode.getId());
/* 171 */         processDiagramCanvas.drawServiceTask(flowNode.getName(), (int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight());
/*     */       }
/*     */     });
/* 176 */     activityDrawInstructions.put(ReceiveTask.class, new ActivityDrawInstruction()
/*     */     {
/*     */       public void draw(ProcessDiagramCanvas processDiagramCanvas, BpmnModel bpmnModel, FlowNode flowNode) {
/* 179 */         GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(flowNode.getId());
/* 180 */         processDiagramCanvas.drawReceiveTask(flowNode.getName(), (int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight());
/*     */       }
/*     */     });
/* 185 */     activityDrawInstructions.put(SendTask.class, new ActivityDrawInstruction()
/*     */     {
/*     */       public void draw(ProcessDiagramCanvas processDiagramCanvas, BpmnModel bpmnModel, FlowNode flowNode) {
/* 188 */         GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(flowNode.getId());
/* 189 */         processDiagramCanvas.drawSendTask(flowNode.getName(), (int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight());
/*     */       }
/*     */     });
/* 194 */     activityDrawInstructions.put(ManualTask.class, new ActivityDrawInstruction()
/*     */     {
/*     */       public void draw(ProcessDiagramCanvas processDiagramCanvas, BpmnModel bpmnModel, FlowNode flowNode) {
/* 197 */         GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(flowNode.getId());
/* 198 */         processDiagramCanvas.drawManualTask(flowNode.getName(), (int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight());
/*     */       }
/*     */     });
/* 203 */     activityDrawInstructions.put(BusinessRuleTask.class, new ActivityDrawInstruction()
/*     */     {
/*     */       public void draw(ProcessDiagramCanvas processDiagramCanvas, BpmnModel bpmnModel, FlowNode flowNode) {
/* 206 */         GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(flowNode.getId());
/* 207 */         processDiagramCanvas.drawBusinessRuleTask(flowNode.getName(), (int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight());
/*     */       }
/*     */     });
/* 212 */     activityDrawInstructions.put(ExclusiveGateway.class, new ActivityDrawInstruction()
/*     */     {
/*     */       public void draw(ProcessDiagramCanvas processDiagramCanvas, BpmnModel bpmnModel, FlowNode flowNode) {
/* 215 */         GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(flowNode.getId());
/* 216 */         processDiagramCanvas.drawExclusiveGateway((int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight());
/*     */       }
/*     */     });
/* 221 */     activityDrawInstructions.put(InclusiveGateway.class, new ActivityDrawInstruction()
/*     */     {
/*     */       public void draw(ProcessDiagramCanvas processDiagramCanvas, BpmnModel bpmnModel, FlowNode flowNode) {
/* 224 */         GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(flowNode.getId());
/* 225 */         processDiagramCanvas.drawInclusiveGateway((int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight());
/*     */       }
/*     */     });
/* 230 */     activityDrawInstructions.put(ParallelGateway.class, new ActivityDrawInstruction()
/*     */     {
/*     */       public void draw(ProcessDiagramCanvas processDiagramCanvas, BpmnModel bpmnModel, FlowNode flowNode) {
/* 233 */         GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(flowNode.getId());
/* 234 */         processDiagramCanvas.drawParallelGateway((int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight());
/*     */       }
/*     */     });
/* 239 */     activityDrawInstructions.put(EventGateway.class, new ActivityDrawInstruction()
/*     */     {
/*     */       public void draw(ProcessDiagramCanvas processDiagramCanvas, BpmnModel bpmnModel, FlowNode flowNode) {
/* 242 */         GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(flowNode.getId());
/* 243 */         processDiagramCanvas.drawEventBasedGateway((int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight());
/*     */       }
/*     */     });
/* 249 */     activityDrawInstructions.put(BoundaryEvent.class, new ActivityDrawInstruction()
/*     */     {
/*     */       public void draw(ProcessDiagramCanvas processDiagramCanvas, BpmnModel bpmnModel, FlowNode flowNode) {
/* 252 */         GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(flowNode.getId());
/* 253 */         BoundaryEvent boundaryEvent = (BoundaryEvent)flowNode;
/* 254 */         if ((boundaryEvent.getEventDefinitions() != null) && (boundaryEvent.getEventDefinitions().size() > 0))
/* 255 */           if ((boundaryEvent.getEventDefinitions().get(0) instanceof TimerEventDefinition))
/*     */           {
/* 257 */             processDiagramCanvas.drawCatchingTimerEvent(flowNode.getName(), (int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight(), boundaryEvent.isCancelActivity());
/*     */           }
/* 260 */           else if ((boundaryEvent.getEventDefinitions().get(0) instanceof ErrorEventDefinition))
/*     */           {
/* 262 */             processDiagramCanvas.drawCatchingErrorEvent((int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight(), boundaryEvent.isCancelActivity());
/*     */           }
/* 265 */           else if ((boundaryEvent.getEventDefinitions().get(0) instanceof SignalEventDefinition))
/* 266 */             processDiagramCanvas.drawCatchingSignalEvent(flowNode.getName(), (int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight(), boundaryEvent.isCancelActivity());
/*     */       }
/*     */     });
/* 275 */     activityDrawInstructions.put(SubProcess.class, new ActivityDrawInstruction()
/*     */     {
/*     */       public void draw(ProcessDiagramCanvas processDiagramCanvas, BpmnModel bpmnModel, FlowNode flowNode) {
/* 278 */         GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(flowNode.getId());
/* 279 */         if (!graphicInfo.isExpanded()) {
/* 280 */           processDiagramCanvas.drawCollapsedSubProcess(flowNode.getName(), (int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight(), Boolean.valueOf(false));
/*     */         }
/*     */         else
/* 283 */           processDiagramCanvas.drawExpandedSubProcess(flowNode.getName(), (int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight(), Boolean.valueOf(false));
/*     */       }
/*     */     });
/* 290 */     activityDrawInstructions.put(EventSubProcess.class, new ActivityDrawInstruction()
/*     */     {
/*     */       public void draw(ProcessDiagramCanvas processDiagramCanvas, BpmnModel bpmnModel, FlowNode flowNode) {
/* 293 */         GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(flowNode.getId());
/* 294 */         if (!graphicInfo.isExpanded()) {
/* 295 */           processDiagramCanvas.drawCollapsedSubProcess(flowNode.getName(), (int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight(), Boolean.valueOf(true));
/*     */         }
/*     */         else
/* 298 */           processDiagramCanvas.drawExpandedSubProcess(flowNode.getName(), (int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight(), Boolean.valueOf(true));
/*     */       }
/*     */     });
/* 305 */     activityDrawInstructions.put(CallActivity.class, new ActivityDrawInstruction()
/*     */     {
/*     */       public void draw(ProcessDiagramCanvas processDiagramCanvas, BpmnModel bpmnModel, FlowNode flowNode) {
/* 308 */         GraphicInfo graphicInfo = bpmnModel.getGraphicInfo(flowNode.getId());
/* 309 */         processDiagramCanvas.drawCollapsedCallActivity(flowNode.getName(), (int)graphicInfo.getX(), (int)graphicInfo.getY(), (int)graphicInfo.getWidth(), (int)graphicInfo.getHeight());
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   protected static abstract interface ActivityDrawInstruction
/*     */   {
/*     */     public abstract void draw(ProcessDiagramCanvas paramProcessDiagramCanvas, BpmnModel paramBpmnModel, FlowNode paramFlowNode);
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.diagram.ProcessDiagramGenerator
 * JD-Core Version:    0.6.0
 */