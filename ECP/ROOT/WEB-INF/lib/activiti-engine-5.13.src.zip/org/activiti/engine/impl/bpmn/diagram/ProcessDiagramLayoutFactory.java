/*     */ package org.activiti.engine.impl.bpmn.diagram;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.TreeMap;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.xpath.XPath;
/*     */ import javax.xml.xpath.XPathExpression;
/*     */ import javax.xml.xpath.XPathExpressionException;
/*     */ import javax.xml.xpath.XPathFactory;
/*     */ import org.activiti.engine.ActivitiException;
/*     */ import org.activiti.engine.repository.DiagramElement;
/*     */ import org.activiti.engine.repository.DiagramLayout;
/*     */ import org.activiti.engine.repository.DiagramNode;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ public class ProcessDiagramLayoutFactory
/*     */ {
/*     */   private static final int GREY_THRESHOLD = 175;
/*     */ 
/*     */   public DiagramLayout getProcessDiagramLayout(InputStream bpmnXmlStream, InputStream imageStream)
/*     */   {
/*  69 */     Document bpmnModel = parseXml(bpmnXmlStream);
/*  70 */     return getBpmnProcessDiagramLayout(bpmnModel, imageStream);
/*     */   }
/*     */ 
/*     */   public DiagramLayout getBpmnProcessDiagramLayout(Document bpmnModel, InputStream imageStream)
/*     */   {
/*  86 */     if (imageStream == null) {
/*  87 */       return null;
/*     */     }
/*  89 */     DiagramNode diagramBoundsXml = getDiagramBoundsFromBpmnDi(bpmnModel);
/*     */     DiagramNode diagramBoundsImage;
/*     */     DiagramNode diagramBoundsImage;
/*  91 */     if (isExportedFromAdonis50(bpmnModel)) {
/*  92 */       int offsetTop = 29;
/*  93 */       int offsetBottom = 61;
/*  94 */       diagramBoundsImage = getDiagramBoundsFromImage(imageStream, offsetTop, offsetBottom);
/*     */     } else {
/*  96 */       diagramBoundsImage = getDiagramBoundsFromImage(imageStream);
/*     */     }
/*     */ 
/*  99 */     Map listOfBounds = new HashMap();
/* 100 */     listOfBounds.put(diagramBoundsXml.getId(), diagramBoundsXml);
/*     */ 
/* 102 */     listOfBounds.putAll(fixFlowNodePositionsIfModelFromAdonis(bpmnModel, getElementBoundsFromBpmnDi(bpmnModel)));
/*     */ 
/* 104 */     Map listOfBoundsForImage = transformBoundsForImage(diagramBoundsImage, diagramBoundsXml, listOfBounds);
/* 105 */     return new DiagramLayout(listOfBoundsForImage);
/*     */   }
/*     */ 
/*     */   protected Document parseXml(InputStream bpmnXmlStream)
/*     */   {
/* 110 */     DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/*     */ 
/* 112 */     factory.setNamespaceAware(true);
/*     */     Document bpmnModel;
/*     */     try {
/* 118 */       DocumentBuilder builder = factory.newDocumentBuilder();
/*     */ 
/* 120 */       bpmnModel = builder.parse(bpmnXmlStream);
/*     */     } catch (Exception e) {
/* 122 */       throw new ActivitiException("Error while parsing BPMN model.", e);
/*     */     }
/* 124 */     return bpmnModel;
/*     */   }
/*     */ 
/*     */   protected DiagramNode getDiagramBoundsFromBpmnDi(Document bpmnModel) {
/* 128 */     Double minX = null;
/* 129 */     Double minY = null;
/* 130 */     Double maxX = null;
/* 131 */     Double maxY = null;
/*     */ 
/* 134 */     NodeList setOfBounds = bpmnModel.getElementsByTagNameNS("http://www.omg.org/spec/DD/20100524/DC", "Bounds");
/* 135 */     for (int i = 0; i < setOfBounds.getLength(); i++) {
/* 136 */       Element element = (Element)setOfBounds.item(i);
/* 137 */       Double x = Double.valueOf(element.getAttribute("x"));
/* 138 */       Double y = Double.valueOf(element.getAttribute("y"));
/* 139 */       Double width = Double.valueOf(element.getAttribute("width"));
/* 140 */       Double height = Double.valueOf(element.getAttribute("height"));
/*     */ 
/* 142 */       if ((x.doubleValue() == 0.0D) && (y.doubleValue() == 0.0D) && (width.doubleValue() == 0.0D) && (height.doubleValue() == 0.0D))
/*     */       {
/*     */         continue;
/*     */       }
/* 146 */       if ((minX == null) || (x.doubleValue() < minX.doubleValue())) {
/* 147 */         minX = x;
/*     */       }
/* 149 */       if ((minY == null) || (y.doubleValue() < minY.doubleValue())) {
/* 150 */         minY = y;
/*     */       }
/* 152 */       if ((maxX == null) || (maxX.doubleValue() < x.doubleValue() + width.doubleValue())) {
/* 153 */         maxX = Double.valueOf(x.doubleValue() + width.doubleValue());
/*     */       }
/* 155 */       if ((maxY == null) || (maxY.doubleValue() < y.doubleValue() + height.doubleValue())) {
/* 156 */         maxY = Double.valueOf(y.doubleValue() + height.doubleValue());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 162 */     NodeList waypoints = bpmnModel.getElementsByTagNameNS("http://www.omg.org/spec/DD/20100524/DI", "waypoint");
/* 163 */     for (int i = 0; i < waypoints.getLength(); i++) {
/* 164 */       Element waypoint = (Element)waypoints.item(i);
/* 165 */       Double x = Double.valueOf(waypoint.getAttribute("x"));
/* 166 */       Double y = Double.valueOf(waypoint.getAttribute("y"));
/*     */ 
/* 168 */       if ((minX == null) || (x.doubleValue() < minX.doubleValue())) {
/* 169 */         minX = x;
/*     */       }
/* 171 */       if ((minY == null) || (y.doubleValue() < minY.doubleValue())) {
/* 172 */         minY = y;
/*     */       }
/* 174 */       if ((maxX == null) || (maxX.doubleValue() < x.doubleValue())) {
/* 175 */         maxX = x;
/*     */       }
/* 177 */       if ((maxY == null) || (maxY.doubleValue() < y.doubleValue())) {
/* 178 */         maxY = y;
/*     */       }
/*     */     }
/*     */ 
/* 182 */     DiagramNode diagramBounds = new DiagramNode("BPMNDiagram");
/* 183 */     diagramBounds.setX(minX);
/* 184 */     diagramBounds.setY(minY);
/* 185 */     diagramBounds.setWidth(Double.valueOf(maxX.doubleValue() - minX.doubleValue()));
/* 186 */     diagramBounds.setHeight(Double.valueOf(maxY.doubleValue() - minY.doubleValue()));
/* 187 */     return diagramBounds;
/*     */   }
/*     */ 
/*     */   protected DiagramNode getDiagramBoundsFromImage(InputStream imageStream) {
/* 191 */     return getDiagramBoundsFromImage(imageStream, 0, 0);
/*     */   }
/*     */   protected DiagramNode getDiagramBoundsFromImage(InputStream imageStream, int offsetTop, int offsetBottom) {
/*     */     BufferedImage image;
/*     */     try {
/* 197 */       image = ImageIO.read(imageStream);
/*     */     } catch (IOException e) {
/* 199 */       throw new ActivitiException("Error while reading process diagram image.", e);
/*     */     }
/* 201 */     DiagramNode diagramBoundsImage = getDiagramBoundsFromImage(image, offsetTop, offsetBottom);
/* 202 */     return diagramBoundsImage;
/*     */   }
/*     */ 
/*     */   protected DiagramNode getDiagramBoundsFromImage(BufferedImage image, int offsetTop, int offsetBottom) {
/* 206 */     int width = image.getWidth();
/* 207 */     int height = image.getHeight();
/*     */ 
/* 209 */     Map rowIsWhite = new TreeMap();
/* 210 */     Map columnIsWhite = new TreeMap();
/*     */ 
/* 212 */     for (int row = 0; row < height; row++) {
/* 213 */       if (!rowIsWhite.containsKey(Integer.valueOf(row))) {
/* 214 */         rowIsWhite.put(Integer.valueOf(row), Boolean.valueOf(true));
/*     */       }
/* 216 */       if ((row <= offsetTop) || (row > image.getHeight() - offsetBottom))
/* 217 */         rowIsWhite.put(Integer.valueOf(row), Boolean.valueOf(true));
/*     */       else {
/* 219 */         for (int column = 0; column < width; column++) {
/* 220 */           if (!columnIsWhite.containsKey(Integer.valueOf(column))) {
/* 221 */             columnIsWhite.put(Integer.valueOf(column), Boolean.valueOf(true));
/*     */           }
/* 223 */           int pixel = image.getRGB(column, row);
/* 224 */           int alpha = pixel >> 24 & 0xFF;
/* 225 */           int red = pixel >> 16 & 0xFF;
/* 226 */           int green = pixel >> 8 & 0xFF;
/* 227 */           int blue = pixel >> 0 & 0xFF;
/* 228 */           if ((alpha != 0) && ((red < 175) || (green < 175) || (blue < 175))) {
/* 229 */             rowIsWhite.put(Integer.valueOf(row), Boolean.valueOf(false));
/* 230 */             columnIsWhite.put(Integer.valueOf(column), Boolean.valueOf(false));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 236 */     int marginTop = 0;
/* 237 */     for (int row = 0; (row < height) && 
/* 238 */       (((Boolean)rowIsWhite.get(Integer.valueOf(row))).booleanValue()); row++)
/*     */     {
/* 239 */       marginTop++;
/*     */     }
/*     */ 
/* 246 */     int marginLeft = 0;
/* 247 */     for (int column = 0; (column < width) && 
/* 248 */       (((Boolean)columnIsWhite.get(Integer.valueOf(column))).booleanValue()); column++)
/*     */     {
/* 249 */       marginLeft++;
/*     */     }
/*     */ 
/* 256 */     int marginRight = 0;
/* 257 */     for (int column = width - 1; (column >= 0) && 
/* 258 */       (((Boolean)columnIsWhite.get(Integer.valueOf(column))).booleanValue()); column--)
/*     */     {
/* 259 */       marginRight++;
/*     */     }
/*     */ 
/* 266 */     int marginBottom = 0;
/* 267 */     for (int row = height - 1; (row >= 0) && 
/* 268 */       (((Boolean)rowIsWhite.get(Integer.valueOf(row))).booleanValue()); row--)
/*     */     {
/* 269 */       marginBottom++;
/*     */     }
/*     */ 
/* 276 */     DiagramNode diagramBoundsImage = new DiagramNode();
/* 277 */     diagramBoundsImage.setX(Double.valueOf(marginLeft));
/* 278 */     diagramBoundsImage.setY(Double.valueOf(marginTop));
/* 279 */     diagramBoundsImage.setWidth(Double.valueOf(width - marginRight - marginLeft));
/* 280 */     diagramBoundsImage.setHeight(Double.valueOf(height - marginBottom - marginTop));
/* 281 */     return diagramBoundsImage;
/*     */   }
/*     */ 
/*     */   protected Map<String, DiagramNode> getElementBoundsFromBpmnDi(Document bpmnModel) {
/* 285 */     Map listOfBounds = new HashMap();
/*     */ 
/* 287 */     NodeList shapes = bpmnModel.getElementsByTagNameNS("http://www.omg.org/spec/BPMN/20100524/DI", "BPMNShape");
/* 288 */     for (int i = 0; i < shapes.getLength(); i++) {
/* 289 */       Element shape = (Element)shapes.item(i);
/* 290 */       String bpmnElementId = shape.getAttribute("bpmnElement");
/*     */ 
/* 292 */       NodeList childNodes = shape.getChildNodes();
/* 293 */       for (int j = 0; j < childNodes.getLength(); j++) {
/* 294 */         Node childNode = childNodes.item(j);
/* 295 */         if ((!(childNode instanceof Element)) || (!"http://www.omg.org/spec/DD/20100524/DC".equals(childNode.getNamespaceURI())) || (!"Bounds".equals(childNode.getLocalName()))) {
/*     */           continue;
/*     */         }
/* 298 */         DiagramNode bounds = parseBounds((Element)childNode);
/* 299 */         bounds.setId(bpmnElementId);
/* 300 */         listOfBounds.put(bpmnElementId, bounds);
/* 301 */         break;
/*     */       }
/*     */     }
/*     */ 
/* 305 */     return listOfBounds;
/*     */   }
/*     */ 
/*     */   protected DiagramNode parseBounds(Element boundsElement) {
/* 309 */     DiagramNode bounds = new DiagramNode();
/* 310 */     bounds.setX(Double.valueOf(boundsElement.getAttribute("x")));
/* 311 */     bounds.setY(Double.valueOf(boundsElement.getAttribute("y")));
/* 312 */     bounds.setWidth(Double.valueOf(boundsElement.getAttribute("width")));
/* 313 */     bounds.setHeight(Double.valueOf(boundsElement.getAttribute("height")));
/* 314 */     return bounds;
/*     */   }
/*     */ 
/*     */   protected Map<String, DiagramElement> transformBoundsForImage(DiagramNode diagramBoundsImage, DiagramNode diagramBoundsXml, Map<String, DiagramNode> listOfBounds) {
/* 318 */     Map listOfBoundsForImage = new HashMap();
/* 319 */     for (Map.Entry bounds : listOfBounds.entrySet()) {
/* 320 */       listOfBoundsForImage.put(bounds.getKey(), transformBoundsForImage(diagramBoundsImage, diagramBoundsXml, (DiagramNode)bounds.getValue()));
/*     */     }
/* 322 */     return listOfBoundsForImage;
/*     */   }
/*     */ 
/*     */   protected DiagramNode transformBoundsForImage(DiagramNode diagramBoundsImage, DiagramNode diagramBoundsXml, DiagramNode elementBounds) {
/* 326 */     double scalingFactorX = diagramBoundsImage.getWidth().doubleValue() / diagramBoundsXml.getWidth().doubleValue();
/* 327 */     double scalingFactorY = diagramBoundsImage.getWidth().doubleValue() / diagramBoundsXml.getWidth().doubleValue();
/*     */ 
/* 329 */     DiagramNode elementBoundsForImage = new DiagramNode(elementBounds.getId());
/* 330 */     elementBoundsForImage.setX(Double.valueOf(Math.round((elementBounds.getX().doubleValue() - diagramBoundsXml.getX().doubleValue()) * scalingFactorX + diagramBoundsImage.getX().doubleValue())));
/* 331 */     elementBoundsForImage.setY(Double.valueOf(Math.round((elementBounds.getY().doubleValue() - diagramBoundsXml.getY().doubleValue()) * scalingFactorY + diagramBoundsImage.getY().doubleValue())));
/* 332 */     elementBoundsForImage.setWidth(Double.valueOf(Math.round(elementBounds.getWidth().doubleValue() * scalingFactorX)));
/* 333 */     elementBoundsForImage.setHeight(Double.valueOf(Math.round(elementBounds.getHeight().doubleValue() * scalingFactorY)));
/* 334 */     return elementBoundsForImage;
/*     */   }
/*     */ 
/*     */   protected Map<String, DiagramNode> fixFlowNodePositionsIfModelFromAdonis(Document bpmnModel, Map<String, DiagramNode> elementBoundsFromBpmnDi) {
/* 338 */     if (isExportedFromAdonis50(bpmnModel)) {
/* 339 */       Map mapOfFixedBounds = new HashMap();
/* 340 */       XPathFactory xPathFactory = XPathFactory.newInstance();
/* 341 */       XPath xPath = xPathFactory.newXPath();
/* 342 */       xPath.setNamespaceContext(new Bpmn20NamespaceContext());
/* 343 */       for (Map.Entry entry : elementBoundsFromBpmnDi.entrySet()) {
/* 344 */         String elementId = (String)entry.getKey();
/* 345 */         DiagramNode elementBounds = (DiagramNode)entry.getValue();
/* 346 */         String expression = "local-name(//bpmn:*[@id = '" + elementId + "'])";
/*     */         try {
/* 348 */           XPathExpression xPathExpression = xPath.compile(expression);
/* 349 */           String elementLocalName = xPathExpression.evaluate(bpmnModel);
/* 350 */           if ((!"participant".equals(elementLocalName)) && (!"lane".equals(elementLocalName)) && (!"textAnnotation".equals(elementLocalName)) && (!"group".equals(elementLocalName)))
/*     */           {
/* 354 */             elementBounds.setX(Double.valueOf(elementBounds.getX().doubleValue() - elementBounds.getWidth().doubleValue() / 2.0D));
/* 355 */             elementBounds.setY(Double.valueOf(elementBounds.getY().doubleValue() - elementBounds.getHeight().doubleValue() / 2.0D));
/*     */           }
/*     */         } catch (XPathExpressionException e) {
/* 358 */           throw new ActivitiException("Error while evaluating the following XPath expression on a BPMN XML document: '" + expression + "'.", e);
/*     */         }
/* 360 */         mapOfFixedBounds.put(elementId, elementBounds);
/*     */       }
/* 362 */       return mapOfFixedBounds;
/*     */     }
/* 364 */     return elementBoundsFromBpmnDi;
/*     */   }
/*     */ 
/*     */   protected boolean isExportedFromAdonis50(Document bpmnModel)
/*     */   {
/* 369 */     return ("ADONIS".equals(bpmnModel.getDocumentElement().getAttribute("exporter"))) && ("5.0".equals(bpmnModel.getDocumentElement().getAttribute("exporterVersion")));
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.diagram.ProcessDiagramLayoutFactory
 * JD-Core Version:    0.6.0
 */