/*     */ package org.activiti.engine.impl.bpmn.helper;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.List;
/*     */ import org.activiti.engine.ActivitiException;
/*     */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*     */ import org.activiti.engine.delegate.BpmnError;
/*     */ import org.activiti.engine.delegate.DelegateExecution;
/*     */ import org.activiti.engine.delegate.DelegateTask;
/*     */ import org.activiti.engine.delegate.ExecutionListener;
/*     */ import org.activiti.engine.delegate.JavaDelegate;
/*     */ import org.activiti.engine.delegate.TaskListener;
/*     */ import org.activiti.engine.impl.bpmn.behavior.AbstractBpmnActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.MultiInstanceActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.ServiceTaskJavaDelegateActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.parser.FieldDeclaration;
/*     */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*     */ import org.activiti.engine.impl.context.Context;
/*     */ import org.activiti.engine.impl.delegate.ExecutionListenerInvocation;
/*     */ import org.activiti.engine.impl.delegate.TaskListenerInvocation;
/*     */ import org.activiti.engine.impl.interceptor.DelegateInterceptor;
/*     */ import org.activiti.engine.impl.pvm.delegate.ActivityBehavior;
/*     */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*     */ import org.activiti.engine.impl.pvm.delegate.SignallableActivityBehavior;
/*     */ import org.activiti.engine.impl.util.ReflectUtil;
/*     */ 
/*     */ public class ClassDelegate extends AbstractBpmnActivityBehavior
/*     */   implements TaskListener, ExecutionListener
/*     */ {
/*     */   protected String className;
/*     */   protected List<FieldDeclaration> fieldDeclarations;
/*     */   protected ExecutionListener executionListenerInstance;
/*     */   protected TaskListener taskListenerInstance;
/*     */   protected ActivityBehavior activityBehaviorInstance;
/*     */ 
/*     */   public ClassDelegate(String className, List<FieldDeclaration> fieldDeclarations)
/*     */   {
/*  58 */     this.className = className;
/*  59 */     this.fieldDeclarations = fieldDeclarations;
/*     */   }
/*     */ 
/*     */   public ClassDelegate(Class<?> clazz, List<FieldDeclaration> fieldDeclarations) {
/*  63 */     this(clazz.getName(), fieldDeclarations);
/*     */   }
/*     */ 
/*     */   public void notify(DelegateExecution execution) throws Exception
/*     */   {
/*  68 */     if (this.executionListenerInstance == null) {
/*  69 */       this.executionListenerInstance = getExecutionListenerInstance();
/*     */     }
/*  71 */     Context.getProcessEngineConfiguration().getDelegateInterceptor().handleInvocation(new ExecutionListenerInvocation(this.executionListenerInstance, execution));
/*     */   }
/*     */ 
/*     */   protected ExecutionListener getExecutionListenerInstance()
/*     */   {
/*  77 */     Object delegateInstance = instantiateDelegate(this.className, this.fieldDeclarations);
/*  78 */     if ((delegateInstance instanceof ExecutionListener))
/*  79 */       return (ExecutionListener)delegateInstance;
/*  80 */     if ((delegateInstance instanceof JavaDelegate)) {
/*  81 */       return new ServiceTaskJavaDelegateActivityBehavior((JavaDelegate)delegateInstance);
/*     */     }
/*  83 */     throw new ActivitiIllegalArgumentException(delegateInstance.getClass().getName() + " doesn't implement " + ExecutionListener.class + " nor " + JavaDelegate.class);
/*     */   }
/*     */ 
/*     */   public void notify(DelegateTask delegateTask)
/*     */   {
/*  89 */     if (this.taskListenerInstance == null)
/*  90 */       this.taskListenerInstance = getTaskListenerInstance();
/*     */     try
/*     */     {
/*  93 */       Context.getProcessEngineConfiguration().getDelegateInterceptor().handleInvocation(new TaskListenerInvocation(this.taskListenerInstance, delegateTask));
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  97 */       throw new ActivitiException("Exception while invoking TaskListener: " + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected TaskListener getTaskListenerInstance() {
/* 102 */     Object delegateInstance = instantiateDelegate(this.className, this.fieldDeclarations);
/* 103 */     if ((delegateInstance instanceof ExecutionListener)) {
/* 104 */       return (ExecutionListener)delegateInstance;
/*     */     }
/* 106 */     throw new ActivitiIllegalArgumentException(delegateInstance.getClass().getName() + " doesn't implement " + ExecutionListener.class);
/*     */   }
/*     */ 
/*     */   public void execute(ActivityExecution execution)
/*     */     throws Exception
/*     */   {
/* 112 */     if (this.activityBehaviorInstance == null)
/* 113 */       this.activityBehaviorInstance = getActivityBehaviorInstance(execution);
/*     */     try
/*     */     {
/* 116 */       this.activityBehaviorInstance.execute(execution);
/*     */     } catch (BpmnError error) {
/* 118 */       ErrorPropagation.propagateError(error, execution);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void signal(ActivityExecution execution, String signalName, Object signalData) throws Exception
/*     */   {
/* 124 */     if (this.activityBehaviorInstance == null) {
/* 125 */       this.activityBehaviorInstance = getActivityBehaviorInstance(execution);
/*     */     }
/*     */ 
/* 128 */     if ((this.activityBehaviorInstance instanceof SignallableActivityBehavior))
/* 129 */       ((SignallableActivityBehavior)this.activityBehaviorInstance).signal(execution, signalName, signalData);
/*     */     else
/* 131 */       throw new ActivitiException("signal() can only be called on a " + SignallableActivityBehavior.class.getName() + " instance");
/*     */   }
/*     */ 
/*     */   protected ActivityBehavior getActivityBehaviorInstance(ActivityExecution execution)
/*     */   {
/* 136 */     Object delegateInstance = instantiateDelegate(this.className, this.fieldDeclarations);
/*     */ 
/* 138 */     if ((delegateInstance instanceof ActivityBehavior))
/* 139 */       return determineBehaviour((ActivityBehavior)delegateInstance, execution);
/* 140 */     if ((delegateInstance instanceof JavaDelegate)) {
/* 141 */       return determineBehaviour(new ServiceTaskJavaDelegateActivityBehavior((JavaDelegate)delegateInstance), execution);
/*     */     }
/* 143 */     throw new ActivitiIllegalArgumentException(delegateInstance.getClass().getName() + " doesn't implement " + JavaDelegate.class.getName() + " nor " + ActivityBehavior.class.getName());
/*     */   }
/*     */ 
/*     */   protected ActivityBehavior determineBehaviour(ActivityBehavior delegateInstance, ActivityExecution execution)
/*     */   {
/* 149 */     if (hasMultiInstanceCharacteristics()) {
/* 150 */       this.multiInstanceActivityBehavior.setInnerActivityBehavior((AbstractBpmnActivityBehavior)delegateInstance);
/* 151 */       return this.multiInstanceActivityBehavior;
/*     */     }
/* 153 */     return delegateInstance;
/*     */   }
/*     */ 
/*     */   public static Object instantiateDelegate(Class<?> clazz, List<FieldDeclaration> fieldDeclarations)
/*     */   {
/* 159 */     return instantiateDelegate(clazz.getName(), fieldDeclarations);
/*     */   }
/*     */ 
/*     */   public static Object instantiateDelegate(String className, List<FieldDeclaration> fieldDeclarations) {
/* 163 */     Object object = ReflectUtil.instantiate(className);
/* 164 */     applyFieldDeclaration(fieldDeclarations, object);
/* 165 */     return object;
/*     */   }
/*     */ 
/*     */   public static void applyFieldDeclaration(List<FieldDeclaration> fieldDeclarations, Object target) {
/* 169 */     if (fieldDeclarations != null)
/* 170 */       for (FieldDeclaration declaration : fieldDeclarations)
/* 171 */         applyFieldDeclaration(declaration, target);
/*     */   }
/*     */ 
/*     */   public static void applyFieldDeclaration(FieldDeclaration declaration, Object target)
/*     */   {
/* 177 */     Method setterMethod = ReflectUtil.getSetter(declaration.getName(), target.getClass(), declaration.getValue().getClass());
/*     */ 
/* 180 */     if (setterMethod != null) {
/*     */       try {
/* 182 */         setterMethod.invoke(target, new Object[] { declaration.getValue() });
/*     */       } catch (IllegalArgumentException e) {
/* 184 */         throw new ActivitiException("Error while invoking '" + declaration.getName() + "' on class " + target.getClass().getName(), e);
/*     */       } catch (IllegalAccessException e) {
/* 186 */         throw new ActivitiException("Illegal acces when calling '" + declaration.getName() + "' on class " + target.getClass().getName(), e);
/*     */       } catch (InvocationTargetException e) {
/* 188 */         throw new ActivitiException("Exception while invoking '" + declaration.getName() + "' on class " + target.getClass().getName(), e);
/*     */       }
/*     */     } else {
/* 191 */       Field field = ReflectUtil.getField(declaration.getName(), target);
/* 192 */       if (field == null) {
/* 193 */         throw new ActivitiIllegalArgumentException("Field definition uses unexisting field '" + declaration.getName() + "' on class " + target.getClass().getName());
/*     */       }
/*     */ 
/* 196 */       if (!fieldTypeCompatible(declaration, field)) {
/* 197 */         throw new ActivitiIllegalArgumentException("Incompatible type set on field declaration '" + declaration.getName() + "' for class " + target.getClass().getName() + ". Declared value has type " + declaration.getValue().getClass().getName() + ", while expecting " + field.getType().getName());
/*     */       }
/*     */ 
/* 202 */       ReflectUtil.setField(field, target, declaration.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean fieldTypeCompatible(FieldDeclaration declaration, Field field) {
/* 207 */     if (declaration.getValue() != null) {
/* 208 */       return field.getType().isAssignableFrom(declaration.getValue().getClass());
/*     */     }
/*     */ 
/* 211 */     return true;
/*     */   }
/*     */ 
/*     */   public String getClassName()
/*     */   {
/* 220 */     return this.className;
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.helper.ClassDelegate
 * JD-Core Version:    0.6.0
 */