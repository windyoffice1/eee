/*    */ package org.activiti.engine.impl.bpmn.helper;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.List;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.impl.bpmn.parser.FieldDeclaration;
/*    */ import org.activiti.engine.impl.util.ReflectUtil;
/*    */ 
/*    */ public class ClassDelegateUtil
/*    */ {
/*    */   public static Object instantiateDelegate(Class<?> clazz, List<FieldDeclaration> fieldDeclarations)
/*    */   {
/* 31 */     return instantiateDelegate(clazz.getName(), fieldDeclarations);
/*    */   }
/*    */ 
/*    */   public static Object instantiateDelegate(String className, List<FieldDeclaration> fieldDeclarations) {
/* 35 */     Object object = ReflectUtil.instantiate(className);
/* 36 */     applyFieldDeclaration(fieldDeclarations, object);
/* 37 */     return object;
/*    */   }
/*    */ 
/*    */   public static void applyFieldDeclaration(List<FieldDeclaration> fieldDeclarations, Object target) {
/* 41 */     if (fieldDeclarations != null)
/* 42 */       for (FieldDeclaration declaration : fieldDeclarations)
/* 43 */         applyFieldDeclaration(declaration, target);
/*    */   }
/*    */ 
/*    */   public static void applyFieldDeclaration(FieldDeclaration declaration, Object target)
/*    */   {
/* 49 */     Method setterMethod = ReflectUtil.getSetter(declaration.getName(), target.getClass(), declaration.getValue().getClass());
/*    */ 
/* 52 */     if (setterMethod != null) {
/*    */       try {
/* 54 */         setterMethod.invoke(target, new Object[] { declaration.getValue() });
/*    */       } catch (IllegalArgumentException e) {
/* 56 */         throw new ActivitiException("Error while invoking '" + declaration.getName() + "' on class " + target.getClass().getName(), e);
/*    */       } catch (IllegalAccessException e) {
/* 58 */         throw new ActivitiException("Illegal acces when calling '" + declaration.getName() + "' on class " + target.getClass().getName(), e);
/*    */       } catch (InvocationTargetException e) {
/* 60 */         throw new ActivitiException("Exception while invoking '" + declaration.getName() + "' on class " + target.getClass().getName(), e);
/*    */       }
/*    */     } else {
/* 63 */       Field field = ReflectUtil.getField(declaration.getName(), target);
/* 64 */       if (field == null) {
/* 65 */         throw new ActivitiIllegalArgumentException("Field definition uses unexisting field '" + declaration.getName() + "' on class " + target.getClass().getName());
/*    */       }
/*    */ 
/* 68 */       if (!fieldTypeCompatible(declaration, field)) {
/* 69 */         throw new ActivitiIllegalArgumentException("Incompatible type set on field declaration '" + declaration.getName() + "' for class " + target.getClass().getName() + ". Declared value has type " + declaration.getValue().getClass().getName() + ", while expecting " + field.getType().getName());
/*    */       }
/*    */ 
/* 74 */       ReflectUtil.setField(field, target, declaration.getValue());
/*    */     }
/*    */   }
/*    */ 
/*    */   public static boolean fieldTypeCompatible(FieldDeclaration declaration, Field field) {
/* 79 */     if (declaration.getValue() != null) {
/* 80 */       return field.getType().isAssignableFrom(declaration.getValue().getClass());
/*    */     }
/*    */ 
/* 83 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.helper.ClassDelegateUtil
 * JD-Core Version:    0.6.0
 */