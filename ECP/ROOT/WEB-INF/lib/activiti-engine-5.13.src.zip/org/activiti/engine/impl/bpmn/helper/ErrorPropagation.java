/*     */ package org.activiti.engine.impl.bpmn.helper;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.activiti.engine.ActivitiException;
/*     */ import org.activiti.engine.delegate.BpmnError;
/*     */ import org.activiti.engine.impl.bpmn.behavior.EventSubProcessStartEventActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.parser.ErrorEventDefinition;
/*     */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*     */ import org.activiti.engine.impl.pvm.PvmActivity;
/*     */ import org.activiti.engine.impl.pvm.PvmProcessDefinition;
/*     */ import org.activiti.engine.impl.pvm.PvmScope;
/*     */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*     */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*     */ import org.activiti.engine.impl.pvm.process.ProcessDefinitionImpl;
/*     */ import org.activiti.engine.impl.pvm.process.ScopeImpl;
/*     */ import org.activiti.engine.impl.pvm.runtime.AtomicOperation;
/*     */ import org.activiti.engine.impl.pvm.runtime.InterpretableExecution;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class ErrorPropagation
/*     */ {
/*  49 */   private static final Logger LOG = LoggerFactory.getLogger(ErrorPropagation.class);
/*     */ 
/*     */   public static void propagateError(BpmnError error, ActivityExecution execution) throws Exception {
/*  52 */     propagateError(error.getErrorCode(), execution);
/*     */   }
/*     */ 
/*     */   public static void propagateError(String errorCode, ActivityExecution execution) throws Exception
/*     */   {
/*  57 */     String eventHandlerId = findLocalErrorEventHandler(execution, errorCode);
/*     */ 
/*  60 */     if (eventHandlerId != null) {
/*  61 */       executeCatch(eventHandlerId, execution);
/*     */     } else {
/*  63 */       ActivityExecution superExecution = getSuperExecution(execution);
/*  64 */       if (superExecution != null) {
/*  65 */         executeCatchInSuperProcess(errorCode, superExecution);
/*     */       } else {
/*  67 */         LOG.info("{} throws error event with errorCode '{}', but no catching boundary event was defined. Execution will simply be ended (none end event semantics).", execution.getActivity().getId(), errorCode);
/*     */ 
/*  69 */         execution.end();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static String findLocalErrorEventHandler(ActivityExecution execution, String errorCode) {
/*  75 */     PvmScope scope = execution.getActivity();
/*  76 */     while (scope != null)
/*     */     {
/*  79 */       List definitions = (List)scope.getProperty("errorEventDefinitions");
/*  80 */       if (definitions != null)
/*     */       {
/*  82 */         for (ErrorEventDefinition errorEventDefinition : definitions) {
/*  83 */           if (errorEventDefinition.catches(errorCode)) {
/*  84 */             return scope.findActivity(errorEventDefinition.getHandlerActivityId()).getId();
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*  90 */       if ((scope instanceof PvmActivity))
/*  91 */         scope = ((PvmActivity)scope).getParent();
/*     */       else {
/*  93 */         scope = null;
/*     */       }
/*     */     }
/*  96 */     return null;
/*     */   }
/*     */ 
/*     */   private static void executeCatchInSuperProcess(String errorCode, ActivityExecution superExecution) {
/* 100 */     String errorHandlerId = findLocalErrorEventHandler(superExecution, errorCode);
/* 101 */     if (errorHandlerId != null) {
/* 102 */       executeCatch(errorHandlerId, superExecution);
/*     */     } else {
/* 104 */       ActivityExecution superSuperExecution = getSuperExecution(superExecution);
/* 105 */       if (superSuperExecution != null)
/* 106 */         executeCatchInSuperProcess(errorCode, superSuperExecution);
/*     */       else
/* 108 */         throw new BpmnError(errorCode, "No catching boundary event found for error with errorCode '" + errorCode + "', neither in same process nor in parent process");
/*     */     }
/*     */   }
/*     */ 
/*     */   private static ActivityExecution getSuperExecution(ActivityExecution execution)
/*     */   {
/* 115 */     ExecutionEntity executionEntity = (ExecutionEntity)execution;
/* 116 */     ExecutionEntity superExecution = executionEntity.getProcessInstance().getSuperExecution();
/* 117 */     if ((superExecution != null) && (!superExecution.isScope())) {
/* 118 */       return superExecution.getParent();
/*     */     }
/* 120 */     return superExecution;
/*     */   }
/*     */ 
/*     */   private static void executeCatch(String errorHandlerId, ActivityExecution execution) {
/* 124 */     ProcessDefinitionImpl processDefinition = ((ExecutionEntity)execution).getProcessDefinition();
/* 125 */     ActivityImpl errorHandler = processDefinition.findActivity(errorHandlerId);
/* 126 */     if (errorHandler == null) {
/* 127 */       throw new ActivitiException(errorHandlerId + " not found in process definition");
/*     */     }
/*     */ 
/* 130 */     boolean matchingParentFound = false;
/* 131 */     ActivityExecution leavingExecution = execution;
/* 132 */     ActivityImpl currentActivity = (ActivityImpl)execution.getActivity();
/*     */ 
/* 134 */     ScopeImpl catchingScope = errorHandler.getParent();
/* 135 */     if ((catchingScope instanceof ActivityImpl)) {
/* 136 */       ActivityImpl catchingScopeActivity = (ActivityImpl)catchingScope;
/* 137 */       if (!catchingScopeActivity.isScope()) {
/* 138 */         catchingScope = catchingScopeActivity.getParent();
/*     */       }
/*     */     }
/*     */ 
/* 142 */     if ((catchingScope instanceof PvmProcessDefinition)) {
/* 143 */       executeEventHandler(errorHandler, ((ExecutionEntity)execution).getProcessInstance());
/*     */     }
/*     */     else {
/* 146 */       if (currentActivity.getId().equals(catchingScope.getId())) {
/* 147 */         matchingParentFound = true;
/*     */       } else {
/* 149 */         currentActivity = (ActivityImpl)currentActivity.getParent();
/*     */ 
/* 153 */         while ((!matchingParentFound) && (leavingExecution != null) && (currentActivity != null)) {
/* 154 */           if ((!leavingExecution.isConcurrent()) && (currentActivity.getId().equals(catchingScope.getId()))) {
/* 155 */             matchingParentFound = true; continue;
/* 156 */           }if (leavingExecution.isConcurrent()) {
/* 157 */             leavingExecution = leavingExecution.getParent(); continue;
/*     */           }
/* 159 */           currentActivity = currentActivity.getParentActivity();
/* 160 */           leavingExecution = leavingExecution.getParent();
/*     */         }
/*     */ 
/* 168 */         while ((leavingExecution != null) && (leavingExecution.getParent() != null) && (leavingExecution.getParent().getActivity() != null) && (leavingExecution.getParent().getActivity().getId().equals(catchingScope.getId()))) {
/* 169 */           leavingExecution = leavingExecution.getParent();
/*     */         }
/*     */       }
/*     */ 
/* 173 */       if ((matchingParentFound) && (leavingExecution != null))
/* 174 */         executeEventHandler(errorHandler, leavingExecution);
/*     */       else
/* 176 */         throw new ActivitiException("No matching parent execution for activity " + errorHandlerId + " found");
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void executeEventHandler(ActivityImpl borderEventActivity, ActivityExecution leavingExecution)
/*     */   {
/* 183 */     if ((borderEventActivity.getActivityBehavior() instanceof EventSubProcessStartEventActivityBehavior)) {
/* 184 */       InterpretableExecution execution = (InterpretableExecution)leavingExecution;
/* 185 */       execution.setActivity(borderEventActivity.getParentActivity());
/* 186 */       execution.performOperation(AtomicOperation.ACTIVITY_START);
/*     */     } else {
/* 188 */       leavingExecution.executeActivity(borderEventActivity);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.helper.ErrorPropagation
 * JD-Core Version:    0.6.0
 */