/*     */ package org.activiti.engine.impl.bpmn.helper;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.activiti.engine.impl.context.Context;
/*     */ import org.activiti.engine.impl.interceptor.CommandContext;
/*     */ import org.activiti.engine.impl.persistence.entity.CompensateEventSubscriptionEntity;
/*     */ import org.activiti.engine.impl.persistence.entity.EventSubscriptionEntity;
/*     */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*     */ import org.activiti.engine.impl.persistence.entity.ExecutionEntityManager;
/*     */ import org.activiti.engine.impl.pvm.PvmProcessDefinition;
/*     */ import org.activiti.engine.impl.pvm.PvmScope;
/*     */ import org.activiti.engine.impl.pvm.delegate.ActivityBehavior;
/*     */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*     */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*     */ import org.activiti.engine.impl.pvm.runtime.InterpretableExecution;
/*     */ 
/*     */ public class ScopeUtil
/*     */ {
/*     */   public static ActivityExecution findScopeExecution(ActivityExecution execution)
/*     */   {
/*  50 */     while (!execution.isScope()) {
/*  51 */       execution = execution.getParent();
/*     */     }
/*     */ 
/*  54 */     if (execution.isConcurrent()) {
/*  55 */       execution = execution.getParent();
/*     */     }
/*     */ 
/*  58 */     return execution;
/*     */   }
/*     */ 
/*     */   public static ExecutionEntity findScopeExecutionForScope(ExecutionEntity execution, PvmScope scopeActivity)
/*     */   {
/*  68 */     if ((scopeActivity instanceof PvmProcessDefinition)) {
/*  69 */       return execution.getProcessInstance();
/*     */     }
/*     */ 
/*  73 */     ActivityImpl currentActivity = execution.getActivity();
/*  74 */     ExecutionEntity candiadateExecution = null;
/*  75 */     ExecutionEntity originalExecution = execution;
/*     */ 
/*  77 */     while (execution != null) {
/*  78 */       currentActivity = execution.getActivity();
/*  79 */       if ((scopeActivity.getActivities().contains(currentActivity)) || (scopeActivity.equals(currentActivity)))
/*     */       {
/*  84 */         candiadateExecution = execution;
/*     */       } else if ((currentActivity != null) && (currentActivity.contains((ActivityImpl)scopeActivity)))
/*     */         {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*  91 */       execution = execution.getParent();
/*     */     }
/*     */ 
/*  95 */     if ((originalExecution == candiadateExecution) && (originalExecution.getActivity().isScope()) && (!originalExecution.getActivity().equals(scopeActivity)))
/*     */     {
/*  98 */       candiadateExecution = originalExecution.getParent();
/*     */     }
/*     */ 
/* 101 */     return candiadateExecution;
/*     */   }
/*     */ 
/*     */   public static ActivityImpl findInParentScopesByBehaviorType(ActivityImpl activity, Class<? extends ActivityBehavior> behaviorType)
/*     */   {
/* 106 */     while (activity != null) {
/* 107 */       for (ActivityImpl childActivity : activity.getActivities()) {
/* 108 */         if (behaviorType.isAssignableFrom(childActivity.getActivityBehavior().getClass())) {
/* 109 */           return childActivity;
/*     */         }
/*     */       }
/* 112 */       activity = activity.getParentActivity();
/*     */     }
/* 114 */     return null;
/*     */   }
/*     */ 
/*     */   public static void throwCompensationEvent(List<CompensateEventSubscriptionEntity> eventSubscriptions, ActivityExecution execution, boolean async)
/*     */   {
/* 123 */     for (EventSubscriptionEntity eventSubscription : eventSubscriptions) {
/* 124 */       ExecutionEntity compensatingExecution = null;
/*     */ 
/* 129 */       if (eventSubscription.getConfiguration() != null) {
/* 130 */         compensatingExecution = Context.getCommandContext().getExecutionEntityManager().findExecutionById(eventSubscription.getConfiguration());
/*     */ 
/* 134 */         compensatingExecution.setParent((InterpretableExecution)execution);
/* 135 */         compensatingExecution.setEventScope(false);
/*     */       } else {
/* 137 */         compensatingExecution = (ExecutionEntity)execution.createExecution();
/* 138 */         eventSubscription.setConfiguration(compensatingExecution.getId());
/*     */       }
/* 140 */       compensatingExecution.setConcurrent(true);
/*     */     }
/*     */ 
/* 144 */     Collections.sort(eventSubscriptions, new Comparator() {
/*     */       public int compare(EventSubscriptionEntity o1, EventSubscriptionEntity o2) {
/* 146 */         return o2.getCreated().compareTo(o1.getCreated());
/*     */       }
/*     */     });
/* 150 */     for (CompensateEventSubscriptionEntity compensateEventSubscriptionEntity : eventSubscriptions)
/* 151 */       compensateEventSubscriptionEntity.eventReceived(null, async);
/*     */   }
/*     */ 
/*     */   public static void createEventScopeExecution(ExecutionEntity execution)
/*     */   {
/* 166 */     ExecutionEntity eventScope = findScopeExecutionForScope(execution, execution.getActivity().getParent());
/*     */ 
/* 168 */     List eventSubscriptions = execution.getCompensateEventSubscriptions();
/*     */ 
/* 170 */     if (eventSubscriptions.size() > 0)
/*     */     {
/* 172 */       ExecutionEntity eventScopeExecution = eventScope.createExecution();
/* 173 */       eventScopeExecution.setActive(false);
/* 174 */       eventScopeExecution.setConcurrent(false);
/* 175 */       eventScopeExecution.setEventScope(true);
/* 176 */       eventScopeExecution.setActivity(execution.getActivity());
/*     */ 
/* 178 */       execution.setConcurrent(false);
/*     */ 
/* 182 */       Map variables = execution.getVariablesLocal();
/* 183 */       for (Map.Entry variable : variables.entrySet()) {
/* 184 */         eventScopeExecution.setVariableLocal((String)variable.getKey(), variable.getValue());
/*     */       }
/*     */ 
/* 188 */       for (CompensateEventSubscriptionEntity eventSubscriptionEntity : eventSubscriptions) {
/* 189 */         eventSubscriptionEntity = eventSubscriptionEntity.moveUnder(eventScopeExecution);
/*     */       }
/*     */ 
/* 192 */       CompensateEventSubscriptionEntity eventSubscription = CompensateEventSubscriptionEntity.createAndInsert(eventScope);
/* 193 */       eventSubscription.setActivity(execution.getActivity());
/* 194 */       eventSubscription.setConfiguration(eventScopeExecution.getId());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.helper.ScopeUtil
 * JD-Core Version:    0.6.0
 */