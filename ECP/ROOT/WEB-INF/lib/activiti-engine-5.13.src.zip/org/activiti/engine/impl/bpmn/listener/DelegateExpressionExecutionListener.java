/*    */ package org.activiti.engine.impl.bpmn.listener;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.delegate.DelegateExecution;
/*    */ import org.activiti.engine.delegate.ExecutionListener;
/*    */ import org.activiti.engine.delegate.Expression;
/*    */ import org.activiti.engine.delegate.JavaDelegate;
/*    */ import org.activiti.engine.impl.bpmn.helper.ClassDelegate;
/*    */ import org.activiti.engine.impl.bpmn.parser.FieldDeclaration;
/*    */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.delegate.ExecutionListenerInvocation;
/*    */ import org.activiti.engine.impl.delegate.JavaDelegateInvocation;
/*    */ import org.activiti.engine.impl.interceptor.DelegateInterceptor;
/*    */ 
/*    */ public class DelegateExpressionExecutionListener
/*    */   implements ExecutionListener
/*    */ {
/*    */   protected Expression expression;
/*    */   private final List<FieldDeclaration> fieldDeclarations;
/*    */ 
/*    */   public DelegateExpressionExecutionListener(Expression expression, List<FieldDeclaration> fieldDeclarations)
/*    */   {
/* 38 */     this.expression = expression;
/* 39 */     this.fieldDeclarations = fieldDeclarations;
/*    */   }
/*    */ 
/*    */   public void notify(DelegateExecution execution)
/*    */     throws Exception
/*    */   {
/* 45 */     Object delegate = this.expression.getValue(execution);
/* 46 */     ClassDelegate.applyFieldDeclaration(this.fieldDeclarations, delegate);
/*    */ 
/* 48 */     if ((delegate instanceof ExecutionListener)) {
/* 49 */       Context.getProcessEngineConfiguration().getDelegateInterceptor().handleInvocation(new ExecutionListenerInvocation((ExecutionListener)delegate, execution));
/*    */     }
/* 52 */     else if ((delegate instanceof JavaDelegate)) {
/* 53 */       Context.getProcessEngineConfiguration().getDelegateInterceptor().handleInvocation(new JavaDelegateInvocation((JavaDelegate)delegate, execution));
/*    */     }
/*    */     else
/*    */     {
/* 57 */       throw new ActivitiIllegalArgumentException("Delegate expression " + this.expression + " did not resolve to an implementation of " + ExecutionListener.class + " nor " + JavaDelegate.class);
/*    */     }
/*    */   }
/*    */ 
/*    */   public String getExpressionText()
/*    */   {
/* 68 */     return this.expression.getExpressionText();
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.listener.DelegateExpressionExecutionListener
 * JD-Core Version:    0.6.0
 */