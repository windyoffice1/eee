/*    */ package org.activiti.engine.impl.bpmn.listener;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.delegate.DelegateTask;
/*    */ import org.activiti.engine.delegate.Expression;
/*    */ import org.activiti.engine.delegate.TaskListener;
/*    */ import org.activiti.engine.impl.bpmn.helper.ClassDelegate;
/*    */ import org.activiti.engine.impl.bpmn.parser.FieldDeclaration;
/*    */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.delegate.TaskListenerInvocation;
/*    */ import org.activiti.engine.impl.interceptor.DelegateInterceptor;
/*    */ 
/*    */ public class DelegateExpressionTaskListener
/*    */   implements TaskListener
/*    */ {
/*    */   protected Expression expression;
/*    */   private final List<FieldDeclaration> fieldDeclarations;
/*    */ 
/*    */   public DelegateExpressionTaskListener(Expression expression, List<FieldDeclaration> fieldDeclarations)
/*    */   {
/* 37 */     this.expression = expression;
/* 38 */     this.fieldDeclarations = fieldDeclarations;
/*    */   }
/*    */ 
/*    */   public void notify(DelegateTask delegateTask)
/*    */   {
/* 44 */     Object delegate = this.expression.getValue(delegateTask.getExecution());
/* 45 */     ClassDelegate.applyFieldDeclaration(this.fieldDeclarations, delegate);
/*    */ 
/* 47 */     if ((delegate instanceof TaskListener))
/*    */       try {
/* 49 */         Context.getProcessEngineConfiguration().getDelegateInterceptor().handleInvocation(new TaskListenerInvocation((TaskListener)delegate, delegateTask));
/*    */       }
/*    */       catch (Exception e)
/*    */       {
/* 53 */         throw new ActivitiException("Exception while invoking TaskListener: " + e.getMessage(), e);
/*    */       }
/*    */     else
/* 56 */       throw new ActivitiIllegalArgumentException("Delegate expression " + this.expression + " did not resolve to an implementation of " + TaskListener.class);
/*    */   }
/*    */ 
/*    */   public String getExpressionText()
/*    */   {
/* 66 */     return this.expression.getExpressionText();
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.listener.DelegateExpressionTaskListener
 * JD-Core Version:    0.6.0
 */