/*    */ package org.activiti.engine.impl.bpmn.listener;
/*    */ 
/*    */ import org.activiti.engine.delegate.DelegateExecution;
/*    */ import org.activiti.engine.delegate.ExecutionListener;
/*    */ import org.activiti.engine.delegate.Expression;
/*    */ 
/*    */ public class ExpressionExecutionListener
/*    */   implements ExecutionListener
/*    */ {
/*    */   protected Expression expression;
/*    */ 
/*    */   public ExpressionExecutionListener(Expression expression)
/*    */   {
/* 30 */     this.expression = expression;
/*    */   }
/*    */ 
/*    */   public void notify(DelegateExecution execution) throws Exception
/*    */   {
/* 35 */     this.expression.getValue(execution);
/*    */   }
/*    */ 
/*    */   public String getExpressionText()
/*    */   {
/* 43 */     return this.expression.getExpressionText();
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.listener.ExpressionExecutionListener
 * JD-Core Version:    0.6.0
 */