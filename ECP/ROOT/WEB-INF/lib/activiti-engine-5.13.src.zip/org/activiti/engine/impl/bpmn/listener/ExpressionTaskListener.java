/*    */ package org.activiti.engine.impl.bpmn.listener;
/*    */ 
/*    */ import org.activiti.engine.delegate.DelegateTask;
/*    */ import org.activiti.engine.delegate.Expression;
/*    */ import org.activiti.engine.delegate.TaskListener;
/*    */ 
/*    */ public class ExpressionTaskListener
/*    */   implements TaskListener
/*    */ {
/*    */   protected Expression expression;
/*    */ 
/*    */   public ExpressionTaskListener(Expression expression)
/*    */   {
/* 29 */     this.expression = expression;
/*    */   }
/*    */ 
/*    */   public void notify(DelegateTask delegateTask) {
/* 33 */     this.expression.getValue(delegateTask);
/*    */   }
/*    */ 
/*    */   public String getExpressionText()
/*    */   {
/* 41 */     return this.expression.getExpressionText();
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.listener.ExpressionTaskListener
 * JD-Core Version:    0.6.0
 */