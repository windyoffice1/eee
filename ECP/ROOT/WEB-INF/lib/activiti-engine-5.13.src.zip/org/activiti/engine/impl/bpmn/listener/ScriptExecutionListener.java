/*    */ package org.activiti.engine.impl.bpmn.listener;
/*    */ 
/*    */ import org.activiti.engine.delegate.DelegateExecution;
/*    */ import org.activiti.engine.delegate.ExecutionListener;
/*    */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.el.Expression;
/*    */ import org.activiti.engine.impl.scripting.ScriptingEngines;
/*    */ 
/*    */ public class ScriptExecutionListener
/*    */   implements ExecutionListener
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private Expression script;
/* 28 */   private Expression language = null;
/*    */ 
/* 30 */   private Expression resultVariable = null;
/*    */ 
/*    */   public void notify(DelegateExecution execution)
/*    */     throws Exception
/*    */   {
/* 35 */     if (this.script == null) {
/* 36 */       throw new IllegalArgumentException("The field 'script' should be set on the ExecutionListener");
/*    */     }
/*    */ 
/* 39 */     if (this.language == null) {
/* 40 */       throw new IllegalArgumentException("The field 'language' should be set on the ExecutionListener");
/*    */     }
/*    */ 
/* 43 */     ScriptingEngines scriptingEngines = Context.getProcessEngineConfiguration().getScriptingEngines();
/*    */ 
/* 45 */     Object result = scriptingEngines.evaluate(this.script.getExpressionText(), this.language.getExpressionText(), execution);
/*    */ 
/* 47 */     if (this.resultVariable != null)
/* 48 */       execution.setVariable(this.resultVariable.getExpressionText(), result);
/*    */   }
/*    */ 
/*    */   public void setScript(Expression script)
/*    */   {
/* 53 */     this.script = script;
/*    */   }
/*    */ 
/*    */   public void setLanguage(Expression language) {
/* 57 */     this.language = language;
/*    */   }
/*    */ 
/*    */   public void setResultVariable(Expression resultVariable) {
/* 61 */     this.resultVariable = resultVariable;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.listener.ScriptExecutionListener
 * JD-Core Version:    0.6.0
 */