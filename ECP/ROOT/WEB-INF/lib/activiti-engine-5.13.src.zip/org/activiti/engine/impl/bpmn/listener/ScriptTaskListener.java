/*    */ package org.activiti.engine.impl.bpmn.listener;
/*    */ 
/*    */ import org.activiti.engine.delegate.DelegateTask;
/*    */ import org.activiti.engine.delegate.TaskListener;
/*    */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.el.Expression;
/*    */ import org.activiti.engine.impl.scripting.ScriptingEngines;
/*    */ 
/*    */ public class ScriptTaskListener
/*    */   implements TaskListener
/*    */ {
/*    */   private static final long serialVersionUID = -8915149072830499057L;
/*    */   protected Expression script;
/* 32 */   protected Expression language = null;
/*    */ 
/* 34 */   protected Expression resultVariable = null;
/*    */   protected boolean autoStoreVariables;
/*    */ 
/*    */   public void notify(DelegateTask delegateTask)
/*    */   {
/* 39 */     if (this.script == null) {
/* 40 */       throw new IllegalArgumentException("The field 'script' should be set on the TaskListener");
/*    */     }
/*    */ 
/* 43 */     if (this.language == null) {
/* 44 */       throw new IllegalArgumentException("The field 'language' should be set on the TaskListener");
/*    */     }
/*    */ 
/* 47 */     ScriptingEngines scriptingEngines = Context.getProcessEngineConfiguration().getScriptingEngines();
/*    */ 
/* 49 */     Object result = scriptingEngines.evaluate(this.script.getExpressionText(), this.language.getExpressionText(), delegateTask, this.autoStoreVariables);
/*    */ 
/* 51 */     if (this.resultVariable != null)
/* 52 */       delegateTask.setVariable(this.resultVariable.getExpressionText(), result);
/*    */   }
/*    */ 
/*    */   public void setScript(Expression script)
/*    */   {
/* 57 */     this.script = script;
/*    */   }
/*    */ 
/*    */   public void setLanguage(Expression language) {
/* 61 */     this.language = language;
/*    */   }
/*    */ 
/*    */   public void setResultVariable(Expression resultVariable) {
/* 65 */     this.resultVariable = resultVariable;
/*    */   }
/*    */ 
/*    */   public void setAutoStoreVariables(boolean autoStoreVariables) {
/* 69 */     this.autoStoreVariables = autoStoreVariables;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.listener.ScriptTaskListener
 * JD-Core Version:    0.6.0
 */