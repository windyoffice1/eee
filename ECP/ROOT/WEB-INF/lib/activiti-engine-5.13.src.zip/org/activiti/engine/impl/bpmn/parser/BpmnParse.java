/*     */ package org.activiti.engine.impl.bpmn.parser;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.activiti.bpmn.constants.BpmnXMLConstants;
/*     */ import org.activiti.bpmn.converter.BpmnXMLConverter;
/*     */ import org.activiti.bpmn.model.BoundaryEvent;
/*     */ import org.activiti.bpmn.model.BpmnModel;
/*     */ import org.activiti.bpmn.model.Event;
/*     */ import org.activiti.bpmn.model.ExclusiveGateway;
/*     */ import org.activiti.bpmn.model.FlowElement;
/*     */ import org.activiti.bpmn.model.FlowNode;
/*     */ import org.activiti.bpmn.model.GraphicInfo;
/*     */ import org.activiti.bpmn.model.Import;
/*     */ import org.activiti.bpmn.model.Interface;
/*     */ import org.activiti.bpmn.model.Message;
/*     */ import org.activiti.bpmn.model.Process;
/*     */ import org.activiti.bpmn.model.SequenceFlow;
/*     */ import org.activiti.bpmn.model.SubProcess;
/*     */ import org.activiti.bpmn.model.parse.Problem;
/*     */ import org.activiti.engine.ActivitiException;
/*     */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*     */ import org.activiti.engine.impl.Condition;
/*     */ import org.activiti.engine.impl.bpmn.data.ClassStructureDefinition;
/*     */ import org.activiti.engine.impl.bpmn.data.ItemKind;
/*     */ import org.activiti.engine.impl.bpmn.data.StructureDefinition;
/*     */ import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
/*     */ import org.activiti.engine.impl.bpmn.parser.factory.ListenerFactory;
/*     */ import org.activiti.engine.impl.bpmn.webservice.BpmnInterface;
/*     */ import org.activiti.engine.impl.bpmn.webservice.BpmnInterfaceImplementation;
/*     */ import org.activiti.engine.impl.bpmn.webservice.MessageDefinition;
/*     */ import org.activiti.engine.impl.bpmn.webservice.OperationImplementation;
/*     */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*     */ import org.activiti.engine.impl.context.Context;
/*     */ import org.activiti.engine.impl.el.ExpressionManager;
/*     */ import org.activiti.engine.impl.persistence.entity.DeploymentEntity;
/*     */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*     */ import org.activiti.engine.impl.pvm.PvmTransition;
/*     */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*     */ import org.activiti.engine.impl.pvm.process.HasDIBounds;
/*     */ import org.activiti.engine.impl.pvm.process.Lane;
/*     */ import org.activiti.engine.impl.pvm.process.ScopeImpl;
/*     */ import org.activiti.engine.impl.pvm.process.TransitionImpl;
/*     */ import org.activiti.engine.impl.util.ReflectUtil;
/*     */ import org.activiti.engine.impl.util.io.InputStreamSource;
/*     */ import org.activiti.engine.impl.util.io.ResourceStreamSource;
/*     */ import org.activiti.engine.impl.util.io.StreamSource;
/*     */ import org.activiti.engine.impl.util.io.StringStreamSource;
/*     */ import org.activiti.engine.impl.util.io.UrlStreamSource;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class BpmnParse
/*     */   implements BpmnXMLConstants
/*     */ {
/*  82 */   protected static final Logger LOGGER = LoggerFactory.getLogger(BpmnParse.class);
/*     */   public static final String PROPERTYNAME_INITIAL = "initial";
/*     */   public static final String PROPERTYNAME_INITIATOR_VARIABLE_NAME = "initiatorVariableName";
/*     */   public static final String PROPERTYNAME_CONDITION = "condition";
/*     */   public static final String PROPERTYNAME_CONDITION_TEXT = "conditionText";
/*     */   public static final String PROPERTYNAME_TIMER_DECLARATION = "timerDeclarations";
/*     */   public static final String PROPERTYNAME_ISEXPANDED = "isExpanded";
/*     */   public static final String PROPERTYNAME_START_TIMER = "timerStart";
/*     */   public static final String PROPERTYNAME_COMPENSATION_HANDLER_ID = "compensationHandler";
/*     */   public static final String PROPERTYNAME_IS_FOR_COMPENSATION = "isForCompensation";
/*     */   public static final String PROPERTYNAME_ERROR_EVENT_DEFINITIONS = "errorEventDefinitions";
/*     */   public static final String PROPERTYNAME_EVENT_SUBSCRIPTION_DECLARATION = "eventDefinitions";
/*     */   protected String name;
/*     */   protected StreamSource streamSource;
/*     */   protected BpmnModel bpmnModel;
/*     */   protected String targetNamespace;
/*     */   protected DeploymentEntity deployment;
/* 108 */   protected List<ProcessDefinitionEntity> processDefinitions = new ArrayList();
/*     */   protected Map<String, TransitionImpl> sequenceFlows;
/*     */   protected BpmnParseHandlers bpmnParserHandlers;
/*     */   protected ProcessDefinitionEntity currentProcessDefinition;
/*     */   protected FlowElement currentFlowElement;
/*     */   protected ActivityImpl currentActivity;
/* 121 */   protected LinkedList<SubProcess> currentSubprocessStack = new LinkedList();
/*     */ 
/* 123 */   protected LinkedList<ScopeImpl> currentScopeStack = new LinkedList();
/*     */ 
/* 133 */   protected Map<String, MessageDefinition> messages = new HashMap();
/* 134 */   protected Map<String, StructureDefinition> structures = new HashMap();
/* 135 */   protected Map<String, BpmnInterfaceImplementation> interfaceImplementations = new HashMap();
/* 136 */   protected Map<String, OperationImplementation> operationImplementations = new HashMap();
/* 137 */   protected Map<String, org.activiti.engine.impl.bpmn.data.ItemDefinition> itemDefinitions = new HashMap();
/* 138 */   protected Map<String, BpmnInterface> bpmnInterfaces = new HashMap();
/* 139 */   protected Map<String, org.activiti.engine.impl.bpmn.webservice.Operation> operations = new HashMap();
/* 140 */   protected Map<String, XMLImporter> importers = new HashMap();
/* 141 */   protected Map<String, String> prefixs = new HashMap();
/*     */   protected ExpressionManager expressionManager;
/*     */   protected ActivityBehaviorFactory activityBehaviorFactory;
/*     */   protected ListenerFactory listenerFactory;
/*     */ 
/*     */   public BpmnParse(BpmnParser parser)
/*     */   {
/* 152 */     this.expressionManager = parser.getExpressionManager();
/* 153 */     this.activityBehaviorFactory = parser.getActivityBehaviorFactory();
/* 154 */     this.listenerFactory = parser.getListenerFactory();
/* 155 */     this.bpmnParserHandlers = parser.getBpmnParserHandlers();
/* 156 */     initializeXSDItemDefinitions();
/*     */   }
/*     */ 
/*     */   protected void initializeXSDItemDefinitions() {
/* 160 */     this.itemDefinitions.put("http://www.w3.org/2001/XMLSchema:string", new org.activiti.engine.impl.bpmn.data.ItemDefinition("http://www.w3.org/2001/XMLSchema:string", new ClassStructureDefinition(String.class)));
/*     */   }
/*     */ 
/*     */   public BpmnParse deployment(DeploymentEntity deployment)
/*     */   {
/* 165 */     this.deployment = deployment;
/* 166 */     return this;
/*     */   }
/*     */ 
/*     */   public BpmnParse execute() {
/*     */     try {
/* 171 */       BpmnXMLConverter converter = new BpmnXMLConverter();
/*     */ 
/* 173 */       boolean enableSafeBpmnXml = false;
/* 174 */       String encoding = null;
/* 175 */       if (Context.getProcessEngineConfiguration() != null) {
/* 176 */         enableSafeBpmnXml = Context.getProcessEngineConfiguration().isEnableSafeBpmnXml();
/* 177 */         encoding = Context.getProcessEngineConfiguration().getXmlEncoding();
/*     */       }
/*     */ 
/* 180 */       if (encoding != null)
/* 181 */         this.bpmnModel = converter.convertToBpmnModel(this.streamSource, true, enableSafeBpmnXml, encoding);
/*     */       else {
/* 183 */         this.bpmnModel = converter.convertToBpmnModel(this.streamSource, true, enableSafeBpmnXml);
/*     */       }
/*     */ 
/* 186 */       createImports();
/* 187 */       createItemDefinitions();
/* 188 */       createMessages();
/* 189 */       createOperations();
/* 190 */       transformProcessDefinitions();
/*     */     } catch (Exception e) {
/* 192 */       if ((e instanceof ActivitiException)) {
/* 193 */         throw ((ActivitiException)e);
/*     */       }
/* 195 */       throw new ActivitiException("Error parsing XML", e);
/*     */     }
/*     */ 
/* 199 */     if (this.bpmnModel.getProblems().size() > 0) {
/* 200 */       StringBuilder problemBuilder = new StringBuilder();
/* 201 */       for (Problem error : this.bpmnModel.getProblems()) {
/* 202 */         problemBuilder.append(error.toString());
/* 203 */         problemBuilder.append("\n");
/*     */       }
/* 205 */       throw new ActivitiException(new StringBuilder().append("Errors while parsing:\n").append(problemBuilder.toString()).toString());
/*     */     }
/*     */ 
/* 208 */     return this;
/*     */   }
/*     */ 
/*     */   public BpmnParse name(String name) {
/* 212 */     this.name = name;
/* 213 */     return this;
/*     */   }
/*     */ 
/*     */   public BpmnParse sourceInputStream(InputStream inputStream) {
/* 217 */     if (this.name == null) {
/* 218 */       name("inputStream");
/*     */     }
/* 220 */     setStreamSource(new InputStreamSource(inputStream));
/* 221 */     return this;
/*     */   }
/*     */ 
/*     */   public BpmnParse sourceResource(String resource) {
/* 225 */     return sourceResource(resource, null);
/*     */   }
/*     */ 
/*     */   public BpmnParse sourceUrl(URL url) {
/* 229 */     if (this.name == null) {
/* 230 */       name(url.toString());
/*     */     }
/* 232 */     setStreamSource(new UrlStreamSource(url));
/* 233 */     return this;
/*     */   }
/*     */ 
/*     */   public BpmnParse sourceUrl(String url) {
/*     */     try {
/* 238 */       return sourceUrl(new URL(url)); } catch (MalformedURLException e) {
/*     */     }
/* 240 */     throw new ActivitiIllegalArgumentException(new StringBuilder().append("malformed url: ").append(url).toString(), e);
/*     */   }
/*     */ 
/*     */   public BpmnParse sourceResource(String resource, ClassLoader classLoader)
/*     */   {
/* 245 */     if (this.name == null) {
/* 246 */       name(resource);
/*     */     }
/* 248 */     setStreamSource(new ResourceStreamSource(resource, classLoader));
/* 249 */     return this;
/*     */   }
/*     */ 
/*     */   public BpmnParse sourceString(String string) {
/* 253 */     if (this.name == null) {
/* 254 */       name("string");
/*     */     }
/* 256 */     setStreamSource(new StringStreamSource(string));
/* 257 */     return this;
/*     */   }
/*     */ 
/*     */   protected void setStreamSource(StreamSource streamSource) {
/* 261 */     if (this.streamSource != null) {
/* 262 */       throw new ActivitiIllegalArgumentException(new StringBuilder().append("invalid: multiple sources ").append(this.streamSource).append(" and ").append(streamSource).toString());
/*     */     }
/* 264 */     this.streamSource = streamSource;
/*     */   }
/*     */ 
/*     */   protected void createImports() {
/* 268 */     for (Import theImport : this.bpmnModel.getImports()) {
/* 269 */       XMLImporter importer = getImporter(theImport);
/* 270 */       if (importer == null)
/* 271 */         this.bpmnModel.addProblem(new StringBuilder().append("Could not import item of type ").append(theImport.getImportType()).toString(), theImport);
/*     */       else
/* 273 */         importer.importFrom(theImport, this);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected XMLImporter getImporter(Import theImport)
/*     */   {
/* 279 */     if (this.importers.containsKey(theImport.getImportType())) {
/* 280 */       return (XMLImporter)this.importers.get(theImport.getImportType());
/*     */     }
/* 282 */     if (theImport.getImportType().equals("http://schemas.xmlsoap.org/wsdl/")) {
/*     */       try
/*     */       {
/* 285 */         Class wsdlImporterClass = Class.forName("org.activiti.engine.impl.webservice.CxfWSDLImporter", true, Thread.currentThread().getContextClassLoader());
/* 286 */         XMLImporter newInstance = (XMLImporter)wsdlImporterClass.newInstance();
/* 287 */         this.importers.put(theImport.getImportType(), newInstance);
/* 288 */         return newInstance;
/*     */       } catch (Exception e) {
/* 290 */         this.bpmnModel.addProblem(new StringBuilder().append("Could not find importer for type ").append(theImport.getImportType()).toString(), theImport);
/*     */       }
/*     */     }
/* 293 */     return null;
/*     */   }
/*     */ 
/*     */   public void createMessages()
/*     */   {
/* 298 */     for (Message messageElement : this.bpmnModel.getMessages()) {
/* 299 */       MessageDefinition messageDefinition = new MessageDefinition(messageElement.getId(), this.name);
/* 300 */       if (StringUtils.isNotEmpty(messageElement.getItemRef())) {
/* 301 */         if (!this.itemDefinitions.containsKey(messageElement.getItemRef())) {
/* 302 */           this.bpmnModel.addProblem(new StringBuilder().append(messageElement.getItemRef()).append(" does not exist").toString(), messageElement);
/*     */         } else {
/* 304 */           org.activiti.engine.impl.bpmn.data.ItemDefinition itemDefinition = (org.activiti.engine.impl.bpmn.data.ItemDefinition)this.itemDefinitions.get(messageElement.getItemRef());
/* 305 */           messageDefinition.setItemDefinition(itemDefinition);
/*     */         }
/*     */       }
/* 308 */       this.messages.put(messageDefinition.getId(), messageDefinition);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void createItemDefinitions()
/*     */   {
/* 314 */     for (org.activiti.bpmn.model.ItemDefinition itemDefinitionElement : this.bpmnModel.getItemDefinitions().values()) {
/* 315 */       StructureDefinition structure = null;
/*     */       try
/*     */       {
/* 319 */         Class classStructure = ReflectUtil.loadClass(itemDefinitionElement.getStructureRef());
/* 320 */         structure = new ClassStructureDefinition(classStructure);
/*     */       }
/*     */       catch (ActivitiException e) {
/* 323 */         structure = (StructureDefinition)this.structures.get(itemDefinitionElement.getStructureRef());
/*     */       }
/*     */ 
/* 326 */       org.activiti.engine.impl.bpmn.data.ItemDefinition itemDefinition = new org.activiti.engine.impl.bpmn.data.ItemDefinition(itemDefinitionElement.getId(), structure);
/* 327 */       if (StringUtils.isNotEmpty(itemDefinitionElement.getItemKind())) {
/* 328 */         itemDefinition.setItemKind(ItemKind.valueOf(itemDefinitionElement.getItemKind()));
/*     */       }
/* 330 */       this.itemDefinitions.put(itemDefinition.getId(), itemDefinition);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void createOperations() {
/* 335 */     for (Interface interfaceObject : this.bpmnModel.getInterfaces()) {
/* 336 */       bpmnInterface = new BpmnInterface(interfaceObject.getId(), interfaceObject.getName());
/* 337 */       bpmnInterface.setImplementation((BpmnInterfaceImplementation)this.interfaceImplementations.get(interfaceObject.getImplementationRef()));
/*     */ 
/* 339 */       for (org.activiti.bpmn.model.Operation operationObject : interfaceObject.getOperations())
/* 340 */         if (!this.messages.containsKey(operationObject.getInMessageRef())) {
/* 341 */           this.bpmnModel.addProblem(new StringBuilder().append(operationObject.getInMessageRef()).append(" does not exist").toString(), operationObject);
/*     */         } else {
/* 343 */           MessageDefinition inMessage = (MessageDefinition)this.messages.get(operationObject.getInMessageRef());
/* 344 */           org.activiti.engine.impl.bpmn.webservice.Operation operation = new org.activiti.engine.impl.bpmn.webservice.Operation(operationObject.getId(), operationObject.getName(), bpmnInterface, inMessage);
/* 345 */           operation.setImplementation((OperationImplementation)this.operationImplementations.get(operationObject.getImplementationRef()));
/*     */ 
/* 347 */           if ((StringUtils.isNotEmpty(operationObject.getOutMessageRef())) && 
/* 348 */             (this.messages.containsKey(operationObject.getOutMessageRef()))) {
/* 349 */             MessageDefinition outMessage = (MessageDefinition)this.messages.get(operationObject.getOutMessageRef());
/* 350 */             operation.setOutMessage(outMessage);
/*     */           }
/*     */ 
/* 354 */           this.operations.put(operation.getId(), operation);
/*     */         }
/*     */     }
/*     */     BpmnInterface bpmnInterface;
/*     */   }
/*     */ 
/*     */   protected void transformProcessDefinitions()
/*     */   {
/* 364 */     this.sequenceFlows = new HashMap();
/* 365 */     for (Process process : this.bpmnModel.getProcesses()) {
/* 366 */       this.bpmnParserHandlers.parseElement(this, process);
/*     */     }
/*     */ 
/* 369 */     if (this.processDefinitions.size() > 0)
/* 370 */       processDI();
/*     */   }
/*     */ 
/*     */   public void processFlowElements(Collection<FlowElement> flowElements)
/*     */   {
/* 381 */     List sequenceFlowToParse = new ArrayList();
/* 382 */     List boundaryEventsToParse = new ArrayList();
/*     */ 
/* 385 */     List defferedFlowElementsToParse = new ArrayList();
/*     */ 
/* 388 */     for (FlowElement flowElement : flowElements)
/*     */     {
/* 391 */       if ((flowElement instanceof SequenceFlow))
/* 392 */         sequenceFlowToParse.add((SequenceFlow)flowElement);
/* 393 */       else if ((flowElement instanceof BoundaryEvent))
/* 394 */         boundaryEventsToParse.add((BoundaryEvent)flowElement);
/* 395 */       else if ((flowElement instanceof Event))
/* 396 */         defferedFlowElementsToParse.add(flowElement);
/*     */       else {
/* 398 */         this.bpmnParserHandlers.parseElement(this, flowElement);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 404 */     for (FlowElement flowElement : defferedFlowElementsToParse) {
/* 405 */       this.bpmnParserHandlers.parseElement(this, flowElement);
/*     */     }
/*     */ 
/* 409 */     for (BoundaryEvent boundaryEvent : boundaryEventsToParse) {
/* 410 */       this.bpmnParserHandlers.parseElement(this, boundaryEvent);
/*     */     }
/*     */ 
/* 414 */     for (SequenceFlow sequenceFlow : sequenceFlowToParse) {
/* 415 */       this.bpmnParserHandlers.parseElement(this, sequenceFlow);
/*     */     }
/*     */ 
/* 419 */     for (FlowElement flowElement : flowElements)
/* 420 */       if ((flowElement instanceof ExclusiveGateway)) {
/* 421 */         ActivityImpl gatewayActivity = getCurrentScope().findActivity(flowElement.getId());
/* 422 */         validateExclusiveGateway(gatewayActivity, (ExclusiveGateway)flowElement);
/*     */       }
/*     */   }
/*     */ 
/*     */   public void validateExclusiveGateway(ActivityImpl activity, ExclusiveGateway exclusiveGateway)
/*     */   {
/* 428 */     if (activity.getOutgoingTransitions().size() == 0)
/*     */     {
/* 431 */       this.bpmnModel.addProblem(new StringBuilder().append("Exclusive Gateway '").append(activity.getId()).append("' has no outgoing sequence flows.").toString(), exclusiveGateway);
/* 432 */     } else if (activity.getOutgoingTransitions().size() == 1) {
/* 433 */       PvmTransition flow = (PvmTransition)activity.getOutgoingTransitions().get(0);
/* 434 */       Condition condition = (Condition)flow.getProperty("condition");
/* 435 */       if (condition != null)
/* 436 */         this.bpmnModel.addProblem(new StringBuilder().append("Exclusive Gateway '").append(activity.getId()).append("' has only one outgoing sequence flow ('").append(flow.getId()).append("'). This is not allowed to have a condition.").toString(), exclusiveGateway);
/*     */     }
/*     */     else
/*     */     {
/* 440 */       String defaultSequenceFlow = (String)activity.getProperty("default");
/* 441 */       boolean hasDefaultFlow = StringUtils.isNotEmpty(defaultSequenceFlow);
/*     */ 
/* 443 */       ArrayList flowsWithoutCondition = new ArrayList();
/* 444 */       for (PvmTransition flow : activity.getOutgoingTransitions()) {
/* 445 */         Condition condition = (Condition)flow.getProperty("condition");
/* 446 */         boolean isDefaultFlow = (flow.getId() != null) && (flow.getId().equals(defaultSequenceFlow));
/* 447 */         boolean hasConditon = condition != null;
/*     */ 
/* 449 */         if ((!hasConditon) && (!isDefaultFlow)) {
/* 450 */           flowsWithoutCondition.add(flow);
/*     */         }
/* 452 */         if ((hasConditon) && (isDefaultFlow)) {
/* 453 */           this.bpmnModel.addProblem(new StringBuilder().append("Exclusive Gateway '").append(activity.getId()).append("' has outgoing sequence flow '").append(flow.getId()).append("' which is the default flow but has a condition too.").toString(), exclusiveGateway);
/*     */         }
/*     */       }
/*     */ 
/* 457 */       if ((hasDefaultFlow) || (flowsWithoutCondition.size() > 1))
/*     */       {
/* 461 */         for (PvmTransition flow : flowsWithoutCondition) {
/* 462 */           this.bpmnModel.addProblem(new StringBuilder().append("Exclusive Gateway '").append(activity.getId()).append("' has outgoing sequence flow '").append(flow.getId()).append("' without condition which is not the default flow.").toString(), exclusiveGateway);
/*     */         }
/*     */       }
/* 465 */       else if (flowsWithoutCondition.size() == 1)
/*     */       {
/* 468 */         PvmTransition flow = (PvmTransition)flowsWithoutCondition.get(0);
/* 469 */         this.bpmnModel.addWarning(new StringBuilder().append("Exclusive Gateway '").append(activity.getId()).append("' has outgoing sequence flow '").append(flow.getId()).append("' without condition which is not the default flow. We assume it to be the default flow, but it is bad modeling practice, better set the default flow in your gateway.").toString(), exclusiveGateway);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void processDI()
/*     */   {
/* 485 */     if (this.bpmnModel.getLocationMap().size() > 0)
/*     */     {
/* 488 */       for (String bpmnReference : this.bpmnModel.getLocationMap().keySet()) {
/* 489 */         if (this.bpmnModel.getFlowElement(bpmnReference) == null)
/* 490 */           LOGGER.warn(new StringBuilder().append("Invalid reference in diagram interchange definition: could not find ").append(bpmnReference).toString());
/* 491 */         else if (!(this.bpmnModel.getFlowElement(bpmnReference) instanceof FlowNode)) {
/* 492 */           LOGGER.warn(new StringBuilder().append("Invalid reference in diagram interchange definition: ").append(bpmnReference).append(" does not reference a flow node").toString());
/*     */         }
/*     */       }
/* 495 */       for (String bpmnReference : this.bpmnModel.getFlowLocationMap().keySet()) {
/* 496 */         if (this.bpmnModel.getFlowElement(bpmnReference) == null)
/* 497 */           LOGGER.warn(new StringBuilder().append("Invalid reference in diagram interchange definition: could not find ").append(bpmnReference).toString());
/* 498 */         else if (!(this.bpmnModel.getFlowElement(bpmnReference) instanceof SequenceFlow)) {
/* 499 */           if (((List)this.bpmnModel.getFlowLocationMap().get(bpmnReference)).size() > 0)
/* 500 */             LOGGER.warn(new StringBuilder().append("Invalid reference in diagram interchange definition: ").append(bpmnReference).append(" does not reference a sequence flow").toString());
/*     */           else {
/* 502 */             LOGGER.warn(new StringBuilder().append("Invalid reference in diagram interchange definition: ").append(bpmnReference).append(" does not reference a sequence flow").toString());
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 507 */       for (Process process : this.bpmnModel.getProcesses()) {
/* 508 */         if (!process.isExecutable())
/*     */         {
/*     */           continue;
/*     */         }
/*     */ 
/* 513 */         ProcessDefinitionEntity processDefinition = getProcessDefinition(process.getId());
/* 514 */         if (processDefinition != null) {
/* 515 */           processDefinition.setGraphicalNotationDefined(true);
/* 516 */           for (String shapeId : this.bpmnModel.getLocationMap().keySet()) {
/* 517 */             if (processDefinition.findActivity(shapeId) != null) {
/* 518 */               createBPMNShape(shapeId, this.bpmnModel.getGraphicInfo(shapeId), processDefinition);
/*     */             }
/*     */           }
/*     */ 
/* 522 */           for (String edgeId : this.bpmnModel.getFlowLocationMap().keySet())
/* 523 */             if (this.bpmnModel.getFlowElement(edgeId) != null)
/* 524 */               createBPMNEdge(edgeId, this.bpmnModel.getFlowLocationGraphicInfo(edgeId));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void createBPMNShape(String key, GraphicInfo graphicInfo, ProcessDefinitionEntity processDefinition)
/*     */   {
/* 533 */     ActivityImpl activity = processDefinition.findActivity(key);
/* 534 */     if (activity != null) {
/* 535 */       createDIBounds(graphicInfo, activity);
/*     */     }
/*     */     else {
/* 538 */       Lane lane = processDefinition.getLaneForId(key);
/*     */ 
/* 540 */       if (lane != null)
/*     */       {
/* 542 */         createDIBounds(graphicInfo, lane);
/*     */       }
/* 544 */       else this.bpmnModel.addProblem(new StringBuilder().append("Invalid reference in 'bpmnElement' attribute, activity ").append(key).append(" not found").toString(), graphicInfo);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void createDIBounds(GraphicInfo graphicInfo, HasDIBounds target)
/*     */   {
/* 550 */     target.setX((int)graphicInfo.getX());
/* 551 */     target.setY((int)graphicInfo.getY());
/* 552 */     target.setWidth((int)graphicInfo.getWidth());
/* 553 */     target.setHeight((int)graphicInfo.getHeight());
/*     */   }
/*     */ 
/*     */   public void createBPMNEdge(String key, List<GraphicInfo> graphicList) {
/* 557 */     FlowElement flowElement = this.bpmnModel.getFlowElement(key);
/* 558 */     if ((flowElement != null) && (this.sequenceFlows.containsKey(key))) {
/* 559 */       TransitionImpl sequenceFlow = (TransitionImpl)this.sequenceFlows.get(key);
/* 560 */       List waypoints = new ArrayList();
/* 561 */       for (GraphicInfo waypointInfo : graphicList) {
/* 562 */         waypoints.add(Integer.valueOf((int)waypointInfo.getX()));
/* 563 */         waypoints.add(Integer.valueOf((int)waypointInfo.getY()));
/*     */       }
/* 565 */       sequenceFlow.setWaypoints(waypoints);
/* 566 */     } else if (this.bpmnModel.getArtifact(key) == null)
/*     */     {
/* 569 */       GraphicInfo graphicInfo = null;
/* 570 */       if ((graphicList != null) && (graphicList.size() > 0))
/* 571 */         graphicInfo = (GraphicInfo)graphicList.get(0);
/*     */       else {
/* 573 */         graphicInfo = new GraphicInfo();
/*     */       }
/* 575 */       this.bpmnModel.addProblem(new StringBuilder().append("Invalid reference in 'bpmnElement' attribute, sequenceFlow ").append(key).append(" not found").toString(), graphicInfo);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ProcessDefinitionEntity getProcessDefinition(String processDefinitionKey) {
/* 580 */     for (ProcessDefinitionEntity processDefinition : this.processDefinitions) {
/* 581 */       if (processDefinition.getKey().equals(processDefinitionKey)) {
/* 582 */         return processDefinition;
/*     */       }
/*     */     }
/* 585 */     return null;
/*     */   }
/*     */ 
/*     */   public void addStructure(StructureDefinition structure) {
/* 589 */     this.structures.put(structure.getId(), structure);
/*     */   }
/*     */ 
/*     */   public void addService(BpmnInterfaceImplementation bpmnInterfaceImplementation) {
/* 593 */     this.interfaceImplementations.put(bpmnInterfaceImplementation.getName(), bpmnInterfaceImplementation);
/*     */   }
/*     */ 
/*     */   public void addOperation(OperationImplementation operationImplementation) {
/* 597 */     this.operationImplementations.put(operationImplementation.getId(), operationImplementation);
/*     */   }
/*     */ 
/*     */   public List<ProcessDefinitionEntity> getProcessDefinitions()
/*     */   {
/* 605 */     return this.processDefinitions;
/*     */   }
/*     */ 
/*     */   public String getTargetNamespace() {
/* 609 */     return this.targetNamespace;
/*     */   }
/*     */ 
/*     */   public BpmnParseHandlers getBpmnParserHandlers() {
/* 613 */     return this.bpmnParserHandlers;
/*     */   }
/*     */ 
/*     */   public void setBpmnParserHandlers(BpmnParseHandlers bpmnParserHandlers) {
/* 617 */     this.bpmnParserHandlers = bpmnParserHandlers;
/*     */   }
/*     */ 
/*     */   public DeploymentEntity getDeployment() {
/* 621 */     return this.deployment;
/*     */   }
/*     */ 
/*     */   public void setDeployment(DeploymentEntity deployment) {
/* 625 */     this.deployment = deployment;
/*     */   }
/*     */ 
/*     */   public BpmnModel getBpmnModel() {
/* 629 */     return this.bpmnModel;
/*     */   }
/*     */ 
/*     */   public void setBpmnModel(BpmnModel bpmnModel) {
/* 633 */     this.bpmnModel = bpmnModel;
/*     */   }
/*     */ 
/*     */   public ActivityBehaviorFactory getActivityBehaviorFactory() {
/* 637 */     return this.activityBehaviorFactory;
/*     */   }
/*     */ 
/*     */   public void setActivityBehaviorFactory(ActivityBehaviorFactory activityBehaviorFactory) {
/* 641 */     this.activityBehaviorFactory = activityBehaviorFactory;
/*     */   }
/*     */ 
/*     */   public ListenerFactory getListenerFactory() {
/* 645 */     return this.listenerFactory;
/*     */   }
/*     */ 
/*     */   public void setListenerFactory(ListenerFactory listenerFactory) {
/* 649 */     this.listenerFactory = listenerFactory;
/*     */   }
/*     */ 
/*     */   public ExpressionManager getExpressionManager() {
/* 653 */     return this.expressionManager;
/*     */   }
/*     */ 
/*     */   public void setExpressionManager(ExpressionManager expressionManager) {
/* 657 */     this.expressionManager = expressionManager;
/*     */   }
/*     */ 
/*     */   public Map<String, TransitionImpl> getSequenceFlows() {
/* 661 */     return this.sequenceFlows;
/*     */   }
/*     */ 
/*     */   public Map<String, MessageDefinition> getMessages() {
/* 665 */     return this.messages;
/*     */   }
/*     */ 
/*     */   public Map<String, BpmnInterfaceImplementation> getInterfaceImplementations() {
/* 669 */     return this.interfaceImplementations;
/*     */   }
/*     */ 
/*     */   public Map<String, org.activiti.engine.impl.bpmn.data.ItemDefinition> getItemDefinitions() {
/* 673 */     return this.itemDefinitions;
/*     */   }
/*     */ 
/*     */   public Map<String, XMLImporter> getImporters() {
/* 677 */     return this.importers;
/*     */   }
/*     */ 
/*     */   public Map<String, org.activiti.engine.impl.bpmn.webservice.Operation> getOperations() {
/* 681 */     return this.operations;
/*     */   }
/*     */ 
/*     */   public void setOperations(Map<String, org.activiti.engine.impl.bpmn.webservice.Operation> operations) {
/* 685 */     this.operations = operations;
/*     */   }
/*     */ 
/*     */   public ProcessDefinitionEntity getCurrentProcessDefinition() {
/* 689 */     return this.currentProcessDefinition;
/*     */   }
/*     */ 
/*     */   public void setCurrentProcessDefinition(ProcessDefinitionEntity currentProcessDefinition) {
/* 693 */     this.currentProcessDefinition = currentProcessDefinition;
/*     */   }
/*     */ 
/*     */   public FlowElement getCurrentFlowElement() {
/* 697 */     return this.currentFlowElement;
/*     */   }
/*     */ 
/*     */   public void setCurrentFlowElement(FlowElement currentFlowElement) {
/* 701 */     this.currentFlowElement = currentFlowElement;
/*     */   }
/*     */ 
/*     */   public ActivityImpl getCurrentActivity() {
/* 705 */     return this.currentActivity;
/*     */   }
/*     */ 
/*     */   public void setCurrentActivity(ActivityImpl currentActivity) {
/* 709 */     this.currentActivity = currentActivity;
/*     */   }
/*     */ 
/*     */   public void setCurrentSubProcess(SubProcess subProcess) {
/* 713 */     this.currentSubprocessStack.push(subProcess);
/*     */   }
/*     */ 
/*     */   public SubProcess getCurrentSubProcess() {
/* 717 */     return (SubProcess)this.currentSubprocessStack.peek();
/*     */   }
/*     */ 
/*     */   public void removeCurrentSubProcess() {
/* 721 */     this.currentSubprocessStack.pop();
/*     */   }
/*     */ 
/*     */   public void setCurrentScope(ScopeImpl scope) {
/* 725 */     this.currentScopeStack.push(scope);
/*     */   }
/*     */ 
/*     */   public ScopeImpl getCurrentScope() {
/* 729 */     return (ScopeImpl)this.currentScopeStack.peek();
/*     */   }
/*     */ 
/*     */   public void removeCurrentScope() {
/* 733 */     this.currentScopeStack.pop();
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.BpmnParse
 * JD-Core Version:    0.6.0
 */