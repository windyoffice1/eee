/*    */ package org.activiti.engine.impl.bpmn.parser;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.activiti.bpmn.model.BaseElement;
/*    */ import org.activiti.bpmn.model.FlowElement;
/*    */ import org.activiti.engine.parse.BpmnParseHandler;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class BpmnParseHandlers
/*    */ {
/* 31 */   private static final Logger LOGGER = LoggerFactory.getLogger(BpmnParseHandlers.class);
/*    */   protected Map<Class<? extends BaseElement>, List<BpmnParseHandler>> parseHandlers;
/*    */ 
/*    */   public BpmnParseHandlers()
/*    */   {
/* 36 */     this.parseHandlers = new HashMap();
/*    */   }
/*    */ 
/*    */   public List<BpmnParseHandler> getHandlersFor(Class<? extends BaseElement> clazz) {
/* 40 */     return (List)this.parseHandlers.get(clazz);
/*    */   }
/*    */ 
/*    */   public void addHandlers(List<BpmnParseHandler> bpmnParseHandlers) {
/* 44 */     for (BpmnParseHandler bpmnParseHandler : bpmnParseHandlers)
/* 45 */       addHandler(bpmnParseHandler);
/*    */   }
/*    */ 
/*    */   public void addHandler(BpmnParseHandler bpmnParseHandler)
/*    */   {
/* 50 */     for (Class type : bpmnParseHandler.getHandledTypes()) {
/* 51 */       List handlers = (List)this.parseHandlers.get(type);
/* 52 */       if (handlers == null) {
/* 53 */         handlers = new ArrayList();
/* 54 */         this.parseHandlers.put(type, handlers);
/*    */       }
/* 56 */       handlers.add(bpmnParseHandler);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void parseElement(BpmnParse bpmnParse, BaseElement element)
/*    */   {
/* 62 */     if ((element instanceof FlowElement)) {
/* 63 */       bpmnParse.setCurrentFlowElement((FlowElement)element);
/*    */     }
/*    */ 
/* 67 */     List handlers = (List)this.parseHandlers.get(element.getClass());
/*    */ 
/* 69 */     if (handlers == null)
/* 70 */       LOGGER.warn("Could not find matching parse handler for + " + element.getId() + " this is likely a bug.");
/*    */     else
/* 72 */       for (BpmnParseHandler handler : handlers)
/* 73 */         handler.parse(bpmnParse, element);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.BpmnParseHandlers
 * JD-Core Version:    0.6.0
 */