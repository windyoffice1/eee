/*    */ package org.activiti.engine.impl.bpmn.parser;
/*    */ 
/*    */ import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
/*    */ import org.activiti.engine.impl.bpmn.parser.factory.ListenerFactory;
/*    */ import org.activiti.engine.impl.cfg.BpmnParseFactory;
/*    */ import org.activiti.engine.impl.el.ExpressionManager;
/*    */ 
/*    */ public class BpmnParser
/*    */ {
/*    */   public static final String BPMN_DI_NS = "http://www.omg.org/spec/BPMN/20100524/DI";
/*    */   public static final String BPMN_DC_NS = "http://www.omg.org/spec/DD/20100524/DC";
/*    */   public static final String OMG_DI_NS = "http://www.omg.org/spec/DD/20100524/DI";
/*    */   protected ExpressionManager expressionManager;
/*    */   protected ActivityBehaviorFactory activityBehaviorFactory;
/*    */   protected ListenerFactory listenerFactory;
/*    */   protected BpmnParseFactory bpmnParseFactory;
/*    */   protected BpmnParseHandlers bpmnParserHandlers;
/*    */ 
/*    */   public BpmnParse createParse()
/*    */   {
/* 59 */     return this.bpmnParseFactory.createBpmnParse(this);
/*    */   }
/*    */ 
/*    */   public ActivityBehaviorFactory getActivityBehaviorFactory() {
/* 63 */     return this.activityBehaviorFactory;
/*    */   }
/*    */ 
/*    */   public void setActivityBehaviorFactory(ActivityBehaviorFactory activityBehaviorFactory) {
/* 67 */     this.activityBehaviorFactory = activityBehaviorFactory;
/*    */   }
/*    */ 
/*    */   public ListenerFactory getListenerFactory() {
/* 71 */     return this.listenerFactory;
/*    */   }
/*    */ 
/*    */   public void setListenerFactory(ListenerFactory listenerFactory) {
/* 75 */     this.listenerFactory = listenerFactory;
/*    */   }
/*    */ 
/*    */   public BpmnParseFactory getBpmnParseFactory() {
/* 79 */     return this.bpmnParseFactory;
/*    */   }
/*    */ 
/*    */   public void setBpmnParseFactory(BpmnParseFactory bpmnParseFactory) {
/* 83 */     this.bpmnParseFactory = bpmnParseFactory;
/*    */   }
/*    */ 
/*    */   public ExpressionManager getExpressionManager() {
/* 87 */     return this.expressionManager;
/*    */   }
/*    */ 
/*    */   public void setExpressionManager(ExpressionManager expressionManager) {
/* 91 */     this.expressionManager = expressionManager;
/*    */   }
/*    */ 
/*    */   public BpmnParseHandlers getBpmnParserHandlers() {
/* 95 */     return this.bpmnParserHandlers;
/*    */   }
/*    */ 
/*    */   public void setBpmnParserHandlers(BpmnParseHandlers bpmnParserHandlers) {
/* 99 */     this.bpmnParserHandlers = bpmnParserHandlers;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.BpmnParser
 * JD-Core Version:    0.6.0
 */