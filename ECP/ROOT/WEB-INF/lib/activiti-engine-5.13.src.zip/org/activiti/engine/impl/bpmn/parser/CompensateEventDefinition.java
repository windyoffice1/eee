/*    */ package org.activiti.engine.impl.bpmn.parser;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class CompensateEventDefinition
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String activityRef;
/*    */   protected boolean waitForCompletion;
/*    */ 
/*    */   public String getActivityRef()
/*    */   {
/* 29 */     return this.activityRef;
/*    */   }
/*    */ 
/*    */   public void setActivityRef(String activityRef) {
/* 33 */     this.activityRef = activityRef;
/*    */   }
/*    */ 
/*    */   public boolean isWaitForCompletion() {
/* 37 */     return this.waitForCompletion;
/*    */   }
/*    */ 
/*    */   public void setWaitForCompletion(boolean waitForCompletion) {
/* 41 */     this.waitForCompletion = waitForCompletion;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.CompensateEventDefinition
 * JD-Core Version:    0.6.0
 */