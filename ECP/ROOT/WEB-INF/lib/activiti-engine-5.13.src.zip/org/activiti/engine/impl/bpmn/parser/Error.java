/*    */ package org.activiti.engine.impl.bpmn.parser;
/*    */ 
/*    */ public class Error
/*    */ {
/*    */   protected String id;
/*    */   protected String errorCode;
/*    */ 
/*    */   public String getId()
/*    */   {
/* 30 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(String id) {
/* 34 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public String getErrorCode() {
/* 38 */     return this.errorCode;
/*    */   }
/*    */ 
/*    */   public void setErrorCode(String errorCode) {
/* 42 */     this.errorCode = errorCode;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.Error
 * JD-Core Version:    0.6.0
 */