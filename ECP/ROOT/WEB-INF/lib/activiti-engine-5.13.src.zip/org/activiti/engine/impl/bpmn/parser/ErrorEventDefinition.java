/*    */ package org.activiti.engine.impl.bpmn.parser;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Comparator;
/*    */ 
/*    */ public class ErrorEventDefinition
/*    */   implements Serializable
/*    */ {
/* 24 */   public static Comparator<ErrorEventDefinition> comparator = new Comparator() {
/*    */     public int compare(ErrorEventDefinition o1, ErrorEventDefinition o2) {
/* 26 */       return o2.getPrecedence().compareTo(o1.getPrecedence());
/*    */     }
/* 24 */   };
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected final String handlerActivityId;
/*    */   protected String errorCode;
/* 34 */   protected Integer precedence = Integer.valueOf(0);
/*    */ 
/*    */   public ErrorEventDefinition(String handlerActivityId) {
/* 37 */     this.handlerActivityId = handlerActivityId;
/*    */   }
/*    */ 
/*    */   public String getErrorCode() {
/* 41 */     return this.errorCode;
/*    */   }
/*    */ 
/*    */   public void setErrorCode(String errorCode) {
/* 45 */     this.errorCode = errorCode;
/*    */   }
/*    */ 
/*    */   public String getHandlerActivityId() {
/* 49 */     return this.handlerActivityId;
/*    */   }
/*    */ 
/*    */   public Integer getPrecedence()
/*    */   {
/* 54 */     return Integer.valueOf(this.precedence.intValue() + (this.errorCode != null ? 1 : 0));
/*    */   }
/*    */ 
/*    */   public void setPrecedence(Integer precedence) {
/* 58 */     this.precedence = precedence;
/*    */   }
/*    */ 
/*    */   public boolean catches(String errorCode) {
/* 62 */     return (errorCode == null) || (this.errorCode == null) || (this.errorCode.equals(errorCode));
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.ErrorEventDefinition
 * JD-Core Version:    0.6.0
 */