/*     */ package org.activiti.engine.impl.bpmn.parser;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*     */ import org.activiti.engine.impl.persistence.entity.EventSubscriptionEntity;
/*     */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*     */ import org.activiti.engine.impl.persistence.entity.MessageEventSubscriptionEntity;
/*     */ import org.activiti.engine.impl.persistence.entity.SignalEventSubscriptionEntity;
/*     */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*     */ import org.activiti.engine.impl.pvm.process.ProcessDefinitionImpl;
/*     */ 
/*     */ public class EventSubscriptionDeclaration
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final String eventName;
/*     */   protected final String eventType;
/*     */   protected boolean async;
/*     */   protected String activityId;
/*     */   protected boolean isStartEvent;
/*     */   protected String configuration;
/*     */ 
/*     */   public EventSubscriptionDeclaration(String eventName, String eventType)
/*     */   {
/*  44 */     this.eventName = eventName;
/*  45 */     this.eventType = eventType;
/*     */   }
/*     */ 
/*     */   public String getEventName() {
/*  49 */     return this.eventName;
/*     */   }
/*     */ 
/*     */   public boolean isAsync() {
/*  53 */     return this.async;
/*     */   }
/*     */ 
/*     */   public void setAsync(boolean async) {
/*  57 */     this.async = async;
/*     */   }
/*     */ 
/*     */   public void setActivityId(String activityId) {
/*  61 */     this.activityId = activityId;
/*     */   }
/*     */ 
/*     */   public String getActivityId() {
/*  65 */     return this.activityId;
/*     */   }
/*     */ 
/*     */   public boolean isStartEvent() {
/*  69 */     return this.isStartEvent;
/*     */   }
/*     */ 
/*     */   public void setStartEvent(boolean isStartEvent) {
/*  73 */     this.isStartEvent = isStartEvent;
/*     */   }
/*     */ 
/*     */   public String getEventType() {
/*  77 */     return this.eventType;
/*     */   }
/*     */ 
/*     */   public String getConfiguration() {
/*  81 */     return this.configuration;
/*     */   }
/*     */ 
/*     */   public void setConfiguration(String configuration) {
/*  85 */     this.configuration = configuration;
/*     */   }
/*     */ 
/*     */   public EventSubscriptionEntity prepareEventSubscriptionEntity(ExecutionEntity execution) {
/*  89 */     EventSubscriptionEntity eventSubscriptionEntity = null;
/*  90 */     if (this.eventType.equals("message"))
/*  91 */       eventSubscriptionEntity = new MessageEventSubscriptionEntity(execution);
/*  92 */     else if (this.eventType.equals("signal"))
/*  93 */       eventSubscriptionEntity = new SignalEventSubscriptionEntity(execution);
/*     */     else {
/*  95 */       throw new ActivitiIllegalArgumentException("Found event definition of unknown type: " + this.eventType);
/*     */     }
/*     */ 
/*  98 */     eventSubscriptionEntity.setEventName(this.eventName);
/*  99 */     if (this.activityId != null) {
/* 100 */       ActivityImpl activity = execution.getProcessDefinition().findActivity(this.activityId);
/* 101 */       eventSubscriptionEntity.setActivity(activity);
/*     */     }
/*     */ 
/* 104 */     if (this.configuration != null) {
/* 105 */       eventSubscriptionEntity.setConfiguration(this.configuration);
/*     */     }
/*     */ 
/* 108 */     return eventSubscriptionEntity;
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.EventSubscriptionDeclaration
 * JD-Core Version:    0.6.0
 */