/*    */ package org.activiti.engine.impl.bpmn.parser;
/*    */ 
/*    */ public class FieldDeclaration
/*    */ {
/*    */   protected String name;
/*    */   protected String type;
/*    */   protected Object value;
/*    */ 
/*    */   public FieldDeclaration(String name, String type, Object value)
/*    */   {
/* 33 */     this.name = name;
/* 34 */     this.type = type;
/* 35 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public FieldDeclaration()
/*    */   {
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 43 */     return this.name;
/*    */   }
/*    */   public void setName(String name) {
/* 46 */     this.name = name;
/*    */   }
/*    */   public String getType() {
/* 49 */     return this.type;
/*    */   }
/*    */   public void setType(String type) {
/* 52 */     this.type = type;
/*    */   }
/*    */   public Object getValue() {
/* 55 */     return this.value;
/*    */   }
/*    */   public void setValue(Object value) {
/* 58 */     this.value = value;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.FieldDeclaration
 * JD-Core Version:    0.6.0
 */