/*    */ package org.activiti.engine.impl.bpmn.parser;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class SignalDefinition
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String id;
/*    */   private String name;
/*    */ 
/*    */   public String getId()
/*    */   {
/* 32 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(String id) {
/* 36 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 40 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 44 */     this.name = name;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.SignalDefinition
 * JD-Core Version:    0.6.0
 */