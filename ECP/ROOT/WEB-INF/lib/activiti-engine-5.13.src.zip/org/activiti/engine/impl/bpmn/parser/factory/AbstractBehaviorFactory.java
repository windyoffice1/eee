/*    */ package org.activiti.engine.impl.bpmn.parser.factory;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.activiti.bpmn.model.FieldExtension;
/*    */ import org.activiti.engine.delegate.Expression;
/*    */ import org.activiti.engine.impl.bpmn.parser.FieldDeclaration;
/*    */ import org.activiti.engine.impl.el.ExpressionManager;
/*    */ import org.activiti.engine.impl.el.FixedValue;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public abstract class AbstractBehaviorFactory
/*    */ {
/*    */   protected ExpressionManager expressionManager;
/*    */ 
/*    */   public List<FieldDeclaration> createFieldDeclarations(List<FieldExtension> fieldList)
/*    */   {
/* 33 */     List fieldDeclarations = new ArrayList();
/*    */ 
/* 35 */     for (FieldExtension fieldExtension : fieldList) {
/* 36 */       FieldDeclaration fieldDeclaration = null;
/* 37 */       if (StringUtils.isNotEmpty(fieldExtension.getExpression())) {
/* 38 */         fieldDeclaration = new FieldDeclaration(fieldExtension.getFieldName(), Expression.class.getName(), this.expressionManager.createExpression(fieldExtension.getExpression()));
/*    */       }
/*    */       else {
/* 41 */         fieldDeclaration = new FieldDeclaration(fieldExtension.getFieldName(), Expression.class.getName(), new FixedValue(fieldExtension.getStringValue()));
/*    */       }
/*    */ 
/* 45 */       fieldDeclarations.add(fieldDeclaration);
/*    */     }
/* 47 */     return fieldDeclarations;
/*    */   }
/*    */ 
/*    */   public ExpressionManager getExpressionManager()
/*    */   {
/* 52 */     return this.expressionManager;
/*    */   }
/*    */ 
/*    */   public void setExpressionManager(ExpressionManager expressionManager) {
/* 56 */     this.expressionManager = expressionManager;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.factory.AbstractBehaviorFactory
 * JD-Core Version:    0.6.0
 */