/*     */ package org.activiti.engine.impl.bpmn.parser.factory;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.activiti.bpmn.model.BoundaryEvent;
/*     */ import org.activiti.bpmn.model.BpmnModel;
/*     */ import org.activiti.bpmn.model.BusinessRuleTask;
/*     */ import org.activiti.bpmn.model.CallActivity;
/*     */ import org.activiti.bpmn.model.CancelEventDefinition;
/*     */ import org.activiti.bpmn.model.EndEvent;
/*     */ import org.activiti.bpmn.model.ErrorEventDefinition;
/*     */ import org.activiti.bpmn.model.EventGateway;
/*     */ import org.activiti.bpmn.model.ExclusiveGateway;
/*     */ import org.activiti.bpmn.model.FieldExtension;
/*     */ import org.activiti.bpmn.model.IOParameter;
/*     */ import org.activiti.bpmn.model.InclusiveGateway;
/*     */ import org.activiti.bpmn.model.IntermediateCatchEvent;
/*     */ import org.activiti.bpmn.model.ManualTask;
/*     */ import org.activiti.bpmn.model.ParallelGateway;
/*     */ import org.activiti.bpmn.model.ReceiveTask;
/*     */ import org.activiti.bpmn.model.ScriptTask;
/*     */ import org.activiti.bpmn.model.SendTask;
/*     */ import org.activiti.bpmn.model.ServiceTask;
/*     */ import org.activiti.bpmn.model.Signal;
/*     */ import org.activiti.bpmn.model.StartEvent;
/*     */ import org.activiti.bpmn.model.SubProcess;
/*     */ import org.activiti.bpmn.model.Task;
/*     */ import org.activiti.bpmn.model.ThrowEvent;
/*     */ import org.activiti.bpmn.model.Transaction;
/*     */ import org.activiti.bpmn.model.UserTask;
/*     */ import org.activiti.engine.delegate.Expression;
/*     */ import org.activiti.engine.impl.bpmn.behavior.AbstractBpmnActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.BoundaryEventActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.BusinessRuleTaskActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.CallActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.CancelBoundaryEventActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.CancelEndEventActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.ErrorEndEventActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.EventBasedGatewayActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.EventSubProcessStartEventActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.ExclusiveGatewayActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.InclusiveGatewayActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.IntermediateCatchEventActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.IntermediateThrowCompensationEventActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.IntermediateThrowNoneEventActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.IntermediateThrowSignalEventActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.MailActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.ManualTaskActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.NoneEndEventActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.NoneStartEventActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.ParallelGatewayActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.ParallelMultiInstanceBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.ReceiveTaskActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.ScriptTaskActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.SequentialMultiInstanceBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.ServiceTaskDelegateExpressionActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.ServiceTaskExpressionActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.ShellActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.SubProcessActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.TaskActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.TerminateEndEventActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.TransactionActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.UserTaskActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.WebServiceActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.data.SimpleDataInputAssociation;
/*     */ import org.activiti.engine.impl.bpmn.helper.ClassDelegate;
/*     */ import org.activiti.engine.impl.bpmn.parser.CompensateEventDefinition;
/*     */ import org.activiti.engine.impl.bpmn.parser.EventSubscriptionDeclaration;
/*     */ import org.activiti.engine.impl.bpmn.webservice.MessageImplicitDataOutputAssociation;
/*     */ import org.activiti.engine.impl.el.ExpressionManager;
/*     */ import org.activiti.engine.impl.pvm.delegate.ActivityBehavior;
/*     */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*     */ import org.activiti.engine.impl.task.TaskDefinition;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class DefaultActivityBehaviorFactory extends AbstractBehaviorFactory
/*     */   implements ActivityBehaviorFactory
/*     */ {
/*     */   public NoneStartEventActivityBehavior createNoneStartEventActivityBehavior(StartEvent startEvent)
/*     */   {
/* 102 */     return new NoneStartEventActivityBehavior();
/*     */   }
/*     */ 
/*     */   public EventSubProcessStartEventActivityBehavior createEventSubProcessStartEventActivityBehavior(StartEvent startEvent, String activityId) {
/* 106 */     return new EventSubProcessStartEventActivityBehavior(activityId);
/*     */   }
/*     */ 
/*     */   public TaskActivityBehavior createTaskActivityBehavior(Task task)
/*     */   {
/* 112 */     return new TaskActivityBehavior();
/*     */   }
/*     */ 
/*     */   public ManualTaskActivityBehavior createManualTaskActivityBehavior(ManualTask manualTask) {
/* 116 */     return new ManualTaskActivityBehavior();
/*     */   }
/*     */ 
/*     */   public ReceiveTaskActivityBehavior createReceiveTaskActivityBehavior(ReceiveTask receiveTask) {
/* 120 */     return new ReceiveTaskActivityBehavior();
/*     */   }
/*     */ 
/*     */   public UserTaskActivityBehavior createUserTaskActivityBehavior(UserTask userTask, TaskDefinition taskDefinition) {
/* 124 */     return new UserTaskActivityBehavior(taskDefinition);
/*     */   }
/*     */ 
/*     */   public ClassDelegate createClassDelegateServiceTask(ServiceTask serviceTask)
/*     */   {
/* 130 */     return new ClassDelegate(serviceTask.getImplementation(), createFieldDeclarations(serviceTask.getFieldExtensions()));
/*     */   }
/*     */ 
/*     */   public ServiceTaskDelegateExpressionActivityBehavior createServiceTaskDelegateExpressionActivityBehavior(ServiceTask serviceTask) {
/* 134 */     Expression delegateExpression = this.expressionManager.createExpression(serviceTask.getImplementation());
/* 135 */     return new ServiceTaskDelegateExpressionActivityBehavior(delegateExpression, createFieldDeclarations(serviceTask.getFieldExtensions()));
/*     */   }
/*     */ 
/*     */   public ServiceTaskExpressionActivityBehavior createServiceTaskExpressionActivityBehavior(ServiceTask serviceTask) {
/* 139 */     Expression expression = this.expressionManager.createExpression(serviceTask.getImplementation());
/* 140 */     return new ServiceTaskExpressionActivityBehavior(expression, serviceTask.getResultVariableName());
/*     */   }
/*     */ 
/*     */   public WebServiceActivityBehavior createWebServiceActivityBehavior(ServiceTask serviceTask) {
/* 144 */     return new WebServiceActivityBehavior();
/*     */   }
/*     */ 
/*     */   public WebServiceActivityBehavior createWebServiceActivityBehavior(SendTask sendTask) {
/* 148 */     return new WebServiceActivityBehavior();
/*     */   }
/*     */ 
/*     */   public MailActivityBehavior createMailActivityBehavior(ServiceTask serviceTask) {
/* 152 */     return createMailActivityBehavior(serviceTask.getId(), serviceTask.getFieldExtensions());
/*     */   }
/*     */ 
/*     */   public MailActivityBehavior createMailActivityBehavior(SendTask sendTask) {
/* 156 */     return createMailActivityBehavior(sendTask.getId(), sendTask.getFieldExtensions());
/*     */   }
/*     */ 
/*     */   protected MailActivityBehavior createMailActivityBehavior(String taskId, List<FieldExtension> fields) {
/* 160 */     List fieldDeclarations = createFieldDeclarations(fields);
/* 161 */     return (MailActivityBehavior)ClassDelegate.instantiateDelegate(MailActivityBehavior.class, fieldDeclarations);
/*     */   }
/*     */ 
/*     */   public ActivityBehavior createMuleActivityBehavior(ServiceTask serviceTask, BpmnModel bpmnModel)
/*     */   {
/* 167 */     return createMuleActivityBehavior(serviceTask, serviceTask.getFieldExtensions(), bpmnModel);
/*     */   }
/*     */ 
/*     */   public ActivityBehavior createMuleActivityBehavior(SendTask sendTask, BpmnModel bpmnModel) {
/* 171 */     return createMuleActivityBehavior(sendTask, sendTask.getFieldExtensions(), bpmnModel);
/*     */   }
/*     */ 
/*     */   protected ActivityBehavior createMuleActivityBehavior(Task task, List<FieldExtension> fieldExtensions, BpmnModel bpmnModel)
/*     */   {
/*     */     try {
/* 177 */       Class theClass = Class.forName("org.activiti.mule.MuleSendActivitiBehavior");
/* 178 */       List fieldDeclarations = createFieldDeclarations(fieldExtensions);
/* 179 */       return (ActivityBehavior)ClassDelegate.instantiateDelegate(theClass, fieldDeclarations);
/*     */     }
/*     */     catch (ClassNotFoundException e)
/*     */     {
/* 183 */       bpmnModel.addProblem("Could not find org.activiti.mule.MuleSendActivitiBehavior: " + e.getMessage(), task);
/* 184 */     }return null;
/*     */   }
/*     */ 
/*     */   public ActivityBehavior createCamelActivityBehavior(ServiceTask serviceTask, BpmnModel bpmnModel)
/*     */   {
/* 192 */     return createCamelActivityBehavior(serviceTask, serviceTask.getFieldExtensions(), bpmnModel);
/*     */   }
/*     */ 
/*     */   public ActivityBehavior createCamelActivityBehavior(SendTask sendTask, BpmnModel bpmnModel) {
/* 196 */     return createCamelActivityBehavior(sendTask, sendTask.getFieldExtensions(), bpmnModel);
/*     */   }
/*     */ 
/*     */   protected ActivityBehavior createCamelActivityBehavior(Task task, List<FieldExtension> fieldExtensions, BpmnModel bpmnModel) {
/*     */     try {
/* 201 */       Class theClass = null;
/* 202 */       FieldExtension behaviorExtension = null;
/* 203 */       for (FieldExtension fieldExtension : fieldExtensions) {
/* 204 */         if (("camelBehaviorClass".equals(fieldExtension.getFieldName())) && (StringUtils.isNotEmpty(fieldExtension.getStringValue()))) {
/* 205 */           theClass = Class.forName(fieldExtension.getStringValue());
/* 206 */           behaviorExtension = fieldExtension;
/* 207 */           break;
/*     */         }
/*     */       }
/*     */ 
/* 211 */       if (behaviorExtension != null) {
/* 212 */         fieldExtensions.remove(behaviorExtension);
/*     */       }
/*     */ 
/* 215 */       if (theClass == null)
/*     */       {
/* 217 */         theClass = Class.forName("org.activiti.camel.impl.CamelBehaviorDefaultImpl");
/*     */       }
/*     */ 
/* 220 */       List fieldDeclarations = createFieldDeclarations(fieldExtensions);
/* 221 */       return (ActivityBehavior)ClassDelegate.instantiateDelegate(theClass, fieldDeclarations);
/*     */     }
/*     */     catch (ClassNotFoundException e)
/*     */     {
/* 225 */       bpmnModel.addProblem("Could not find org.activiti.camel.CamelBehavior: " + e.getMessage(), task);
/* 226 */     }return null;
/*     */   }
/*     */ 
/*     */   public ShellActivityBehavior createShellActivityBehavior(ServiceTask serviceTask)
/*     */   {
/* 231 */     List fieldDeclarations = createFieldDeclarations(serviceTask.getFieldExtensions());
/* 232 */     return (ShellActivityBehavior)ClassDelegate.instantiateDelegate(ShellActivityBehavior.class, fieldDeclarations);
/*     */   }
/*     */ 
/*     */   public BusinessRuleTaskActivityBehavior createBusinessRuleTaskActivityBehavior(BusinessRuleTask businessRuleTask) {
/* 236 */     BusinessRuleTaskActivityBehavior ruleActivity = new BusinessRuleTaskActivityBehavior();
/*     */ 
/* 238 */     for (String ruleVariableInputObject : businessRuleTask.getInputVariables()) {
/* 239 */       ruleActivity.addRuleVariableInputIdExpression(this.expressionManager.createExpression(ruleVariableInputObject.trim()));
/*     */     }
/*     */ 
/* 242 */     for (String rule : businessRuleTask.getRuleNames()) {
/* 243 */       ruleActivity.addRuleIdExpression(this.expressionManager.createExpression(rule.trim()));
/*     */     }
/*     */ 
/* 246 */     ruleActivity.setExclude(businessRuleTask.isExclude());
/*     */ 
/* 248 */     if ((businessRuleTask.getResultVariableName() != null) && (businessRuleTask.getResultVariableName().length() > 0))
/* 249 */       ruleActivity.setResultVariable(businessRuleTask.getResultVariableName());
/*     */     else {
/* 251 */       ruleActivity.setResultVariable("org.activiti.engine.rules.OUTPUT");
/*     */     }
/*     */ 
/* 254 */     return ruleActivity;
/*     */   }
/*     */ 
/*     */   public ScriptTaskActivityBehavior createScriptTaskActivityBehavior(ScriptTask scriptTask)
/*     */   {
/* 260 */     String language = scriptTask.getScriptFormat();
/* 261 */     if (language == null) {
/* 262 */       language = "juel";
/*     */     }
/* 264 */     return new ScriptTaskActivityBehavior(scriptTask.getScript(), language, scriptTask.getResultVariable(), scriptTask.isAutoStoreVariables());
/*     */   }
/*     */ 
/*     */   public ExclusiveGatewayActivityBehavior createExclusiveGatewayActivityBehavior(ExclusiveGateway exclusiveGateway)
/*     */   {
/* 270 */     return new ExclusiveGatewayActivityBehavior();
/*     */   }
/*     */ 
/*     */   public ParallelGatewayActivityBehavior createParallelGatewayActivityBehavior(ParallelGateway parallelGateway) {
/* 274 */     return new ParallelGatewayActivityBehavior();
/*     */   }
/*     */ 
/*     */   public InclusiveGatewayActivityBehavior createInclusiveGatewayActivityBehavior(InclusiveGateway inclusiveGateway) {
/* 278 */     return new InclusiveGatewayActivityBehavior();
/*     */   }
/*     */ 
/*     */   public EventBasedGatewayActivityBehavior createEventBasedGatewayActivityBehavior(EventGateway eventGateway) {
/* 282 */     return new EventBasedGatewayActivityBehavior();
/*     */   }
/*     */ 
/*     */   public SequentialMultiInstanceBehavior createSequentialMultiInstanceBehavior(ActivityImpl activity, AbstractBpmnActivityBehavior innerActivityBehavior)
/*     */   {
/* 288 */     return new SequentialMultiInstanceBehavior(activity, innerActivityBehavior);
/*     */   }
/*     */ 
/*     */   public ParallelMultiInstanceBehavior createParallelMultiInstanceBehavior(ActivityImpl activity, AbstractBpmnActivityBehavior innerActivityBehavior) {
/* 292 */     return new ParallelMultiInstanceBehavior(activity, innerActivityBehavior);
/*     */   }
/*     */ 
/*     */   public SubProcessActivityBehavior createSubprocActivityBehavior(SubProcess subProcess)
/*     */   {
/* 298 */     return new SubProcessActivityBehavior();
/*     */   }
/*     */ 
/*     */   public CallActivityBehavior createCallActivityBehavior(CallActivity callActivity)
/*     */   {
/* 304 */     String expressionRegex = "\\$+\\{+.+\\}";
/*     */ 
/* 306 */     CallActivityBehavior callActivityBehaviour = null;
/* 307 */     if ((StringUtils.isNotEmpty(callActivity.getCalledElement())) && (callActivity.getCalledElement().matches(expressionRegex)))
/* 308 */       callActivityBehaviour = new CallActivityBehavior(this.expressionManager.createExpression(callActivity.getCalledElement()));
/*     */     else {
/* 310 */       callActivityBehaviour = new CallActivityBehavior(callActivity.getCalledElement());
/*     */     }
/*     */ 
/* 313 */     for (IOParameter ioParameter : callActivity.getInParameters()) {
/* 314 */       if (StringUtils.isNotEmpty(ioParameter.getSourceExpression())) {
/* 315 */         Expression expression = this.expressionManager.createExpression(ioParameter.getSourceExpression().trim());
/* 316 */         callActivityBehaviour.addDataInputAssociation(new SimpleDataInputAssociation(expression, ioParameter.getTarget()));
/*     */       } else {
/* 318 */         callActivityBehaviour.addDataInputAssociation(new SimpleDataInputAssociation(ioParameter.getSource(), ioParameter.getTarget()));
/*     */       }
/*     */     }
/*     */ 
/* 322 */     for (IOParameter ioParameter : callActivity.getOutParameters()) {
/* 323 */       if (StringUtils.isNotEmpty(ioParameter.getSourceExpression())) {
/* 324 */         Expression expression = this.expressionManager.createExpression(ioParameter.getSourceExpression().trim());
/* 325 */         callActivityBehaviour.addDataOutputAssociation(new MessageImplicitDataOutputAssociation(ioParameter.getTarget(), expression));
/*     */       } else {
/* 327 */         callActivityBehaviour.addDataOutputAssociation(new MessageImplicitDataOutputAssociation(ioParameter.getTarget(), ioParameter.getSource()));
/*     */       }
/*     */     }
/*     */ 
/* 331 */     return callActivityBehaviour;
/*     */   }
/*     */ 
/*     */   public TransactionActivityBehavior createTransactionActivityBehavior(Transaction transaction)
/*     */   {
/* 337 */     return new TransactionActivityBehavior();
/*     */   }
/*     */ 
/*     */   public IntermediateCatchEventActivityBehavior createIntermediateCatchEventActivityBehavior(IntermediateCatchEvent intermediateCatchEvent)
/*     */   {
/* 343 */     return new IntermediateCatchEventActivityBehavior();
/*     */   }
/*     */ 
/*     */   public IntermediateThrowNoneEventActivityBehavior createIntermediateThrowNoneEventActivityBehavior(ThrowEvent throwEvent) {
/* 347 */     return new IntermediateThrowNoneEventActivityBehavior();
/*     */   }
/*     */ 
/*     */   public IntermediateThrowSignalEventActivityBehavior createIntermediateThrowSignalEventActivityBehavior(ThrowEvent throwEvent, Signal signal, EventSubscriptionDeclaration eventSubscriptionDeclaration)
/*     */   {
/* 352 */     return new IntermediateThrowSignalEventActivityBehavior(throwEvent, signal, eventSubscriptionDeclaration);
/*     */   }
/*     */ 
/*     */   public IntermediateThrowCompensationEventActivityBehavior createIntermediateThrowCompensationEventActivityBehavior(ThrowEvent throwEvent, CompensateEventDefinition compensateEventDefinition)
/*     */   {
/* 357 */     return new IntermediateThrowCompensationEventActivityBehavior(compensateEventDefinition);
/*     */   }
/*     */ 
/*     */   public NoneEndEventActivityBehavior createNoneEndEventActivityBehavior(EndEvent endEvent)
/*     */   {
/* 363 */     return new NoneEndEventActivityBehavior();
/*     */   }
/*     */ 
/*     */   public ErrorEndEventActivityBehavior createErrorEndEventActivityBehavior(EndEvent endEvent, ErrorEventDefinition errorEventDefinition) {
/* 367 */     return new ErrorEndEventActivityBehavior(errorEventDefinition.getErrorCode());
/*     */   }
/*     */ 
/*     */   public CancelEndEventActivityBehavior createCancelEndEventActivityBehavior(EndEvent endEvent) {
/* 371 */     return new CancelEndEventActivityBehavior();
/*     */   }
/*     */ 
/*     */   public TerminateEndEventActivityBehavior createTerminateEndEventActivityBehavior(EndEvent endEvent) {
/* 375 */     return new TerminateEndEventActivityBehavior();
/*     */   }
/*     */ 
/*     */   public BoundaryEventActivityBehavior createBoundaryEventActivityBehavior(BoundaryEvent boundaryEvent, boolean interrupting, ActivityImpl activity)
/*     */   {
/* 381 */     return new BoundaryEventActivityBehavior(interrupting, activity.getId());
/*     */   }
/*     */ 
/*     */   public CancelBoundaryEventActivityBehavior createCancelBoundaryEventActivityBehavior(CancelEventDefinition cancelEventDefinition) {
/* 385 */     return new CancelBoundaryEventActivityBehavior();
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.factory.DefaultActivityBehaviorFactory
 * JD-Core Version:    0.6.0
 */