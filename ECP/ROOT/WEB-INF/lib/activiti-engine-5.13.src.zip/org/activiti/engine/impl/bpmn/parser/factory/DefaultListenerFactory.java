/*    */ package org.activiti.engine.impl.bpmn.parser.factory;
/*    */ 
/*    */ import org.activiti.bpmn.model.ActivitiListener;
/*    */ import org.activiti.engine.delegate.ExecutionListener;
/*    */ import org.activiti.engine.delegate.TaskListener;
/*    */ import org.activiti.engine.impl.bpmn.helper.ClassDelegate;
/*    */ import org.activiti.engine.impl.bpmn.listener.DelegateExpressionExecutionListener;
/*    */ import org.activiti.engine.impl.bpmn.listener.DelegateExpressionTaskListener;
/*    */ import org.activiti.engine.impl.bpmn.listener.ExpressionExecutionListener;
/*    */ import org.activiti.engine.impl.bpmn.listener.ExpressionTaskListener;
/*    */ import org.activiti.engine.impl.el.ExpressionManager;
/*    */ 
/*    */ public class DefaultListenerFactory extends AbstractBehaviorFactory
/*    */   implements ListenerFactory
/*    */ {
/*    */   public TaskListener createClassDelegateTaskListener(ActivitiListener activitiListener)
/*    */   {
/* 35 */     return new ClassDelegate(activitiListener.getImplementation(), createFieldDeclarations(activitiListener.getFieldExtensions()));
/*    */   }
/*    */ 
/*    */   public TaskListener createExpressionTaskListener(ActivitiListener activitiListener) {
/* 39 */     return new ExpressionTaskListener(this.expressionManager.createExpression(activitiListener.getImplementation()));
/*    */   }
/*    */ 
/*    */   public TaskListener createDelegateExpressionTaskListener(ActivitiListener activitiListener) {
/* 43 */     return new DelegateExpressionTaskListener(this.expressionManager.createExpression(activitiListener.getImplementation()), createFieldDeclarations(activitiListener.getFieldExtensions()));
/*    */   }
/*    */ 
/*    */   public ExecutionListener createClassDelegateExecutionListener(ActivitiListener activitiListener)
/*    */   {
/* 48 */     return new ClassDelegate(activitiListener.getImplementation(), createFieldDeclarations(activitiListener.getFieldExtensions()));
/*    */   }
/*    */ 
/*    */   public ExecutionListener createExpressionExecutionListener(ActivitiListener activitiListener) {
/* 52 */     return new ExpressionExecutionListener(this.expressionManager.createExpression(activitiListener.getImplementation()));
/*    */   }
/*    */ 
/*    */   public ExecutionListener createDelegateExpressionExecutionListener(ActivitiListener activitiListener) {
/* 56 */     return new DelegateExpressionExecutionListener(this.expressionManager.createExpression(activitiListener.getImplementation()), createFieldDeclarations(activitiListener.getFieldExtensions()));
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.factory.DefaultListenerFactory
 * JD-Core Version:    0.6.0
 */