package org.activiti.engine.impl.bpmn.parser.factory;

import org.activiti.bpmn.model.ActivitiListener;
import org.activiti.engine.delegate.ExecutionListener;
import org.activiti.engine.delegate.TaskListener;

public abstract interface ListenerFactory
{
  public abstract TaskListener createClassDelegateTaskListener(ActivitiListener paramActivitiListener);

  public abstract TaskListener createExpressionTaskListener(ActivitiListener paramActivitiListener);

  public abstract TaskListener createDelegateExpressionTaskListener(ActivitiListener paramActivitiListener);

  public abstract ExecutionListener createClassDelegateExecutionListener(ActivitiListener paramActivitiListener);

  public abstract ExecutionListener createExpressionExecutionListener(ActivitiListener paramActivitiListener);

  public abstract ExecutionListener createDelegateExpressionExecutionListener(ActivitiListener paramActivitiListener);
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.factory.ListenerFactory
 * JD-Core Version:    0.6.0
 */