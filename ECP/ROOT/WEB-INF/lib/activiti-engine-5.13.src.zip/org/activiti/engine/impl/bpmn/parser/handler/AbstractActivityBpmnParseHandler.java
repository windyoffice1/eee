/*     */ package org.activiti.engine.impl.bpmn.parser.handler;
/*     */ 
/*     */ import org.activiti.bpmn.model.Activity;
/*     */ import org.activiti.bpmn.model.BaseElement;
/*     */ import org.activiti.bpmn.model.BpmnModel;
/*     */ import org.activiti.bpmn.model.FlowNode;
/*     */ import org.activiti.bpmn.model.MultiInstanceLoopCharacteristics;
/*     */ import org.activiti.engine.impl.bpmn.behavior.AbstractBpmnActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.behavior.MultiInstanceActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*     */ import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
/*     */ import org.activiti.engine.impl.el.ExpressionManager;
/*     */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*     */ import org.activiti.engine.impl.pvm.process.ScopeImpl;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public abstract class AbstractActivityBpmnParseHandler<T extends FlowNode> extends AbstractFlowNodeBpmnParseHandler<T>
/*     */ {
/*     */   public void parse(BpmnParse bpmnParse, BaseElement element)
/*     */   {
/*  35 */     super.parse(bpmnParse, element);
/*     */ 
/*  37 */     if (((element instanceof Activity)) && (((Activity)element).getLoopCharacteristics() != null))
/*     */     {
/*  39 */       createMultiInstanceLoopCharacteristics(bpmnParse, (Activity)element);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void createMultiInstanceLoopCharacteristics(BpmnParse bpmnParse, Activity modelActivity)
/*     */   {
/*  45 */     MultiInstanceLoopCharacteristics loopCharacteristics = modelActivity.getLoopCharacteristics();
/*     */ 
/*  48 */     MultiInstanceActivityBehavior miActivityBehavior = null;
/*  49 */     ActivityImpl activity = bpmnParse.getCurrentScope().findActivity(modelActivity.getId());
/*  50 */     if (activity == null) {
/*  51 */       bpmnParse.getBpmnModel().addProblem("Activity " + modelActivity.getId() + " needed for multi instance cannot bv found", modelActivity);
/*     */     }
/*     */ 
/*  54 */     if (loopCharacteristics.isSequential()) {
/*  55 */       miActivityBehavior = bpmnParse.getActivityBehaviorFactory().createSequentialMultiInstanceBehavior(activity, (AbstractBpmnActivityBehavior)activity.getActivityBehavior());
/*     */     }
/*     */     else {
/*  58 */       miActivityBehavior = bpmnParse.getActivityBehaviorFactory().createParallelMultiInstanceBehavior(activity, (AbstractBpmnActivityBehavior)activity.getActivityBehavior());
/*     */     }
/*     */ 
/*  63 */     activity.setScope(true);
/*  64 */     activity.setProperty("multiInstance", loopCharacteristics.isSequential() ? "sequential" : "parallel");
/*  65 */     activity.setActivityBehavior(miActivityBehavior);
/*     */ 
/*  67 */     ExpressionManager expressionManager = bpmnParse.getExpressionManager();
/*  68 */     BpmnModel bpmnModel = bpmnParse.getBpmnModel();
/*     */ 
/*  71 */     if (StringUtils.isNotEmpty(loopCharacteristics.getLoopCardinality())) {
/*  72 */       miActivityBehavior.setLoopCardinalityExpression(expressionManager.createExpression(loopCharacteristics.getLoopCardinality()));
/*     */     }
/*     */ 
/*  76 */     if (StringUtils.isNotEmpty(loopCharacteristics.getCompletionCondition())) {
/*  77 */       miActivityBehavior.setCompletionConditionExpression(expressionManager.createExpression(loopCharacteristics.getCompletionCondition()));
/*     */     }
/*     */ 
/*  81 */     if (StringUtils.isNotEmpty(loopCharacteristics.getInputDataItem())) {
/*  82 */       if (loopCharacteristics.getInputDataItem().contains("{"))
/*  83 */         miActivityBehavior.setCollectionExpression(expressionManager.createExpression(loopCharacteristics.getInputDataItem()));
/*     */       else {
/*  85 */         miActivityBehavior.setCollectionVariable(loopCharacteristics.getInputDataItem());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  90 */     if (StringUtils.isNotEmpty(loopCharacteristics.getElementVariable())) {
/*  91 */       miActivityBehavior.setCollectionElementVariable(loopCharacteristics.getElementVariable());
/*     */     }
/*     */ 
/*  95 */     if ((miActivityBehavior.getLoopCardinalityExpression() == null) && (miActivityBehavior.getCollectionExpression() == null) && (miActivityBehavior.getCollectionVariable() == null))
/*     */     {
/*  97 */       bpmnModel.addProblem("Either loopCardinality or loopDataInputRef/activiti:collection must been set.", loopCharacteristics);
/*     */     }
/*     */ 
/* 101 */     if ((miActivityBehavior.getCollectionExpression() == null) && (miActivityBehavior.getCollectionVariable() == null) && (miActivityBehavior.getCollectionElementVariable() != null))
/*     */     {
/* 103 */       bpmnModel.addProblem("LoopDataInputRef/activiti:collection must be set when using inputDataItem or activiti:elementVariable.", loopCharacteristics);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.AbstractActivityBpmnParseHandler
 * JD-Core Version:    0.6.0
 */