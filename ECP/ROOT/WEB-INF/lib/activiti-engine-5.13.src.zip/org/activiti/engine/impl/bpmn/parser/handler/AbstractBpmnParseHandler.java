/*     */ package org.activiti.engine.impl.bpmn.parser.handler;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.activiti.bpmn.model.ActivitiListener;
/*     */ import org.activiti.bpmn.model.Activity;
/*     */ import org.activiti.bpmn.model.Artifact;
/*     */ import org.activiti.bpmn.model.Association;
/*     */ import org.activiti.bpmn.model.BaseElement;
/*     */ import org.activiti.bpmn.model.BpmnModel;
/*     */ import org.activiti.bpmn.model.DataSpec;
/*     */ import org.activiti.bpmn.model.EventDefinition;
/*     */ import org.activiti.bpmn.model.EventGateway;
/*     */ import org.activiti.bpmn.model.FlowElement;
/*     */ import org.activiti.bpmn.model.Gateway;
/*     */ import org.activiti.bpmn.model.ImplementationType;
/*     */ import org.activiti.bpmn.model.IntermediateCatchEvent;
/*     */ import org.activiti.bpmn.model.SequenceFlow;
/*     */ import org.activiti.engine.delegate.ExecutionListener;
/*     */ import org.activiti.engine.impl.bpmn.data.Data;
/*     */ import org.activiti.engine.impl.bpmn.data.DataRef;
/*     */ import org.activiti.engine.impl.bpmn.data.ItemDefinition;
/*     */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*     */ import org.activiti.engine.impl.bpmn.parser.EventSubscriptionDeclaration;
/*     */ import org.activiti.engine.impl.bpmn.parser.factory.ListenerFactory;
/*     */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*     */ import org.activiti.engine.impl.pvm.process.ScopeImpl;
/*     */ import org.activiti.engine.impl.pvm.process.TransitionImpl;
/*     */ import org.activiti.engine.parse.BpmnParseHandler;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public abstract class AbstractBpmnParseHandler<T extends BaseElement>
/*     */   implements BpmnParseHandler
/*     */ {
/*  55 */   private static final Logger LOGGER = LoggerFactory.getLogger(AbstractBpmnParseHandler.class);
/*     */   public static final String PROPERTYNAME_IS_FOR_COMPENSATION = "isForCompensation";
/*     */   public static final String PROPERTYNAME_EVENT_SUBSCRIPTION_DECLARATION = "eventDefinitions";
/*     */   public static final String PROPERTYNAME_ERROR_EVENT_DEFINITIONS = "errorEventDefinitions";
/*     */   public static final String PROPERTYNAME_TIMER_DECLARATION = "timerDeclarations";
/*     */ 
/*     */   public Set<Class<? extends BaseElement>> getHandledTypes()
/*     */   {
/*  66 */     Set types = new HashSet();
/*  67 */     types.add(getHandledType());
/*  68 */     return types;
/*     */   }
/*     */ 
/*     */   protected Class<? extends BaseElement> getHandledType()
/*     */   {
/*  73 */     return null;
/*     */   }
/*     */ 
/*     */   public void parse(BpmnParse bpmnParse, BaseElement element)
/*     */   {
/*  78 */     BaseElement baseElement = element;
/*  79 */     executeParse(bpmnParse, baseElement);
/*     */   }
/*     */   protected abstract void executeParse(BpmnParse paramBpmnParse, T paramT);
/*     */ 
/*     */   protected ActivityImpl findActivity(BpmnParse bpmnParse, String id) {
/*  85 */     return bpmnParse.getCurrentScope().findActivity(id);
/*     */   }
/*     */ 
/*     */   public ActivityImpl createActivityOnCurrentScope(BpmnParse bpmnParse, FlowElement flowElement, String xmlLocalName) {
/*  89 */     return createActivityOnScope(bpmnParse, flowElement, xmlLocalName, bpmnParse.getCurrentScope());
/*     */   }
/*     */ 
/*     */   public ActivityImpl createActivityOnScope(BpmnParse bpmnParse, FlowElement flowElement, String xmlLocalName, ScopeImpl scopeElement) {
/*  93 */     if (LOGGER.isDebugEnabled()) {
/*  94 */       LOGGER.debug("Parsing activity {}", flowElement.getId());
/*     */     }
/*     */ 
/*  97 */     ActivityImpl activity = scopeElement.createActivity(flowElement.getId());
/*  98 */     bpmnParse.setCurrentActivity(activity);
/*     */ 
/* 100 */     activity.setProperty("name", flowElement.getName());
/* 101 */     activity.setProperty("documentation", flowElement.getDocumentation());
/* 102 */     if ((flowElement instanceof Activity)) {
/* 103 */       Activity modelActivity = (Activity)flowElement;
/* 104 */       activity.setProperty("default", modelActivity.getDefaultFlow());
/* 105 */       if (modelActivity.isForCompensation())
/* 106 */         activity.setProperty("isForCompensation", Boolean.valueOf(true));
/*     */     }
/* 108 */     else if ((flowElement instanceof Gateway)) {
/* 109 */       activity.setProperty("default", ((Gateway)flowElement).getDefaultFlow());
/*     */     }
/* 111 */     activity.setProperty("type", xmlLocalName);
/*     */ 
/* 113 */     return activity;
/*     */   }
/*     */ 
/*     */   protected void createExecutionListenersOnScope(BpmnParse bpmnParse, List<ActivitiListener> activitiListenerList, ScopeImpl scope) {
/* 117 */     for (ActivitiListener activitiListener : activitiListenerList)
/* 118 */       scope.addExecutionListener(activitiListener.getEvent(), createExecutionListener(bpmnParse, activitiListener));
/*     */   }
/*     */ 
/*     */   protected void createExecutionListenersOnTransition(BpmnParse bpmnParse, List<ActivitiListener> activitiListenerList, TransitionImpl transition)
/*     */   {
/* 123 */     for (ActivitiListener activitiListener : activitiListenerList)
/* 124 */       transition.addExecutionListener(createExecutionListener(bpmnParse, activitiListener));
/*     */   }
/*     */ 
/*     */   protected ExecutionListener createExecutionListener(BpmnParse bpmnParse, ActivitiListener activitiListener)
/*     */   {
/* 129 */     ExecutionListener executionListener = null;
/*     */ 
/* 131 */     if (ImplementationType.IMPLEMENTATION_TYPE_CLASS.equalsIgnoreCase(activitiListener.getImplementationType()))
/* 132 */       executionListener = bpmnParse.getListenerFactory().createClassDelegateExecutionListener(activitiListener);
/* 133 */     else if (ImplementationType.IMPLEMENTATION_TYPE_EXPRESSION.equalsIgnoreCase(activitiListener.getImplementationType()))
/* 134 */       executionListener = bpmnParse.getListenerFactory().createExpressionExecutionListener(activitiListener);
/* 135 */     else if (ImplementationType.IMPLEMENTATION_TYPE_DELEGATEEXPRESSION.equalsIgnoreCase(activitiListener.getImplementationType())) {
/* 136 */       executionListener = bpmnParse.getListenerFactory().createDelegateExpressionExecutionListener(activitiListener);
/*     */     }
/* 138 */     return executionListener;
/*     */   }
/*     */ 
/*     */   protected void addEventSubscriptionDeclaration(BpmnParse bpmnParse, EventSubscriptionDeclaration subscription, EventDefinition parsedEventDefinition, ScopeImpl scope)
/*     */   {
/* 143 */     List eventDefinitions = (List)scope.getProperty("eventDefinitions");
/* 144 */     if (eventDefinitions == null) {
/* 145 */       eventDefinitions = new ArrayList();
/* 146 */       scope.setProperty("eventDefinitions", eventDefinitions);
/*     */     }
/* 149 */     else if (subscription.getEventType().equals("message")) {
/* 150 */       for (EventSubscriptionDeclaration eventDefinition : eventDefinitions) {
/* 151 */         if ((eventDefinition.getEventType().equals("message")) && (eventDefinition.getEventName().equals(subscription.getEventName())) && (eventDefinition.isStartEvent() == subscription.isStartEvent()))
/*     */         {
/* 155 */           bpmnParse.getBpmnModel().addProblem("Cannot have more than one message event subscription with name '" + subscription.getEventName() + "' for scope '" + scope.getId() + "'", parsedEventDefinition);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 161 */     eventDefinitions.add(subscription);
/*     */   }
/*     */ 
/*     */   protected String getPrecedingEventBasedGateway(BpmnParse bpmnParse, IntermediateCatchEvent event) {
/* 165 */     String eventBasedGatewayId = null;
/* 166 */     for (SequenceFlow sequenceFlow : event.getIncomingFlows()) {
/* 167 */       FlowElement sourceElement = bpmnParse.getBpmnModel().getFlowElement(sequenceFlow.getSourceRef());
/* 168 */       if ((sourceElement instanceof EventGateway)) {
/* 169 */         eventBasedGatewayId = sourceElement.getId();
/* 170 */         break;
/*     */       }
/*     */     }
/* 173 */     return eventBasedGatewayId;
/*     */   }
/*     */ 
/*     */   protected org.activiti.engine.impl.bpmn.data.IOSpecification createIOSpecification(BpmnParse bpmnParse, org.activiti.bpmn.model.IOSpecification specificationModel) {
/* 177 */     org.activiti.engine.impl.bpmn.data.IOSpecification ioSpecification = new org.activiti.engine.impl.bpmn.data.IOSpecification();
/*     */ 
/* 179 */     for (DataSpec dataInputElement : specificationModel.getDataInputs()) {
/* 180 */       ItemDefinition itemDefinition = (ItemDefinition)bpmnParse.getItemDefinitions().get(dataInputElement.getItemSubjectRef());
/* 181 */       Data dataInput = new Data(bpmnParse.getTargetNamespace() + ":" + dataInputElement.getId(), dataInputElement.getId(), itemDefinition);
/* 182 */       ioSpecification.addInput(dataInput);
/*     */     }
/*     */ 
/* 185 */     for (DataSpec dataOutputElement : specificationModel.getDataOutputs()) {
/* 186 */       ItemDefinition itemDefinition = (ItemDefinition)bpmnParse.getItemDefinitions().get(dataOutputElement.getItemSubjectRef());
/* 187 */       Data dataOutput = new Data(bpmnParse.getTargetNamespace() + ":" + dataOutputElement.getId(), dataOutputElement.getId(), itemDefinition);
/* 188 */       ioSpecification.addOutput(dataOutput);
/*     */     }
/*     */ 
/* 191 */     for (String dataInputRef : specificationModel.getDataInputRefs()) {
/* 192 */       DataRef dataRef = new DataRef(dataInputRef);
/* 193 */       ioSpecification.addInputRef(dataRef);
/*     */     }
/*     */ 
/* 196 */     for (String dataOutputRef : specificationModel.getDataOutputRefs()) {
/* 197 */       DataRef dataRef = new DataRef(dataOutputRef);
/* 198 */       ioSpecification.addOutputRef(dataRef);
/*     */     }
/*     */ 
/* 201 */     return ioSpecification;
/*     */   }
/*     */ 
/*     */   protected void processArtifacts(BpmnParse bpmnParse, Collection<Artifact> artifacts, ScopeImpl scope)
/*     */   {
/* 206 */     for (Artifact artifact : artifacts)
/* 207 */       if ((artifact instanceof Association))
/* 208 */         createAssociation(bpmnParse, (Association)artifact, scope);
/*     */   }
/*     */ 
/*     */   protected void createAssociation(BpmnParse bpmnParse, Association association, ScopeImpl parentScope)
/*     */   {
/* 214 */     BpmnModel bpmnModel = bpmnParse.getBpmnModel();
/* 215 */     if ((bpmnModel.getArtifact(association.getSourceRef()) != null) || (bpmnModel.getArtifact(association.getTargetRef()) != null))
/*     */     {
/* 219 */       return;
/*     */     }
/*     */ 
/* 222 */     ActivityImpl sourceActivity = parentScope.findActivity(association.getSourceRef());
/* 223 */     ActivityImpl targetActivity = parentScope.findActivity(association.getTargetRef());
/*     */ 
/* 228 */     if (sourceActivity != null)
/*     */     {
/* 230 */       if (targetActivity != null)
/*     */       {
/* 233 */         if (sourceActivity.getProperty("type").equals("compensationBoundaryCatch")) {
/* 234 */           Object isForCompensation = targetActivity.getProperty("isForCompensation");
/* 235 */           if ((isForCompensation == null) || (!((Boolean)isForCompensation).booleanValue())) {
/* 236 */             bpmnModel.addProblem("compensation boundary catch must be connected to element with isForCompensation=true", association);
/*     */           } else {
/* 238 */             ActivityImpl compensatedActivity = sourceActivity.getParentActivity();
/* 239 */             compensatedActivity.setProperty("compensationHandler", targetActivity.getId());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.AbstractBpmnParseHandler
 * JD-Core Version:    0.6.0
 */