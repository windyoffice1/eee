/*     */ package org.activiti.engine.impl.bpmn.parser.handler;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.activiti.bpmn.model.BpmnModel;
/*     */ import org.activiti.bpmn.model.DataAssociation;
/*     */ import org.activiti.bpmn.model.FieldExtension;
/*     */ import org.activiti.bpmn.model.FlowNode;
/*     */ import org.activiti.bpmn.model.Task;
/*     */ import org.activiti.engine.delegate.Expression;
/*     */ import org.activiti.engine.impl.bpmn.data.AbstractDataAssociation;
/*     */ import org.activiti.engine.impl.bpmn.data.SimpleDataInputAssociation;
/*     */ import org.activiti.engine.impl.bpmn.data.TransformationDataOutputAssociation;
/*     */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*     */ import org.activiti.engine.impl.bpmn.webservice.MessageImplicitDataInputAssociation;
/*     */ import org.activiti.engine.impl.bpmn.webservice.MessageImplicitDataOutputAssociation;
/*     */ import org.activiti.engine.impl.el.ExpressionManager;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public abstract class AbstractExternalInvocationBpmnParseHandler<T extends FlowNode> extends AbstractActivityBpmnParseHandler<T>
/*     */ {
/*     */   protected void validateFieldDeclarationsForEmail(BpmnParse bpmnParse, Task task, List<FieldExtension> fieldExtensions)
/*     */   {
/*  38 */     boolean toDefined = false;
/*  39 */     boolean textOrHtmlDefined = false;
/*     */ 
/*  41 */     for (FieldExtension fieldExtension : fieldExtensions) {
/*  42 */       if (fieldExtension.getFieldName().equals("to")) {
/*  43 */         toDefined = true;
/*     */       }
/*  45 */       if (fieldExtension.getFieldName().equals("html")) {
/*  46 */         textOrHtmlDefined = true;
/*     */       }
/*  48 */       if (fieldExtension.getFieldName().equals("text")) {
/*  49 */         textOrHtmlDefined = true;
/*     */       }
/*     */     }
/*     */ 
/*  53 */     if (!toDefined) {
/*  54 */       bpmnParse.getBpmnModel().addProblem("No recipient is defined on the mail activity", task);
/*     */     }
/*  56 */     if (!textOrHtmlDefined)
/*  57 */       bpmnParse.getBpmnModel().addProblem("Text or html field should be provided", task);
/*     */   }
/*     */ 
/*     */   protected void validateFieldDeclarationsForShell(BpmnParse bpmnParse, Task task, List<FieldExtension> fieldExtensions)
/*     */   {
/*  62 */     boolean shellCommandDefined = false;
/*     */ 
/*  64 */     for (FieldExtension fieldExtension : fieldExtensions) {
/*  65 */       String fieldName = fieldExtension.getFieldName();
/*  66 */       String fieldValue = fieldExtension.getStringValue();
/*     */ 
/*  68 */       shellCommandDefined |= fieldName.equals("command");
/*     */ 
/*  70 */       if (((fieldName.equals("wait")) || (fieldName.equals("redirectError")) || (fieldName.equals("cleanEnv"))) && (!fieldValue.toLowerCase().equals("true")) && (!fieldValue.toLowerCase().equals("false")))
/*     */       {
/*  72 */         bpmnParse.getBpmnModel().addProblem("undefined value for shell " + fieldName + " parameter :" + fieldValue.toString() + ".", task);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  77 */     if (!shellCommandDefined)
/*  78 */       bpmnParse.getBpmnModel().addProblem("No shell command is defined on the shell activity", task);
/*     */   }
/*     */ 
/*     */   public AbstractDataAssociation createDataInputAssociation(BpmnParse bpmnParse, DataAssociation dataAssociationElement)
/*     */   {
/*  83 */     if (StringUtils.isEmpty(dataAssociationElement.getTargetRef())) {
/*  84 */       bpmnParse.getBpmnModel().addProblem("targetRef is required", dataAssociationElement);
/*     */     }
/*     */ 
/*  87 */     if (dataAssociationElement.getAssignments().isEmpty()) {
/*  88 */       return new MessageImplicitDataInputAssociation(dataAssociationElement.getSourceRef(), dataAssociationElement.getTargetRef());
/*     */     }
/*  90 */     SimpleDataInputAssociation dataAssociation = new SimpleDataInputAssociation(dataAssociationElement.getSourceRef(), dataAssociationElement.getTargetRef());
/*     */ 
/*  93 */     for (org.activiti.bpmn.model.Assignment assigmentElement : dataAssociationElement.getAssignments()) {
/*  94 */       if ((StringUtils.isNotEmpty(assigmentElement.getFrom())) && (StringUtils.isNotEmpty(assigmentElement.getTo()))) {
/*  95 */         Expression from = bpmnParse.getExpressionManager().createExpression(assigmentElement.getFrom());
/*  96 */         Expression to = bpmnParse.getExpressionManager().createExpression(assigmentElement.getTo());
/*  97 */         org.activiti.engine.impl.bpmn.data.Assignment assignment = new org.activiti.engine.impl.bpmn.data.Assignment(from, to);
/*  98 */         dataAssociation.addAssignment(assignment);
/*     */       }
/*     */     }
/* 101 */     return dataAssociation;
/*     */   }
/*     */ 
/*     */   public AbstractDataAssociation createDataOutputAssociation(BpmnParse bpmnParse, DataAssociation dataAssociationElement)
/*     */   {
/* 106 */     if (StringUtils.isNotEmpty(dataAssociationElement.getSourceRef())) {
/* 107 */       return new MessageImplicitDataOutputAssociation(dataAssociationElement.getTargetRef(), dataAssociationElement.getSourceRef());
/*     */     }
/* 109 */     Expression transformation = bpmnParse.getExpressionManager().createExpression(dataAssociationElement.getTransformation());
/* 110 */     AbstractDataAssociation dataOutputAssociation = new TransformationDataOutputAssociation(null, dataAssociationElement.getTargetRef(), transformation);
/* 111 */     return dataOutputAssociation;
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.AbstractExternalInvocationBpmnParseHandler
 * JD-Core Version:    0.6.0
 */