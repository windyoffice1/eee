/*    */ package org.activiti.engine.impl.bpmn.parser.handler;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.activiti.bpmn.model.BaseElement;
/*    */ import org.activiti.bpmn.model.BoundaryEvent;
/*    */ import org.activiti.bpmn.model.BpmnModel;
/*    */ import org.activiti.bpmn.model.CancelEventDefinition;
/*    */ import org.activiti.bpmn.model.CompensateEventDefinition;
/*    */ import org.activiti.bpmn.model.ErrorEventDefinition;
/*    */ import org.activiti.bpmn.model.EventDefinition;
/*    */ import org.activiti.bpmn.model.MessageEventDefinition;
/*    */ import org.activiti.bpmn.model.SignalEventDefinition;
/*    */ import org.activiti.bpmn.model.TimerEventDefinition;
/*    */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*    */ import org.activiti.engine.impl.bpmn.parser.BpmnParseHandlers;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ 
/*    */ public class BoundaryEventParseHandler extends AbstractBpmnParseHandler<BoundaryEvent>
/*    */ {
/*    */   public Class<? extends BaseElement> getHandledType()
/*    */   {
/* 34 */     return BoundaryEvent.class;
/*    */   }
/*    */ 
/*    */   protected void executeParse(BpmnParse bpmnParse, BoundaryEvent boundaryEvent)
/*    */   {
/* 39 */     BpmnModel bpmnModel = bpmnParse.getBpmnModel();
/* 40 */     ActivityImpl parentActivity = findActivity(bpmnParse, boundaryEvent.getAttachedToRefId());
/* 41 */     if (parentActivity == null) {
/* 42 */       bpmnModel.addProblem("Invalid reference in boundary event. Make sure that the referenced activity is defined in the same scope as the boundary event", boundaryEvent);
/* 43 */       return;
/*    */     }
/*    */ 
/* 46 */     ActivityImpl nestedActivity = createActivityOnScope(bpmnParse, boundaryEvent, "boundaryEvent", parentActivity);
/* 47 */     bpmnParse.setCurrentActivity(nestedActivity);
/*    */ 
/* 49 */     EventDefinition eventDefinition = null;
/* 50 */     if (boundaryEvent.getEventDefinitions().size() > 0) {
/* 51 */       eventDefinition = (EventDefinition)boundaryEvent.getEventDefinitions().get(0);
/*    */     }
/*    */ 
/* 54 */     if (((eventDefinition instanceof TimerEventDefinition)) || ((eventDefinition instanceof ErrorEventDefinition)) || ((eventDefinition instanceof SignalEventDefinition)) || ((eventDefinition instanceof CancelEventDefinition)) || ((eventDefinition instanceof MessageEventDefinition)) || ((eventDefinition instanceof CompensateEventDefinition)))
/*    */     {
/* 61 */       bpmnParse.getBpmnParserHandlers().parseElement(bpmnParse, eventDefinition);
/*    */     }
/*    */     else
/* 64 */       bpmnModel.addProblem("Unsupported boundary event type", boundaryEvent);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.BoundaryEventParseHandler
 * JD-Core Version:    0.6.0
 */