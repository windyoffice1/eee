/*    */ package org.activiti.engine.impl.bpmn.parser.handler;
/*    */ 
/*    */ import org.activiti.bpmn.model.BaseElement;
/*    */ import org.activiti.bpmn.model.CallActivity;
/*    */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*    */ import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ 
/*    */ public class CallActivityParseHandler extends AbstractActivityBpmnParseHandler<CallActivity>
/*    */ {
/*    */   public Class<? extends BaseElement> getHandledType()
/*    */   {
/* 28 */     return CallActivity.class;
/*    */   }
/*    */ 
/*    */   protected void executeParse(BpmnParse bpmnParse, CallActivity callActivity)
/*    */   {
/* 33 */     ActivityImpl activity = createActivityOnCurrentScope(bpmnParse, callActivity, "callActivity");
/* 34 */     activity.setScope(true);
/* 35 */     activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createCallActivityBehavior(callActivity));
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.CallActivityParseHandler
 * JD-Core Version:    0.6.0
 */