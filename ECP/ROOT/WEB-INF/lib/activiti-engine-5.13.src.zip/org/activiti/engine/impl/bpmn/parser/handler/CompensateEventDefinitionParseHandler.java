/*    */ package org.activiti.engine.impl.bpmn.parser.handler;
/*    */ 
/*    */ import org.activiti.bpmn.model.BaseElement;
/*    */ import org.activiti.bpmn.model.BoundaryEvent;
/*    */ import org.activiti.bpmn.model.BpmnModel;
/*    */ import org.activiti.bpmn.model.ThrowEvent;
/*    */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*    */ import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ import org.activiti.engine.impl.pvm.process.ScopeImpl;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class CompensateEventDefinitionParseHandler extends AbstractBpmnParseHandler<org.activiti.bpmn.model.CompensateEventDefinition>
/*    */ {
/*    */   public Class<? extends BaseElement> getHandledType()
/*    */   {
/* 30 */     return org.activiti.bpmn.model.CompensateEventDefinition.class;
/*    */   }
/*    */ 
/*    */   protected void executeParse(BpmnParse bpmnParse, org.activiti.bpmn.model.CompensateEventDefinition eventDefinition)
/*    */   {
/* 35 */     ScopeImpl scope = bpmnParse.getCurrentScope();
/* 36 */     if ((StringUtils.isNotEmpty(eventDefinition.getActivityRef())) && 
/* 37 */       (scope.findActivity(eventDefinition.getActivityRef()) == null)) {
/* 38 */       bpmnParse.getBpmnModel().addProblem("Invalid attribute value for 'activityRef': no activity with id '" + eventDefinition.getActivityRef() + "' in current scope " + scope.getId(), eventDefinition);
/*    */     }
/*    */ 
/* 43 */     org.activiti.engine.impl.bpmn.parser.CompensateEventDefinition compensateEventDefinition = new org.activiti.engine.impl.bpmn.parser.CompensateEventDefinition();
/*    */ 
/* 45 */     compensateEventDefinition.setActivityRef(eventDefinition.getActivityRef());
/* 46 */     compensateEventDefinition.setWaitForCompletion(eventDefinition.isWaitForCompletion());
/*    */ 
/* 48 */     ActivityImpl activity = bpmnParse.getCurrentActivity();
/* 49 */     if ((bpmnParse.getCurrentFlowElement() instanceof ThrowEvent))
/*    */     {
/* 51 */       activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createIntermediateThrowCompensationEventActivityBehavior((ThrowEvent)bpmnParse.getCurrentFlowElement(), compensateEventDefinition));
/*    */     }
/* 53 */     else if ((bpmnParse.getCurrentFlowElement() instanceof BoundaryEvent))
/*    */     {
/* 55 */       BoundaryEvent boundaryEvent = (BoundaryEvent)bpmnParse.getCurrentFlowElement();
/* 56 */       boolean interrupting = boundaryEvent.isCancelActivity();
/*    */ 
/* 58 */       activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createBoundaryEventActivityBehavior(boundaryEvent, interrupting, activity));
/* 59 */       activity.setProperty("type", "compensationBoundaryCatch");
/*    */ 
/* 61 */       ScopeImpl parent = activity.getParent();
/* 62 */       for (ActivityImpl child : parent.getActivities())
/* 63 */         if ((child.getProperty("type").equals("compensationBoundaryCatch")) && (child != activity))
/* 64 */           bpmnParse.getBpmnModel().addProblem("multiple boundary events with compensateEventDefinition not supported on same activity.", eventDefinition);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.CompensateEventDefinitionParseHandler
 * JD-Core Version:    0.6.0
 */