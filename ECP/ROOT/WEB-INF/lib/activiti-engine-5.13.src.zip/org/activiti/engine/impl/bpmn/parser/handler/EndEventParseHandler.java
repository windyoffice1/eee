/*    */ package org.activiti.engine.impl.bpmn.parser.handler;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.activiti.bpmn.model.BaseElement;
/*    */ import org.activiti.bpmn.model.BpmnModel;
/*    */ import org.activiti.bpmn.model.CancelEventDefinition;
/*    */ import org.activiti.bpmn.model.EndEvent;
/*    */ import org.activiti.bpmn.model.ErrorEventDefinition;
/*    */ import org.activiti.bpmn.model.EventDefinition;
/*    */ import org.activiti.bpmn.model.TerminateEventDefinition;
/*    */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*    */ import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ import org.activiti.engine.impl.pvm.process.ScopeImpl;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class EndEventParseHandler extends AbstractActivityBpmnParseHandler<EndEvent>
/*    */ {
/*    */   public Class<? extends BaseElement> getHandledType()
/*    */   {
/* 33 */     return EndEvent.class;
/*    */   }
/*    */ 
/*    */   protected void executeParse(BpmnParse bpmnParse, EndEvent endEvent)
/*    */   {
/* 38 */     ActivityImpl endEventActivity = createActivityOnCurrentScope(bpmnParse, endEvent, "endEvent");
/* 39 */     EventDefinition eventDefinition = null;
/* 40 */     if (endEvent.getEventDefinitions().size() > 0) {
/* 41 */       eventDefinition = (EventDefinition)endEvent.getEventDefinitions().get(0);
/*    */     }
/*    */ 
/* 45 */     if ((eventDefinition instanceof ErrorEventDefinition)) {
/* 46 */       ErrorEventDefinition errorDefinition = (ErrorEventDefinition)eventDefinition;
/* 47 */       if (bpmnParse.getBpmnModel().containsErrorRef(errorDefinition.getErrorCode())) {
/* 48 */         String errorCode = (String)bpmnParse.getBpmnModel().getErrors().get(errorDefinition.getErrorCode());
/* 49 */         if (StringUtils.isEmpty(errorCode)) {
/* 50 */           bpmnParse.getBpmnModel().addProblem("errorCode is required for an error event", errorDefinition);
/*    */         }
/* 52 */         endEventActivity.setProperty("type", "errorEndEvent");
/* 53 */         errorDefinition.setErrorCode(errorCode);
/*    */       }
/* 55 */       endEventActivity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createErrorEndEventActivityBehavior(endEvent, errorDefinition));
/*    */     }
/* 58 */     else if ((eventDefinition instanceof CancelEventDefinition)) {
/* 59 */       ScopeImpl scope = bpmnParse.getCurrentScope();
/* 60 */       if ((scope.getProperty("type") == null) || (!scope.getProperty("type").equals("transaction"))) {
/* 61 */         bpmnParse.getBpmnModel().addProblem("end event with cancelEventDefinition only supported inside transaction subprocess", endEvent);
/*    */       } else {
/* 63 */         endEventActivity.setProperty("type", "cancelEndEvent");
/* 64 */         endEventActivity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createCancelEndEventActivityBehavior(endEvent));
/*    */       }
/*    */ 
/*    */     }
/* 68 */     else if ((eventDefinition instanceof TerminateEventDefinition)) {
/* 69 */       endEventActivity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createTerminateEndEventActivityBehavior(endEvent));
/*    */     }
/* 72 */     else if (eventDefinition == null) {
/* 73 */       endEventActivity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createNoneEndEventActivityBehavior(endEvent));
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.EndEventParseHandler
 * JD-Core Version:    0.6.0
 */