/*     */ package org.activiti.engine.impl.bpmn.parser.handler;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.activiti.bpmn.model.BaseElement;
/*     */ import org.activiti.bpmn.model.BoundaryEvent;
/*     */ import org.activiti.bpmn.model.BpmnModel;
/*     */ import org.activiti.bpmn.model.StartEvent;
/*     */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*     */ import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
/*     */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*     */ import org.activiti.engine.impl.pvm.process.ScopeImpl;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class ErrorEventDefinitionParseHandler extends AbstractBpmnParseHandler<org.activiti.bpmn.model.ErrorEventDefinition>
/*     */ {
/*     */   public static final String PROPERTYNAME_INITIAL = "initial";
/*     */ 
/*     */   public Class<? extends BaseElement> getHandledType()
/*     */   {
/*  37 */     return org.activiti.bpmn.model.ErrorEventDefinition.class;
/*     */   }
/*     */ 
/*     */   protected void executeParse(BpmnParse bpmnParse, org.activiti.bpmn.model.ErrorEventDefinition eventDefinition)
/*     */   {
/*  42 */     org.activiti.bpmn.model.ErrorEventDefinition modelErrorEvent = eventDefinition;
/*  43 */     if (bpmnParse.getBpmnModel().containsErrorRef(modelErrorEvent.getErrorCode())) {
/*  44 */       String errorCode = (String)bpmnParse.getBpmnModel().getErrors().get(modelErrorEvent.getErrorCode());
/*  45 */       if (StringUtils.isEmpty(errorCode)) {
/*  46 */         bpmnParse.getBpmnModel().addProblem("errorCode is required for an error event", eventDefinition);
/*     */       }
/*  48 */       modelErrorEvent.setErrorCode(errorCode);
/*     */     }
/*     */ 
/*  51 */     ScopeImpl scope = bpmnParse.getCurrentScope();
/*  52 */     ActivityImpl activity = bpmnParse.getCurrentActivity();
/*  53 */     if ((bpmnParse.getCurrentFlowElement() instanceof StartEvent))
/*     */     {
/*  55 */       if (scope.getProperty("initial") == null) {
/*  56 */         scope.setProperty("initial", activity);
/*     */ 
/*  60 */         ScopeImpl catchingScope = ((ActivityImpl)scope).getParent();
/*     */ 
/*  62 */         createErrorStartEventDefinition(modelErrorEvent, activity, catchingScope);
/*     */       } else {
/*  64 */         bpmnParse.getBpmnModel().addProblem("multiple start events not supported for subprocess", bpmnParse.getCurrentSubProcess());
/*     */       }
/*     */     }
/*  67 */     else if ((bpmnParse.getCurrentFlowElement() instanceof BoundaryEvent))
/*     */     {
/*  69 */       BoundaryEvent boundaryEvent = (BoundaryEvent)bpmnParse.getCurrentFlowElement();
/*  70 */       boolean interrupting = true;
/*  71 */       activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createBoundaryEventActivityBehavior(boundaryEvent, interrupting, activity));
/*  72 */       ActivityImpl parentActivity = scope.findActivity(boundaryEvent.getAttachedToRefId());
/*  73 */       createBoundaryErrorEventDefinition(modelErrorEvent, interrupting, parentActivity, activity);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void createErrorStartEventDefinition(org.activiti.bpmn.model.ErrorEventDefinition errorEventDefinition, ActivityImpl startEventActivity, ScopeImpl scope)
/*     */   {
/*  79 */     org.activiti.engine.impl.bpmn.parser.ErrorEventDefinition definition = new org.activiti.engine.impl.bpmn.parser.ErrorEventDefinition(startEventActivity.getId());
/*  80 */     if (StringUtils.isNotEmpty(errorEventDefinition.getErrorCode())) {
/*  81 */       definition.setErrorCode(errorEventDefinition.getErrorCode());
/*     */     }
/*  83 */     definition.setPrecedence(Integer.valueOf(10));
/*  84 */     addErrorEventDefinition(definition, scope);
/*     */   }
/*     */ 
/*     */   public void createBoundaryErrorEventDefinition(org.activiti.bpmn.model.ErrorEventDefinition errorEventDefinition, boolean interrupting, ActivityImpl activity, ActivityImpl nestedErrorEventActivity)
/*     */   {
/*  90 */     nestedErrorEventActivity.setProperty("type", "boundaryError");
/*  91 */     ScopeImpl catchingScope = nestedErrorEventActivity.getParent();
/*  92 */     ((ActivityImpl)catchingScope).setScope(true);
/*     */ 
/*  94 */     org.activiti.engine.impl.bpmn.parser.ErrorEventDefinition definition = new org.activiti.engine.impl.bpmn.parser.ErrorEventDefinition(nestedErrorEventActivity.getId());
/*     */ 
/*  96 */     definition.setErrorCode(errorEventDefinition.getErrorCode());
/*     */ 
/*  98 */     addErrorEventDefinition(definition, catchingScope);
/*     */   }
/*     */ 
/*     */   protected void addErrorEventDefinition(org.activiti.engine.impl.bpmn.parser.ErrorEventDefinition errorEventDefinition, ScopeImpl catchingScope)
/*     */   {
/* 104 */     List errorEventDefinitions = (List)catchingScope.getProperty("errorEventDefinitions");
/*     */ 
/* 106 */     if (errorEventDefinitions == null) {
/* 107 */       errorEventDefinitions = new ArrayList();
/* 108 */       catchingScope.setProperty("errorEventDefinitions", errorEventDefinitions);
/*     */     }
/* 110 */     errorEventDefinitions.add(errorEventDefinition);
/* 111 */     Collections.sort(errorEventDefinitions, org.activiti.engine.impl.bpmn.parser.ErrorEventDefinition.comparator);
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.ErrorEventDefinitionParseHandler
 * JD-Core Version:    0.6.0
 */