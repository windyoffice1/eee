/*    */ package org.activiti.engine.impl.bpmn.parser.handler;
/*    */ 
/*    */ import org.activiti.bpmn.model.BaseElement;
/*    */ import org.activiti.bpmn.model.EventSubProcess;
/*    */ 
/*    */ public class EventSubProcessParseHandler extends SubProcessParseHandler
/*    */ {
/*    */   protected Class<? extends BaseElement> getHandledType()
/*    */   {
/* 25 */     return EventSubProcess.class;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.EventSubProcessParseHandler
 * JD-Core Version:    0.6.0
 */