/*    */ package org.activiti.engine.impl.bpmn.parser.handler;
/*    */ 
/*    */ import org.activiti.bpmn.model.BaseElement;
/*    */ import org.activiti.bpmn.model.InclusiveGateway;
/*    */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*    */ import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ 
/*    */ public class InclusiveGatewayParseHandler extends AbstractActivityBpmnParseHandler<InclusiveGateway>
/*    */ {
/*    */   public Class<? extends BaseElement> getHandledType()
/*    */   {
/* 28 */     return InclusiveGateway.class;
/*    */   }
/*    */ 
/*    */   protected void executeParse(BpmnParse bpmnParse, InclusiveGateway gateway) {
/* 32 */     ActivityImpl activity = createActivityOnCurrentScope(bpmnParse, gateway, "inclusiveGateway");
/* 33 */     activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createInclusiveGatewayActivityBehavior(gateway));
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.InclusiveGatewayParseHandler
 * JD-Core Version:    0.6.0
 */