/*    */ package org.activiti.engine.impl.bpmn.parser.handler;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.activiti.bpmn.model.BaseElement;
/*    */ import org.activiti.bpmn.model.BpmnModel;
/*    */ import org.activiti.bpmn.model.EventDefinition;
/*    */ import org.activiti.bpmn.model.IntermediateCatchEvent;
/*    */ import org.activiti.bpmn.model.MessageEventDefinition;
/*    */ import org.activiti.bpmn.model.SignalEventDefinition;
/*    */ import org.activiti.bpmn.model.TimerEventDefinition;
/*    */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*    */ import org.activiti.engine.impl.bpmn.parser.BpmnParseHandlers;
/*    */ import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ import org.activiti.engine.impl.pvm.process.ScopeImpl;
/*    */ 
/*    */ public class IntermediateCatchEventParseHandler extends AbstractActivityBpmnParseHandler<IntermediateCatchEvent>
/*    */ {
/*    */   public Class<? extends BaseElement> getHandledType()
/*    */   {
/* 34 */     return IntermediateCatchEvent.class;
/*    */   }
/*    */ 
/*    */   protected void executeParse(BpmnParse bpmnParse, IntermediateCatchEvent event)
/*    */   {
/* 39 */     BpmnModel bpmnModel = bpmnParse.getBpmnModel();
/* 40 */     ActivityImpl nestedActivity = null;
/* 41 */     EventDefinition eventDefinition = null;
/* 42 */     if (event.getEventDefinitions().size() > 0) {
/* 43 */       eventDefinition = (EventDefinition)event.getEventDefinitions().get(0);
/*    */     }
/*    */ 
/* 46 */     if (eventDefinition == null)
/*    */     {
/* 48 */       bpmnModel.addProblem("No event definition for intermediate catch event " + event.getId(), event);
/* 49 */       nestedActivity = createActivityOnCurrentScope(bpmnParse, event, "intermediateCatchEvent");
/*    */     }
/*    */     else
/*    */     {
/* 53 */       ScopeImpl scope = bpmnParse.getCurrentScope();
/* 54 */       String eventBasedGatewayId = getPrecedingEventBasedGateway(bpmnParse, event);
/* 55 */       if (eventBasedGatewayId != null) {
/* 56 */         ActivityImpl gatewayActivity = scope.findActivity(eventBasedGatewayId);
/* 57 */         nestedActivity = createActivityOnScope(bpmnParse, event, "intermediateCatchEvent", gatewayActivity);
/*    */       } else {
/* 59 */         nestedActivity = createActivityOnScope(bpmnParse, event, "intermediateCatchEvent", scope);
/*    */       }
/*    */ 
/* 63 */       nestedActivity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createIntermediateCatchEventActivityBehavior(event));
/*    */ 
/* 65 */       if (((eventDefinition instanceof TimerEventDefinition)) || ((eventDefinition instanceof SignalEventDefinition)) || ((eventDefinition instanceof MessageEventDefinition)))
/*    */       {
/* 69 */         bpmnParse.getBpmnParserHandlers().parseElement(bpmnParse, eventDefinition);
/*    */       }
/*    */       else
/* 72 */         bpmnModel.addProblem("Unsupported intermediate catch event type.", event);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.IntermediateCatchEventParseHandler
 * JD-Core Version:    0.6.0
 */