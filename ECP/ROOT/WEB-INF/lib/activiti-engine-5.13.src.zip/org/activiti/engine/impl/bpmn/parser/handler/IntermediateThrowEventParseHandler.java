/*    */ package org.activiti.engine.impl.bpmn.parser.handler;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.activiti.bpmn.model.BaseElement;
/*    */ import org.activiti.bpmn.model.BpmnModel;
/*    */ import org.activiti.bpmn.model.EventDefinition;
/*    */ import org.activiti.bpmn.model.SignalEventDefinition;
/*    */ import org.activiti.bpmn.model.ThrowEvent;
/*    */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*    */ import org.activiti.engine.impl.bpmn.parser.BpmnParseHandlers;
/*    */ import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ import org.activiti.engine.impl.pvm.process.ScopeImpl;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class IntermediateThrowEventParseHandler extends AbstractActivityBpmnParseHandler<ThrowEvent>
/*    */ {
/*    */   public Class<? extends BaseElement> getHandledType()
/*    */   {
/* 34 */     return ThrowEvent.class;
/*    */   }
/*    */ 
/*    */   protected void executeParse(BpmnParse bpmnParse, ThrowEvent intermediateEvent)
/*    */   {
/* 39 */     BpmnModel bpmnModel = bpmnParse.getBpmnModel();
/*    */ 
/* 41 */     ActivityImpl nestedActivityImpl = createActivityOnCurrentScope(bpmnParse, intermediateEvent, "intermediateThrowEvent");
/*    */ 
/* 43 */     EventDefinition eventDefinition = null;
/* 44 */     if (intermediateEvent.getEventDefinitions().size() > 0) {
/* 45 */       eventDefinition = (EventDefinition)intermediateEvent.getEventDefinitions().get(0);
/*    */     }
/*    */ 
/* 48 */     if ((eventDefinition instanceof SignalEventDefinition))
/* 49 */       bpmnParse.getBpmnParserHandlers().parseElement(bpmnParse, eventDefinition);
/* 50 */     else if ((eventDefinition instanceof org.activiti.bpmn.model.CompensateEventDefinition))
/* 51 */       bpmnParse.getBpmnParserHandlers().parseElement(bpmnParse, eventDefinition);
/* 52 */     else if (eventDefinition == null)
/* 53 */       nestedActivityImpl.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createIntermediateThrowNoneEventActivityBehavior(intermediateEvent));
/*    */     else
/* 55 */       bpmnModel.addProblem("Unsupported intermediate throw event type " + eventDefinition, intermediateEvent);
/*    */   }
/*    */ 
/*    */   protected org.activiti.engine.impl.bpmn.parser.CompensateEventDefinition createCompensateEventDefinition(BpmnParse bpmnParse, org.activiti.bpmn.model.CompensateEventDefinition eventDefinition, ScopeImpl scopeElement)
/*    */   {
/* 60 */     if ((StringUtils.isNotEmpty(eventDefinition.getActivityRef())) && 
/* 61 */       (scopeElement.findActivity(eventDefinition.getActivityRef()) == null)) {
/* 62 */       bpmnParse.getBpmnModel().addProblem("Invalid attribute value for 'activityRef': no activity with id '" + eventDefinition.getActivityRef() + "' in current scope " + scopeElement.getId(), eventDefinition);
/*    */     }
/*    */ 
/* 67 */     org.activiti.engine.impl.bpmn.parser.CompensateEventDefinition compensateEventDefinition = new org.activiti.engine.impl.bpmn.parser.CompensateEventDefinition();
/* 68 */     compensateEventDefinition.setActivityRef(eventDefinition.getActivityRef());
/* 69 */     compensateEventDefinition.setWaitForCompletion(eventDefinition.isWaitForCompletion());
/*    */ 
/* 71 */     return compensateEventDefinition;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.IntermediateThrowEventParseHandler
 * JD-Core Version:    0.6.0
 */