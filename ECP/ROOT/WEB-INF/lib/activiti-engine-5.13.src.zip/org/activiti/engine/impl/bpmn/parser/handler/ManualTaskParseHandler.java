/*    */ package org.activiti.engine.impl.bpmn.parser.handler;
/*    */ 
/*    */ import org.activiti.bpmn.model.BaseElement;
/*    */ import org.activiti.bpmn.model.ManualTask;
/*    */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*    */ import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ 
/*    */ public class ManualTaskParseHandler extends AbstractActivityBpmnParseHandler<ManualTask>
/*    */ {
/*    */   public Class<? extends BaseElement> getHandledType()
/*    */   {
/* 28 */     return ManualTask.class;
/*    */   }
/*    */ 
/*    */   protected void executeParse(BpmnParse bpmnParse, ManualTask manualTask) {
/* 32 */     ActivityImpl activity = createActivityOnCurrentScope(bpmnParse, manualTask, "manualTask");
/* 33 */     activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createManualTaskActivityBehavior(manualTask));
/*    */ 
/* 35 */     activity.setAsync(manualTask.isAsynchronous());
/* 36 */     activity.setExclusive(!manualTask.isNotExclusive());
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.ManualTaskParseHandler
 * JD-Core Version:    0.6.0
 */