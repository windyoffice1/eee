/*    */ package org.activiti.engine.impl.bpmn.parser.handler;
/*    */ 
/*    */ import org.activiti.bpmn.model.BaseElement;
/*    */ import org.activiti.bpmn.model.BoundaryEvent;
/*    */ import org.activiti.bpmn.model.BpmnModel;
/*    */ import org.activiti.bpmn.model.IntermediateCatchEvent;
/*    */ import org.activiti.bpmn.model.Message;
/*    */ import org.activiti.bpmn.model.MessageEventDefinition;
/*    */ import org.activiti.bpmn.model.StartEvent;
/*    */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*    */ import org.activiti.engine.impl.bpmn.parser.EventSubscriptionDeclaration;
/*    */ import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ import org.activiti.engine.impl.pvm.process.ScopeImpl;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class MessageEventDefinitionParseHandler extends AbstractBpmnParseHandler<MessageEventDefinition>
/*    */ {
/*    */   public Class<? extends BaseElement> getHandledType()
/*    */   {
/* 33 */     return MessageEventDefinition.class;
/*    */   }
/*    */ 
/*    */   protected void executeParse(BpmnParse bpmnParse, MessageEventDefinition messageDefinition)
/*    */   {
/* 38 */     if (bpmnParse.getBpmnModel().containsMessageId(messageDefinition.getMessageRef())) {
/* 39 */       String messageName = bpmnParse.getBpmnModel().getMessage(messageDefinition.getMessageRef()).getName();
/* 40 */       if (StringUtils.isEmpty(messageName)) {
/* 41 */         bpmnParse.getBpmnModel().addProblem("messageName is required for a message event", messageDefinition);
/*    */       }
/* 43 */       messageDefinition.setMessageRef(messageName);
/*    */     }
/*    */ 
/* 46 */     EventSubscriptionDeclaration eventSubscription = new EventSubscriptionDeclaration(messageDefinition.getMessageRef(), "message");
/*    */ 
/* 48 */     ScopeImpl scope = bpmnParse.getCurrentScope();
/* 49 */     ActivityImpl activity = bpmnParse.getCurrentActivity();
/* 50 */     if (((bpmnParse.getCurrentFlowElement() instanceof StartEvent)) && (bpmnParse.getCurrentSubProcess() != null))
/*    */     {
/* 54 */       ScopeImpl catchingScope = ((ActivityImpl)scope).getParent();
/*    */ 
/* 56 */       EventSubscriptionDeclaration eventSubscriptionDeclaration = new EventSubscriptionDeclaration(messageDefinition.getMessageRef(), "message");
/* 57 */       eventSubscriptionDeclaration.setActivityId(activity.getId());
/* 58 */       eventSubscriptionDeclaration.setStartEvent(false);
/* 59 */       addEventSubscriptionDeclaration(bpmnParse, eventSubscriptionDeclaration, messageDefinition, catchingScope);
/*    */     }
/* 61 */     else if ((bpmnParse.getCurrentFlowElement() instanceof StartEvent))
/*    */     {
/* 63 */       activity.setProperty("type", "messageStartEvent");
/* 64 */       eventSubscription.setStartEvent(true);
/* 65 */       eventSubscription.setActivityId(activity.getId());
/* 66 */       addEventSubscriptionDeclaration(bpmnParse, eventSubscription, messageDefinition, bpmnParse.getCurrentProcessDefinition());
/*    */     }
/* 68 */     else if ((bpmnParse.getCurrentFlowElement() instanceof IntermediateCatchEvent))
/*    */     {
/* 70 */       activity.setProperty("type", "intermediateMessageCatch");
/*    */ 
/* 72 */       if (getPrecedingEventBasedGateway(bpmnParse, (IntermediateCatchEvent)bpmnParse.getCurrentFlowElement()) != null) {
/* 73 */         eventSubscription.setActivityId(activity.getId());
/* 74 */         addEventSubscriptionDeclaration(bpmnParse, eventSubscription, messageDefinition, activity.getParent());
/*    */       } else {
/* 76 */         activity.setScope(true);
/* 77 */         addEventSubscriptionDeclaration(bpmnParse, eventSubscription, messageDefinition, activity);
/*    */       }
/*    */     }
/* 80 */     else if ((bpmnParse.getCurrentFlowElement() instanceof BoundaryEvent))
/*    */     {
/* 82 */       BoundaryEvent boundaryEvent = (BoundaryEvent)bpmnParse.getCurrentFlowElement();
/* 83 */       boolean interrupting = boundaryEvent.isCancelActivity();
/* 84 */       activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createBoundaryEventActivityBehavior(boundaryEvent, interrupting, activity));
/*    */ 
/* 86 */       activity.setProperty("type", "boundaryMessage");
/*    */ 
/* 88 */       EventSubscriptionDeclaration eventSubscriptionDeclaration = new EventSubscriptionDeclaration(messageDefinition.getMessageRef(), "message");
/* 89 */       eventSubscriptionDeclaration.setActivityId(activity.getId());
/* 90 */       addEventSubscriptionDeclaration(bpmnParse, eventSubscriptionDeclaration, messageDefinition, activity.getParent());
/*    */ 
/* 92 */       if ((activity.getParent() instanceof ActivityImpl))
/* 93 */         ((ActivityImpl)activity.getParent()).setScope(true);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.MessageEventDefinitionParseHandler
 * JD-Core Version:    0.6.0
 */