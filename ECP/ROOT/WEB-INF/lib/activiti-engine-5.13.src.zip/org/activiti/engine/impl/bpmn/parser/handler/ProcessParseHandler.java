/*    */ package org.activiti.engine.impl.bpmn.parser.handler;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import org.activiti.bpmn.model.BaseElement;
/*    */ import org.activiti.bpmn.model.BpmnModel;
/*    */ import org.activiti.bpmn.model.Process;
/*    */ import org.activiti.engine.impl.bpmn.data.IOSpecification;
/*    */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*    */ import org.activiti.engine.impl.el.ExpressionManager;
/*    */ import org.activiti.engine.impl.persistence.entity.DeploymentEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class ProcessParseHandler extends AbstractBpmnParseHandler<Process>
/*    */ {
/* 32 */   private static final Logger LOGGER = LoggerFactory.getLogger(ProcessParseHandler.class);
/*    */   public static final String PROPERTYNAME_DOCUMENTATION = "documentation";
/*    */ 
/*    */   public Class<? extends BaseElement> getHandledType()
/*    */   {
/* 37 */     return Process.class;
/*    */   }
/*    */ 
/*    */   protected void executeParse(BpmnParse bpmnParse, Process process) {
/* 41 */     if (!process.isExecutable())
/* 42 */       LOGGER.info("Ignoring non-executable process with id='" + process.getId() + "'. Set the attribute isExecutable=\"true\" to deploy this process.");
/*    */     else
/* 44 */       bpmnParse.getProcessDefinitions().add(transformProcess(bpmnParse, process));
/*    */   }
/*    */ 
/*    */   protected ProcessDefinitionEntity transformProcess(BpmnParse bpmnParse, Process process)
/*    */   {
/* 49 */     ProcessDefinitionEntity currentProcessDefinition = new ProcessDefinitionEntity();
/* 50 */     bpmnParse.setCurrentProcessDefinition(currentProcessDefinition);
/*    */ 
/* 57 */     currentProcessDefinition.setKey(process.getId());
/* 58 */     currentProcessDefinition.setName(process.getName());
/* 59 */     currentProcessDefinition.setCategory(bpmnParse.getBpmnModel().getTargetNamespace());
/* 60 */     currentProcessDefinition.setDescription(process.getDocumentation());
/* 61 */     currentProcessDefinition.setProperty("documentation", process.getDocumentation());
/* 62 */     currentProcessDefinition.setTaskDefinitions(new HashMap());
/* 63 */     currentProcessDefinition.setDeploymentId(bpmnParse.getDeployment().getId());
/* 64 */     createExecutionListenersOnScope(bpmnParse, process.getExecutionListeners(), currentProcessDefinition);
/*    */ 
/* 66 */     ExpressionManager expressionManager = bpmnParse.getExpressionManager();
/*    */ 
/* 68 */     for (String candidateUser : process.getCandidateStarterUsers()) {
/* 69 */       currentProcessDefinition.addCandidateStarterUserIdExpression(expressionManager.createExpression(candidateUser));
/*    */     }
/*    */ 
/* 72 */     for (String candidateGroup : process.getCandidateStarterGroups()) {
/* 73 */       currentProcessDefinition.addCandidateStarterGroupIdExpression(expressionManager.createExpression(candidateGroup));
/*    */     }
/*    */ 
/* 76 */     if (LOGGER.isDebugEnabled()) {
/* 77 */       LOGGER.debug("Parsing process {}", currentProcessDefinition.getKey());
/*    */     }
/*    */ 
/* 80 */     bpmnParse.setCurrentScope(currentProcessDefinition);
/*    */ 
/* 82 */     bpmnParse.processFlowElements(process.getFlowElements());
/* 83 */     processArtifacts(bpmnParse, process.getArtifacts(), currentProcessDefinition);
/*    */ 
/* 85 */     bpmnParse.removeCurrentScope();
/*    */ 
/* 87 */     if (process.getIoSpecification() != null) {
/* 88 */       IOSpecification ioSpecification = createIOSpecification(bpmnParse, process.getIoSpecification());
/* 89 */       currentProcessDefinition.setIoSpecification(ioSpecification);
/*    */     }
/* 91 */     return currentProcessDefinition;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.ProcessParseHandler
 * JD-Core Version:    0.6.0
 */