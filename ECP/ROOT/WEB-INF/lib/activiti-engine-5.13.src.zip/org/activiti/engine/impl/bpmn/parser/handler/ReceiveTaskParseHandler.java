/*    */ package org.activiti.engine.impl.bpmn.parser.handler;
/*    */ 
/*    */ import org.activiti.bpmn.model.BaseElement;
/*    */ import org.activiti.bpmn.model.ReceiveTask;
/*    */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*    */ import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ 
/*    */ public class ReceiveTaskParseHandler extends AbstractActivityBpmnParseHandler<ReceiveTask>
/*    */ {
/*    */   public Class<? extends BaseElement> getHandledType()
/*    */   {
/* 28 */     return ReceiveTask.class;
/*    */   }
/*    */ 
/*    */   protected void executeParse(BpmnParse bpmnParse, ReceiveTask receiveTask) {
/* 32 */     ActivityImpl activity = createActivityOnCurrentScope(bpmnParse, receiveTask, "receiveTask");
/* 33 */     activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createReceiveTaskActivityBehavior(receiveTask));
/*    */ 
/* 35 */     activity.setAsync(receiveTask.isAsynchronous());
/* 36 */     activity.setExclusive(!receiveTask.isNotExclusive());
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.ReceiveTaskParseHandler
 * JD-Core Version:    0.6.0
 */