/*    */ package org.activiti.engine.impl.bpmn.parser.handler;
/*    */ 
/*    */ import org.activiti.bpmn.model.BaseElement;
/*    */ import org.activiti.bpmn.model.BpmnModel;
/*    */ import org.activiti.bpmn.model.ScriptTask;
/*    */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*    */ import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ 
/*    */ public class ScriptTaskParseHandler extends AbstractActivityBpmnParseHandler<ScriptTask>
/*    */ {
/*    */   public Class<? extends BaseElement> getHandledType()
/*    */   {
/* 28 */     return ScriptTask.class;
/*    */   }
/*    */ 
/*    */   protected void executeParse(BpmnParse bpmnParse, ScriptTask scriptTask)
/*    */   {
/* 33 */     if (scriptTask.getScript() == null) {
/* 34 */       bpmnParse.getBpmnModel().addProblem("No script provided for scriptTask. ", scriptTask);
/*    */     }
/*    */ 
/* 37 */     ActivityImpl activity = createActivityOnCurrentScope(bpmnParse, scriptTask, "scriptTask");
/*    */ 
/* 39 */     activity.setAsync(scriptTask.isAsynchronous());
/* 40 */     activity.setExclusive(!scriptTask.isNotExclusive());
/*    */ 
/* 42 */     activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createScriptTaskActivityBehavior(scriptTask));
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.ScriptTaskParseHandler
 * JD-Core Version:    0.6.0
 */