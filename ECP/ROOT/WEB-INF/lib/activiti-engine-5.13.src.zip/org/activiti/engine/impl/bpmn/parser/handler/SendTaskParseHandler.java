/*    */ package org.activiti.engine.impl.bpmn.parser.handler;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.activiti.bpmn.model.BaseElement;
/*    */ import org.activiti.bpmn.model.BpmnModel;
/*    */ import org.activiti.bpmn.model.DataAssociation;
/*    */ import org.activiti.bpmn.model.ImplementationType;
/*    */ import org.activiti.bpmn.model.SendTask;
/*    */ import org.activiti.engine.impl.bpmn.behavior.WebServiceActivityBehavior;
/*    */ import org.activiti.engine.impl.bpmn.data.AbstractDataAssociation;
/*    */ import org.activiti.engine.impl.bpmn.data.IOSpecification;
/*    */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*    */ import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
/*    */ import org.activiti.engine.impl.bpmn.webservice.Operation;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class SendTaskParseHandler extends AbstractExternalInvocationBpmnParseHandler<SendTask>
/*    */ {
/*    */   public Class<? extends BaseElement> getHandledType()
/*    */   {
/* 35 */     return SendTask.class;
/*    */   }
/*    */ 
/*    */   protected void executeParse(BpmnParse bpmnParse, SendTask sendTask)
/*    */   {
/* 40 */     ActivityImpl activity = createActivityOnCurrentScope(bpmnParse, sendTask, "sendTask");
/*    */ 
/* 42 */     activity.setAsync(sendTask.isAsynchronous());
/* 43 */     activity.setExclusive(!sendTask.isNotExclusive());
/*    */ 
/* 46 */     if (StringUtils.isNotEmpty(sendTask.getType())) {
/* 47 */       if (sendTask.getType().equalsIgnoreCase("mail")) {
/* 48 */         validateFieldDeclarationsForEmail(bpmnParse, sendTask, sendTask.getFieldExtensions());
/* 49 */         activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createMailActivityBehavior(sendTask));
/* 50 */       } else if (sendTask.getType().equalsIgnoreCase("mule")) {
/* 51 */         activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createMuleActivityBehavior(sendTask, bpmnParse.getBpmnModel()));
/* 52 */       } else if (sendTask.getType().equalsIgnoreCase("camel")) {
/* 53 */         activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createCamelActivityBehavior(sendTask, bpmnParse.getBpmnModel()));
/*    */       } else {
/* 55 */         bpmnParse.getBpmnModel().addProblem("Invalid usage of type attribute: '" + sendTask.getType() + "'.", sendTask);
/*    */       }
/*    */ 
/*    */     }
/* 59 */     else if ((ImplementationType.IMPLEMENTATION_TYPE_WEBSERVICE.equalsIgnoreCase(sendTask.getImplementationType())) && (StringUtils.isNotEmpty(sendTask.getOperationRef())))
/*    */     {
/* 62 */       if (!bpmnParse.getOperations().containsKey(sendTask.getOperationRef())) {
/* 63 */         bpmnParse.getBpmnModel().addProblem(sendTask.getOperationRef() + " does not exist", sendTask);
/*    */       } else {
/* 65 */         WebServiceActivityBehavior webServiceActivityBehavior = bpmnParse.getActivityBehaviorFactory().createWebServiceActivityBehavior(sendTask);
/* 66 */         Operation operation = (Operation)bpmnParse.getOperations().get(sendTask.getOperationRef());
/* 67 */         webServiceActivityBehavior.setOperation(operation);
/*    */ 
/* 69 */         if (sendTask.getIoSpecification() != null) {
/* 70 */           IOSpecification ioSpecification = createIOSpecification(bpmnParse, sendTask.getIoSpecification());
/* 71 */           webServiceActivityBehavior.setIoSpecification(ioSpecification);
/*    */         }
/*    */ 
/* 74 */         for (DataAssociation dataAssociationElement : sendTask.getDataInputAssociations()) {
/* 75 */           AbstractDataAssociation dataAssociation = createDataInputAssociation(bpmnParse, dataAssociationElement);
/* 76 */           webServiceActivityBehavior.addDataInputAssociation(dataAssociation);
/*    */         }
/*    */ 
/* 79 */         for (DataAssociation dataAssociationElement : sendTask.getDataOutputAssociations()) {
/* 80 */           AbstractDataAssociation dataAssociation = createDataOutputAssociation(bpmnParse, dataAssociationElement);
/* 81 */           webServiceActivityBehavior.addDataOutputAssociation(dataAssociation);
/*    */         }
/*    */ 
/* 84 */         activity.setActivityBehavior(webServiceActivityBehavior);
/*    */       }
/*    */     }
/* 87 */     else bpmnParse.getBpmnModel().addProblem("One of the attributes 'type' or 'operation' is mandatory on sendTask.", sendTask);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.SendTaskParseHandler
 * JD-Core Version:    0.6.0
 */