/*    */ package org.activiti.engine.impl.bpmn.parser.handler;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.activiti.bpmn.model.BaseElement;
/*    */ import org.activiti.bpmn.model.BpmnModel;
/*    */ import org.activiti.bpmn.model.SequenceFlow;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.impl.Condition;
/*    */ import org.activiti.engine.impl.bpmn.behavior.EventBasedGatewayActivityBehavior;
/*    */ import org.activiti.engine.impl.bpmn.behavior.IntermediateCatchEventActivityBehavior;
/*    */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*    */ import org.activiti.engine.impl.el.ExpressionManager;
/*    */ import org.activiti.engine.impl.el.UelExpressionCondition;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ import org.activiti.engine.impl.pvm.process.ScopeImpl;
/*    */ import org.activiti.engine.impl.pvm.process.TransitionImpl;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class SequenceFlowParseHandler extends AbstractBpmnParseHandler<SequenceFlow>
/*    */ {
/*    */   public static final String PROPERTYNAME_CONDITION = "condition";
/*    */   public static final String PROPERTYNAME_CONDITION_TEXT = "conditionText";
/*    */ 
/*    */   public Class<? extends BaseElement> getHandledType()
/*    */   {
/* 38 */     return SequenceFlow.class;
/*    */   }
/*    */ 
/*    */   protected void executeParse(BpmnParse bpmnParse, SequenceFlow sequenceFlow)
/*    */   {
/* 43 */     BpmnModel bpmnModel = bpmnParse.getBpmnModel();
/* 44 */     ScopeImpl scope = bpmnParse.getCurrentScope();
/*    */ 
/* 48 */     ActivityImpl sourceActivity = scope.findActivity(sequenceFlow.getSourceRef());
/* 49 */     ActivityImpl destinationActivity = scope.findActivity(sequenceFlow.getTargetRef());
/*    */ 
/* 51 */     if (sourceActivity == null) {
/* 52 */       bpmnModel.addProblem("Invalid source '" + sequenceFlow.getSourceRef() + "' of sequence flow '" + sequenceFlow.getId() + "'", sequenceFlow); } else {
/* 53 */       if (destinationActivity == null)
/* 54 */         throw new ActivitiException("Invalid destination '" + sequenceFlow.getTargetRef() + "' of sequence flow '" + sequenceFlow.getId() + "'");
/* 55 */       if ((!(sourceActivity.getActivityBehavior() instanceof EventBasedGatewayActivityBehavior)) && ((destinationActivity.getActivityBehavior() instanceof IntermediateCatchEventActivityBehavior)) && (destinationActivity.getParentActivity() != null) && ((destinationActivity.getParentActivity().getActivityBehavior() instanceof EventBasedGatewayActivityBehavior)))
/*    */       {
/* 59 */         bpmnModel.addProblem("Invalid incoming sequenceflow " + sequenceFlow.getId() + " for intermediateCatchEvent with id '" + destinationActivity.getId() + "' connected to an event-based gateway.", sequenceFlow);
/*    */       }
/*    */       else
/*    */       {
/* 63 */         TransitionImpl transition = sourceActivity.createOutgoingTransition(sequenceFlow.getId());
/* 64 */         bpmnParse.getSequenceFlows().put(sequenceFlow.getId(), transition);
/* 65 */         transition.setProperty("name", sequenceFlow.getName());
/* 66 */         transition.setProperty("documentation", sequenceFlow.getDocumentation());
/* 67 */         transition.setDestination(destinationActivity);
/*    */ 
/* 69 */         if (StringUtils.isNotEmpty(sequenceFlow.getConditionExpression())) {
/* 70 */           Condition expressionCondition = new UelExpressionCondition(bpmnParse.getExpressionManager().createExpression(sequenceFlow.getConditionExpression()));
/* 71 */           transition.setProperty("conditionText", sequenceFlow.getConditionExpression());
/* 72 */           transition.setProperty("condition", expressionCondition);
/*    */         }
/*    */ 
/* 75 */         createExecutionListenersOnTransition(bpmnParse, sequenceFlow.getExecutionListeners(), transition);
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.SequenceFlowParseHandler
 * JD-Core Version:    0.6.0
 */