/*    */ package org.activiti.engine.impl.bpmn.parser.handler;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.activiti.bpmn.model.BaseElement;
/*    */ import org.activiti.bpmn.model.BpmnModel;
/*    */ import org.activiti.bpmn.model.DataAssociation;
/*    */ import org.activiti.bpmn.model.ImplementationType;
/*    */ import org.activiti.bpmn.model.ServiceTask;
/*    */ import org.activiti.engine.impl.bpmn.behavior.WebServiceActivityBehavior;
/*    */ import org.activiti.engine.impl.bpmn.data.AbstractDataAssociation;
/*    */ import org.activiti.engine.impl.bpmn.data.IOSpecification;
/*    */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*    */ import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
/*    */ import org.activiti.engine.impl.bpmn.webservice.Operation;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class ServiceTaskParseHandler extends AbstractExternalInvocationBpmnParseHandler<ServiceTask>
/*    */ {
/*    */   public Class<? extends BaseElement> getHandledType()
/*    */   {
/* 34 */     return ServiceTask.class;
/*    */   }
/*    */ 
/*    */   protected void executeParse(BpmnParse bpmnParse, ServiceTask serviceTask)
/*    */   {
/* 39 */     ActivityImpl activity = createActivityOnCurrentScope(bpmnParse, serviceTask, "serviceTask");
/* 40 */     activity.setAsync(serviceTask.isAsynchronous());
/* 41 */     activity.setExclusive(!serviceTask.isNotExclusive());
/*    */ 
/* 44 */     if (StringUtils.isNotEmpty(serviceTask.getType()))
/*    */     {
/* 46 */       if (serviceTask.getType().equalsIgnoreCase("mail")) {
/* 47 */         validateFieldDeclarationsForEmail(bpmnParse, serviceTask, serviceTask.getFieldExtensions());
/* 48 */         activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createMailActivityBehavior(serviceTask));
/*    */       }
/* 50 */       else if (serviceTask.getType().equalsIgnoreCase("mule")) {
/* 51 */         activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createMuleActivityBehavior(serviceTask, bpmnParse.getBpmnModel()));
/*    */       }
/* 53 */       else if (serviceTask.getType().equalsIgnoreCase("camel")) {
/* 54 */         activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createCamelActivityBehavior(serviceTask, bpmnParse.getBpmnModel()));
/*    */       }
/* 56 */       else if (serviceTask.getType().equalsIgnoreCase("shell")) {
/* 57 */         validateFieldDeclarationsForShell(bpmnParse, serviceTask, serviceTask.getFieldExtensions());
/* 58 */         activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createShellActivityBehavior(serviceTask));
/*    */       }
/*    */       else {
/* 61 */         bpmnParse.getBpmnModel().addProblem("Invalid usage of type attribute: '" + serviceTask.getType() + "'.", serviceTask);
/*    */       }
/*    */ 
/*    */     }
/* 65 */     else if (ImplementationType.IMPLEMENTATION_TYPE_CLASS.equalsIgnoreCase(serviceTask.getImplementationType())) {
/* 66 */       activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createClassDelegateServiceTask(serviceTask));
/*    */     }
/* 69 */     else if (ImplementationType.IMPLEMENTATION_TYPE_DELEGATEEXPRESSION.equalsIgnoreCase(serviceTask.getImplementationType())) {
/* 70 */       activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createServiceTaskDelegateExpressionActivityBehavior(serviceTask));
/*    */     }
/* 73 */     else if (ImplementationType.IMPLEMENTATION_TYPE_EXPRESSION.equalsIgnoreCase(serviceTask.getImplementationType())) {
/* 74 */       activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createServiceTaskExpressionActivityBehavior(serviceTask));
/*    */     }
/* 77 */     else if ((ImplementationType.IMPLEMENTATION_TYPE_WEBSERVICE.equalsIgnoreCase(serviceTask.getImplementationType())) && (StringUtils.isNotEmpty(serviceTask.getOperationRef())))
/*    */     {
/* 80 */       if (!bpmnParse.getOperations().containsKey(serviceTask.getOperationRef())) {
/* 81 */         bpmnParse.getBpmnModel().addProblem(serviceTask.getOperationRef() + " does not exist", serviceTask);
/*    */       }
/*    */       else {
/* 84 */         WebServiceActivityBehavior webServiceActivityBehavior = bpmnParse.getActivityBehaviorFactory().createWebServiceActivityBehavior(serviceTask);
/* 85 */         webServiceActivityBehavior.setOperation((Operation)bpmnParse.getOperations().get(serviceTask.getOperationRef()));
/*    */ 
/* 87 */         if (serviceTask.getIoSpecification() != null) {
/* 88 */           IOSpecification ioSpecification = createIOSpecification(bpmnParse, serviceTask.getIoSpecification());
/* 89 */           webServiceActivityBehavior.setIoSpecification(ioSpecification);
/*    */         }
/*    */ 
/* 92 */         for (DataAssociation dataAssociationElement : serviceTask.getDataInputAssociations()) {
/* 93 */           AbstractDataAssociation dataAssociation = createDataInputAssociation(bpmnParse, dataAssociationElement);
/* 94 */           webServiceActivityBehavior.addDataInputAssociation(dataAssociation);
/*    */         }
/*    */ 
/* 97 */         for (DataAssociation dataAssociationElement : serviceTask.getDataOutputAssociations()) {
/* 98 */           AbstractDataAssociation dataAssociation = createDataOutputAssociation(bpmnParse, dataAssociationElement);
/* 99 */           webServiceActivityBehavior.addDataOutputAssociation(dataAssociation);
/*    */         }
/*    */ 
/* 102 */         activity.setActivityBehavior(webServiceActivityBehavior);
/*    */       }
/*    */     }
/* 105 */     else bpmnParse.getBpmnModel().addProblem("One of the attributes 'class', 'delegateExpression', 'type', 'operation', or 'expression' is mandatory on serviceTask.", serviceTask);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.ServiceTaskParseHandler
 * JD-Core Version:    0.6.0
 */