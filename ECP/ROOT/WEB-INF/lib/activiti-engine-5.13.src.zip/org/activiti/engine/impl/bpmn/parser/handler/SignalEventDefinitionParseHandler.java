/*    */ package org.activiti.engine.impl.bpmn.parser.handler;
/*    */ 
/*    */ import org.activiti.bpmn.model.BaseElement;
/*    */ import org.activiti.bpmn.model.BoundaryEvent;
/*    */ import org.activiti.bpmn.model.BpmnModel;
/*    */ import org.activiti.bpmn.model.IntermediateCatchEvent;
/*    */ import org.activiti.bpmn.model.Signal;
/*    */ import org.activiti.bpmn.model.SignalEventDefinition;
/*    */ import org.activiti.bpmn.model.StartEvent;
/*    */ import org.activiti.bpmn.model.ThrowEvent;
/*    */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*    */ import org.activiti.engine.impl.bpmn.parser.EventSubscriptionDeclaration;
/*    */ import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class SignalEventDefinitionParseHandler extends AbstractBpmnParseHandler<SignalEventDefinition>
/*    */ {
/*    */   public Class<? extends BaseElement> getHandledType()
/*    */   {
/* 34 */     return SignalEventDefinition.class;
/*    */   }
/*    */ 
/*    */   protected void executeParse(BpmnParse bpmnParse, SignalEventDefinition signalDefinition)
/*    */   {
/* 39 */     Signal signal = null;
/* 40 */     if (bpmnParse.getBpmnModel().containsSignalId(signalDefinition.getSignalRef())) {
/* 41 */       signal = bpmnParse.getBpmnModel().getSignal(signalDefinition.getSignalRef());
/* 42 */       String signalName = signal.getName();
/* 43 */       if (StringUtils.isEmpty(signalName)) {
/* 44 */         bpmnParse.getBpmnModel().addProblem("signalName is required for a signal event", signalDefinition);
/*    */       }
/* 46 */       signalDefinition.setSignalRef(signalName);
/*    */     }
/*    */ 
/* 49 */     if (signal == null) {
/* 50 */       return;
/*    */     }
/*    */ 
/* 53 */     ActivityImpl activity = bpmnParse.getCurrentActivity();
/* 54 */     if ((bpmnParse.getCurrentFlowElement() instanceof StartEvent))
/*    */     {
/* 56 */       EventSubscriptionDeclaration eventSubscriptionDeclaration = new EventSubscriptionDeclaration(signalDefinition.getSignalRef(), "signal");
/* 57 */       eventSubscriptionDeclaration.setActivityId(activity.getId());
/* 58 */       eventSubscriptionDeclaration.setStartEvent(false);
/* 59 */       addEventSubscriptionDeclaration(bpmnParse, eventSubscriptionDeclaration, signalDefinition, bpmnParse.getCurrentScope());
/*    */     }
/* 61 */     else if ((bpmnParse.getCurrentFlowElement() instanceof IntermediateCatchEvent))
/*    */     {
/* 63 */       activity.setProperty("type", "intermediateSignalCatch");
/*    */ 
/* 65 */       EventSubscriptionDeclaration eventSubscriptionDeclaration = new EventSubscriptionDeclaration(signalDefinition.getSignalRef(), "signal");
/*    */ 
/* 67 */       if (signal.getScope() != null) {
/* 68 */         eventSubscriptionDeclaration.setConfiguration(signal.getScope());
/*    */       }
/*    */ 
/* 71 */       if (getPrecedingEventBasedGateway(bpmnParse, (IntermediateCatchEvent)bpmnParse.getCurrentFlowElement()) != null) {
/* 72 */         eventSubscriptionDeclaration.setActivityId(activity.getId());
/* 73 */         addEventSubscriptionDeclaration(bpmnParse, eventSubscriptionDeclaration, signalDefinition, activity.getParent());
/*    */       } else {
/* 75 */         activity.setScope(true);
/* 76 */         addEventSubscriptionDeclaration(bpmnParse, eventSubscriptionDeclaration, signalDefinition, activity);
/*    */       }
/*    */     }
/* 79 */     else if ((bpmnParse.getCurrentFlowElement() instanceof ThrowEvent))
/*    */     {
/* 81 */       ThrowEvent throwEvent = (ThrowEvent)bpmnParse.getCurrentFlowElement();
/*    */ 
/* 83 */       activity.setProperty("type", "intermediateSignalThrow");
/* 84 */       EventSubscriptionDeclaration eventSubscriptionDeclaration = new EventSubscriptionDeclaration(signalDefinition.getSignalRef(), "signal");
/* 85 */       eventSubscriptionDeclaration.setAsync(signalDefinition.isAsync());
/*    */ 
/* 87 */       activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createIntermediateThrowSignalEventActivityBehavior(throwEvent, signal, eventSubscriptionDeclaration));
/*    */     }
/* 89 */     else if ((bpmnParse.getCurrentFlowElement() instanceof BoundaryEvent))
/*    */     {
/* 91 */       BoundaryEvent boundaryEvent = (BoundaryEvent)bpmnParse.getCurrentFlowElement();
/* 92 */       boolean interrupting = boundaryEvent.isCancelActivity();
/* 93 */       activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createBoundaryEventActivityBehavior(boundaryEvent, interrupting, activity));
/*    */ 
/* 95 */       activity.setProperty("type", "boundarySignal");
/*    */ 
/* 97 */       EventSubscriptionDeclaration eventSubscriptionDeclaration = new EventSubscriptionDeclaration(signalDefinition.getSignalRef(), "signal");
/* 98 */       eventSubscriptionDeclaration.setActivityId(activity.getId());
/*    */ 
/* 100 */       if (signal.getScope() != null) {
/* 101 */         eventSubscriptionDeclaration.setConfiguration(signal.getScope());
/*    */       }
/*    */ 
/* 104 */       addEventSubscriptionDeclaration(bpmnParse, eventSubscriptionDeclaration, signalDefinition, activity.getParent());
/*    */ 
/* 106 */       if ((activity.getParent() instanceof ActivityImpl))
/* 107 */         ((ActivityImpl)activity.getParent()).setScope(true);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.SignalEventDefinitionParseHandler
 * JD-Core Version:    0.6.0
 */