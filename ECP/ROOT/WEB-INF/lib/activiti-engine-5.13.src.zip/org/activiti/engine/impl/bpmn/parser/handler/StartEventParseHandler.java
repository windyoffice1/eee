/*     */ package org.activiti.engine.impl.bpmn.parser.handler;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.activiti.bpmn.model.BaseElement;
/*     */ import org.activiti.bpmn.model.BpmnModel;
/*     */ import org.activiti.bpmn.model.ErrorEventDefinition;
/*     */ import org.activiti.bpmn.model.EventDefinition;
/*     */ import org.activiti.bpmn.model.MessageEventDefinition;
/*     */ import org.activiti.bpmn.model.SignalEventDefinition;
/*     */ import org.activiti.bpmn.model.StartEvent;
/*     */ import org.activiti.bpmn.model.TimerEventDefinition;
/*     */ import org.activiti.engine.impl.bpmn.behavior.EventSubProcessStartEventActivityBehavior;
/*     */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*     */ import org.activiti.engine.impl.bpmn.parser.BpmnParseHandlers;
/*     */ import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
/*     */ import org.activiti.engine.impl.form.DefaultStartFormHandler;
/*     */ import org.activiti.engine.impl.form.StartFormHandler;
/*     */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*     */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*     */ import org.activiti.engine.impl.pvm.process.ScopeImpl;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class StartEventParseHandler extends AbstractActivityBpmnParseHandler<StartEvent>
/*     */ {
/*     */   public static final String PROPERTYNAME_INITIATOR_VARIABLE_NAME = "initiatorVariableName";
/*     */   public static final String PROPERTYNAME_INITIAL = "initial";
/*     */ 
/*     */   public Class<? extends BaseElement> getHandledType()
/*     */   {
/*  42 */     return StartEvent.class;
/*     */   }
/*     */ 
/*     */   protected void executeParse(BpmnParse bpmnParse, StartEvent startEvent)
/*     */   {
/*  47 */     ActivityImpl startEventActivity = createActivityOnCurrentScope(bpmnParse, startEvent, "startEvent");
/*     */ 
/*  49 */     ScopeImpl scope = bpmnParse.getCurrentScope();
/*  50 */     if ((scope instanceof ProcessDefinitionEntity)) {
/*  51 */       createProcessDefinitionStartEvent(bpmnParse, startEventActivity, startEvent, (ProcessDefinitionEntity)scope);
/*  52 */       selectInitial(bpmnParse, startEventActivity, startEvent, (ProcessDefinitionEntity)scope);
/*  53 */       createStartFormHandlers(bpmnParse, startEvent, (ProcessDefinitionEntity)scope);
/*     */     } else {
/*  55 */       createScopeStartEvent(bpmnParse, startEventActivity, startEvent);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void selectInitial(BpmnParse bpmnParse, ActivityImpl startEventActivity, StartEvent startEvent, ProcessDefinitionEntity processDefinition) {
/*  60 */     if (processDefinition.getInitial() == null) {
/*  61 */       processDefinition.setInitial(startEventActivity);
/*     */     }
/*  64 */     else if (!startEventActivity.getProperty("type").equals("messageStartEvent")) {
/*  65 */       String currentInitialType = (String)processDefinition.getInitial().getProperty("type");
/*  66 */       if (currentInitialType.equals("messageStartEvent"))
/*  67 */         processDefinition.setInitial(startEventActivity);
/*     */       else
/*  69 */         bpmnParse.getBpmnModel().addProblem("multiple none start events or timer start events not supported on process definition.", startEvent);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void createStartFormHandlers(BpmnParse bpmnParse, StartEvent startEvent, ProcessDefinitionEntity processDefinition)
/*     */   {
/*  76 */     if ((processDefinition.getInitial() != null) && 
/*  77 */       (startEvent.getId().equals(processDefinition.getInitial().getId()))) {
/*  78 */       StartFormHandler startFormHandler = new DefaultStartFormHandler();
/*  79 */       startFormHandler.parseConfiguration(startEvent.getFormProperties(), startEvent.getFormKey(), bpmnParse.getDeployment(), processDefinition);
/*  80 */       processDefinition.setStartFormHandler(startFormHandler);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void createProcessDefinitionStartEvent(BpmnParse bpmnParse, ActivityImpl startEventActivity, StartEvent startEvent, ProcessDefinitionEntity processDefinition)
/*     */   {
/*  86 */     if (StringUtils.isNotEmpty(startEvent.getInitiator())) {
/*  87 */       processDefinition.setProperty("initiatorVariableName", startEvent.getInitiator());
/*     */     }
/*     */ 
/*  91 */     startEventActivity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createNoneStartEventActivityBehavior(startEvent));
/*  92 */     if (startEvent.getEventDefinitions().size() > 0) {
/*  93 */       EventDefinition eventDefinition = (EventDefinition)startEvent.getEventDefinitions().get(0);
/*  94 */       if (((eventDefinition instanceof TimerEventDefinition)) || ((eventDefinition instanceof MessageEventDefinition)))
/*  95 */         bpmnParse.getBpmnParserHandlers().parseElement(bpmnParse, eventDefinition);
/*     */       else
/*  97 */         bpmnParse.getBpmnModel().addProblem("Unsupported event definition on start event", eventDefinition);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void createScopeStartEvent(BpmnParse bpmnParse, ActivityImpl startEventActivity, StartEvent startEvent)
/*     */   {
/* 104 */     ScopeImpl scope = bpmnParse.getCurrentScope();
/* 105 */     Object triggeredByEvent = scope.getProperty("triggeredByEvent");
/* 106 */     boolean isTriggeredByEvent = (triggeredByEvent != null) && (((Boolean)triggeredByEvent).booleanValue() == true);
/*     */ 
/* 108 */     if (isTriggeredByEvent)
/*     */     {
/* 111 */       EventSubProcessStartEventActivityBehavior activityBehavior = bpmnParse.getActivityBehaviorFactory().createEventSubProcessStartEventActivityBehavior(startEvent, startEventActivity.getId());
/*     */ 
/* 113 */       startEventActivity.setActivityBehavior(activityBehavior);
/*     */ 
/* 115 */       if (startEvent.getEventDefinitions().size() > 0) {
/* 116 */         EventDefinition eventDefinition = (EventDefinition)startEvent.getEventDefinitions().get(0);
/*     */ 
/* 118 */         if (((eventDefinition instanceof ErrorEventDefinition)) || ((eventDefinition instanceof MessageEventDefinition)) || ((eventDefinition instanceof SignalEventDefinition)))
/*     */         {
/* 121 */           bpmnParse.getBpmnParserHandlers().parseElement(bpmnParse, eventDefinition);
/*     */         }
/* 123 */         else bpmnParse.getBpmnModel().addProblem("start event of event subprocess must be of type 'error', 'message' or 'signal' ", startEvent);
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 129 */       if (startEvent.getEventDefinitions().size() > 0) {
/* 130 */         bpmnParse.getBpmnModel().addProblem("event definitions only allowed on start event if subprocess is an event subprocess", startEvent);
/*     */       }
/* 132 */       if (scope.getProperty("initial") == null) {
/* 133 */         scope.setProperty("initial", startEventActivity);
/* 134 */         startEventActivity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createNoneStartEventActivityBehavior(startEvent));
/*     */       } else {
/* 136 */         bpmnParse.getBpmnModel().addProblem("multiple start events not supported for subprocess", bpmnParse.getCurrentSubProcess());
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.StartEventParseHandler
 * JD-Core Version:    0.6.0
 */