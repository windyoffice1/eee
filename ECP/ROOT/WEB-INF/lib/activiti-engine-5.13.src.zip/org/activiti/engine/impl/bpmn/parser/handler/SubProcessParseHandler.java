/*    */ package org.activiti.engine.impl.bpmn.parser.handler;
/*    */ 
/*    */ import org.activiti.bpmn.model.BaseElement;
/*    */ import org.activiti.bpmn.model.EventSubProcess;
/*    */ import org.activiti.bpmn.model.SubProcess;
/*    */ import org.activiti.engine.impl.bpmn.data.IOSpecification;
/*    */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*    */ import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ 
/*    */ public class SubProcessParseHandler extends AbstractActivityBpmnParseHandler<SubProcess>
/*    */ {
/*    */   protected Class<? extends BaseElement> getHandledType()
/*    */   {
/* 30 */     return SubProcess.class;
/*    */   }
/*    */ 
/*    */   protected void executeParse(BpmnParse bpmnParse, SubProcess subProcess)
/*    */   {
/* 35 */     ActivityImpl activity = createActivityOnScope(bpmnParse, subProcess, "subProcess", bpmnParse.getCurrentScope());
/*    */ 
/* 37 */     activity.setAsync(subProcess.isAsynchronous());
/* 38 */     activity.setExclusive(!subProcess.isNotExclusive());
/*    */ 
/* 40 */     boolean triggeredByEvent = false;
/* 41 */     if ((subProcess instanceof EventSubProcess)) {
/* 42 */       triggeredByEvent = true;
/*    */     }
/* 44 */     activity.setProperty("triggeredByEvent", Boolean.valueOf(triggeredByEvent));
/*    */ 
/* 47 */     activity.setScope(!triggeredByEvent);
/* 48 */     activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createSubprocActivityBehavior(subProcess));
/*    */ 
/* 50 */     bpmnParse.setCurrentScope(activity);
/* 51 */     bpmnParse.setCurrentSubProcess(subProcess);
/*    */ 
/* 53 */     bpmnParse.processFlowElements(subProcess.getFlowElements());
/* 54 */     processArtifacts(bpmnParse, subProcess.getArtifacts(), activity);
/*    */ 
/* 56 */     bpmnParse.removeCurrentScope();
/* 57 */     bpmnParse.removeCurrentSubProcess();
/*    */ 
/* 59 */     if (subProcess.getIoSpecification() != null) {
/* 60 */       IOSpecification ioSpecification = createIOSpecification(bpmnParse, subProcess.getIoSpecification());
/* 61 */       activity.setIoSpecification(ioSpecification);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.SubProcessParseHandler
 * JD-Core Version:    0.6.0
 */