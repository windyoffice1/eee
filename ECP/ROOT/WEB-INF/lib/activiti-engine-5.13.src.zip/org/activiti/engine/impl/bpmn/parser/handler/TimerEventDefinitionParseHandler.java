/*     */ package org.activiti.engine.impl.bpmn.parser.handler;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.activiti.bpmn.model.BaseElement;
/*     */ import org.activiti.bpmn.model.BoundaryEvent;
/*     */ import org.activiti.bpmn.model.BpmnModel;
/*     */ import org.activiti.bpmn.model.IntermediateCatchEvent;
/*     */ import org.activiti.bpmn.model.StartEvent;
/*     */ import org.activiti.bpmn.model.TimerEventDefinition;
/*     */ import org.activiti.engine.delegate.Expression;
/*     */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*     */ import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
/*     */ import org.activiti.engine.impl.el.ExpressionManager;
/*     */ import org.activiti.engine.impl.jobexecutor.TimerDeclarationImpl;
/*     */ import org.activiti.engine.impl.jobexecutor.TimerDeclarationType;
/*     */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*     */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*     */ import org.activiti.engine.impl.pvm.process.ScopeImpl;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class TimerEventDefinitionParseHandler extends AbstractBpmnParseHandler<TimerEventDefinition>
/*     */ {
/*     */   public static final String PROPERTYNAME_START_TIMER = "timerStart";
/*     */ 
/*     */   public Class<? extends BaseElement> getHandledType()
/*     */   {
/*  45 */     return TimerEventDefinition.class;
/*     */   }
/*     */ 
/*     */   protected void executeParse(BpmnParse bpmnParse, TimerEventDefinition timerEventDefinition)
/*     */   {
/*  50 */     ActivityImpl timerActivity = bpmnParse.getCurrentActivity();
/*  51 */     if ((bpmnParse.getCurrentFlowElement() instanceof StartEvent))
/*     */     {
/*  53 */       ProcessDefinitionEntity processDefinition = bpmnParse.getCurrentProcessDefinition();
/*  54 */       timerActivity.setProperty("type", "startTimerEvent");
/*  55 */       TimerDeclarationImpl timerDeclaration = createTimer(bpmnParse, timerEventDefinition, timerActivity, "timer-start-event");
/*  56 */       timerDeclaration.setJobHandlerConfiguration(processDefinition.getKey());
/*     */ 
/*  58 */       List timerDeclarations = (List)processDefinition.getProperty("timerStart");
/*  59 */       if (timerDeclarations == null) {
/*  60 */         timerDeclarations = new ArrayList();
/*  61 */         processDefinition.setProperty("timerStart", timerDeclarations);
/*     */       }
/*  63 */       timerDeclarations.add(timerDeclaration);
/*     */     }
/*  65 */     else if ((bpmnParse.getCurrentFlowElement() instanceof IntermediateCatchEvent))
/*     */     {
/*  67 */       timerActivity.setProperty("type", "intermediateTimer");
/*  68 */       TimerDeclarationImpl timerDeclaration = createTimer(bpmnParse, timerEventDefinition, timerActivity, "timer-intermediate-transition");
/*  69 */       if (getPrecedingEventBasedGateway(bpmnParse, (IntermediateCatchEvent)bpmnParse.getCurrentFlowElement()) != null) {
/*  70 */         addTimerDeclaration(timerActivity.getParent(), timerDeclaration);
/*     */       } else {
/*  72 */         addTimerDeclaration(timerActivity, timerDeclaration);
/*  73 */         timerActivity.setScope(true);
/*     */       }
/*     */     }
/*  76 */     else if ((bpmnParse.getCurrentFlowElement() instanceof BoundaryEvent))
/*     */     {
/*  78 */       timerActivity.setProperty("type", "boundaryTimer");
/*  79 */       TimerDeclarationImpl timerDeclaration = createTimer(bpmnParse, timerEventDefinition, timerActivity, "timer-transition");
/*     */ 
/*  82 */       BoundaryEvent boundaryEvent = (BoundaryEvent)bpmnParse.getCurrentFlowElement();
/*  83 */       boolean interrupting = boundaryEvent.isCancelActivity();
/*  84 */       if (interrupting) {
/*  85 */         timerDeclaration.setInterruptingTimer(true);
/*     */       }
/*     */ 
/*  88 */       addTimerDeclaration(timerActivity.getParent(), timerDeclaration);
/*     */ 
/*  90 */       if ((timerActivity.getParent() instanceof ActivityImpl)) {
/*  91 */         ((ActivityImpl)timerActivity.getParent()).setScope(true);
/*     */       }
/*     */ 
/*  94 */       timerActivity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createBoundaryEventActivityBehavior((BoundaryEvent)bpmnParse.getCurrentFlowElement(), interrupting, timerActivity));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected TimerDeclarationImpl createTimer(BpmnParse bpmnParse, TimerEventDefinition timerEventDefinition, ScopeImpl timerActivity, String jobHandlerType)
/*     */   {
/* 101 */     TimerDeclarationType type = null;
/* 102 */     Expression expression = null;
/* 103 */     ExpressionManager expressionManager = bpmnParse.getExpressionManager();
/* 104 */     if (StringUtils.isNotEmpty(timerEventDefinition.getTimeDate()))
/*     */     {
/* 106 */       type = TimerDeclarationType.DATE;
/* 107 */       expression = expressionManager.createExpression(timerEventDefinition.getTimeDate());
/* 108 */     } else if (StringUtils.isNotEmpty(timerEventDefinition.getTimeCycle()))
/*     */     {
/* 110 */       type = TimerDeclarationType.CYCLE;
/* 111 */       expression = expressionManager.createExpression(timerEventDefinition.getTimeCycle());
/* 112 */     } else if (StringUtils.isNotEmpty(timerEventDefinition.getTimeDuration()))
/*     */     {
/* 114 */       type = TimerDeclarationType.DURATION;
/* 115 */       expression = expressionManager.createExpression(timerEventDefinition.getTimeDuration());
/*     */     }
/*     */ 
/* 119 */     if (expression == null) {
/* 120 */       bpmnParse.getBpmnModel().addProblem("Timer needs configuration (either timeDate, timeCycle or timeDuration is needed).", timerEventDefinition);
/*     */     }
/*     */ 
/* 126 */     TimerDeclarationImpl timerDeclaration = new TimerDeclarationImpl(expression, type, jobHandlerType);
/* 127 */     timerDeclaration.setJobHandlerConfiguration(timerActivity.getId());
/* 128 */     timerDeclaration.setExclusive(true);
/* 129 */     return timerDeclaration;
/*     */   }
/*     */ 
/*     */   protected void addTimerDeclaration(ScopeImpl scope, TimerDeclarationImpl timerDeclaration)
/*     */   {
/* 134 */     List timerDeclarations = (List)scope.getProperty("timerDeclarations");
/* 135 */     if (timerDeclarations == null) {
/* 136 */       timerDeclarations = new ArrayList();
/* 137 */       scope.setProperty("timerDeclarations", timerDeclarations);
/*     */     }
/* 139 */     timerDeclarations.add(timerDeclaration);
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.TimerEventDefinitionParseHandler
 * JD-Core Version:    0.6.0
 */