/*    */ package org.activiti.engine.impl.bpmn.parser.handler;
/*    */ 
/*    */ import org.activiti.bpmn.model.BaseElement;
/*    */ import org.activiti.bpmn.model.Transaction;
/*    */ import org.activiti.engine.impl.bpmn.data.IOSpecification;
/*    */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*    */ import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ 
/*    */ public class TransactionParseHandler extends AbstractActivityBpmnParseHandler<Transaction>
/*    */ {
/*    */   public Class<? extends BaseElement> getHandledType()
/*    */   {
/* 29 */     return Transaction.class;
/*    */   }
/*    */ 
/*    */   protected void executeParse(BpmnParse bpmnParse, Transaction transaction)
/*    */   {
/* 34 */     ActivityImpl activity = createActivityOnCurrentScope(bpmnParse, transaction, "transaction");
/*    */ 
/* 36 */     activity.setAsync(transaction.isAsynchronous());
/* 37 */     activity.setExclusive(!transaction.isNotExclusive());
/*    */ 
/* 39 */     activity.setScope(true);
/* 40 */     activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createTransactionActivityBehavior(transaction));
/*    */ 
/* 43 */     bpmnParse.setCurrentScope(activity);
/*    */ 
/* 45 */     bpmnParse.processFlowElements(transaction.getFlowElements());
/* 46 */     processArtifacts(bpmnParse, transaction.getArtifacts(), activity);
/*    */ 
/* 48 */     bpmnParse.removeCurrentScope();
/*    */ 
/* 50 */     if (transaction.getIoSpecification() != null) {
/* 51 */       IOSpecification ioSpecification = createIOSpecification(bpmnParse, transaction.getIoSpecification());
/* 52 */       activity.setIoSpecification(ioSpecification);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.TransactionParseHandler
 * JD-Core Version:    0.6.0
 */