/*     */ package org.activiti.engine.impl.bpmn.parser.handler;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.activiti.bpmn.model.ActivitiListener;
/*     */ import org.activiti.bpmn.model.BaseElement;
/*     */ import org.activiti.bpmn.model.BpmnModel;
/*     */ import org.activiti.bpmn.model.ImplementationType;
/*     */ import org.activiti.bpmn.model.UserTask;
/*     */ import org.activiti.engine.delegate.TaskListener;
/*     */ import org.activiti.engine.impl.bpmn.parser.BpmnParse;
/*     */ import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
/*     */ import org.activiti.engine.impl.bpmn.parser.factory.ListenerFactory;
/*     */ import org.activiti.engine.impl.el.ExpressionManager;
/*     */ import org.activiti.engine.impl.form.DefaultTaskFormHandler;
/*     */ import org.activiti.engine.impl.form.TaskFormHandler;
/*     */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*     */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*     */ import org.activiti.engine.impl.pvm.process.ScopeImpl;
/*     */ import org.activiti.engine.impl.task.TaskDefinition;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class UserTaskParseHandler extends AbstractActivityBpmnParseHandler<UserTask>
/*     */ {
/*     */   public static final String PROPERTY_TASK_DEFINITION = "taskDefinition";
/*     */ 
/*     */   public Class<? extends BaseElement> getHandledType()
/*     */   {
/*  39 */     return UserTask.class;
/*     */   }
/*     */ 
/*     */   protected void executeParse(BpmnParse bpmnParse, UserTask userTask) {
/*  43 */     ActivityImpl activity = createActivityOnCurrentScope(bpmnParse, userTask, "userTask");
/*     */ 
/*  45 */     activity.setAsync(userTask.isAsynchronous());
/*  46 */     activity.setExclusive(!userTask.isNotExclusive());
/*     */ 
/*  48 */     TaskDefinition taskDefinition = parseTaskDefinition(bpmnParse, userTask, userTask.getId(), (ProcessDefinitionEntity)bpmnParse.getCurrentScope().getProcessDefinition());
/*  49 */     activity.setProperty("taskDefinition", taskDefinition);
/*  50 */     activity.setActivityBehavior(bpmnParse.getActivityBehaviorFactory().createUserTaskActivityBehavior(userTask, taskDefinition));
/*     */   }
/*     */ 
/*     */   public TaskDefinition parseTaskDefinition(BpmnParse bpmnParse, UserTask userTask, String taskDefinitionKey, ProcessDefinitionEntity processDefinition) {
/*  54 */     TaskFormHandler taskFormHandler = new DefaultTaskFormHandler();
/*  55 */     taskFormHandler.parseConfiguration(userTask.getFormProperties(), userTask.getFormKey(), bpmnParse.getDeployment(), processDefinition);
/*     */ 
/*  57 */     TaskDefinition taskDefinition = new TaskDefinition(taskFormHandler);
/*     */ 
/*  59 */     taskDefinition.setKey(taskDefinitionKey);
/*  60 */     processDefinition.getTaskDefinitions().put(taskDefinitionKey, taskDefinition);
/*  61 */     ExpressionManager expressionManager = bpmnParse.getExpressionManager();
/*     */ 
/*  63 */     if (StringUtils.isNotEmpty(userTask.getName())) {
/*  64 */       taskDefinition.setNameExpression(expressionManager.createExpression(userTask.getName()));
/*     */     }
/*     */ 
/*  67 */     if (StringUtils.isNotEmpty(userTask.getDocumentation())) {
/*  68 */       taskDefinition.setDescriptionExpression(expressionManager.createExpression(userTask.getDocumentation()));
/*     */     }
/*     */ 
/*  71 */     if (StringUtils.isNotEmpty(userTask.getAssignee())) {
/*  72 */       taskDefinition.setAssigneeExpression(expressionManager.createExpression(userTask.getAssignee()));
/*     */     }
/*  74 */     for (String candidateUser : userTask.getCandidateUsers()) {
/*  75 */       taskDefinition.addCandidateUserIdExpression(expressionManager.createExpression(candidateUser));
/*     */     }
/*  77 */     for (String candidateGroup : userTask.getCandidateGroups()) {
/*  78 */       taskDefinition.addCandidateGroupIdExpression(expressionManager.createExpression(candidateGroup));
/*     */     }
/*     */ 
/*  84 */     for (ActivitiListener taskListener : userTask.getTaskListeners()) {
/*  85 */       taskDefinition.addTaskListener(taskListener.getEvent(), createTaskListener(bpmnParse, taskListener, userTask.getId()));
/*     */     }
/*     */ 
/*  89 */     if (StringUtils.isNotEmpty(userTask.getDueDate())) {
/*  90 */       taskDefinition.setDueDateExpression(expressionManager.createExpression(userTask.getDueDate()));
/*     */     }
/*     */ 
/*  94 */     if (StringUtils.isNotEmpty(userTask.getPriority())) {
/*  95 */       taskDefinition.setPriorityExpression(expressionManager.createExpression(userTask.getPriority()));
/*     */     }
/*     */ 
/*  98 */     return taskDefinition;
/*     */   }
/*     */ 
/*     */   protected TaskListener createTaskListener(BpmnParse bpmnParse, ActivitiListener activitiListener, String taskId) {
/* 102 */     TaskListener taskListener = null;
/*     */ 
/* 104 */     if (ImplementationType.IMPLEMENTATION_TYPE_CLASS.equalsIgnoreCase(activitiListener.getImplementationType()))
/* 105 */       taskListener = bpmnParse.getListenerFactory().createClassDelegateTaskListener(activitiListener);
/* 106 */     else if (ImplementationType.IMPLEMENTATION_TYPE_EXPRESSION.equalsIgnoreCase(activitiListener.getImplementationType()))
/* 107 */       taskListener = bpmnParse.getListenerFactory().createExpressionTaskListener(activitiListener);
/* 108 */     else if (ImplementationType.IMPLEMENTATION_TYPE_DELEGATEEXPRESSION.equalsIgnoreCase(activitiListener.getImplementationType()))
/* 109 */       taskListener = bpmnParse.getListenerFactory().createDelegateExpressionTaskListener(activitiListener);
/*     */     else {
/* 111 */       bpmnParse.getBpmnModel().addProblem("Element 'class', 'expression' or 'delegateExpression' is mandatory on taskListener for task", activitiListener);
/*     */     }
/* 113 */     return taskListener;
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.parser.handler.UserTaskParseHandler
 * JD-Core Version:    0.6.0
 */