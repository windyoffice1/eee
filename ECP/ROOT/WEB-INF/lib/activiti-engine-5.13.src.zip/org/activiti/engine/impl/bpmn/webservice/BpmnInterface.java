/*    */ package org.activiti.engine.impl.bpmn.webservice;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class BpmnInterface
/*    */ {
/*    */   protected String id;
/*    */   protected String name;
/*    */   protected BpmnInterfaceImplementation implementation;
/* 37 */   protected Map<String, Operation> operations = new HashMap();
/*    */ 
/*    */   public BpmnInterface()
/*    */   {
/*    */   }
/*    */ 
/*    */   public BpmnInterface(String id, String name) {
/* 44 */     setId(id);
/* 45 */     setName(name);
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 49 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(String id) {
/* 53 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 57 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 61 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public void addOperation(Operation operation) {
/* 65 */     this.operations.put(operation.getId(), operation);
/*    */   }
/*    */ 
/*    */   public Operation getOperation(String operationId) {
/* 69 */     return (Operation)this.operations.get(operationId);
/*    */   }
/*    */ 
/*    */   public Collection<Operation> getOperations() {
/* 73 */     return this.operations.values();
/*    */   }
/*    */ 
/*    */   public BpmnInterfaceImplementation getImplementation() {
/* 77 */     return this.implementation;
/*    */   }
/*    */ 
/*    */   public void setImplementation(BpmnInterfaceImplementation implementation) {
/* 81 */     this.implementation = implementation;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.webservice.BpmnInterface
 * JD-Core Version:    0.6.0
 */