/*    */ package org.activiti.engine.impl.bpmn.webservice;
/*    */ 
/*    */ import org.activiti.engine.impl.bpmn.data.ItemDefinition;
/*    */ import org.activiti.engine.impl.bpmn.data.StructureDefinition;
/*    */ 
/*    */ public class MessageDefinition
/*    */ {
/*    */   protected String id;
/*    */   protected ItemDefinition itemDefinition;
/*    */   protected String name;
/*    */ 
/*    */   public MessageDefinition(String id, String name)
/*    */   {
/* 32 */     this.id = id;
/* 33 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public MessageInstance createInstance() {
/* 37 */     return new MessageInstance(this, this.itemDefinition.createInstance());
/*    */   }
/*    */ 
/*    */   public ItemDefinition getItemDefinition() {
/* 41 */     return this.itemDefinition;
/*    */   }
/*    */ 
/*    */   public StructureDefinition getStructureDefinition() {
/* 45 */     return this.itemDefinition.getStructureDefinition();
/*    */   }
/*    */ 
/*    */   public void setItemDefinition(ItemDefinition itemDefinition) {
/* 49 */     this.itemDefinition = itemDefinition;
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 53 */     return this.id;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 57 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 61 */     this.name = name;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.webservice.MessageDefinition
 * JD-Core Version:    0.6.0
 */