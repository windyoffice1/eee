/*    */ package org.activiti.engine.impl.bpmn.webservice;
/*    */ 
/*    */ import org.activiti.engine.impl.bpmn.data.AbstractDataAssociation;
/*    */ import org.activiti.engine.impl.bpmn.data.FieldBaseStructureInstance;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class MessageImplicitDataInputAssociation extends AbstractDataAssociation
/*    */ {
/*    */   public MessageImplicitDataInputAssociation(String source, String target)
/*    */   {
/* 30 */     super(source, target);
/*    */   }
/*    */ 
/*    */   public void evaluate(ActivityExecution execution)
/*    */   {
/* 35 */     if (StringUtils.isNotEmpty(this.source)) {
/* 36 */       Object value = execution.getVariable(this.source);
/* 37 */       MessageInstance message = (MessageInstance)execution.getVariable("org.activiti.engine.impl.bpmn.CURRENT_MESSAGE");
/* 38 */       if ((message.getStructureInstance() instanceof FieldBaseStructureInstance)) {
/* 39 */         FieldBaseStructureInstance structure = (FieldBaseStructureInstance)message.getStructureInstance();
/* 40 */         structure.setFieldValue(this.target, value);
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.webservice.MessageImplicitDataInputAssociation
 * JD-Core Version:    0.6.0
 */