/*    */ package org.activiti.engine.impl.bpmn.webservice;
/*    */ 
/*    */ import org.activiti.engine.delegate.Expression;
/*    */ import org.activiti.engine.impl.bpmn.data.AbstractDataAssociation;
/*    */ import org.activiti.engine.impl.bpmn.data.FieldBaseStructureInstance;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ 
/*    */ public class MessageImplicitDataOutputAssociation extends AbstractDataAssociation
/*    */ {
/*    */   public MessageImplicitDataOutputAssociation(String targetRef, Expression sourceExpression)
/*    */   {
/* 30 */     super(sourceExpression, targetRef);
/*    */   }
/*    */ 
/*    */   public MessageImplicitDataOutputAssociation(String targetRef, String sourceRef) {
/* 34 */     super(sourceRef, targetRef);
/*    */   }
/*    */ 
/*    */   public void evaluate(ActivityExecution execution)
/*    */   {
/* 39 */     MessageInstance message = (MessageInstance)execution.getVariable("org.activiti.engine.impl.bpmn.CURRENT_MESSAGE");
/* 40 */     if ((message.getStructureInstance() instanceof FieldBaseStructureInstance)) {
/* 41 */       FieldBaseStructureInstance structure = (FieldBaseStructureInstance)message.getStructureInstance();
/* 42 */       execution.setVariable(getTarget(), structure.getFieldValue(getSource()));
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.webservice.MessageImplicitDataOutputAssociation
 * JD-Core Version:    0.6.0
 */