/*    */ package org.activiti.engine.impl.bpmn.webservice;
/*    */ 
/*    */ import org.activiti.engine.impl.bpmn.data.ItemInstance;
/*    */ import org.activiti.engine.impl.bpmn.data.StructureInstance;
/*    */ 
/*    */ public class MessageInstance
/*    */ {
/*    */   protected MessageDefinition message;
/*    */   protected ItemInstance item;
/*    */ 
/*    */   public MessageInstance(MessageDefinition message, ItemInstance item)
/*    */   {
/* 31 */     this.message = message;
/* 32 */     this.item = item;
/*    */   }
/*    */ 
/*    */   public StructureInstance getStructureInstance() {
/* 36 */     return this.item.getStructureInstance();
/*    */   }
/*    */ 
/*    */   public MessageDefinition getMessage() {
/* 40 */     return this.message;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.webservice.MessageInstance
 * JD-Core Version:    0.6.0
 */