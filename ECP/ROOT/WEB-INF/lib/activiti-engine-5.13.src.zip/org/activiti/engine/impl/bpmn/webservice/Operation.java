/*    */ package org.activiti.engine.impl.bpmn.webservice;
/*    */ 
/*    */ public class Operation
/*    */ {
/*    */   protected String id;
/*    */   protected String name;
/*    */   protected MessageDefinition inMessage;
/*    */   protected MessageDefinition outMessage;
/*    */   protected OperationImplementation implementation;
/*    */   protected BpmnInterface bpmnInterface;
/*    */ 
/*    */   public Operation()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Operation(String id, String name, BpmnInterface bpmnInterface, MessageDefinition inMessage)
/*    */   {
/* 43 */     setId(id);
/* 44 */     setName(name);
/* 45 */     setInterface(bpmnInterface);
/* 46 */     setInMessage(inMessage);
/*    */   }
/*    */ 
/*    */   public MessageInstance sendMessage(MessageInstance message) {
/* 50 */     return this.implementation.sendFor(message, this);
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 54 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(String id) {
/* 58 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 62 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 66 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public BpmnInterface getInterface() {
/* 70 */     return this.bpmnInterface;
/*    */   }
/*    */ 
/*    */   public void setInterface(BpmnInterface bpmnInterface) {
/* 74 */     this.bpmnInterface = bpmnInterface;
/*    */   }
/*    */ 
/*    */   public MessageDefinition getInMessage() {
/* 78 */     return this.inMessage;
/*    */   }
/*    */ 
/*    */   public void setInMessage(MessageDefinition inMessage) {
/* 82 */     this.inMessage = inMessage;
/*    */   }
/*    */ 
/*    */   public MessageDefinition getOutMessage() {
/* 86 */     return this.outMessage;
/*    */   }
/*    */ 
/*    */   public void setOutMessage(MessageDefinition outMessage) {
/* 90 */     this.outMessage = outMessage;
/*    */   }
/*    */ 
/*    */   public OperationImplementation getImplementation() {
/* 94 */     return this.implementation;
/*    */   }
/*    */ 
/*    */   public void setImplementation(OperationImplementation implementation) {
/* 98 */     this.implementation = implementation;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.bpmn.webservice.Operation
 * JD-Core Version:    0.6.0
 */