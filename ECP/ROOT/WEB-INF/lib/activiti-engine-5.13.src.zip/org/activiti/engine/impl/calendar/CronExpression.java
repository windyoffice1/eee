/*      */ package org.activiti.engine.impl.calendar;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.text.ParseException;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.SortedSet;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.TimeZone;
/*      */ import java.util.TreeSet;
/*      */ 
/*      */ public class CronExpression
/*      */   implements Serializable, Cloneable
/*      */ {
/*      */   private static final long serialVersionUID = 12423409423L;
/*      */   protected static final int SECOND = 0;
/*      */   protected static final int MINUTE = 1;
/*      */   protected static final int HOUR = 2;
/*      */   protected static final int DAY_OF_MONTH = 3;
/*      */   protected static final int MONTH = 4;
/*      */   protected static final int DAY_OF_WEEK = 5;
/*      */   protected static final int YEAR = 6;
/*      */   protected static final int ALL_SPEC_INT = 99;
/*      */   protected static final int NO_SPEC_INT = 98;
/*  213 */   protected static final Integer ALL_SPEC = Integer.valueOf(99);
/*  214 */   protected static final Integer NO_SPEC = Integer.valueOf(98);
/*      */ 
/*  216 */   protected static final Map monthMap = new HashMap(20);
/*  217 */   protected static final Map dayMap = new HashMap(60);
/*      */ 
/*  241 */   private String cronExpression = null;
/*  242 */   private TimeZone timeZone = null;
/*      */   protected transient TreeSet<Integer> seconds;
/*      */   protected transient TreeSet<Integer> minutes;
/*      */   protected transient TreeSet<Integer> hours;
/*      */   protected transient TreeSet<Integer> daysOfMonth;
/*      */   protected transient TreeSet<Integer> months;
/*      */   protected transient TreeSet<Integer> daysOfWeek;
/*      */   protected transient TreeSet<Integer> years;
/*  251 */   protected transient boolean lastdayOfWeek = false;
/*  252 */   protected transient int nthdayOfWeek = 0;
/*  253 */   protected transient boolean lastdayOfMonth = false;
/*  254 */   protected transient boolean nearestWeekday = false;
/*  255 */   protected transient int lastdayOffset = 0;
/*  256 */   protected transient boolean expressionParsed = false;
/*      */   public static final int MAX_YEAR;
/*      */ 
/*      */   public CronExpression(String cronExpression)
/*      */     throws ParseException
/*      */   {
/*  271 */     if (cronExpression == null) {
/*  272 */       throw new IllegalArgumentException("cronExpression cannot be null");
/*      */     }
/*      */ 
/*  275 */     this.cronExpression = cronExpression.toUpperCase(Locale.US);
/*      */ 
/*  277 */     buildExpression(this.cronExpression);
/*      */   }
/*      */ 
/*      */   public TimeZone getTimeZone()
/*      */   {
/*  287 */     if (this.timeZone == null) {
/*  288 */       this.timeZone = TimeZone.getDefault();
/*      */     }
/*      */ 
/*  291 */     return this.timeZone;
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/*  300 */     return this.cronExpression;
/*      */   }
/*      */ 
/*      */   protected void buildExpression(String expression)
/*      */     throws ParseException
/*      */   {
/*  311 */     this.expressionParsed = true;
/*      */     try
/*      */     {
/*  315 */       if (this.seconds == null) {
/*  316 */         this.seconds = new TreeSet();
/*      */       }
/*  318 */       if (this.minutes == null) {
/*  319 */         this.minutes = new TreeSet();
/*      */       }
/*  321 */       if (this.hours == null) {
/*  322 */         this.hours = new TreeSet();
/*      */       }
/*  324 */       if (this.daysOfMonth == null) {
/*  325 */         this.daysOfMonth = new TreeSet();
/*      */       }
/*  327 */       if (this.months == null) {
/*  328 */         this.months = new TreeSet();
/*      */       }
/*  330 */       if (this.daysOfWeek == null) {
/*  331 */         this.daysOfWeek = new TreeSet();
/*      */       }
/*  333 */       if (this.years == null) {
/*  334 */         this.years = new TreeSet();
/*      */       }
/*      */ 
/*  337 */       int exprOn = 0;
/*      */ 
/*  339 */       StringTokenizer exprsTok = new StringTokenizer(expression, " \t", false);
/*      */ 
/*  342 */       while ((exprsTok.hasMoreTokens()) && (exprOn <= 6)) {
/*  343 */         String expr = exprsTok.nextToken().trim();
/*      */ 
/*  346 */         if ((exprOn == 3) && (expr.indexOf('L') != -1) && (expr.length() > 1) && (expr.indexOf(",") >= 0)) {
/*  347 */           throw new ParseException("Support for specifying 'L' and 'LW' with other days of the month is not implemented", -1);
/*      */         }
/*      */ 
/*  350 */         if ((exprOn == 5) && (expr.indexOf('L') != -1) && (expr.length() > 1) && (expr.indexOf(",") >= 0)) {
/*  351 */           throw new ParseException("Support for specifying 'L' with other days of the week is not implemented", -1);
/*      */         }
/*  353 */         if ((exprOn == 5) && (expr.indexOf('#') != -1) && (expr.indexOf('#', expr.indexOf(35) + 1) != -1)) {
/*  354 */           throw new ParseException("Support for specifying multiple \"nth\" days is not imlemented.", -1);
/*      */         }
/*      */ 
/*  357 */         StringTokenizer vTok = new StringTokenizer(expr, ",");
/*  358 */         while (vTok.hasMoreTokens()) {
/*  359 */           String v = vTok.nextToken();
/*  360 */           storeExpressionVals(0, v, exprOn);
/*      */         }
/*      */ 
/*  363 */         exprOn++;
/*      */       }
/*      */ 
/*  366 */       if (exprOn <= 5) {
/*  367 */         throw new ParseException("Unexpected end of expression.", expression.length());
/*      */       }
/*      */ 
/*  371 */       if (exprOn <= 6) {
/*  372 */         storeExpressionVals(0, "*", 6);
/*      */       }
/*      */ 
/*  375 */       TreeSet dow = getSet(5);
/*  376 */       TreeSet dom = getSet(3);
/*      */ 
/*  379 */       boolean dayOfMSpec = !dom.contains(NO_SPEC);
/*  380 */       boolean dayOfWSpec = !dow.contains(NO_SPEC);
/*      */ 
/*  382 */       if ((!dayOfMSpec) || (dayOfWSpec))
/*      */       {
/*  384 */         if ((!dayOfWSpec) || (dayOfMSpec))
/*      */         {
/*  387 */           throw new ParseException("Support for specifying both a day-of-week AND a day-of-month parameter is not implemented.", 0);
/*      */         }
/*      */       }
/*      */     } catch (ParseException pe) {
/*  391 */       throw pe;
/*      */     } catch (Exception e) {
/*  393 */       throw new ParseException(new StringBuilder().append("Illegal cron expression format (").append(e.toString()).append(")").toString(), 0);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected int storeExpressionVals(int pos, String s, int type)
/*      */     throws ParseException
/*      */   {
/*  401 */     int incr = 0;
/*  402 */     int i = skipWhiteSpace(pos, s);
/*  403 */     if (i >= s.length()) {
/*  404 */       return i;
/*      */     }
/*  406 */     char c = s.charAt(i);
/*  407 */     if ((c >= 'A') && (c <= 'Z') && (!s.equals("L")) && (!s.equals("LW")) && (!s.matches("^L-[0-9]*[W]?"))) {
/*  408 */       String sub = s.substring(i, i + 3);
/*  409 */       int sval = -1;
/*  410 */       int eval = -1;
/*  411 */       if (type == 4) {
/*  412 */         sval = getMonthNumber(sub) + 1;
/*  413 */         if (sval <= 0) {
/*  414 */           throw new ParseException(new StringBuilder().append("Invalid Month value: '").append(sub).append("'").toString(), i);
/*      */         }
/*  416 */         if (s.length() > i + 3) {
/*  417 */           c = s.charAt(i + 3);
/*  418 */           if (c == '-') {
/*  419 */             i += 4;
/*  420 */             sub = s.substring(i, i + 3);
/*  421 */             eval = getMonthNumber(sub) + 1;
/*  422 */             if (eval <= 0)
/*  423 */               throw new ParseException(new StringBuilder().append("Invalid Month value: '").append(sub).append("'").toString(), i);
/*      */           }
/*      */         }
/*      */       }
/*  427 */       else if (type == 5) {
/*  428 */         sval = getDayOfWeekNumber(sub);
/*  429 */         if (sval < 0) {
/*  430 */           throw new ParseException(new StringBuilder().append("Invalid Day-of-Week value: '").append(sub).append("'").toString(), i);
/*      */         }
/*      */ 
/*  433 */         if (s.length() > i + 3) {
/*  434 */           c = s.charAt(i + 3);
/*  435 */           if (c == '-') {
/*  436 */             i += 4;
/*  437 */             sub = s.substring(i, i + 3);
/*  438 */             eval = getDayOfWeekNumber(sub);
/*  439 */             if (eval < 0) {
/*  440 */               throw new ParseException(new StringBuilder().append("Invalid Day-of-Week value: '").append(sub).append("'").toString(), i);
/*      */             }
/*      */ 
/*      */           }
/*  444 */           else if (c == '#') {
/*      */             try {
/*  446 */               i += 4;
/*  447 */               this.nthdayOfWeek = Integer.parseInt(s.substring(i));
/*  448 */               if ((this.nthdayOfWeek < 1) || (this.nthdayOfWeek > 5))
/*  449 */                 throw new Exception();
/*      */             }
/*      */             catch (Exception e) {
/*  452 */               throw new ParseException("A numeric value between 1 and 5 must follow the '#' option", i);
/*      */             }
/*      */ 
/*      */           }
/*  456 */           else if (c == 'L') {
/*  457 */             this.lastdayOfWeek = true;
/*  458 */             i++;
/*      */           }
/*      */         }
/*      */       }
/*      */       else {
/*  463 */         throw new ParseException(new StringBuilder().append("Illegal characters for this position: '").append(sub).append("'").toString(), i);
/*      */       }
/*      */ 
/*  467 */       if (eval != -1) {
/*  468 */         incr = 1;
/*      */       }
/*  470 */       addToSet(sval, eval, incr, type);
/*  471 */       return i + 3;
/*      */     }
/*      */ 
/*  474 */     if (c == '?') {
/*  475 */       i++;
/*  476 */       if ((i + 1 < s.length()) && (s.charAt(i) != ' ') && (s.charAt(i + 1) != '\t'))
/*      */       {
/*  478 */         throw new ParseException(new StringBuilder().append("Illegal character after '?': ").append(s.charAt(i)).toString(), i);
/*      */       }
/*      */ 
/*  481 */       if ((type != 5) && (type != 3)) {
/*  482 */         throw new ParseException("'?' can only be specfied for Day-of-Month or Day-of-Week.", i);
/*      */       }
/*      */ 
/*  486 */       if ((type == 5) && (!this.lastdayOfMonth)) {
/*  487 */         int val = ((Integer)this.daysOfMonth.last()).intValue();
/*  488 */         if (val == 98) {
/*  489 */           throw new ParseException("'?' can only be specfied for Day-of-Month -OR- Day-of-Week.", i);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  495 */       addToSet(98, -1, 0, type);
/*  496 */       return i;
/*      */     }
/*      */ 
/*  499 */     if ((c == '*') || (c == '/')) {
/*  500 */       if ((c == '*') && (i + 1 >= s.length())) {
/*  501 */         addToSet(99, -1, incr, type);
/*  502 */         return i + 1;
/*  503 */       }if ((c == '/') && ((i + 1 >= s.length()) || (s.charAt(i + 1) == ' ') || (s.charAt(i + 1) == '\t')))
/*      */       {
/*  506 */         throw new ParseException("'/' must be followed by an integer.", i);
/*  507 */       }if (c == '*') {
/*  508 */         i++;
/*      */       }
/*  510 */       c = s.charAt(i);
/*  511 */       if (c == '/') {
/*  512 */         i++;
/*  513 */         if (i >= s.length()) {
/*  514 */           throw new ParseException("Unexpected end of string.", i);
/*      */         }
/*      */ 
/*  517 */         incr = getNumericValue(s, i);
/*      */ 
/*  519 */         i++;
/*  520 */         if (incr > 10) {
/*  521 */           i++;
/*      */         }
/*  523 */         if ((incr > 59) && ((type == 0) || (type == 1)))
/*  524 */           throw new ParseException(new StringBuilder().append("Increment > 60 : ").append(incr).toString(), i);
/*  525 */         if ((incr > 23) && (type == 2))
/*  526 */           throw new ParseException(new StringBuilder().append("Increment > 24 : ").append(incr).toString(), i);
/*  527 */         if ((incr > 31) && (type == 3))
/*  528 */           throw new ParseException(new StringBuilder().append("Increment > 31 : ").append(incr).toString(), i);
/*  529 */         if ((incr > 7) && (type == 5))
/*  530 */           throw new ParseException(new StringBuilder().append("Increment > 7 : ").append(incr).toString(), i);
/*  531 */         if ((incr > 12) && (type == 4))
/*  532 */           throw new ParseException(new StringBuilder().append("Increment > 12 : ").append(incr).toString(), i);
/*      */       }
/*      */       else {
/*  535 */         incr = 1;
/*      */       }
/*      */ 
/*  538 */       addToSet(99, -1, incr, type);
/*  539 */       return i;
/*  540 */     }if (c == 'L') {
/*  541 */       i++;
/*  542 */       if (type == 3) {
/*  543 */         this.lastdayOfMonth = true;
/*      */       }
/*  545 */       if (type == 5) {
/*  546 */         addToSet(7, 7, 0, type);
/*      */       }
/*  548 */       if ((type == 3) && (s.length() > i)) {
/*  549 */         c = s.charAt(i);
/*  550 */         if (c == '-') {
/*  551 */           ValueSet vs = getValue(0, s, i + 1);
/*  552 */           this.lastdayOffset = vs.value;
/*  553 */           if (this.lastdayOffset > 30)
/*  554 */             throw new ParseException("Offset from last day must be <= 30", i + 1);
/*  555 */           i = vs.pos;
/*      */         }
/*  557 */         if (s.length() > i) {
/*  558 */           c = s.charAt(i);
/*  559 */           if (c == 'W') {
/*  560 */             this.nearestWeekday = true;
/*  561 */             i++;
/*      */           }
/*      */         }
/*      */       }
/*  565 */       return i;
/*  566 */     }if ((c >= '0') && (c <= '9')) {
/*  567 */       int val = Integer.parseInt(String.valueOf(c));
/*  568 */       i++;
/*  569 */       if (i >= s.length()) {
/*  570 */         addToSet(val, -1, -1, type);
/*      */       } else {
/*  572 */         c = s.charAt(i);
/*  573 */         if ((c >= '0') && (c <= '9')) {
/*  574 */           ValueSet vs = getValue(val, s, i);
/*  575 */           val = vs.value;
/*  576 */           i = vs.pos;
/*      */         }
/*  578 */         i = checkNext(i, s, val, type);
/*  579 */         return i;
/*      */       }
/*      */     } else {
/*  582 */       throw new ParseException(new StringBuilder().append("Unexpected character: ").append(c).toString(), i);
/*      */     }
/*      */ 
/*  585 */     return i;
/*      */   }
/*      */ 
/*      */   protected int checkNext(int pos, String s, int val, int type)
/*      */     throws ParseException
/*      */   {
/*  591 */     int end = -1;
/*  592 */     int i = pos;
/*      */ 
/*  594 */     if (i >= s.length()) {
/*  595 */       addToSet(val, end, -1, type);
/*  596 */       return i;
/*      */     }
/*      */ 
/*  599 */     char c = s.charAt(pos);
/*      */ 
/*  601 */     if (c == 'L') {
/*  602 */       if (type == 5) {
/*  603 */         if ((val < 1) || (val > 7))
/*  604 */           throw new ParseException("Day-of-Week values must be between 1 and 7", -1);
/*  605 */         this.lastdayOfWeek = true;
/*      */       } else {
/*  607 */         throw new ParseException(new StringBuilder().append("'L' option is not valid here. (pos=").append(i).append(")").toString(), i);
/*      */       }
/*  609 */       TreeSet set = getSet(type);
/*  610 */       set.add(Integer.valueOf(val));
/*  611 */       i++;
/*  612 */       return i;
/*      */     }
/*      */ 
/*  615 */     if (c == 'W') {
/*  616 */       if (type == 3)
/*  617 */         this.nearestWeekday = true;
/*      */       else {
/*  619 */         throw new ParseException(new StringBuilder().append("'W' option is not valid here. (pos=").append(i).append(")").toString(), i);
/*      */       }
/*  621 */       if (val > 31)
/*  622 */         throw new ParseException("The 'W' option does not make sense with values larger than 31 (max number of days in a month)", i);
/*  623 */       TreeSet set = getSet(type);
/*  624 */       set.add(Integer.valueOf(val));
/*  625 */       i++;
/*  626 */       return i;
/*      */     }
/*      */ 
/*  629 */     if (c == '#') {
/*  630 */       if (type != 5) {
/*  631 */         throw new ParseException(new StringBuilder().append("'#' option is not valid here. (pos=").append(i).append(")").toString(), i);
/*      */       }
/*  633 */       i++;
/*      */       try {
/*  635 */         this.nthdayOfWeek = Integer.parseInt(s.substring(i));
/*  636 */         if ((this.nthdayOfWeek < 1) || (this.nthdayOfWeek > 5))
/*  637 */           throw new Exception();
/*      */       }
/*      */       catch (Exception e) {
/*  640 */         throw new ParseException("A numeric value between 1 and 5 must follow the '#' option", i);
/*      */       }
/*      */ 
/*  645 */       TreeSet set = getSet(type);
/*  646 */       set.add(Integer.valueOf(val));
/*  647 */       i++;
/*  648 */       return i;
/*      */     }
/*      */ 
/*  651 */     if (c == '-') {
/*  652 */       i++;
/*  653 */       c = s.charAt(i);
/*  654 */       int v = Integer.parseInt(String.valueOf(c));
/*  655 */       end = v;
/*  656 */       i++;
/*  657 */       if (i >= s.length()) {
/*  658 */         addToSet(val, end, 1, type);
/*  659 */         return i;
/*      */       }
/*  661 */       c = s.charAt(i);
/*  662 */       if ((c >= '0') && (c <= '9')) {
/*  663 */         ValueSet vs = getValue(v, s, i);
/*  664 */         int v1 = vs.value;
/*  665 */         end = v1;
/*  666 */         i = vs.pos;
/*      */       }
/*  668 */       if ((i < s.length()) && ((c = s.charAt(i)) == '/')) {
/*  669 */         i++;
/*  670 */         c = s.charAt(i);
/*  671 */         int v2 = Integer.parseInt(String.valueOf(c));
/*  672 */         i++;
/*  673 */         if (i >= s.length()) {
/*  674 */           addToSet(val, end, v2, type);
/*  675 */           return i;
/*      */         }
/*  677 */         c = s.charAt(i);
/*  678 */         if ((c >= '0') && (c <= '9')) {
/*  679 */           ValueSet vs = getValue(v2, s, i);
/*  680 */           int v3 = vs.value;
/*  681 */           addToSet(val, end, v3, type);
/*  682 */           i = vs.pos;
/*  683 */           return i;
/*      */         }
/*  685 */         addToSet(val, end, v2, type);
/*  686 */         return i;
/*      */       }
/*      */ 
/*  689 */       addToSet(val, end, 1, type);
/*  690 */       return i;
/*      */     }
/*      */ 
/*  694 */     if (c == '/') {
/*  695 */       i++;
/*  696 */       c = s.charAt(i);
/*  697 */       int v2 = Integer.parseInt(String.valueOf(c));
/*  698 */       i++;
/*  699 */       if (i >= s.length()) {
/*  700 */         addToSet(val, end, v2, type);
/*  701 */         return i;
/*      */       }
/*  703 */       c = s.charAt(i);
/*  704 */       if ((c >= '0') && (c <= '9')) {
/*  705 */         ValueSet vs = getValue(v2, s, i);
/*  706 */         int v3 = vs.value;
/*  707 */         addToSet(val, end, v3, type);
/*  708 */         i = vs.pos;
/*  709 */         return i;
/*      */       }
/*  711 */       throw new ParseException(new StringBuilder().append("Unexpected character '").append(c).append("' after '/'").toString(), i);
/*      */     }
/*      */ 
/*  715 */     addToSet(val, end, 0, type);
/*  716 */     i++;
/*  717 */     return i;
/*      */   }
/*      */ 
/*      */   protected int skipWhiteSpace(int i, String s)
/*      */   {
/*  722 */     while ((i < s.length()) && ((s.charAt(i) == ' ') || (s.charAt(i) == '\t'))) i++;
/*      */ 
/*  726 */     return i;
/*      */   }
/*      */ 
/*      */   protected int findNextWhiteSpace(int i, String s) {
/*  730 */     while ((i < s.length()) && ((s.charAt(i) != ' ') || (s.charAt(i) != '\t'))) i++;
/*      */ 
/*  734 */     return i;
/*      */   }
/*      */ 
/*      */   protected void addToSet(int val, int end, int incr, int type)
/*      */     throws ParseException
/*      */   {
/*  740 */     TreeSet set = getSet(type);
/*      */ 
/*  742 */     if ((type == 0) || (type == 1)) {
/*  743 */       if (((val < 0) || (val > 59) || (end > 59)) && (val != 99)) {
/*  744 */         throw new ParseException("Minute and Second values must be between 0 and 59", -1);
/*      */       }
/*      */ 
/*      */     }
/*  748 */     else if (type == 2) {
/*  749 */       if (((val < 0) || (val > 23) || (end > 23)) && (val != 99)) {
/*  750 */         throw new ParseException("Hour values must be between 0 and 23", -1);
/*      */       }
/*      */     }
/*  753 */     else if (type == 3) {
/*  754 */       if (((val < 1) || (val > 31) || (end > 31)) && (val != 99) && (val != 98))
/*      */       {
/*  756 */         throw new ParseException("Day of month values must be between 1 and 31", -1);
/*      */       }
/*      */     }
/*  759 */     else if (type == 4) {
/*  760 */       if (((val < 1) || (val > 12) || (end > 12)) && (val != 99)) {
/*  761 */         throw new ParseException("Month values must be between 1 and 12", -1);
/*      */       }
/*      */     }
/*  764 */     else if ((type == 5) && 
/*  765 */       ((val == 0) || (val > 7) || (end > 7)) && (val != 99) && (val != 98))
/*      */     {
/*  767 */       throw new ParseException("Day-of-Week values must be between 1 and 7", -1);
/*      */     }
/*      */ 
/*  772 */     if (((incr == 0) || (incr == -1)) && (val != 99)) {
/*  773 */       if (val != -1)
/*  774 */         set.add(Integer.valueOf(val));
/*      */       else {
/*  776 */         set.add(NO_SPEC);
/*      */       }
/*      */ 
/*  779 */       return;
/*      */     }
/*      */ 
/*  782 */     int startAt = val;
/*  783 */     int stopAt = end;
/*      */ 
/*  785 */     if ((val == 99) && (incr <= 0)) {
/*  786 */       incr = 1;
/*  787 */       set.add(ALL_SPEC);
/*      */     }
/*      */ 
/*  790 */     if ((type == 0) || (type == 1)) {
/*  791 */       if (stopAt == -1) {
/*  792 */         stopAt = 59;
/*      */       }
/*  794 */       if ((startAt == -1) || (startAt == 99))
/*  795 */         startAt = 0;
/*      */     }
/*  797 */     else if (type == 2) {
/*  798 */       if (stopAt == -1) {
/*  799 */         stopAt = 23;
/*      */       }
/*  801 */       if ((startAt == -1) || (startAt == 99))
/*  802 */         startAt = 0;
/*      */     }
/*  804 */     else if (type == 3) {
/*  805 */       if (stopAt == -1) {
/*  806 */         stopAt = 31;
/*      */       }
/*  808 */       if ((startAt == -1) || (startAt == 99))
/*  809 */         startAt = 1;
/*      */     }
/*  811 */     else if (type == 4) {
/*  812 */       if (stopAt == -1) {
/*  813 */         stopAt = 12;
/*      */       }
/*  815 */       if ((startAt == -1) || (startAt == 99))
/*  816 */         startAt = 1;
/*      */     }
/*  818 */     else if (type == 5) {
/*  819 */       if (stopAt == -1) {
/*  820 */         stopAt = 7;
/*      */       }
/*  822 */       if ((startAt == -1) || (startAt == 99))
/*  823 */         startAt = 1;
/*      */     }
/*  825 */     else if (type == 6) {
/*  826 */       if (stopAt == -1) {
/*  827 */         stopAt = MAX_YEAR;
/*      */       }
/*  829 */       if ((startAt == -1) || (startAt == 99)) {
/*  830 */         startAt = 1970;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  837 */     int max = -1;
/*  838 */     if (stopAt < startAt) {
/*  839 */       switch (type) { case 0:
/*  840 */         max = 60; break;
/*      */       case 1:
/*  841 */         max = 60; break;
/*      */       case 2:
/*  842 */         max = 24; break;
/*      */       case 4:
/*  843 */         max = 12; break;
/*      */       case 5:
/*  844 */         max = 7; break;
/*      */       case 3:
/*  845 */         max = 31; break;
/*      */       case 6:
/*  846 */         throw new IllegalArgumentException("Start year must be less than stop year");
/*      */       default:
/*  847 */         throw new IllegalArgumentException("Unexpected type encountered");
/*      */       }
/*  849 */       stopAt += max;
/*      */     }
/*      */ 
/*  852 */     for (int i = startAt; i <= stopAt; i += incr)
/*  853 */       if (max == -1)
/*      */       {
/*  855 */         set.add(Integer.valueOf(i));
/*      */       }
/*      */       else {
/*  858 */         int i2 = i % max;
/*      */ 
/*  861 */         if ((i2 == 0) && ((type == 4) || (type == 5) || (type == 3))) {
/*  862 */           i2 = max;
/*      */         }
/*      */ 
/*  865 */         set.add(Integer.valueOf(i2));
/*      */       }
/*      */   }
/*      */ 
/*      */   protected TreeSet<Integer> getSet(int type)
/*      */   {
/*  871 */     switch (type) {
/*      */     case 0:
/*  873 */       return this.seconds;
/*      */     case 1:
/*  875 */       return this.minutes;
/*      */     case 2:
/*  877 */       return this.hours;
/*      */     case 3:
/*  879 */       return this.daysOfMonth;
/*      */     case 4:
/*  881 */       return this.months;
/*      */     case 5:
/*  883 */       return this.daysOfWeek;
/*      */     case 6:
/*  885 */       return this.years;
/*      */     }
/*  887 */     return null;
/*      */   }
/*      */ 
/*      */   protected ValueSet getValue(int v, String s, int i)
/*      */   {
/*  892 */     char c = s.charAt(i);
/*  893 */     StringBuilder s1 = new StringBuilder(String.valueOf(v));
/*  894 */     while ((c >= '0') && (c <= '9')) {
/*  895 */       s1.append(c);
/*  896 */       i++;
/*  897 */       if (i >= s.length()) {
/*      */         break;
/*      */       }
/*  900 */       c = s.charAt(i);
/*      */     }
/*  902 */     ValueSet val = new ValueSet();
/*      */ 
/*  904 */     val.pos = (i < s.length() ? i : i + 1);
/*  905 */     val.value = Integer.parseInt(s1.toString());
/*  906 */     return val;
/*      */   }
/*      */ 
/*      */   protected int getNumericValue(String s, int i) {
/*  910 */     int endOfVal = findNextWhiteSpace(i, s);
/*  911 */     String val = s.substring(i, endOfVal);
/*  912 */     return Integer.parseInt(val);
/*      */   }
/*      */ 
/*      */   protected int getMonthNumber(String s) {
/*  916 */     Integer integer = (Integer)monthMap.get(s);
/*      */ 
/*  918 */     if (integer == null) {
/*  919 */       return -1;
/*      */     }
/*      */ 
/*  922 */     return integer.intValue();
/*      */   }
/*      */ 
/*      */   protected int getDayOfWeekNumber(String s) {
/*  926 */     Integer integer = (Integer)dayMap.get(s);
/*      */ 
/*  928 */     if (integer == null) {
/*  929 */       return -1;
/*      */     }
/*      */ 
/*  932 */     return integer.intValue();
/*      */   }
/*      */ 
/*      */   public Date getTimeAfter(Date afterTime)
/*      */   {
/*  944 */     Calendar cl = new GregorianCalendar(getTimeZone());
/*      */ 
/*  948 */     afterTime = new Date(afterTime.getTime() + 1000L);
/*      */ 
/*  950 */     cl.setTime(afterTime);
/*  951 */     cl.set(14, 0);
/*      */ 
/*  953 */     boolean gotOne = false;
/*      */ 
/*  955 */     while (!gotOne)
/*      */     {
/*  958 */       if (cl.get(1) > 2999) {
/*  959 */         return null;
/*      */       }
/*      */ 
/*  962 */       SortedSet st = null;
/*  963 */       int t = 0;
/*      */ 
/*  965 */       int sec = cl.get(13);
/*  966 */       int min = cl.get(12);
/*      */ 
/*  969 */       st = this.seconds.tailSet(Integer.valueOf(sec));
/*  970 */       if ((st != null) && (st.size() != 0)) {
/*  971 */         sec = ((Integer)st.first()).intValue();
/*      */       } else {
/*  973 */         sec = ((Integer)this.seconds.first()).intValue();
/*  974 */         min++;
/*  975 */         cl.set(12, min);
/*      */       }
/*  977 */       cl.set(13, sec);
/*      */ 
/*  979 */       min = cl.get(12);
/*  980 */       int hr = cl.get(11);
/*  981 */       t = -1;
/*      */ 
/*  984 */       st = this.minutes.tailSet(Integer.valueOf(min));
/*  985 */       if ((st != null) && (st.size() != 0)) {
/*  986 */         t = min;
/*  987 */         min = ((Integer)st.first()).intValue();
/*      */       } else {
/*  989 */         min = ((Integer)this.minutes.first()).intValue();
/*  990 */         hr++;
/*      */       }
/*  992 */       if (min != t) {
/*  993 */         cl.set(13, 0);
/*  994 */         cl.set(12, min);
/*  995 */         setCalendarHour(cl, hr);
/*  996 */         continue;
/*      */       }
/*  998 */       cl.set(12, min);
/*      */ 
/* 1000 */       hr = cl.get(11);
/* 1001 */       int day = cl.get(5);
/* 1002 */       t = -1;
/*      */ 
/* 1005 */       st = this.hours.tailSet(Integer.valueOf(hr));
/* 1006 */       if ((st != null) && (st.size() != 0)) {
/* 1007 */         t = hr;
/* 1008 */         hr = ((Integer)st.first()).intValue();
/*      */       } else {
/* 1010 */         hr = ((Integer)this.hours.first()).intValue();
/* 1011 */         day++;
/*      */       }
/* 1013 */       if (hr != t) {
/* 1014 */         cl.set(13, 0);
/* 1015 */         cl.set(12, 0);
/* 1016 */         cl.set(5, day);
/* 1017 */         setCalendarHour(cl, hr);
/* 1018 */         continue;
/*      */       }
/* 1020 */       cl.set(11, hr);
/*      */ 
/* 1022 */       day = cl.get(5);
/* 1023 */       int mon = cl.get(2) + 1;
/*      */ 
/* 1026 */       t = -1;
/* 1027 */       int tmon = mon;
/*      */ 
/* 1030 */       boolean dayOfMSpec = !this.daysOfMonth.contains(NO_SPEC);
/* 1031 */       boolean dayOfWSpec = !this.daysOfWeek.contains(NO_SPEC);
/* 1032 */       if ((dayOfMSpec) && (!dayOfWSpec)) {
/* 1033 */         st = this.daysOfMonth.tailSet(Integer.valueOf(day));
/* 1034 */         if (this.lastdayOfMonth) {
/* 1035 */           if (!this.nearestWeekday) {
/* 1036 */             t = day;
/* 1037 */             day = getLastDayOfMonth(mon, cl.get(1));
/* 1038 */             day -= this.lastdayOffset;
/*      */           } else {
/* 1040 */             t = day;
/* 1041 */             day = getLastDayOfMonth(mon, cl.get(1));
/* 1042 */             day -= this.lastdayOffset;
/*      */ 
/* 1044 */             Calendar tcal = Calendar.getInstance(getTimeZone());
/* 1045 */             tcal.set(13, 0);
/* 1046 */             tcal.set(12, 0);
/* 1047 */             tcal.set(11, 0);
/* 1048 */             tcal.set(5, day);
/* 1049 */             tcal.set(2, mon - 1);
/* 1050 */             tcal.set(1, cl.get(1));
/*      */ 
/* 1052 */             int ldom = getLastDayOfMonth(mon, cl.get(1));
/* 1053 */             int dow = tcal.get(7);
/*      */ 
/* 1055 */             if ((dow == 7) && (day == 1))
/* 1056 */               day += 2;
/* 1057 */             else if (dow == 7)
/* 1058 */               day--;
/* 1059 */             else if ((dow == 1) && (day == ldom))
/* 1060 */               day -= 2;
/* 1061 */             else if (dow == 1) {
/* 1062 */               day++;
/*      */             }
/*      */ 
/* 1065 */             tcal.set(13, sec);
/* 1066 */             tcal.set(12, min);
/* 1067 */             tcal.set(11, hr);
/* 1068 */             tcal.set(5, day);
/* 1069 */             tcal.set(2, mon - 1);
/* 1070 */             Date nTime = tcal.getTime();
/* 1071 */             if (nTime.before(afterTime)) {
/* 1072 */               day = 1;
/* 1073 */               mon++;
/*      */             }
/*      */           }
/* 1076 */         } else if (this.nearestWeekday) {
/* 1077 */           t = day;
/* 1078 */           day = ((Integer)this.daysOfMonth.first()).intValue();
/*      */ 
/* 1080 */           Calendar tcal = Calendar.getInstance(getTimeZone());
/* 1081 */           tcal.set(13, 0);
/* 1082 */           tcal.set(12, 0);
/* 1083 */           tcal.set(11, 0);
/* 1084 */           tcal.set(5, day);
/* 1085 */           tcal.set(2, mon - 1);
/* 1086 */           tcal.set(1, cl.get(1));
/*      */ 
/* 1088 */           int ldom = getLastDayOfMonth(mon, cl.get(1));
/* 1089 */           int dow = tcal.get(7);
/*      */ 
/* 1091 */           if ((dow == 7) && (day == 1))
/* 1092 */             day += 2;
/* 1093 */           else if (dow == 7)
/* 1094 */             day--;
/* 1095 */           else if ((dow == 1) && (day == ldom))
/* 1096 */             day -= 2;
/* 1097 */           else if (dow == 1) {
/* 1098 */             day++;
/*      */           }
/*      */ 
/* 1102 */           tcal.set(13, sec);
/* 1103 */           tcal.set(12, min);
/* 1104 */           tcal.set(11, hr);
/* 1105 */           tcal.set(5, day);
/* 1106 */           tcal.set(2, mon - 1);
/* 1107 */           Date nTime = tcal.getTime();
/* 1108 */           if (nTime.before(afterTime)) {
/* 1109 */             day = ((Integer)this.daysOfMonth.first()).intValue();
/* 1110 */             mon++;
/*      */           }
/* 1112 */         } else if ((st != null) && (st.size() != 0)) {
/* 1113 */           t = day;
/* 1114 */           day = ((Integer)st.first()).intValue();
/*      */ 
/* 1116 */           int lastDay = getLastDayOfMonth(mon, cl.get(1));
/* 1117 */           if (day > lastDay) {
/* 1118 */             day = ((Integer)this.daysOfMonth.first()).intValue();
/* 1119 */             mon++;
/*      */           }
/*      */         } else {
/* 1122 */           day = ((Integer)this.daysOfMonth.first()).intValue();
/* 1123 */           mon++;
/*      */         }
/*      */ 
/* 1126 */         if ((day != t) || (mon != tmon)) {
/* 1127 */           cl.set(13, 0);
/* 1128 */           cl.set(12, 0);
/* 1129 */           cl.set(11, 0);
/* 1130 */           cl.set(5, day);
/* 1131 */           cl.set(2, mon - 1);
/*      */ 
/* 1134 */           continue;
/*      */         }
/* 1136 */       } else if ((dayOfWSpec) && (!dayOfMSpec)) {
/* 1137 */         if (this.lastdayOfWeek)
/*      */         {
/* 1139 */           int dow = ((Integer)this.daysOfWeek.first()).intValue();
/*      */ 
/* 1141 */           int cDow = cl.get(7);
/* 1142 */           int daysToAdd = 0;
/* 1143 */           if (cDow < dow) {
/* 1144 */             daysToAdd = dow - cDow;
/*      */           }
/* 1146 */           if (cDow > dow) {
/* 1147 */             daysToAdd = dow + (7 - cDow);
/*      */           }
/*      */ 
/* 1150 */           int lDay = getLastDayOfMonth(mon, cl.get(1));
/*      */ 
/* 1152 */           if (day + daysToAdd > lDay)
/*      */           {
/* 1154 */             cl.set(13, 0);
/* 1155 */             cl.set(12, 0);
/* 1156 */             cl.set(11, 0);
/* 1157 */             cl.set(5, 1);
/* 1158 */             cl.set(2, mon);
/*      */ 
/* 1160 */             continue;
/*      */           }
/*      */ 
/* 1164 */           while (day + daysToAdd + 7 <= lDay) {
/* 1165 */             daysToAdd += 7;
/*      */           }
/*      */ 
/* 1168 */           day += daysToAdd;
/*      */ 
/* 1170 */           if (daysToAdd > 0) {
/* 1171 */             cl.set(13, 0);
/* 1172 */             cl.set(12, 0);
/* 1173 */             cl.set(11, 0);
/* 1174 */             cl.set(5, day);
/* 1175 */             cl.set(2, mon - 1);
/*      */ 
/* 1177 */             continue;
/*      */           }
/*      */         }
/* 1180 */         else if (this.nthdayOfWeek != 0)
/*      */         {
/* 1182 */           int dow = ((Integer)this.daysOfWeek.first()).intValue();
/*      */ 
/* 1184 */           int cDow = cl.get(7);
/* 1185 */           int daysToAdd = 0;
/* 1186 */           if (cDow < dow)
/* 1187 */             daysToAdd = dow - cDow;
/* 1188 */           else if (cDow > dow) {
/* 1189 */             daysToAdd = dow + (7 - cDow);
/*      */           }
/*      */ 
/* 1192 */           boolean dayShifted = false;
/* 1193 */           if (daysToAdd > 0) {
/* 1194 */             dayShifted = true;
/*      */           }
/*      */ 
/* 1197 */           day += daysToAdd;
/* 1198 */           int weekOfMonth = day / 7;
/* 1199 */           if (day % 7 > 0) {
/* 1200 */             weekOfMonth++;
/*      */           }
/*      */ 
/* 1203 */           daysToAdd = (this.nthdayOfWeek - weekOfMonth) * 7;
/* 1204 */           day += daysToAdd;
/* 1205 */           if ((daysToAdd < 0) || (day > getLastDayOfMonth(mon, cl.get(1))))
/*      */           {
/* 1208 */             cl.set(13, 0);
/* 1209 */             cl.set(12, 0);
/* 1210 */             cl.set(11, 0);
/* 1211 */             cl.set(5, 1);
/* 1212 */             cl.set(2, mon);
/*      */ 
/* 1214 */             continue;
/* 1215 */           }if ((daysToAdd > 0) || (dayShifted)) {
/* 1216 */             cl.set(13, 0);
/* 1217 */             cl.set(12, 0);
/* 1218 */             cl.set(11, 0);
/* 1219 */             cl.set(5, day);
/* 1220 */             cl.set(2, mon - 1);
/*      */ 
/* 1222 */             continue;
/*      */           }
/*      */         } else {
/* 1225 */           int cDow = cl.get(7);
/* 1226 */           int dow = ((Integer)this.daysOfWeek.first()).intValue();
/*      */ 
/* 1228 */           st = this.daysOfWeek.tailSet(Integer.valueOf(cDow));
/* 1229 */           if ((st != null) && (st.size() > 0)) {
/* 1230 */             dow = ((Integer)st.first()).intValue();
/*      */           }
/*      */ 
/* 1233 */           int daysToAdd = 0;
/* 1234 */           if (cDow < dow) {
/* 1235 */             daysToAdd = dow - cDow;
/*      */           }
/* 1237 */           if (cDow > dow) {
/* 1238 */             daysToAdd = dow + (7 - cDow);
/*      */           }
/*      */ 
/* 1241 */           int lDay = getLastDayOfMonth(mon, cl.get(1));
/*      */ 
/* 1243 */           if (day + daysToAdd > lDay)
/*      */           {
/* 1245 */             cl.set(13, 0);
/* 1246 */             cl.set(12, 0);
/* 1247 */             cl.set(11, 0);
/* 1248 */             cl.set(5, 1);
/* 1249 */             cl.set(2, mon);
/*      */ 
/* 1251 */             continue;
/* 1252 */           }if (daysToAdd > 0) {
/* 1253 */             cl.set(13, 0);
/* 1254 */             cl.set(12, 0);
/* 1255 */             cl.set(11, 0);
/* 1256 */             cl.set(5, day + daysToAdd);
/* 1257 */             cl.set(2, mon - 1);
/*      */ 
/* 1260 */             continue;
/*      */           }
/*      */         }
/*      */       } else {
/* 1264 */         throw new UnsupportedOperationException("Support for specifying both a day-of-week AND a day-of-month parameter is not implemented.");
/*      */       }
/*      */ 
/* 1268 */       cl.set(5, day);
/*      */ 
/* 1270 */       mon = cl.get(2) + 1;
/*      */ 
/* 1273 */       int year = cl.get(1);
/* 1274 */       t = -1;
/*      */ 
/* 1278 */       if (year > MAX_YEAR) {
/* 1279 */         return null;
/*      */       }
/*      */ 
/* 1283 */       st = this.months.tailSet(Integer.valueOf(mon));
/* 1284 */       if ((st != null) && (st.size() != 0)) {
/* 1285 */         t = mon;
/* 1286 */         mon = ((Integer)st.first()).intValue();
/*      */       } else {
/* 1288 */         mon = ((Integer)this.months.first()).intValue();
/* 1289 */         year++;
/*      */       }
/* 1291 */       if (mon != t) {
/* 1292 */         cl.set(13, 0);
/* 1293 */         cl.set(12, 0);
/* 1294 */         cl.set(11, 0);
/* 1295 */         cl.set(5, 1);
/* 1296 */         cl.set(2, mon - 1);
/*      */ 
/* 1299 */         cl.set(1, year);
/* 1300 */         continue;
/*      */       }
/* 1302 */       cl.set(2, mon - 1);
/*      */ 
/* 1306 */       year = cl.get(1);
/* 1307 */       t = -1;
/*      */ 
/* 1310 */       st = this.years.tailSet(Integer.valueOf(year));
/* 1311 */       if ((st != null) && (st.size() != 0)) {
/* 1312 */         t = year;
/* 1313 */         year = ((Integer)st.first()).intValue();
/*      */       } else {
/* 1315 */         return null;
/*      */       }
/*      */ 
/* 1318 */       if (year != t) {
/* 1319 */         cl.set(13, 0);
/* 1320 */         cl.set(12, 0);
/* 1321 */         cl.set(11, 0);
/* 1322 */         cl.set(5, 1);
/* 1323 */         cl.set(2, 0);
/*      */ 
/* 1326 */         cl.set(1, year);
/* 1327 */         continue;
/*      */       }
/* 1329 */       cl.set(1, year);
/*      */ 
/* 1331 */       gotOne = true;
/*      */     }
/*      */ 
/* 1334 */     return cl.getTime();
/*      */   }
/*      */ 
/*      */   protected void setCalendarHour(Calendar cal, int hour)
/*      */   {
/* 1345 */     cal.set(11, hour);
/* 1346 */     if ((cal.get(11) != hour) && (hour != 24))
/* 1347 */       cal.set(11, hour + 1);
/*      */   }
/*      */ 
/*      */   protected boolean isLeapYear(int year)
/*      */   {
/* 1354 */     return ((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0);
/*      */   }
/*      */ 
/*      */   protected int getLastDayOfMonth(int monthNum, int year)
/*      */   {
/* 1359 */     switch (monthNum) {
/*      */     case 1:
/* 1361 */       return 31;
/*      */     case 2:
/* 1363 */       return isLeapYear(year) ? 29 : 28;
/*      */     case 3:
/* 1365 */       return 31;
/*      */     case 4:
/* 1367 */       return 30;
/*      */     case 5:
/* 1369 */       return 31;
/*      */     case 6:
/* 1371 */       return 30;
/*      */     case 7:
/* 1373 */       return 31;
/*      */     case 8:
/* 1375 */       return 31;
/*      */     case 9:
/* 1377 */       return 30;
/*      */     case 10:
/* 1379 */       return 31;
/*      */     case 11:
/* 1381 */       return 30;
/*      */     case 12:
/* 1383 */       return 31;
/*      */     }
/* 1385 */     throw new IllegalArgumentException(new StringBuilder().append("Illegal month number: ").append(monthNum).toString());
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*  219 */     monthMap.put("JAN", Integer.valueOf(0));
/*  220 */     monthMap.put("FEB", Integer.valueOf(1));
/*  221 */     monthMap.put("MAR", Integer.valueOf(2));
/*  222 */     monthMap.put("APR", Integer.valueOf(3));
/*  223 */     monthMap.put("MAY", Integer.valueOf(4));
/*  224 */     monthMap.put("JUN", Integer.valueOf(5));
/*  225 */     monthMap.put("JUL", Integer.valueOf(6));
/*  226 */     monthMap.put("AUG", Integer.valueOf(7));
/*  227 */     monthMap.put("SEP", Integer.valueOf(8));
/*  228 */     monthMap.put("OCT", Integer.valueOf(9));
/*  229 */     monthMap.put("NOV", Integer.valueOf(10));
/*  230 */     monthMap.put("DEC", Integer.valueOf(11));
/*      */ 
/*  232 */     dayMap.put("SUN", Integer.valueOf(1));
/*  233 */     dayMap.put("MON", Integer.valueOf(2));
/*  234 */     dayMap.put("TUE", Integer.valueOf(3));
/*  235 */     dayMap.put("WED", Integer.valueOf(4));
/*  236 */     dayMap.put("THU", Integer.valueOf(5));
/*  237 */     dayMap.put("FRI", Integer.valueOf(6));
/*  238 */     dayMap.put("SAT", Integer.valueOf(7));
/*      */ 
/*  258 */     MAX_YEAR = Calendar.getInstance().get(1) + 100;
/*      */   }
/*      */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.calendar.CronExpression
 * JD-Core Version:    0.6.0
 */