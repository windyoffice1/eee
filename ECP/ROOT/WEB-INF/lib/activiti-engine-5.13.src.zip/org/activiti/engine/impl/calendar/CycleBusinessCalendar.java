/*    */ package org.activiti.engine.impl.calendar;
/*    */ 
/*    */ import java.util.Date;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.impl.util.ClockUtil;
/*    */ 
/*    */ public class CycleBusinessCalendar
/*    */   implements BusinessCalendar
/*    */ {
/* 24 */   public static String NAME = "cycle";
/*    */ 
/*    */   public Date resolveDuedate(String duedateDescription)
/*    */   {
/*    */     try {
/* 29 */       if (duedateDescription.startsWith("R")) {
/* 30 */         return new DurationHelper(duedateDescription).getDateAfter();
/*    */       }
/* 32 */       CronExpression ce = new CronExpression(duedateDescription);
/* 33 */       return ce.getTimeAfter(ClockUtil.getCurrentTime());
/*    */     }
/*    */     catch (Exception e) {
/*    */     }
/* 37 */     throw new ActivitiException("Failed to parse cron expression: " + duedateDescription, e);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.calendar.CycleBusinessCalendar
 * JD-Core Version:    0.6.0
 */