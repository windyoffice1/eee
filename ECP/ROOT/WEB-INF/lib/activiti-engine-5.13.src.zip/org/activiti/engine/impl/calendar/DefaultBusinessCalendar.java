/*    */ package org.activiti.engine.impl.calendar;
/*    */ 
/*    */ import java.util.Date;
/*    */ import java.util.GregorianCalendar;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.impl.util.ClockUtil;
/*    */ 
/*    */ public class DefaultBusinessCalendar
/*    */   implements BusinessCalendar
/*    */ {
/* 30 */   private static Map<String, Integer> units = new HashMap();
/*    */ 
/*    */   public Date resolveDuedate(String duedate)
/*    */   {
/* 50 */     Date resolvedDuedate = ClockUtil.getCurrentTime();
/*    */ 
/* 52 */     String[] tokens = duedate.split(" and ");
/* 53 */     for (String token : tokens) {
/* 54 */       resolvedDuedate = addSingleUnitQuantity(resolvedDuedate, token);
/*    */     }
/*    */ 
/* 57 */     return resolvedDuedate;
/*    */   }
/*    */ 
/*    */   protected Date addSingleUnitQuantity(Date startDate, String singleUnitQuantity) {
/* 61 */     int spaceIndex = singleUnitQuantity.indexOf(" ");
/* 62 */     if ((spaceIndex == -1) || (singleUnitQuantity.length() < spaceIndex + 1)) {
/* 63 */       throw new ActivitiIllegalArgumentException("invalid duedate format: " + singleUnitQuantity);
/*    */     }
/*    */ 
/* 66 */     String quantityText = singleUnitQuantity.substring(0, spaceIndex);
/* 67 */     Integer quantity = new Integer(quantityText);
/*    */ 
/* 69 */     String unitText = singleUnitQuantity.substring(spaceIndex + 1).trim().toLowerCase();
/*    */ 
/* 74 */     int unit = ((Integer)units.get(unitText)).intValue();
/*    */ 
/* 76 */     GregorianCalendar calendar = new GregorianCalendar();
/* 77 */     calendar.setTime(startDate);
/* 78 */     calendar.add(unit, quantity.intValue());
/*    */ 
/* 80 */     return calendar.getTime();
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 32 */     units.put("millis", Integer.valueOf(14));
/* 33 */     units.put("seconds", Integer.valueOf(13));
/* 34 */     units.put("second", Integer.valueOf(13));
/* 35 */     units.put("minute", Integer.valueOf(12));
/* 36 */     units.put("minutes", Integer.valueOf(12));
/* 37 */     units.put("hour", Integer.valueOf(10));
/* 38 */     units.put("hours", Integer.valueOf(10));
/* 39 */     units.put("day", Integer.valueOf(6));
/* 40 */     units.put("days", Integer.valueOf(6));
/* 41 */     units.put("week", Integer.valueOf(3));
/* 42 */     units.put("weeks", Integer.valueOf(3));
/* 43 */     units.put("month", Integer.valueOf(2));
/* 44 */     units.put("months", Integer.valueOf(2));
/* 45 */     units.put("year", Integer.valueOf(1));
/* 46 */     units.put("years", Integer.valueOf(1));
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.calendar.DefaultBusinessCalendar
 * JD-Core Version:    0.6.0
 */