/*    */ package org.activiti.engine.impl.calendar;
/*    */ 
/*    */ import java.util.Date;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.joda.time.DateTime;
/*    */ import org.joda.time.Period;
/*    */ 
/*    */ public class DueDateBusinessCalendar
/*    */   implements BusinessCalendar
/*    */ {
/*    */   public static final String NAME = "dueDate";
/*    */ 
/*    */   public Date resolveDuedate(String duedate)
/*    */   {
/*    */     try
/*    */     {
/* 30 */       if (duedate.startsWith("P")) {
/* 31 */         return DateTime.now().plus(Period.parse(duedate)).toDate();
/*    */       }
/*    */ 
/* 34 */       return DateTime.parse(duedate).toDate();
/*    */     } catch (Exception e) {
/*    */     }
/* 37 */     throw new ActivitiException("couldn't resolve duedate: " + e.getMessage(), e);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.calendar.DueDateBusinessCalendar
 * JD-Core Version:    0.6.0
 */