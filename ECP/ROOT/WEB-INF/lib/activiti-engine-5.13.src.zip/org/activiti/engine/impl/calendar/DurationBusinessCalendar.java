/*    */ package org.activiti.engine.impl.calendar;
/*    */ 
/*    */ import java.util.Date;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ 
/*    */ public class DurationBusinessCalendar
/*    */   implements BusinessCalendar
/*    */ {
/* 31 */   public static String NAME = "duration";
/*    */ 
/*    */   public Date resolveDuedate(String duedate) {
/*    */     try {
/* 35 */       DurationHelper dh = new DurationHelper(duedate);
/* 36 */       return dh.getDateAfter(); } catch (Exception e) {
/*    */     }
/* 38 */     throw new ActivitiException("couldn't resolve duedate: " + e.getMessage(), e);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.calendar.DurationBusinessCalendar
 * JD-Core Version:    0.6.0
 */