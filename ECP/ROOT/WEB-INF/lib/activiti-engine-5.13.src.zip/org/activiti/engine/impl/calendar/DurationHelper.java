/*     */ package org.activiti.engine.impl.calendar;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.List;
/*     */ import javax.xml.datatype.DatatypeFactory;
/*     */ import javax.xml.datatype.Duration;
/*     */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*     */ import org.activiti.engine.impl.util.ClockUtil;
/*     */ import org.joda.time.DateTime;
/*     */ 
/*     */ public class DurationHelper
/*     */ {
/*     */   Date start;
/*     */   Date end;
/*     */   Duration period;
/*     */   boolean isRepeat;
/*     */   int times;
/*     */   DatatypeFactory datatypeFactory;
/*     */ 
/*     */   public DurationHelper(String expressionS)
/*     */     throws Exception
/*     */   {
/*  48 */     List expression = Arrays.asList(expressionS.split("/"));
/*  49 */     this.datatypeFactory = DatatypeFactory.newInstance();
/*     */ 
/*  51 */     if ((expression.size() > 3) || (expression.isEmpty())) {
/*  52 */       throw new ActivitiIllegalArgumentException("Cannot parse duration");
/*     */     }
/*  54 */     if (((String)expression.get(0)).startsWith("R")) {
/*  55 */       this.isRepeat = true;
/*  56 */       this.times = (((String)expression.get(0)).length() == 1 ? 2147483647 : Integer.parseInt(((String)expression.get(0)).substring(1)));
/*  57 */       expression = expression.subList(1, expression.size());
/*     */     }
/*     */ 
/*  60 */     if (isDuration((String)expression.get(0))) {
/*  61 */       this.period = parsePeriod((String)expression.get(0));
/*  62 */       this.end = (expression.size() == 1 ? null : parseDate((String)expression.get(1)));
/*     */     } else {
/*  64 */       this.start = parseDate((String)expression.get(0));
/*  65 */       if (isDuration((String)expression.get(1))) {
/*  66 */         this.period = parsePeriod((String)expression.get(1));
/*     */       } else {
/*  68 */         this.end = parseDate((String)expression.get(1));
/*  69 */         this.period = this.datatypeFactory.newDuration(this.end.getTime() - this.start.getTime());
/*     */       }
/*     */     }
/*  72 */     if ((this.start == null) && (this.end == null))
/*  73 */       this.start = ClockUtil.getCurrentTime();
/*     */   }
/*     */ 
/*     */   public Date getDateAfter()
/*     */   {
/*  79 */     if (this.isRepeat) {
/*  80 */       return getDateAfterRepeat(ClockUtil.getCurrentTime());
/*     */     }
/*     */ 
/*  83 */     if (this.end != null) {
/*  84 */       return this.end;
/*     */     }
/*  86 */     return add(this.start, this.period);
/*     */   }
/*     */ 
/*     */   public int getTimes() {
/*  90 */     return this.times;
/*     */   }
/*     */ 
/*     */   private Date getDateAfterRepeat(Date date) {
/*  94 */     if (this.start != null) {
/*  95 */       Date cur = this.start;
/*  96 */       for (int i = 0; (i < this.times) && (!cur.after(date)); i++) {
/*  97 */         cur = add(cur, this.period);
/*     */       }
/*  99 */       return cur.before(date) ? null : cur;
/*     */     }
/* 101 */     Date cur = add(this.end, this.period.negate());
/* 102 */     Date next = this.end;
/*     */ 
/* 104 */     for (int i = 0; (i < this.times) && (cur.after(date)); i++) {
/* 105 */       next = cur;
/* 106 */       cur = add(cur, this.period.negate());
/*     */     }
/* 108 */     return next.before(date) ? null : next;
/*     */   }
/*     */ 
/*     */   private Date add(Date date, Duration duration) {
/* 112 */     Calendar calendar = new GregorianCalendar();
/* 113 */     calendar.setTime(date);
/* 114 */     duration.addTo(calendar);
/* 115 */     return calendar.getTime();
/*     */   }
/*     */ 
/*     */   private Date parseDate(String date) throws Exception {
/* 119 */     return DateTime.parse(date).toDate();
/*     */   }
/*     */ 
/*     */   private Duration parsePeriod(String period) throws Exception {
/* 123 */     return this.datatypeFactory.newDuration(period);
/*     */   }
/*     */ 
/*     */   private boolean isDuration(String time) {
/* 127 */     return time.startsWith("P");
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.calendar.DurationHelper
 * JD-Core Version:    0.6.0
 */