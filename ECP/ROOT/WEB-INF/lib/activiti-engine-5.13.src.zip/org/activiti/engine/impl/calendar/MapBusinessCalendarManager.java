/*    */ package org.activiti.engine.impl.calendar;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class MapBusinessCalendarManager
/*    */   implements BusinessCalendarManager
/*    */ {
/* 24 */   private Map<String, BusinessCalendar> businessCalendars = new HashMap();
/*    */ 
/*    */   public BusinessCalendar getBusinessCalendar(String businessCalendarRef) {
/* 27 */     return (BusinessCalendar)this.businessCalendars.get(businessCalendarRef);
/*    */   }
/*    */ 
/*    */   public BusinessCalendarManager addBusinessCalendar(String businessCalendarRef, BusinessCalendar businessCalendar) {
/* 31 */     this.businessCalendars.put(businessCalendarRef, businessCalendar);
/* 32 */     return this;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.calendar.MapBusinessCalendarManager
 * JD-Core Version:    0.6.0
 */