package org.activiti.engine.impl.calendar;

class ValueSet
{
  public int value;
  public int pos;
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.calendar.ValueSet
 * JD-Core Version:    0.6.0
 */