/*    */ package org.activiti.engine.impl.cfg;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import org.activiti.engine.ProcessEngineConfiguration;
/*    */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*    */ import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
/*    */ import org.springframework.core.io.ClassPathResource;
/*    */ import org.springframework.core.io.InputStreamResource;
/*    */ import org.springframework.core.io.Resource;
/*    */ 
/*    */ public class BeansConfigurationHelper
/*    */ {
/*    */   public static ProcessEngineConfiguration parseProcessEngineConfiguration(Resource springResource, String beanName)
/*    */   {
/* 32 */     DefaultListableBeanFactory beanFactory = new DefaultListableBeanFactory();
/* 33 */     XmlBeanDefinitionReader xmlBeanDefinitionReader = new XmlBeanDefinitionReader(beanFactory);
/* 34 */     xmlBeanDefinitionReader.setValidationMode(3);
/* 35 */     xmlBeanDefinitionReader.loadBeanDefinitions(springResource);
/* 36 */     ProcessEngineConfigurationImpl processEngineConfiguration = (ProcessEngineConfigurationImpl)beanFactory.getBean(beanName);
/* 37 */     processEngineConfiguration.setBeans(new SpringBeanFactoryProxyMap(beanFactory));
/* 38 */     return processEngineConfiguration;
/*    */   }
/*    */ 
/*    */   public static ProcessEngineConfiguration parseProcessEngineConfigurationFromInputStream(InputStream inputStream, String beanName) {
/* 42 */     Resource springResource = new InputStreamResource(inputStream);
/* 43 */     return parseProcessEngineConfiguration(springResource, beanName);
/*    */   }
/*    */ 
/*    */   public static ProcessEngineConfiguration parseProcessEngineConfigurationFromResource(String resource, String beanName) {
/* 47 */     Resource springResource = new ClassPathResource(resource);
/* 48 */     return parseProcessEngineConfiguration(springResource, beanName);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cfg.BeansConfigurationHelper
 * JD-Core Version:    0.6.0
 */