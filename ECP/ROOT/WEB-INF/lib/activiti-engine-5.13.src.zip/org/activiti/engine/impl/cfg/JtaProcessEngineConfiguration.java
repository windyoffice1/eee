/*    */ package org.activiti.engine.impl.cfg;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import javax.transaction.TransactionManager;
/*    */ import org.activiti.engine.impl.cfg.jta.JtaTransactionContextFactory;
/*    */ import org.activiti.engine.impl.interceptor.CommandContextInterceptor;
/*    */ import org.activiti.engine.impl.interceptor.CommandInterceptor;
/*    */ import org.activiti.engine.impl.interceptor.JtaTransactionInterceptor;
/*    */ import org.activiti.engine.impl.interceptor.LogInterceptor;
/*    */ 
/*    */ public class JtaProcessEngineConfiguration extends ProcessEngineConfigurationImpl
/*    */ {
/*    */   protected TransactionManager transactionManager;
/*    */ 
/*    */   protected Collection<? extends CommandInterceptor> getDefaultCommandInterceptorsTxRequired()
/*    */   {
/* 38 */     List defaultCommandInterceptorsTxRequired = new ArrayList();
/* 39 */     defaultCommandInterceptorsTxRequired.add(new LogInterceptor());
/* 40 */     defaultCommandInterceptorsTxRequired.add(new JtaTransactionInterceptor(this.transactionManager, false));
/* 41 */     defaultCommandInterceptorsTxRequired.add(new CommandContextInterceptor(this.commandContextFactory, this));
/* 42 */     return defaultCommandInterceptorsTxRequired;
/*    */   }
/*    */ 
/*    */   protected Collection<? extends CommandInterceptor> getDefaultCommandInterceptorsTxRequiresNew()
/*    */   {
/* 47 */     List defaultCommandInterceptorsTxRequiresNew = new ArrayList();
/* 48 */     defaultCommandInterceptorsTxRequiresNew.add(new LogInterceptor());
/* 49 */     defaultCommandInterceptorsTxRequiresNew.add(new JtaTransactionInterceptor(this.transactionManager, true));
/* 50 */     defaultCommandInterceptorsTxRequiresNew.add(new CommandContextInterceptor(this.commandContextFactory, this));
/* 51 */     return defaultCommandInterceptorsTxRequiresNew;
/*    */   }
/*    */ 
/*    */   protected void initTransactionContextFactory()
/*    */   {
/* 56 */     if (this.transactionContextFactory == null)
/* 57 */       this.transactionContextFactory = new JtaTransactionContextFactory(this.transactionManager);
/*    */   }
/*    */ 
/*    */   public TransactionManager getTransactionManager()
/*    */   {
/* 62 */     return this.transactionManager;
/*    */   }
/*    */ 
/*    */   public void setTransactionManager(TransactionManager transactionManager) {
/* 66 */     this.transactionManager = transactionManager;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cfg.JtaProcessEngineConfiguration
 * JD-Core Version:    0.6.0
 */