/*    */ package org.activiti.engine.impl.cfg;
/*    */ 
/*    */ public class MailServerInfo
/*    */ {
/*    */   protected String mailServerDefaultFrom;
/*    */   protected String mailServerHost;
/*    */   protected int mailServerPort;
/*    */   protected String mailServerUsername;
/*    */   protected String mailServerPassword;
/*    */ 
/*    */   public String getMailServerDefaultFrom()
/*    */   {
/* 29 */     return this.mailServerDefaultFrom;
/*    */   }
/*    */ 
/*    */   public void setMailServerDefaultFrom(String mailServerDefaultFrom) {
/* 33 */     this.mailServerDefaultFrom = mailServerDefaultFrom;
/*    */   }
/*    */ 
/*    */   public String getMailServerHost() {
/* 37 */     return this.mailServerHost;
/*    */   }
/*    */ 
/*    */   public void setMailServerHost(String mailServerHost) {
/* 41 */     this.mailServerHost = mailServerHost;
/*    */   }
/*    */ 
/*    */   public int getMailServerPort() {
/* 45 */     return this.mailServerPort;
/*    */   }
/*    */ 
/*    */   public void setMailServerPort(int mailServerPort) {
/* 49 */     this.mailServerPort = mailServerPort;
/*    */   }
/*    */ 
/*    */   public String getMailServerUsername() {
/* 53 */     return this.mailServerUsername;
/*    */   }
/*    */ 
/*    */   public void setMailServerUsername(String mailServerUsername) {
/* 57 */     this.mailServerUsername = mailServerUsername;
/*    */   }
/*    */ 
/*    */   public String getMailServerPassword() {
/* 61 */     return this.mailServerPassword;
/*    */   }
/*    */ 
/*    */   public void setMailServerPassword(String mailServerPassword) {
/* 65 */     this.mailServerPassword = mailServerPassword;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cfg.MailServerInfo
 * JD-Core Version:    0.6.0
 */