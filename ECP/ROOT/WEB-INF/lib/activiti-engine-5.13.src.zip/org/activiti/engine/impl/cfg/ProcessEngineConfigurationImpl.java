/*      */ package org.activiti.engine.impl.cfg;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.Reader;
/*      */ import java.sql.Connection;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import javax.naming.InitialContext;
/*      */ import javax.sql.DataSource;
/*      */ import org.activiti.engine.ActivitiException;
/*      */ import org.activiti.engine.FormService;
/*      */ import org.activiti.engine.HistoryService;
/*      */ import org.activiti.engine.IdentityService;
/*      */ import org.activiti.engine.ManagementService;
/*      */ import org.activiti.engine.ProcessEngine;
/*      */ import org.activiti.engine.ProcessEngineConfiguration;
/*      */ import org.activiti.engine.RepositoryService;
/*      */ import org.activiti.engine.RuntimeService;
/*      */ import org.activiti.engine.TaskService;
/*      */ import org.activiti.engine.form.AbstractFormType;
/*      */ import org.activiti.engine.impl.FormServiceImpl;
/*      */ import org.activiti.engine.impl.HistoryServiceImpl;
/*      */ import org.activiti.engine.impl.IdentityServiceImpl;
/*      */ import org.activiti.engine.impl.ManagementServiceImpl;
/*      */ import org.activiti.engine.impl.ProcessEngineImpl;
/*      */ import org.activiti.engine.impl.RepositoryServiceImpl;
/*      */ import org.activiti.engine.impl.RuntimeServiceImpl;
/*      */ import org.activiti.engine.impl.ServiceImpl;
/*      */ import org.activiti.engine.impl.TaskServiceImpl;
/*      */ import org.activiti.engine.impl.bpmn.data.ItemInstance;
/*      */ import org.activiti.engine.impl.bpmn.deployer.BpmnDeployer;
/*      */ import org.activiti.engine.impl.bpmn.parser.BpmnParseHandlers;
/*      */ import org.activiti.engine.impl.bpmn.parser.BpmnParser;
/*      */ import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
/*      */ import org.activiti.engine.impl.bpmn.parser.factory.DefaultActivityBehaviorFactory;
/*      */ import org.activiti.engine.impl.bpmn.parser.factory.DefaultListenerFactory;
/*      */ import org.activiti.engine.impl.bpmn.parser.factory.ListenerFactory;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.BoundaryEventParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.BusinessRuleParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.CallActivityParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.CancelEventDefinitionParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.CompensateEventDefinitionParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.EndEventParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.ErrorEventDefinitionParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.EventBasedGatewayParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.EventSubProcessParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.ExclusiveGatewayParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.InclusiveGatewayParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.IntermediateCatchEventParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.IntermediateThrowEventParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.ManualTaskParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.MessageEventDefinitionParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.ParallelGatewayParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.ProcessParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.ReceiveTaskParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.ScriptTaskParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.SendTaskParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.SequenceFlowParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.ServiceTaskParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.SignalEventDefinitionParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.StartEventParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.SubProcessParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.TaskParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.TimerEventDefinitionParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.TransactionParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.parser.handler.UserTaskParseHandler;
/*      */ import org.activiti.engine.impl.bpmn.webservice.MessageInstance;
/*      */ import org.activiti.engine.impl.calendar.BusinessCalendarManager;
/*      */ import org.activiti.engine.impl.calendar.CycleBusinessCalendar;
/*      */ import org.activiti.engine.impl.calendar.DueDateBusinessCalendar;
/*      */ import org.activiti.engine.impl.calendar.DurationBusinessCalendar;
/*      */ import org.activiti.engine.impl.calendar.MapBusinessCalendarManager;
/*      */ import org.activiti.engine.impl.cfg.standalone.StandaloneMybatisTransactionContextFactory;
/*      */ import org.activiti.engine.impl.db.DbIdGenerator;
/*      */ import org.activiti.engine.impl.db.DbSqlSessionFactory;
/*      */ import org.activiti.engine.impl.db.IbatisVariableTypeHandler;
/*      */ import org.activiti.engine.impl.delegate.DefaultDelegateInterceptor;
/*      */ import org.activiti.engine.impl.el.ExpressionManager;
/*      */ import org.activiti.engine.impl.event.CompensationEventHandler;
/*      */ import org.activiti.engine.impl.event.EventHandler;
/*      */ import org.activiti.engine.impl.event.MessageEventHandler;
/*      */ import org.activiti.engine.impl.event.SignalEventHandler;
/*      */ import org.activiti.engine.impl.form.BooleanFormType;
/*      */ import org.activiti.engine.impl.form.DateFormType;
/*      */ import org.activiti.engine.impl.form.FormEngine;
/*      */ import org.activiti.engine.impl.form.FormTypes;
/*      */ import org.activiti.engine.impl.form.JuelFormEngine;
/*      */ import org.activiti.engine.impl.form.LongFormType;
/*      */ import org.activiti.engine.impl.form.StringFormType;
/*      */ import org.activiti.engine.impl.history.HistoryLevel;
/*      */ import org.activiti.engine.impl.history.HistoryManager;
/*      */ import org.activiti.engine.impl.history.parse.FlowNodeHistoryParseHandler;
/*      */ import org.activiti.engine.impl.history.parse.ProcessHistoryParseHandler;
/*      */ import org.activiti.engine.impl.history.parse.StartEventHistoryParseHandler;
/*      */ import org.activiti.engine.impl.history.parse.UserTaskHistoryParseHandler;
/*      */ import org.activiti.engine.impl.interceptor.CommandContextFactory;
/*      */ import org.activiti.engine.impl.interceptor.CommandExecutor;
/*      */ import org.activiti.engine.impl.interceptor.CommandExecutorImpl;
/*      */ import org.activiti.engine.impl.interceptor.CommandInterceptor;
/*      */ import org.activiti.engine.impl.interceptor.DelegateInterceptor;
/*      */ import org.activiti.engine.impl.interceptor.SessionFactory;
/*      */ import org.activiti.engine.impl.jobexecutor.AsyncContinuationJobHandler;
/*      */ import org.activiti.engine.impl.jobexecutor.CallerRunsRejectedJobsHandler;
/*      */ import org.activiti.engine.impl.jobexecutor.DefaultFailedJobCommandFactory;
/*      */ import org.activiti.engine.impl.jobexecutor.DefaultJobExecutor;
/*      */ import org.activiti.engine.impl.jobexecutor.FailedJobCommandFactory;
/*      */ import org.activiti.engine.impl.jobexecutor.JobExecutor;
/*      */ import org.activiti.engine.impl.jobexecutor.JobHandler;
/*      */ import org.activiti.engine.impl.jobexecutor.ProcessEventJobHandler;
/*      */ import org.activiti.engine.impl.jobexecutor.RejectedJobsHandler;
/*      */ import org.activiti.engine.impl.jobexecutor.TimerActivateProcessDefinitionHandler;
/*      */ import org.activiti.engine.impl.jobexecutor.TimerCatchIntermediateEventJobHandler;
/*      */ import org.activiti.engine.impl.jobexecutor.TimerExecuteNestedActivityJobHandler;
/*      */ import org.activiti.engine.impl.jobexecutor.TimerStartEventJobHandler;
/*      */ import org.activiti.engine.impl.jobexecutor.TimerSuspendProcessDefinitionHandler;
/*      */ import org.activiti.engine.impl.persistence.GenericManagerFactory;
/*      */ import org.activiti.engine.impl.persistence.GroupEntityManagerFactory;
/*      */ import org.activiti.engine.impl.persistence.MembershipEntityManagerFactory;
/*      */ import org.activiti.engine.impl.persistence.UserEntityManagerFactory;
/*      */ import org.activiti.engine.impl.persistence.deploy.DefaultDeploymentCache;
/*      */ import org.activiti.engine.impl.persistence.deploy.Deployer;
/*      */ import org.activiti.engine.impl.persistence.deploy.DeploymentCache;
/*      */ import org.activiti.engine.impl.persistence.deploy.DeploymentManager;
/*      */ import org.activiti.engine.impl.persistence.entity.AttachmentEntityManager;
/*      */ import org.activiti.engine.impl.persistence.entity.ByteArrayEntityManager;
/*      */ import org.activiti.engine.impl.persistence.entity.CommentEntityManager;
/*      */ import org.activiti.engine.impl.persistence.entity.DeploymentEntityManager;
/*      */ import org.activiti.engine.impl.persistence.entity.EventSubscriptionEntityManager;
/*      */ import org.activiti.engine.impl.persistence.entity.ExecutionEntityManager;
/*      */ import org.activiti.engine.impl.persistence.entity.HistoricActivityInstanceEntityManager;
/*      */ import org.activiti.engine.impl.persistence.entity.HistoricDetailEntityManager;
/*      */ import org.activiti.engine.impl.persistence.entity.HistoricIdentityLinkEntityManager;
/*      */ import org.activiti.engine.impl.persistence.entity.HistoricProcessInstanceEntityManager;
/*      */ import org.activiti.engine.impl.persistence.entity.HistoricTaskInstanceEntityManager;
/*      */ import org.activiti.engine.impl.persistence.entity.HistoricVariableInstanceEntityManager;
/*      */ import org.activiti.engine.impl.persistence.entity.IdentityInfoEntityManager;
/*      */ import org.activiti.engine.impl.persistence.entity.IdentityLinkEntityManager;
/*      */ import org.activiti.engine.impl.persistence.entity.JobEntityManager;
/*      */ import org.activiti.engine.impl.persistence.entity.ModelEntityManager;
/*      */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*      */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntityManager;
/*      */ import org.activiti.engine.impl.persistence.entity.PropertyEntityManager;
/*      */ import org.activiti.engine.impl.persistence.entity.ResourceEntityManager;
/*      */ import org.activiti.engine.impl.persistence.entity.TableDataManager;
/*      */ import org.activiti.engine.impl.persistence.entity.TaskEntityManager;
/*      */ import org.activiti.engine.impl.persistence.entity.VariableInstanceEntityManager;
/*      */ import org.activiti.engine.impl.scripting.BeansResolverFactory;
/*      */ import org.activiti.engine.impl.scripting.ResolverFactory;
/*      */ import org.activiti.engine.impl.scripting.ScriptBindingsFactory;
/*      */ import org.activiti.engine.impl.scripting.ScriptingEngines;
/*      */ import org.activiti.engine.impl.scripting.VariableScopeResolverFactory;
/*      */ import org.activiti.engine.impl.util.IoUtil;
/*      */ import org.activiti.engine.impl.util.ReflectUtil;
/*      */ import org.activiti.engine.impl.variable.BooleanType;
/*      */ import org.activiti.engine.impl.variable.ByteArrayType;
/*      */ import org.activiti.engine.impl.variable.CustomObjectType;
/*      */ import org.activiti.engine.impl.variable.DateType;
/*      */ import org.activiti.engine.impl.variable.DefaultVariableTypes;
/*      */ import org.activiti.engine.impl.variable.DoubleType;
/*      */ import org.activiti.engine.impl.variable.EntityManagerSession;
/*      */ import org.activiti.engine.impl.variable.EntityManagerSessionFactory;
/*      */ import org.activiti.engine.impl.variable.IntegerType;
/*      */ import org.activiti.engine.impl.variable.JPAEntityVariableType;
/*      */ import org.activiti.engine.impl.variable.LongType;
/*      */ import org.activiti.engine.impl.variable.NullType;
/*      */ import org.activiti.engine.impl.variable.SerializableType;
/*      */ import org.activiti.engine.impl.variable.ShortType;
/*      */ import org.activiti.engine.impl.variable.StringType;
/*      */ import org.activiti.engine.impl.variable.VariableType;
/*      */ import org.activiti.engine.impl.variable.VariableTypes;
/*      */ import org.activiti.engine.parse.BpmnParseHandler;
/*      */ import org.apache.commons.lang.ObjectUtils;
/*      */ import org.apache.ibatis.builder.xml.XMLConfigBuilder;
/*      */ import org.apache.ibatis.datasource.pooled.PooledDataSource;
/*      */ import org.apache.ibatis.mapping.Environment;
/*      */ import org.apache.ibatis.session.Configuration;
/*      */ import org.apache.ibatis.session.SqlSessionFactory;
/*      */ import org.apache.ibatis.session.defaults.DefaultSqlSessionFactory;
/*      */ import org.apache.ibatis.transaction.TransactionFactory;
/*      */ import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;
/*      */ import org.apache.ibatis.transaction.managed.ManagedTransactionFactory;
/*      */ import org.apache.ibatis.type.JdbcType;
/*      */ import org.apache.ibatis.type.TypeHandlerRegistry;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ 
/*      */ public abstract class ProcessEngineConfigurationImpl extends ProcessEngineConfiguration
/*      */ {
/*  215 */   private static Logger log = LoggerFactory.getLogger(ProcessEngineConfigurationImpl.class);
/*      */   public static final String DB_SCHEMA_UPDATE_CREATE = "create";
/*      */   public static final String DB_SCHEMA_UPDATE_DROP_CREATE = "drop-create";
/*      */   public static final String DEFAULT_WS_SYNC_FACTORY = "org.activiti.engine.impl.webservice.CxfWebServiceClientFactory";
/*      */   public static final String DEFAULT_MYBATIS_MAPPING_FILE = "org/activiti/db/mapping/mappings.xml";
/*  226 */   protected RepositoryService repositoryService = new RepositoryServiceImpl();
/*  227 */   protected RuntimeService runtimeService = new RuntimeServiceImpl();
/*  228 */   protected HistoryService historyService = new HistoryServiceImpl();
/*  229 */   protected IdentityService identityService = new IdentityServiceImpl();
/*  230 */   protected TaskService taskService = new TaskServiceImpl();
/*  231 */   protected FormService formService = new FormServiceImpl();
/*  232 */   protected ManagementService managementService = new ManagementServiceImpl();
/*      */   protected List<CommandInterceptor> customPreCommandInterceptorsTxRequired;
/*      */   protected List<CommandInterceptor> customPostCommandInterceptorsTxRequired;
/*      */   protected List<CommandInterceptor> commandInterceptorsTxRequired;
/*      */   protected CommandExecutor commandExecutorTxRequired;
/*      */   protected List<CommandInterceptor> customPreCommandInterceptorsTxRequiresNew;
/*      */   protected List<CommandInterceptor> customPostCommandInterceptorsTxRequiresNew;
/*      */   protected List<CommandInterceptor> commandInterceptorsTxRequiresNew;
/*      */   protected CommandExecutor commandExecutorTxRequiresNew;
/*      */   protected List<SessionFactory> customSessionFactories;
/*      */   protected DbSqlSessionFactory dbSqlSessionFactory;
/*      */   protected Map<Class<?>, SessionFactory> sessionFactories;
/*      */   protected List<ProcessEngineConfigurator> configurators;
/*      */   protected BpmnDeployer bpmnDeployer;
/*      */   protected BpmnParser bpmnParser;
/*      */   protected List<Deployer> customPreDeployers;
/*      */   protected List<Deployer> customPostDeployers;
/*      */   protected List<Deployer> deployers;
/*      */   protected DeploymentManager deploymentManager;
/*  274 */   protected int processDefinitionCacheLimit = -1;
/*      */   protected DeploymentCache<ProcessDefinitionEntity> processDefinitionCache;
/*  277 */   protected int knowledgeBaseCacheLimit = -1;
/*      */   protected DeploymentCache<Object> knowledgeBaseCache;
/*      */   protected List<JobHandler> customJobHandlers;
/*      */   protected Map<String, JobHandler> jobHandlers;
/*      */   protected JobExecutor jobExecutor;
/*      */   protected SqlSessionFactory sqlSessionFactory;
/*      */   protected TransactionFactory transactionFactory;
/*      */   protected IdGenerator idGenerator;
/*      */   protected DataSource idGeneratorDataSource;
/*      */   protected String idGeneratorDataSourceJndiName;
/*      */   protected List<BpmnParseHandler> preBpmnParseHandlers;
/*      */   protected List<BpmnParseHandler> postBpmnParseHandlers;
/*      */   protected List<BpmnParseHandler> customDefaultBpmnParseHandlers;
/*      */   protected ActivityBehaviorFactory activityBehaviorFactory;
/*      */   protected ListenerFactory listenerFactory;
/*      */   protected BpmnParseFactory bpmnParseFactory;
/*      */   protected List<FormEngine> customFormEngines;
/*      */   protected Map<String, FormEngine> formEngines;
/*      */   protected List<AbstractFormType> customFormTypes;
/*      */   protected FormTypes formTypes;
/*      */   protected List<VariableType> customPreVariableTypes;
/*      */   protected List<VariableType> customPostVariableTypes;
/*      */   protected VariableTypes variableTypes;
/*      */   protected ExpressionManager expressionManager;
/*      */   protected List<String> customScriptingEngineClasses;
/*      */   protected ScriptingEngines scriptingEngines;
/*      */   protected List<ResolverFactory> resolverFactories;
/*      */   protected BusinessCalendarManager businessCalendarManager;
/*  323 */   protected String wsSyncFactoryClassName = "org.activiti.engine.impl.webservice.CxfWebServiceClientFactory";
/*      */   protected CommandContextFactory commandContextFactory;
/*      */   protected TransactionContextFactory transactionContextFactory;
/*      */   protected Map<Object, Object> beans;
/*      */   protected DelegateInterceptor delegateInterceptor;
/*      */   protected CommandInterceptor actualCommandExecutor;
/*      */   protected RejectedJobsHandler customRejectedJobsHandler;
/*      */   protected Map<String, EventHandler> eventHandlers;
/*      */   protected List<EventHandler> customEventHandlers;
/*      */   protected FailedJobCommandFactory failedJobCommandFactory;
/*  349 */   protected boolean enableSafeBpmnXml = false;
/*      */ 
/*  358 */   protected int batchSizeProcessInstances = 25;
/*  359 */   protected int batchSizeTasks = 25;
/*      */ 
/*  549 */   protected static Properties databaseTypeMappings = getDefaultDatabaseTypeMappings();
/*      */ 
/*      */   public ProcessEngine buildProcessEngine()
/*      */   {
/*  364 */     init();
/*  365 */     return new ProcessEngineImpl(this);
/*      */   }
/*      */ 
/*      */   protected void init()
/*      */   {
/*  371 */     initHistoryLevel();
/*  372 */     initExpressionManager();
/*  373 */     initVariableTypes();
/*  374 */     initBeans();
/*  375 */     initFormEngines();
/*  376 */     initFormTypes();
/*  377 */     initScriptingEngines();
/*  378 */     initBusinessCalendarManager();
/*  379 */     initCommandContextFactory();
/*  380 */     initTransactionContextFactory();
/*  381 */     initCommandExecutors();
/*  382 */     initServices();
/*  383 */     initIdGenerator();
/*  384 */     initDeployers();
/*  385 */     initJobExecutor();
/*  386 */     initDataSource();
/*  387 */     initTransactionFactory();
/*  388 */     initSqlSessionFactory();
/*  389 */     initSessionFactories();
/*  390 */     initJpa();
/*  391 */     initDelegateInterceptor();
/*  392 */     initEventHandlers();
/*  393 */     initFailedJobCommandFactory();
/*  394 */     initConfigurators();
/*      */   }
/*      */ 
/*      */   protected void initFailedJobCommandFactory()
/*      */   {
/*  400 */     if (this.failedJobCommandFactory == null)
/*  401 */       this.failedJobCommandFactory = new DefaultFailedJobCommandFactory();
/*      */   }
/*      */ 
/*      */   protected abstract Collection<? extends CommandInterceptor> getDefaultCommandInterceptorsTxRequired();
/*      */ 
/*      */   protected abstract Collection<? extends CommandInterceptor> getDefaultCommandInterceptorsTxRequiresNew();
/*      */ 
/*      */   protected void initCommandExecutors() {
/*  411 */     initActualCommandExecutor();
/*  412 */     initCommandInterceptorsTxRequired();
/*  413 */     initCommandExecutorTxRequired();
/*  414 */     initCommandInterceptorsTxRequiresNew();
/*  415 */     initCommandExecutorTxRequiresNew();
/*      */   }
/*      */ 
/*      */   protected void initActualCommandExecutor() {
/*  419 */     this.actualCommandExecutor = new CommandExecutorImpl();
/*      */   }
/*      */ 
/*      */   protected void initCommandInterceptorsTxRequired() {
/*  423 */     if (this.commandInterceptorsTxRequired == null) {
/*  424 */       if (this.customPreCommandInterceptorsTxRequired != null)
/*  425 */         this.commandInterceptorsTxRequired = new ArrayList(this.customPreCommandInterceptorsTxRequired);
/*      */       else {
/*  427 */         this.commandInterceptorsTxRequired = new ArrayList();
/*      */       }
/*  429 */       this.commandInterceptorsTxRequired.addAll(getDefaultCommandInterceptorsTxRequired());
/*  430 */       if (this.customPostCommandInterceptorsTxRequired != null) {
/*  431 */         this.commandInterceptorsTxRequired.addAll(this.customPostCommandInterceptorsTxRequired);
/*      */       }
/*  433 */       this.commandInterceptorsTxRequired.add(this.actualCommandExecutor);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void initCommandInterceptorsTxRequiresNew() {
/*  438 */     if (this.commandInterceptorsTxRequiresNew == null) {
/*  439 */       if (this.customPreCommandInterceptorsTxRequiresNew != null)
/*  440 */         this.commandInterceptorsTxRequiresNew = new ArrayList(this.customPreCommandInterceptorsTxRequiresNew);
/*      */       else {
/*  442 */         this.commandInterceptorsTxRequiresNew = new ArrayList();
/*      */       }
/*  444 */       this.commandInterceptorsTxRequiresNew.addAll(getDefaultCommandInterceptorsTxRequiresNew());
/*  445 */       if (this.customPostCommandInterceptorsTxRequiresNew != null) {
/*  446 */         this.commandInterceptorsTxRequiresNew.addAll(this.customPostCommandInterceptorsTxRequiresNew);
/*      */       }
/*  448 */       this.commandInterceptorsTxRequiresNew.add(this.actualCommandExecutor);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void initCommandExecutorTxRequired() {
/*  453 */     if (this.commandExecutorTxRequired == null)
/*  454 */       this.commandExecutorTxRequired = initInterceptorChain(this.commandInterceptorsTxRequired);
/*      */   }
/*      */ 
/*      */   protected void initCommandExecutorTxRequiresNew()
/*      */   {
/*  459 */     if (this.commandExecutorTxRequiresNew == null)
/*  460 */       this.commandExecutorTxRequiresNew = initInterceptorChain(this.commandInterceptorsTxRequiresNew);
/*      */   }
/*      */ 
/*      */   protected CommandInterceptor initInterceptorChain(List<CommandInterceptor> chain)
/*      */   {
/*  465 */     if ((chain == null) || (chain.isEmpty())) {
/*  466 */       throw new ActivitiException(new StringBuilder().append("invalid command interceptor chain configuration: ").append(chain).toString());
/*      */     }
/*  468 */     for (int i = 0; i < chain.size() - 1; i++) {
/*  469 */       ((CommandInterceptor)chain.get(i)).setNext((CommandExecutor)chain.get(i + 1));
/*      */     }
/*  471 */     return (CommandInterceptor)chain.get(0);
/*      */   }
/*      */ 
/*      */   protected void initServices()
/*      */   {
/*  477 */     initService(this.repositoryService);
/*  478 */     initService(this.runtimeService);
/*  479 */     initService(this.historyService);
/*  480 */     initService(this.identityService);
/*  481 */     initService(this.taskService);
/*  482 */     initService(this.formService);
/*  483 */     initService(this.managementService);
/*      */   }
/*      */ 
/*      */   protected void initService(Object service) {
/*  487 */     if ((service instanceof ServiceImpl))
/*  488 */       ((ServiceImpl)service).setCommandExecutor(this.commandExecutorTxRequired);
/*      */   }
/*      */ 
/*      */   protected void initDataSource()
/*      */   {
/*  495 */     if (this.dataSource == null) {
/*  496 */       if (this.dataSourceJndiName != null) {
/*      */         try {
/*  498 */           this.dataSource = ((DataSource)new InitialContext().lookup(this.dataSourceJndiName));
/*      */         } catch (Exception e) {
/*  500 */           throw new ActivitiException(new StringBuilder().append("couldn't lookup datasource from ").append(this.dataSourceJndiName).append(": ").append(e.getMessage()).toString(), e);
/*      */         }
/*      */       }
/*  503 */       else if (this.jdbcUrl != null) {
/*  504 */         if ((this.jdbcDriver == null) || (this.jdbcUrl == null) || (this.jdbcUsername == null)) {
/*  505 */           throw new ActivitiException("DataSource or JDBC properties have to be specified in a process engine configuration");
/*      */         }
/*      */ 
/*  508 */         log.debug("initializing datasource to db: {}", this.jdbcUrl);
/*      */ 
/*  510 */         PooledDataSource pooledDataSource = new PooledDataSource(ReflectUtil.getClassLoader(), this.jdbcDriver, this.jdbcUrl, this.jdbcUsername, this.jdbcPassword);
/*      */ 
/*  513 */         if (this.jdbcMaxActiveConnections > 0) {
/*  514 */           pooledDataSource.setPoolMaximumActiveConnections(this.jdbcMaxActiveConnections);
/*      */         }
/*  516 */         if (this.jdbcMaxIdleConnections > 0) {
/*  517 */           pooledDataSource.setPoolMaximumIdleConnections(this.jdbcMaxIdleConnections);
/*      */         }
/*  519 */         if (this.jdbcMaxCheckoutTime > 0) {
/*  520 */           pooledDataSource.setPoolMaximumCheckoutTime(this.jdbcMaxCheckoutTime);
/*      */         }
/*  522 */         if (this.jdbcMaxWaitTime > 0) {
/*  523 */           pooledDataSource.setPoolTimeToWait(this.jdbcMaxWaitTime);
/*      */         }
/*  525 */         if (this.jdbcPingEnabled == true) {
/*  526 */           pooledDataSource.setPoolPingEnabled(true);
/*  527 */           if (this.jdbcPingQuery != null) {
/*  528 */             pooledDataSource.setPoolPingQuery(this.jdbcPingQuery);
/*      */           }
/*  530 */           pooledDataSource.setPoolPingConnectionsNotUsedFor(this.jdbcPingConnectionNotUsedFor);
/*      */         }
/*  532 */         if (this.jdbcDefaultTransactionIsolationLevel > 0) {
/*  533 */           pooledDataSource.setDefaultTransactionIsolationLevel(Integer.valueOf(this.jdbcDefaultTransactionIsolationLevel));
/*      */         }
/*  535 */         this.dataSource = pooledDataSource;
/*      */       }
/*      */ 
/*  538 */       if ((this.dataSource instanceof PooledDataSource))
/*      */       {
/*  540 */         ((PooledDataSource)this.dataSource).forceCloseAll();
/*      */       }
/*      */     }
/*      */ 
/*  544 */     if (this.databaseType == null)
/*  545 */       initDatabaseType();
/*      */   }
/*      */ 
/*      */   protected static Properties getDefaultDatabaseTypeMappings()
/*      */   {
/*  552 */     Properties databaseTypeMappings = new Properties();
/*  553 */     databaseTypeMappings.setProperty("H2", "h2");
/*  554 */     databaseTypeMappings.setProperty("MySQL", "mysql");
/*  555 */     databaseTypeMappings.setProperty("Oracle", "oracle");
/*  556 */     databaseTypeMappings.setProperty("PostgreSQL", "postgres");
/*  557 */     databaseTypeMappings.setProperty("Microsoft SQL Server", "mssql");
/*  558 */     databaseTypeMappings.setProperty("DB2", "db2");
/*  559 */     databaseTypeMappings.setProperty("DB2", "db2");
/*  560 */     databaseTypeMappings.setProperty("DB2/NT", "db2");
/*  561 */     databaseTypeMappings.setProperty("DB2/NT64", "db2");
/*  562 */     databaseTypeMappings.setProperty("DB2 UDP", "db2");
/*  563 */     databaseTypeMappings.setProperty("DB2/LINUX", "db2");
/*  564 */     databaseTypeMappings.setProperty("DB2/LINUX390", "db2");
/*  565 */     databaseTypeMappings.setProperty("DB2/LINUXX8664", "db2");
/*  566 */     databaseTypeMappings.setProperty("DB2/LINUXZ64", "db2");
/*  567 */     databaseTypeMappings.setProperty("DB2/400 SQL", "db2");
/*  568 */     databaseTypeMappings.setProperty("DB2/6000", "db2");
/*  569 */     databaseTypeMappings.setProperty("DB2 UDB iSeries", "db2");
/*  570 */     databaseTypeMappings.setProperty("DB2/AIX64", "db2");
/*  571 */     databaseTypeMappings.setProperty("DB2/HPUX", "db2");
/*  572 */     databaseTypeMappings.setProperty("DB2/HP64", "db2");
/*  573 */     databaseTypeMappings.setProperty("DB2/SUN", "db2");
/*  574 */     databaseTypeMappings.setProperty("DB2/SUN64", "db2");
/*  575 */     databaseTypeMappings.setProperty("DB2/PTX", "db2");
/*  576 */     databaseTypeMappings.setProperty("DB2/2", "db2");
/*  577 */     return databaseTypeMappings;
/*      */   }
/*      */ 
/*      */   public void initDatabaseType() {
/*  581 */     Connection connection = null;
/*      */     try {
/*  583 */       connection = this.dataSource.getConnection();
/*  584 */       DatabaseMetaData databaseMetaData = connection.getMetaData();
/*  585 */       String databaseProductName = databaseMetaData.getDatabaseProductName();
/*  586 */       log.debug("database product name: '{}'", databaseProductName);
/*  587 */       this.databaseType = databaseTypeMappings.getProperty(databaseProductName);
/*  588 */       if (this.databaseType == null) {
/*  589 */         throw new ActivitiException(new StringBuilder().append("couldn't deduct database type from database product name '").append(databaseProductName).append("'").toString());
/*      */       }
/*  591 */       log.debug("using database type: {}", this.databaseType);
/*      */     }
/*      */     catch (SQLException e) {
/*  594 */       e.printStackTrace();
/*      */     } finally {
/*      */       try {
/*  597 */         if (connection != null)
/*  598 */           connection.close();
/*      */       }
/*      */       catch (SQLException e) {
/*  601 */         e.printStackTrace();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void initTransactionFactory()
/*      */   {
/*  609 */     if (this.transactionFactory == null)
/*  610 */       if (this.transactionsExternallyManaged)
/*  611 */         this.transactionFactory = new ManagedTransactionFactory();
/*      */       else
/*  613 */         this.transactionFactory = new JdbcTransactionFactory();
/*      */   }
/*      */ 
/*      */   protected void initSqlSessionFactory()
/*      */   {
/*  619 */     if (this.sqlSessionFactory == null) {
/*  620 */       InputStream inputStream = null;
/*      */       try {
/*  622 */         inputStream = getMyBatisXmlConfigurationSteam();
/*      */ 
/*  625 */         Environment environment = new Environment("default", this.transactionFactory, this.dataSource);
/*  626 */         Reader reader = new InputStreamReader(inputStream);
/*  627 */         Properties properties = new Properties();
/*  628 */         properties.put("prefix", this.databaseTablePrefix);
/*  629 */         if (this.databaseType != null) {
/*  630 */           properties.put("limitBefore", DbSqlSessionFactory.databaseSpecificLimitBeforeStatements.get(this.databaseType));
/*  631 */           properties.put("limitAfter", DbSqlSessionFactory.databaseSpecificLimitAfterStatements.get(this.databaseType));
/*  632 */           properties.put("limitBetween", DbSqlSessionFactory.databaseSpecificLimitBetweenStatements.get(this.databaseType));
/*  633 */           properties.put("limitOuterJoinBetween", DbSqlSessionFactory.databaseOuterJoinLimitBetweenStatements.get(this.databaseType));
/*  634 */           properties.put("orderBy", DbSqlSessionFactory.databaseSpecificOrderByStatements.get(this.databaseType));
/*  635 */           properties.put("limitBeforeNativeQuery", ObjectUtils.toString(DbSqlSessionFactory.databaseSpecificLimitBeforeNativeQueryStatements.get(this.databaseType)));
/*      */         }
/*  637 */         XMLConfigBuilder parser = new XMLConfigBuilder(reader, "", properties);
/*  638 */         Configuration configuration = parser.getConfiguration();
/*  639 */         configuration.setEnvironment(environment);
/*  640 */         configuration.getTypeHandlerRegistry().register(VariableType.class, JdbcType.VARCHAR, new IbatisVariableTypeHandler());
/*  641 */         configuration = parser.parse();
/*      */ 
/*  643 */         this.sqlSessionFactory = new DefaultSqlSessionFactory(configuration);
/*      */       }
/*      */       catch (Exception e) {
/*  646 */         throw new ActivitiException(new StringBuilder().append("Error while building ibatis SqlSessionFactory: ").append(e.getMessage()).toString(), e);
/*      */       } finally {
/*  648 */         IoUtil.closeSilently(inputStream);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected InputStream getMyBatisXmlConfigurationSteam() {
/*  654 */     return ReflectUtil.getResourceAsStream("org/activiti/db/mapping/mappings.xml");
/*      */   }
/*      */ 
/*      */   protected void initSessionFactories()
/*      */   {
/*  660 */     if (this.sessionFactories == null) {
/*  661 */       this.sessionFactories = new HashMap();
/*      */ 
/*  663 */       this.dbSqlSessionFactory = new DbSqlSessionFactory();
/*  664 */       this.dbSqlSessionFactory.setDatabaseType(this.databaseType);
/*  665 */       this.dbSqlSessionFactory.setIdGenerator(this.idGenerator);
/*  666 */       this.dbSqlSessionFactory.setSqlSessionFactory(this.sqlSessionFactory);
/*  667 */       this.dbSqlSessionFactory.setDbIdentityUsed(this.isDbIdentityUsed);
/*  668 */       this.dbSqlSessionFactory.setDbHistoryUsed(this.isDbHistoryUsed);
/*  669 */       this.dbSqlSessionFactory.setDatabaseTablePrefix(this.databaseTablePrefix);
/*  670 */       this.dbSqlSessionFactory.setDatabaseSchema(this.databaseSchema);
/*  671 */       addSessionFactory(this.dbSqlSessionFactory);
/*      */ 
/*  673 */       addSessionFactory(new GenericManagerFactory(AttachmentEntityManager.class));
/*  674 */       addSessionFactory(new GenericManagerFactory(CommentEntityManager.class));
/*  675 */       addSessionFactory(new GenericManagerFactory(DeploymentEntityManager.class));
/*  676 */       addSessionFactory(new GenericManagerFactory(ModelEntityManager.class));
/*  677 */       addSessionFactory(new GenericManagerFactory(ExecutionEntityManager.class));
/*  678 */       addSessionFactory(new GenericManagerFactory(HistoricActivityInstanceEntityManager.class));
/*  679 */       addSessionFactory(new GenericManagerFactory(HistoricDetailEntityManager.class));
/*  680 */       addSessionFactory(new GenericManagerFactory(HistoricProcessInstanceEntityManager.class));
/*  681 */       addSessionFactory(new GenericManagerFactory(HistoricVariableInstanceEntityManager.class));
/*  682 */       addSessionFactory(new GenericManagerFactory(HistoricTaskInstanceEntityManager.class));
/*  683 */       addSessionFactory(new GenericManagerFactory(HistoricIdentityLinkEntityManager.class));
/*  684 */       addSessionFactory(new GenericManagerFactory(IdentityInfoEntityManager.class));
/*  685 */       addSessionFactory(new GenericManagerFactory(IdentityLinkEntityManager.class));
/*  686 */       addSessionFactory(new GenericManagerFactory(JobEntityManager.class));
/*  687 */       addSessionFactory(new GenericManagerFactory(ProcessDefinitionEntityManager.class));
/*  688 */       addSessionFactory(new GenericManagerFactory(PropertyEntityManager.class));
/*  689 */       addSessionFactory(new GenericManagerFactory(ResourceEntityManager.class));
/*  690 */       addSessionFactory(new GenericManagerFactory(ByteArrayEntityManager.class));
/*  691 */       addSessionFactory(new GenericManagerFactory(TableDataManager.class));
/*  692 */       addSessionFactory(new GenericManagerFactory(TaskEntityManager.class));
/*  693 */       addSessionFactory(new GenericManagerFactory(VariableInstanceEntityManager.class));
/*  694 */       addSessionFactory(new GenericManagerFactory(EventSubscriptionEntityManager.class));
/*  695 */       addSessionFactory(new GenericManagerFactory(HistoryManager.class));
/*      */ 
/*  697 */       addSessionFactory(new UserEntityManagerFactory());
/*  698 */       addSessionFactory(new GroupEntityManagerFactory());
/*  699 */       addSessionFactory(new MembershipEntityManagerFactory());
/*      */     }
/*      */ 
/*  702 */     if (this.customSessionFactories != null)
/*  703 */       for (SessionFactory sessionFactory : this.customSessionFactories)
/*  704 */         addSessionFactory(sessionFactory);
/*      */   }
/*      */ 
/*      */   protected void addSessionFactory(SessionFactory sessionFactory)
/*      */   {
/*  710 */     this.sessionFactories.put(sessionFactory.getSessionType(), sessionFactory);
/*      */   }
/*      */ 
/*      */   protected void initConfigurators() {
/*  714 */     if (this.configurators != null)
/*  715 */       for (ProcessEngineConfigurator configurator : this.configurators)
/*  716 */         configurator.configure(this);
/*      */   }
/*      */ 
/*      */   protected void initDeployers()
/*      */   {
/*  724 */     if (this.deployers == null) {
/*  725 */       this.deployers = new ArrayList();
/*  726 */       if (this.customPreDeployers != null) {
/*  727 */         this.deployers.addAll(this.customPreDeployers);
/*      */       }
/*  729 */       this.deployers.addAll(getDefaultDeployers());
/*  730 */       if (this.customPostDeployers != null) {
/*  731 */         this.deployers.addAll(this.customPostDeployers);
/*      */       }
/*      */     }
/*  734 */     if (this.deploymentManager == null) {
/*  735 */       this.deploymentManager = new DeploymentManager();
/*  736 */       this.deploymentManager.setDeployers(this.deployers);
/*      */ 
/*  739 */       if (this.processDefinitionCache == null) {
/*  740 */         if (this.processDefinitionCacheLimit <= 0)
/*  741 */           this.processDefinitionCache = new DefaultDeploymentCache();
/*      */         else {
/*  743 */           this.processDefinitionCache = new DefaultDeploymentCache(this.processDefinitionCacheLimit);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  748 */       if (this.knowledgeBaseCache == null) {
/*  749 */         if (this.knowledgeBaseCacheLimit <= 0)
/*  750 */           this.knowledgeBaseCache = new DefaultDeploymentCache();
/*      */         else {
/*  752 */           this.knowledgeBaseCache = new DefaultDeploymentCache(this.knowledgeBaseCacheLimit);
/*      */         }
/*      */       }
/*      */ 
/*  756 */       this.deploymentManager.setProcessDefinitionCache(this.processDefinitionCache);
/*  757 */       this.deploymentManager.setKnowledgeBaseCache(this.knowledgeBaseCache);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected Collection<? extends Deployer> getDefaultDeployers() {
/*  762 */     List defaultDeployers = new ArrayList();
/*      */ 
/*  764 */     if (this.bpmnDeployer == null) {
/*  765 */       this.bpmnDeployer = new BpmnDeployer();
/*      */     }
/*      */ 
/*  768 */     this.bpmnDeployer.setExpressionManager(this.expressionManager);
/*  769 */     this.bpmnDeployer.setIdGenerator(this.idGenerator);
/*      */ 
/*  771 */     if (this.bpmnParseFactory == null) {
/*  772 */       this.bpmnParseFactory = new DefaultBpmnParseFactory();
/*      */     }
/*      */ 
/*  775 */     if (this.activityBehaviorFactory == null) {
/*  776 */       DefaultActivityBehaviorFactory defaultActivityBehaviorFactory = new DefaultActivityBehaviorFactory();
/*  777 */       defaultActivityBehaviorFactory.setExpressionManager(this.expressionManager);
/*  778 */       this.activityBehaviorFactory = defaultActivityBehaviorFactory;
/*      */     }
/*      */ 
/*  781 */     if (this.listenerFactory == null) {
/*  782 */       DefaultListenerFactory defaultListenerFactory = new DefaultListenerFactory();
/*  783 */       defaultListenerFactory.setExpressionManager(this.expressionManager);
/*  784 */       this.listenerFactory = defaultListenerFactory;
/*      */     }
/*      */ 
/*  787 */     if (this.bpmnParser == null) {
/*  788 */       this.bpmnParser = new BpmnParser();
/*      */     }
/*      */ 
/*  791 */     this.bpmnParser.setExpressionManager(this.expressionManager);
/*  792 */     this.bpmnParser.setBpmnParseFactory(this.bpmnParseFactory);
/*  793 */     this.bpmnParser.setActivityBehaviorFactory(this.activityBehaviorFactory);
/*  794 */     this.bpmnParser.setListenerFactory(this.listenerFactory);
/*      */ 
/*  796 */     List parseHandlers = new ArrayList();
/*  797 */     if (getPreBpmnParseHandlers() != null) {
/*  798 */       parseHandlers.addAll(getPreBpmnParseHandlers());
/*      */     }
/*  800 */     parseHandlers.addAll(getDefaultBpmnParseHandlers());
/*  801 */     if (getPostBpmnParseHandlers() != null) {
/*  802 */       parseHandlers.addAll(getPostBpmnParseHandlers());
/*      */     }
/*      */ 
/*  805 */     BpmnParseHandlers bpmnParseHandlers = new BpmnParseHandlers();
/*  806 */     bpmnParseHandlers.addHandlers(parseHandlers);
/*  807 */     this.bpmnParser.setBpmnParserHandlers(bpmnParseHandlers);
/*      */ 
/*  809 */     this.bpmnDeployer.setBpmnParser(this.bpmnParser);
/*      */ 
/*  811 */     defaultDeployers.add(this.bpmnDeployer);
/*  812 */     return defaultDeployers;
/*      */   }
/*      */ 
/*      */   protected List<BpmnParseHandler> getDefaultBpmnParseHandlers()
/*      */   {
/*  818 */     List bpmnParserHandlers = new ArrayList();
/*  819 */     bpmnParserHandlers.add(new BoundaryEventParseHandler());
/*  820 */     bpmnParserHandlers.add(new BusinessRuleParseHandler());
/*  821 */     bpmnParserHandlers.add(new CallActivityParseHandler());
/*  822 */     bpmnParserHandlers.add(new CancelEventDefinitionParseHandler());
/*  823 */     bpmnParserHandlers.add(new CompensateEventDefinitionParseHandler());
/*  824 */     bpmnParserHandlers.add(new EndEventParseHandler());
/*  825 */     bpmnParserHandlers.add(new ErrorEventDefinitionParseHandler());
/*  826 */     bpmnParserHandlers.add(new EventBasedGatewayParseHandler());
/*  827 */     bpmnParserHandlers.add(new ExclusiveGatewayParseHandler());
/*  828 */     bpmnParserHandlers.add(new InclusiveGatewayParseHandler());
/*  829 */     bpmnParserHandlers.add(new IntermediateCatchEventParseHandler());
/*  830 */     bpmnParserHandlers.add(new IntermediateThrowEventParseHandler());
/*  831 */     bpmnParserHandlers.add(new ManualTaskParseHandler());
/*  832 */     bpmnParserHandlers.add(new MessageEventDefinitionParseHandler());
/*  833 */     bpmnParserHandlers.add(new ParallelGatewayParseHandler());
/*  834 */     bpmnParserHandlers.add(new ProcessParseHandler());
/*  835 */     bpmnParserHandlers.add(new ReceiveTaskParseHandler());
/*  836 */     bpmnParserHandlers.add(new ScriptTaskParseHandler());
/*  837 */     bpmnParserHandlers.add(new SendTaskParseHandler());
/*  838 */     bpmnParserHandlers.add(new SequenceFlowParseHandler());
/*  839 */     bpmnParserHandlers.add(new ServiceTaskParseHandler());
/*  840 */     bpmnParserHandlers.add(new SignalEventDefinitionParseHandler());
/*  841 */     bpmnParserHandlers.add(new StartEventParseHandler());
/*  842 */     bpmnParserHandlers.add(new SubProcessParseHandler());
/*  843 */     bpmnParserHandlers.add(new EventSubProcessParseHandler());
/*  844 */     bpmnParserHandlers.add(new TaskParseHandler());
/*  845 */     bpmnParserHandlers.add(new TimerEventDefinitionParseHandler());
/*  846 */     bpmnParserHandlers.add(new TransactionParseHandler());
/*  847 */     bpmnParserHandlers.add(new UserTaskParseHandler());
/*      */ 
/*  850 */     if (this.customDefaultBpmnParseHandlers != null)
/*      */     {
/*  852 */       Map customParseHandlerMap = new HashMap();
/*  853 */       for (Iterator i$ = this.customDefaultBpmnParseHandlers.iterator(); i$.hasNext(); ) { bpmnParseHandler = (BpmnParseHandler)i$.next();
/*  854 */         for (Class handledType : bpmnParseHandler.getHandledTypes())
/*  855 */           customParseHandlerMap.put(handledType, bpmnParseHandler);
/*      */       }
/*      */       BpmnParseHandler bpmnParseHandler;
/*  859 */       for (int i = 0; i < bpmnParserHandlers.size(); i++)
/*      */       {
/*  861 */         BpmnParseHandler defaultBpmnParseHandler = (BpmnParseHandler)bpmnParserHandlers.get(i);
/*  862 */         if (defaultBpmnParseHandler.getHandledTypes().size() != 1) {
/*  863 */           StringBuilder supportedTypes = new StringBuilder();
/*  864 */           for (Class type : defaultBpmnParseHandler.getHandledTypes()) {
/*  865 */             supportedTypes.append(new StringBuilder().append(" ").append(type.getCanonicalName()).append(" ").toString());
/*      */           }
/*  867 */           throw new ActivitiException(new StringBuilder().append("The default BPMN parse handlers should only support one type, but ").append(defaultBpmnParseHandler.getClass()).append(" supports ").append(supportedTypes.toString()).append(". This is likely a programmatic error").toString());
/*      */         }
/*      */ 
/*  870 */         Class handledType = (Class)defaultBpmnParseHandler.getHandledTypes().iterator().next();
/*  871 */         if (customParseHandlerMap.containsKey(handledType)) {
/*  872 */           BpmnParseHandler newBpmnParseHandler = (BpmnParseHandler)customParseHandlerMap.get(handledType);
/*  873 */           log.info(new StringBuilder().append("Replacing default BpmnParseHandler ").append(defaultBpmnParseHandler.getClass().getName()).append(" with ").append(newBpmnParseHandler.getClass().getName()).toString());
/*  874 */           bpmnParserHandlers.set(i, newBpmnParseHandler);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  881 */     for (BpmnParseHandler handler : getDefaultHistoryParseHandlers()) {
/*  882 */       bpmnParserHandlers.add(handler);
/*      */     }
/*      */ 
/*  885 */     return bpmnParserHandlers;
/*      */   }
/*      */ 
/*      */   protected List<BpmnParseHandler> getDefaultHistoryParseHandlers() {
/*  889 */     List parseHandlers = new ArrayList();
/*  890 */     parseHandlers.add(new FlowNodeHistoryParseHandler());
/*  891 */     parseHandlers.add(new ProcessHistoryParseHandler());
/*  892 */     parseHandlers.add(new StartEventHistoryParseHandler());
/*  893 */     parseHandlers.add(new UserTaskHistoryParseHandler());
/*  894 */     return parseHandlers;
/*      */   }
/*      */ 
/*      */   protected void initJobExecutor()
/*      */   {
/*  900 */     if (this.jobExecutor == null) {
/*  901 */       this.jobExecutor = new DefaultJobExecutor();
/*      */     }
/*      */ 
/*  904 */     this.jobHandlers = new HashMap();
/*  905 */     TimerExecuteNestedActivityJobHandler timerExecuteNestedActivityJobHandler = new TimerExecuteNestedActivityJobHandler();
/*  906 */     this.jobHandlers.put(timerExecuteNestedActivityJobHandler.getType(), timerExecuteNestedActivityJobHandler);
/*      */ 
/*  908 */     TimerCatchIntermediateEventJobHandler timerCatchIntermediateEvent = new TimerCatchIntermediateEventJobHandler();
/*  909 */     this.jobHandlers.put(timerCatchIntermediateEvent.getType(), timerCatchIntermediateEvent);
/*      */ 
/*  911 */     TimerStartEventJobHandler timerStartEvent = new TimerStartEventJobHandler();
/*  912 */     this.jobHandlers.put(timerStartEvent.getType(), timerStartEvent);
/*      */ 
/*  914 */     AsyncContinuationJobHandler asyncContinuationJobHandler = new AsyncContinuationJobHandler();
/*  915 */     this.jobHandlers.put(asyncContinuationJobHandler.getType(), asyncContinuationJobHandler);
/*      */ 
/*  917 */     ProcessEventJobHandler processEventJobHandler = new ProcessEventJobHandler();
/*  918 */     this.jobHandlers.put(processEventJobHandler.getType(), processEventJobHandler);
/*      */ 
/*  920 */     TimerSuspendProcessDefinitionHandler suspendProcessDefinitionHandler = new TimerSuspendProcessDefinitionHandler();
/*  921 */     this.jobHandlers.put(suspendProcessDefinitionHandler.getType(), suspendProcessDefinitionHandler);
/*      */ 
/*  923 */     TimerActivateProcessDefinitionHandler activateProcessDefinitionHandler = new TimerActivateProcessDefinitionHandler();
/*  924 */     this.jobHandlers.put(activateProcessDefinitionHandler.getType(), activateProcessDefinitionHandler);
/*      */ 
/*  927 */     if (getCustomJobHandlers() != null) {
/*  928 */       for (JobHandler customJobHandler : getCustomJobHandlers()) {
/*  929 */         this.jobHandlers.put(customJobHandler.getType(), customJobHandler);
/*      */       }
/*      */     }
/*      */ 
/*  933 */     this.jobExecutor.setCommandExecutor(this.commandExecutorTxRequired);
/*  934 */     this.jobExecutor.setAutoActivate(this.jobExecutorActivate);
/*      */ 
/*  936 */     if (this.jobExecutor.getRejectedJobsHandler() == null)
/*  937 */       if (this.customRejectedJobsHandler != null)
/*  938 */         this.jobExecutor.setRejectedJobsHandler(this.customRejectedJobsHandler);
/*      */       else
/*  940 */         this.jobExecutor.setRejectedJobsHandler(new CallerRunsRejectedJobsHandler());
/*      */   }
/*      */ 
/*      */   public void initHistoryLevel()
/*      */   {
/*  949 */     this.historyLevel = HistoryLevel.getHistoryLevelForKey(getHistory());
/*      */   }
/*      */ 
/*      */   protected void initIdGenerator()
/*      */   {
/*  955 */     if (this.idGenerator == null) {
/*  956 */       CommandExecutor idGeneratorCommandExecutor = null;
/*  957 */       if (this.idGeneratorDataSource != null) {
/*  958 */         ProcessEngineConfigurationImpl processEngineConfiguration = new StandaloneProcessEngineConfiguration();
/*  959 */         processEngineConfiguration.setDataSource(this.idGeneratorDataSource);
/*  960 */         processEngineConfiguration.setDatabaseSchemaUpdate("false");
/*  961 */         processEngineConfiguration.init();
/*  962 */         idGeneratorCommandExecutor = processEngineConfiguration.getCommandExecutorTxRequiresNew();
/*  963 */       } else if (this.idGeneratorDataSourceJndiName != null) {
/*  964 */         ProcessEngineConfigurationImpl processEngineConfiguration = new StandaloneProcessEngineConfiguration();
/*  965 */         processEngineConfiguration.setDataSourceJndiName(this.idGeneratorDataSourceJndiName);
/*  966 */         processEngineConfiguration.setDatabaseSchemaUpdate("false");
/*  967 */         processEngineConfiguration.init();
/*  968 */         idGeneratorCommandExecutor = processEngineConfiguration.getCommandExecutorTxRequiresNew();
/*      */       } else {
/*  970 */         idGeneratorCommandExecutor = this.commandExecutorTxRequiresNew;
/*      */       }
/*      */ 
/*  973 */       DbIdGenerator dbIdGenerator = new DbIdGenerator();
/*  974 */       dbIdGenerator.setIdBlockSize(this.idBlockSize);
/*  975 */       dbIdGenerator.setCommandExecutor(idGeneratorCommandExecutor);
/*  976 */       this.idGenerator = dbIdGenerator;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void initCommandContextFactory()
/*      */   {
/*  983 */     if (this.commandContextFactory == null) {
/*  984 */       this.commandContextFactory = new CommandContextFactory();
/*  985 */       this.commandContextFactory.setProcessEngineConfiguration(this);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void initTransactionContextFactory() {
/*  990 */     if (this.transactionContextFactory == null)
/*  991 */       this.transactionContextFactory = new StandaloneMybatisTransactionContextFactory();
/*      */   }
/*      */ 
/*      */   protected void initVariableTypes()
/*      */   {
/*  996 */     if (this.variableTypes == null) {
/*  997 */       this.variableTypes = new DefaultVariableTypes();
/*  998 */       if (this.customPreVariableTypes != null) {
/*  999 */         for (VariableType customVariableType : this.customPreVariableTypes) {
/* 1000 */           this.variableTypes.addType(customVariableType);
/*      */         }
/*      */       }
/* 1003 */       this.variableTypes.addType(new NullType());
/* 1004 */       this.variableTypes.addType(new StringType());
/* 1005 */       this.variableTypes.addType(new BooleanType());
/* 1006 */       this.variableTypes.addType(new ShortType());
/* 1007 */       this.variableTypes.addType(new IntegerType());
/* 1008 */       this.variableTypes.addType(new LongType());
/* 1009 */       this.variableTypes.addType(new DateType());
/* 1010 */       this.variableTypes.addType(new DoubleType());
/* 1011 */       this.variableTypes.addType(new ByteArrayType());
/* 1012 */       this.variableTypes.addType(new SerializableType());
/* 1013 */       this.variableTypes.addType(new CustomObjectType("item", ItemInstance.class));
/* 1014 */       this.variableTypes.addType(new CustomObjectType("message", MessageInstance.class));
/* 1015 */       if (this.customPostVariableTypes != null)
/* 1016 */         for (VariableType customVariableType : this.customPostVariableTypes)
/* 1017 */           this.variableTypes.addType(customVariableType);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void initFormEngines()
/*      */   {
/* 1024 */     if (this.formEngines == null) {
/* 1025 */       this.formEngines = new HashMap();
/* 1026 */       FormEngine defaultFormEngine = new JuelFormEngine();
/* 1027 */       this.formEngines.put(null, defaultFormEngine);
/* 1028 */       this.formEngines.put(defaultFormEngine.getName(), defaultFormEngine);
/*      */     }
/* 1030 */     if (this.customFormEngines != null)
/* 1031 */       for (FormEngine formEngine : this.customFormEngines)
/* 1032 */         this.formEngines.put(formEngine.getName(), formEngine);
/*      */   }
/*      */ 
/*      */   protected void initFormTypes()
/*      */   {
/* 1038 */     if (this.formTypes == null) {
/* 1039 */       this.formTypes = new FormTypes();
/* 1040 */       this.formTypes.addFormType(new StringFormType());
/* 1041 */       this.formTypes.addFormType(new LongFormType());
/* 1042 */       this.formTypes.addFormType(new DateFormType("dd/MM/yyyy"));
/* 1043 */       this.formTypes.addFormType(new BooleanFormType());
/*      */     }
/* 1045 */     if (this.customFormTypes != null)
/* 1046 */       for (AbstractFormType customFormType : this.customFormTypes)
/* 1047 */         this.formTypes.addFormType(customFormType);
/*      */   }
/*      */ 
/*      */   protected void initScriptingEngines()
/*      */   {
/* 1053 */     if (this.resolverFactories == null) {
/* 1054 */       this.resolverFactories = new ArrayList();
/* 1055 */       this.resolverFactories.add(new VariableScopeResolverFactory());
/* 1056 */       this.resolverFactories.add(new BeansResolverFactory());
/*      */     }
/* 1058 */     if (this.scriptingEngines == null)
/* 1059 */       this.scriptingEngines = new ScriptingEngines(new ScriptBindingsFactory(this.resolverFactories));
/*      */   }
/*      */ 
/*      */   protected void initExpressionManager()
/*      */   {
/* 1064 */     if (this.expressionManager == null)
/* 1065 */       this.expressionManager = new ExpressionManager(this.beans);
/*      */   }
/*      */ 
/*      */   protected void initBusinessCalendarManager()
/*      */   {
/* 1070 */     if (this.businessCalendarManager == null) {
/* 1071 */       MapBusinessCalendarManager mapBusinessCalendarManager = new MapBusinessCalendarManager();
/* 1072 */       mapBusinessCalendarManager.addBusinessCalendar(DurationBusinessCalendar.NAME, new DurationBusinessCalendar());
/* 1073 */       mapBusinessCalendarManager.addBusinessCalendar("dueDate", new DueDateBusinessCalendar());
/* 1074 */       mapBusinessCalendarManager.addBusinessCalendar(CycleBusinessCalendar.NAME, new CycleBusinessCalendar());
/*      */ 
/* 1076 */       this.businessCalendarManager = mapBusinessCalendarManager;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void initDelegateInterceptor() {
/* 1081 */     if (this.delegateInterceptor == null)
/* 1082 */       this.delegateInterceptor = new DefaultDelegateInterceptor();
/*      */   }
/*      */ 
/*      */   protected void initEventHandlers()
/*      */   {
/* 1087 */     if (this.eventHandlers == null) {
/* 1088 */       this.eventHandlers = new HashMap();
/*      */ 
/* 1090 */       SignalEventHandler signalEventHander = new SignalEventHandler();
/* 1091 */       this.eventHandlers.put(signalEventHander.getEventHandlerType(), signalEventHander);
/*      */ 
/* 1093 */       CompensationEventHandler compensationEventHandler = new CompensationEventHandler();
/* 1094 */       this.eventHandlers.put(compensationEventHandler.getEventHandlerType(), compensationEventHandler);
/*      */ 
/* 1096 */       MessageEventHandler messageEventHandler = new MessageEventHandler();
/* 1097 */       this.eventHandlers.put(messageEventHandler.getEventHandlerType(), messageEventHandler);
/*      */     }
/*      */ 
/* 1100 */     if (this.customEventHandlers != null)
/* 1101 */       for (EventHandler eventHandler : this.customEventHandlers)
/* 1102 */         this.eventHandlers.put(eventHandler.getEventHandlerType(), eventHandler);
/*      */   }
/*      */ 
/*      */   protected void initJpa()
/*      */   {
/* 1110 */     if (this.jpaPersistenceUnitName != null) {
/* 1111 */       this.jpaEntityManagerFactory = JpaHelper.createEntityManagerFactory(this.jpaPersistenceUnitName);
/*      */     }
/* 1113 */     if (this.jpaEntityManagerFactory != null) {
/* 1114 */       this.sessionFactories.put(EntityManagerSession.class, new EntityManagerSessionFactory(this.jpaEntityManagerFactory, this.jpaHandleTransaction, this.jpaCloseEntityManager));
/* 1115 */       VariableType jpaType = this.variableTypes.getVariableType("jpa-entity");
/*      */ 
/* 1117 */       if (jpaType == null)
/*      */       {
/* 1119 */         int serializableIndex = this.variableTypes.getTypeIndex("serializable");
/* 1120 */         if (serializableIndex > -1)
/* 1121 */           this.variableTypes.addType(new JPAEntityVariableType(), serializableIndex);
/*      */         else
/* 1123 */           this.variableTypes.addType(new JPAEntityVariableType());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void initBeans()
/*      */   {
/* 1130 */     if (this.beans == null)
/* 1131 */       this.beans = new HashMap();
/*      */   }
/*      */ 
/*      */   public List<CommandInterceptor> getCustomPreCommandInterceptorsTxRequired()
/*      */   {
/* 1138 */     return this.customPreCommandInterceptorsTxRequired;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setCustomPreCommandInterceptorsTxRequired(List<CommandInterceptor> customPreCommandInterceptorsTxRequired) {
/* 1142 */     this.customPreCommandInterceptorsTxRequired = customPreCommandInterceptorsTxRequired;
/* 1143 */     return this;
/*      */   }
/*      */ 
/*      */   public List<CommandInterceptor> getCustomPostCommandInterceptorsTxRequired() {
/* 1147 */     return this.customPostCommandInterceptorsTxRequired;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setCustomPostCommandInterceptorsTxRequired(List<CommandInterceptor> customPostCommandInterceptorsTxRequired) {
/* 1151 */     this.customPostCommandInterceptorsTxRequired = customPostCommandInterceptorsTxRequired;
/* 1152 */     return this;
/*      */   }
/*      */ 
/*      */   public List<CommandInterceptor> getCommandInterceptorsTxRequired() {
/* 1156 */     return this.commandInterceptorsTxRequired;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setCommandInterceptorsTxRequired(List<CommandInterceptor> commandInterceptorsTxRequired) {
/* 1160 */     this.commandInterceptorsTxRequired = commandInterceptorsTxRequired;
/* 1161 */     return this;
/*      */   }
/*      */ 
/*      */   public CommandExecutor getCommandExecutorTxRequired() {
/* 1165 */     return this.commandExecutorTxRequired;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setCommandExecutorTxRequired(CommandExecutor commandExecutorTxRequired) {
/* 1169 */     this.commandExecutorTxRequired = commandExecutorTxRequired;
/* 1170 */     return this;
/*      */   }
/*      */ 
/*      */   public List<CommandInterceptor> getCustomPreCommandInterceptorsTxRequiresNew() {
/* 1174 */     return this.customPreCommandInterceptorsTxRequiresNew;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setCustomPreCommandInterceptorsTxRequiresNew(List<CommandInterceptor> customPreCommandInterceptorsTxRequiresNew) {
/* 1178 */     this.customPreCommandInterceptorsTxRequiresNew = customPreCommandInterceptorsTxRequiresNew;
/* 1179 */     return this;
/*      */   }
/*      */ 
/*      */   public List<CommandInterceptor> getCustomPostCommandInterceptorsTxRequiresNew() {
/* 1183 */     return this.customPostCommandInterceptorsTxRequiresNew;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setCustomPostCommandInterceptorsTxRequiresNew(List<CommandInterceptor> customPostCommandInterceptorsTxRequiresNew) {
/* 1187 */     this.customPostCommandInterceptorsTxRequiresNew = customPostCommandInterceptorsTxRequiresNew;
/* 1188 */     return this;
/*      */   }
/*      */ 
/*      */   public List<CommandInterceptor> getCommandInterceptorsTxRequiresNew() {
/* 1192 */     return this.commandInterceptorsTxRequiresNew;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setCommandInterceptorsTxRequiresNew(List<CommandInterceptor> commandInterceptorsTxRequiresNew) {
/* 1196 */     this.commandInterceptorsTxRequiresNew = commandInterceptorsTxRequiresNew;
/* 1197 */     return this;
/*      */   }
/*      */ 
/*      */   public CommandExecutor getCommandExecutorTxRequiresNew() {
/* 1201 */     return this.commandExecutorTxRequiresNew;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setCommandExecutorTxRequiresNew(CommandExecutor commandExecutorTxRequiresNew) {
/* 1205 */     this.commandExecutorTxRequiresNew = commandExecutorTxRequiresNew;
/* 1206 */     return this;
/*      */   }
/*      */ 
/*      */   public RepositoryService getRepositoryService() {
/* 1210 */     return this.repositoryService;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setRepositoryService(RepositoryService repositoryService) {
/* 1214 */     this.repositoryService = repositoryService;
/* 1215 */     return this;
/*      */   }
/*      */ 
/*      */   public RuntimeService getRuntimeService() {
/* 1219 */     return this.runtimeService;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setRuntimeService(RuntimeService runtimeService) {
/* 1223 */     this.runtimeService = runtimeService;
/* 1224 */     return this;
/*      */   }
/*      */ 
/*      */   public HistoryService getHistoryService() {
/* 1228 */     return this.historyService;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setHistoryService(HistoryService historyService) {
/* 1232 */     this.historyService = historyService;
/* 1233 */     return this;
/*      */   }
/*      */ 
/*      */   public IdentityService getIdentityService() {
/* 1237 */     return this.identityService;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setIdentityService(IdentityService identityService) {
/* 1241 */     this.identityService = identityService;
/* 1242 */     return this;
/*      */   }
/*      */ 
/*      */   public TaskService getTaskService() {
/* 1246 */     return this.taskService;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setTaskService(TaskService taskService) {
/* 1250 */     this.taskService = taskService;
/* 1251 */     return this;
/*      */   }
/*      */ 
/*      */   public FormService getFormService() {
/* 1255 */     return this.formService;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setFormService(FormService formService) {
/* 1259 */     this.formService = formService;
/* 1260 */     return this;
/*      */   }
/*      */ 
/*      */   public ManagementService getManagementService() {
/* 1264 */     return this.managementService;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setManagementService(ManagementService managementService) {
/* 1268 */     this.managementService = managementService;
/* 1269 */     return this;
/*      */   }
/*      */ 
/*      */   public Map<Class<?>, SessionFactory> getSessionFactories() {
/* 1273 */     return this.sessionFactories;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setSessionFactories(Map<Class<?>, SessionFactory> sessionFactories) {
/* 1277 */     this.sessionFactories = sessionFactories;
/* 1278 */     return this;
/*      */   }
/*      */ 
/*      */   public List<ProcessEngineConfigurator> getConfigurators() {
/* 1282 */     return this.configurators;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setConfigurators(List<ProcessEngineConfigurator> configurators) {
/* 1286 */     this.configurators = configurators;
/* 1287 */     return this;
/*      */   }
/*      */ 
/*      */   public BpmnDeployer getBpmnDeployer() {
/* 1291 */     return this.bpmnDeployer;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setBpmnDeployer(BpmnDeployer bpmnDeployer) {
/* 1295 */     this.bpmnDeployer = bpmnDeployer;
/* 1296 */     return this;
/*      */   }
/*      */ 
/*      */   public BpmnParser getBpmnParser() {
/* 1300 */     return this.bpmnParser;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setBpmnParser(BpmnParser bpmnParser) {
/* 1304 */     this.bpmnParser = bpmnParser;
/* 1305 */     return this;
/*      */   }
/*      */ 
/*      */   public List<Deployer> getDeployers() {
/* 1309 */     return this.deployers;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setDeployers(List<Deployer> deployers) {
/* 1313 */     this.deployers = deployers;
/* 1314 */     return this;
/*      */   }
/*      */ 
/*      */   public JobExecutor getJobExecutor() {
/* 1318 */     return this.jobExecutor;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setJobExecutor(JobExecutor jobExecutor) {
/* 1322 */     this.jobExecutor = jobExecutor;
/* 1323 */     return this;
/*      */   }
/*      */ 
/*      */   public IdGenerator getIdGenerator() {
/* 1327 */     return this.idGenerator;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setIdGenerator(IdGenerator idGenerator) {
/* 1331 */     this.idGenerator = idGenerator;
/* 1332 */     return this;
/*      */   }
/*      */ 
/*      */   public String getWsSyncFactoryClassName() {
/* 1336 */     return this.wsSyncFactoryClassName;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setWsSyncFactoryClassName(String wsSyncFactoryClassName) {
/* 1340 */     this.wsSyncFactoryClassName = wsSyncFactoryClassName;
/* 1341 */     return this;
/*      */   }
/*      */ 
/*      */   public Map<String, FormEngine> getFormEngines() {
/* 1345 */     return this.formEngines;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setFormEngines(Map<String, FormEngine> formEngines) {
/* 1349 */     this.formEngines = formEngines;
/* 1350 */     return this;
/*      */   }
/*      */ 
/*      */   public FormTypes getFormTypes() {
/* 1354 */     return this.formTypes;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setFormTypes(FormTypes formTypes) {
/* 1358 */     this.formTypes = formTypes;
/* 1359 */     return this;
/*      */   }
/*      */ 
/*      */   public ScriptingEngines getScriptingEngines() {
/* 1363 */     return this.scriptingEngines;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setScriptingEngines(ScriptingEngines scriptingEngines) {
/* 1367 */     this.scriptingEngines = scriptingEngines;
/* 1368 */     return this;
/*      */   }
/*      */ 
/*      */   public VariableTypes getVariableTypes() {
/* 1372 */     return this.variableTypes;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setVariableTypes(VariableTypes variableTypes) {
/* 1376 */     this.variableTypes = variableTypes;
/* 1377 */     return this;
/*      */   }
/*      */ 
/*      */   public ExpressionManager getExpressionManager() {
/* 1381 */     return this.expressionManager;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setExpressionManager(ExpressionManager expressionManager) {
/* 1385 */     this.expressionManager = expressionManager;
/* 1386 */     return this;
/*      */   }
/*      */ 
/*      */   public BusinessCalendarManager getBusinessCalendarManager() {
/* 1390 */     return this.businessCalendarManager;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setBusinessCalendarManager(BusinessCalendarManager businessCalendarManager) {
/* 1394 */     this.businessCalendarManager = businessCalendarManager;
/* 1395 */     return this;
/*      */   }
/*      */ 
/*      */   public CommandContextFactory getCommandContextFactory() {
/* 1399 */     return this.commandContextFactory;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setCommandContextFactory(CommandContextFactory commandContextFactory) {
/* 1403 */     this.commandContextFactory = commandContextFactory;
/* 1404 */     return this;
/*      */   }
/*      */ 
/*      */   public TransactionContextFactory getTransactionContextFactory() {
/* 1408 */     return this.transactionContextFactory;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setTransactionContextFactory(TransactionContextFactory transactionContextFactory) {
/* 1412 */     this.transactionContextFactory = transactionContextFactory;
/* 1413 */     return this;
/*      */   }
/*      */ 
/*      */   public List<Deployer> getCustomPreDeployers() {
/* 1417 */     return this.customPreDeployers;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setCustomPreDeployers(List<Deployer> customPreDeployers) {
/* 1421 */     this.customPreDeployers = customPreDeployers;
/* 1422 */     return this;
/*      */   }
/*      */ 
/*      */   public List<Deployer> getCustomPostDeployers() {
/* 1426 */     return this.customPostDeployers;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setCustomPostDeployers(List<Deployer> customPostDeployers) {
/* 1430 */     this.customPostDeployers = customPostDeployers;
/* 1431 */     return this;
/*      */   }
/*      */ 
/*      */   public Map<String, JobHandler> getJobHandlers() {
/* 1435 */     return this.jobHandlers;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setJobHandlers(Map<String, JobHandler> jobHandlers) {
/* 1439 */     this.jobHandlers = jobHandlers;
/* 1440 */     return this;
/*      */   }
/*      */ 
/*      */   public SqlSessionFactory getSqlSessionFactory() {
/* 1444 */     return this.sqlSessionFactory;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setSqlSessionFactory(SqlSessionFactory sqlSessionFactory) {
/* 1448 */     this.sqlSessionFactory = sqlSessionFactory;
/* 1449 */     return this;
/*      */   }
/*      */ 
/*      */   public DbSqlSessionFactory getDbSqlSessionFactory() {
/* 1453 */     return this.dbSqlSessionFactory;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setDbSqlSessionFactory(DbSqlSessionFactory dbSqlSessionFactory) {
/* 1457 */     this.dbSqlSessionFactory = dbSqlSessionFactory;
/* 1458 */     return this;
/*      */   }
/*      */ 
/*      */   public TransactionFactory getTransactionFactory() {
/* 1462 */     return this.transactionFactory;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setTransactionFactory(TransactionFactory transactionFactory) {
/* 1466 */     this.transactionFactory = transactionFactory;
/* 1467 */     return this;
/*      */   }
/*      */ 
/*      */   public List<SessionFactory> getCustomSessionFactories() {
/* 1471 */     return this.customSessionFactories;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setCustomSessionFactories(List<SessionFactory> customSessionFactories) {
/* 1475 */     this.customSessionFactories = customSessionFactories;
/* 1476 */     return this;
/*      */   }
/*      */ 
/*      */   public List<JobHandler> getCustomJobHandlers() {
/* 1480 */     return this.customJobHandlers;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setCustomJobHandlers(List<JobHandler> customJobHandlers) {
/* 1484 */     this.customJobHandlers = customJobHandlers;
/* 1485 */     return this;
/*      */   }
/*      */ 
/*      */   public List<FormEngine> getCustomFormEngines() {
/* 1489 */     return this.customFormEngines;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setCustomFormEngines(List<FormEngine> customFormEngines) {
/* 1493 */     this.customFormEngines = customFormEngines;
/* 1494 */     return this;
/*      */   }
/*      */ 
/*      */   public List<AbstractFormType> getCustomFormTypes() {
/* 1498 */     return this.customFormTypes;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setCustomFormTypes(List<AbstractFormType> customFormTypes) {
/* 1502 */     this.customFormTypes = customFormTypes;
/* 1503 */     return this;
/*      */   }
/*      */ 
/*      */   public List<String> getCustomScriptingEngineClasses() {
/* 1507 */     return this.customScriptingEngineClasses;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setCustomScriptingEngineClasses(List<String> customScriptingEngineClasses) {
/* 1511 */     this.customScriptingEngineClasses = customScriptingEngineClasses;
/* 1512 */     return this;
/*      */   }
/*      */ 
/*      */   public List<VariableType> getCustomPreVariableTypes() {
/* 1516 */     return this.customPreVariableTypes;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setCustomPreVariableTypes(List<VariableType> customPreVariableTypes) {
/* 1520 */     this.customPreVariableTypes = customPreVariableTypes;
/* 1521 */     return this;
/*      */   }
/*      */ 
/*      */   public List<VariableType> getCustomPostVariableTypes() {
/* 1525 */     return this.customPostVariableTypes;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setCustomPostVariableTypes(List<VariableType> customPostVariableTypes) {
/* 1529 */     this.customPostVariableTypes = customPostVariableTypes;
/* 1530 */     return this;
/*      */   }
/*      */ 
/*      */   public List<BpmnParseHandler> getPreBpmnParseHandlers() {
/* 1534 */     return this.preBpmnParseHandlers;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setPreBpmnParseHandlers(List<BpmnParseHandler> preBpmnParseHandlers) {
/* 1538 */     this.preBpmnParseHandlers = preBpmnParseHandlers;
/* 1539 */     return this;
/*      */   }
/*      */ 
/*      */   public List<BpmnParseHandler> getCustomDefaultBpmnParseHandlers() {
/* 1543 */     return this.customDefaultBpmnParseHandlers;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setCustomDefaultBpmnParseHandlers(List<BpmnParseHandler> customDefaultBpmnParseHandlers) {
/* 1547 */     this.customDefaultBpmnParseHandlers = customDefaultBpmnParseHandlers;
/* 1548 */     return this;
/*      */   }
/*      */ 
/*      */   public List<BpmnParseHandler> getPostBpmnParseHandlers() {
/* 1552 */     return this.postBpmnParseHandlers;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setPostBpmnParseHandlers(List<BpmnParseHandler> postBpmnParseHandlers) {
/* 1556 */     this.postBpmnParseHandlers = postBpmnParseHandlers;
/* 1557 */     return this;
/*      */   }
/*      */ 
/*      */   public ActivityBehaviorFactory getActivityBehaviorFactory() {
/* 1561 */     return this.activityBehaviorFactory;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setActivityBehaviorFactory(ActivityBehaviorFactory activityBehaviorFactory) {
/* 1565 */     this.activityBehaviorFactory = activityBehaviorFactory;
/* 1566 */     return this;
/*      */   }
/*      */ 
/*      */   public ListenerFactory getListenerFactory() {
/* 1570 */     return this.listenerFactory;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setListenerFactory(ListenerFactory listenerFactory) {
/* 1574 */     this.listenerFactory = listenerFactory;
/* 1575 */     return this;
/*      */   }
/*      */ 
/*      */   public BpmnParseFactory getBpmnParseFactory() {
/* 1579 */     return this.bpmnParseFactory;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setBpmnParseFactory(BpmnParseFactory bpmnParseFactory) {
/* 1583 */     this.bpmnParseFactory = bpmnParseFactory;
/* 1584 */     return this;
/*      */   }
/*      */ 
/*      */   public Map<Object, Object> getBeans() {
/* 1588 */     return this.beans;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setBeans(Map<Object, Object> beans) {
/* 1592 */     this.beans = beans;
/* 1593 */     return this;
/*      */   }
/*      */ 
/*      */   public List<ResolverFactory> getResolverFactories() {
/* 1597 */     return this.resolverFactories;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setResolverFactories(List<ResolverFactory> resolverFactories) {
/* 1601 */     this.resolverFactories = resolverFactories;
/* 1602 */     return this;
/*      */   }
/*      */ 
/*      */   public DeploymentManager getDeploymentManager() {
/* 1606 */     return this.deploymentManager;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setDeploymentManager(DeploymentManager deploymentManager) {
/* 1610 */     this.deploymentManager = deploymentManager;
/* 1611 */     return this;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setDelegateInterceptor(DelegateInterceptor delegateInterceptor) {
/* 1615 */     this.delegateInterceptor = delegateInterceptor;
/* 1616 */     return this;
/*      */   }
/*      */ 
/*      */   public DelegateInterceptor getDelegateInterceptor() {
/* 1620 */     return this.delegateInterceptor;
/*      */   }
/*      */ 
/*      */   public RejectedJobsHandler getCustomRejectedJobsHandler() {
/* 1624 */     return this.customRejectedJobsHandler;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setCustomRejectedJobsHandler(RejectedJobsHandler customRejectedJobsHandler) {
/* 1628 */     this.customRejectedJobsHandler = customRejectedJobsHandler;
/* 1629 */     return this;
/*      */   }
/*      */ 
/*      */   public EventHandler getEventHandler(String eventType) {
/* 1633 */     return (EventHandler)this.eventHandlers.get(eventType);
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setEventHandlers(Map<String, EventHandler> eventHandlers) {
/* 1637 */     this.eventHandlers = eventHandlers;
/* 1638 */     return this;
/*      */   }
/*      */ 
/*      */   public Map<String, EventHandler> getEventHandlers() {
/* 1642 */     return this.eventHandlers;
/*      */   }
/*      */ 
/*      */   public List<EventHandler> getCustomEventHandlers() {
/* 1646 */     return this.customEventHandlers;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setCustomEventHandlers(List<EventHandler> customEventHandlers) {
/* 1650 */     this.customEventHandlers = customEventHandlers;
/* 1651 */     return this;
/*      */   }
/*      */ 
/*      */   public FailedJobCommandFactory getFailedJobCommandFactory() {
/* 1655 */     return this.failedJobCommandFactory;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setFailedJobCommandFactory(FailedJobCommandFactory failedJobCommandFactory) {
/* 1659 */     this.failedJobCommandFactory = failedJobCommandFactory;
/* 1660 */     return this;
/*      */   }
/*      */ 
/*      */   public DataSource getIdGeneratorDataSource() {
/* 1664 */     return this.idGeneratorDataSource;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setIdGeneratorDataSource(DataSource idGeneratorDataSource) {
/* 1668 */     this.idGeneratorDataSource = idGeneratorDataSource;
/* 1669 */     return this;
/*      */   }
/*      */ 
/*      */   public String getIdGeneratorDataSourceJndiName() {
/* 1673 */     return this.idGeneratorDataSourceJndiName;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setIdGeneratorDataSourceJndiName(String idGeneratorDataSourceJndiName) {
/* 1677 */     this.idGeneratorDataSourceJndiName = idGeneratorDataSourceJndiName;
/* 1678 */     return this;
/*      */   }
/*      */ 
/*      */   public int getBatchSizeProcessInstances() {
/* 1682 */     return this.batchSizeProcessInstances;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setBatchSizeProcessInstances(int batchSizeProcessInstances) {
/* 1686 */     this.batchSizeProcessInstances = batchSizeProcessInstances;
/* 1687 */     return this;
/*      */   }
/*      */ 
/*      */   public int getBatchSizeTasks() {
/* 1691 */     return this.batchSizeTasks;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setBatchSizeTasks(int batchSizeTasks) {
/* 1695 */     this.batchSizeTasks = batchSizeTasks;
/* 1696 */     return this;
/*      */   }
/*      */ 
/*      */   public int getProcessDefinitionCacheLimit() {
/* 1700 */     return this.processDefinitionCacheLimit;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setProcessDefinitionCacheLimit(int processDefinitionCacheLimit) {
/* 1704 */     this.processDefinitionCacheLimit = processDefinitionCacheLimit;
/* 1705 */     return this;
/*      */   }
/*      */ 
/*      */   public DeploymentCache<ProcessDefinitionEntity> getProcessDefinitionCache() {
/* 1709 */     return this.processDefinitionCache;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setProcessDefinitionCache(DeploymentCache<ProcessDefinitionEntity> processDefinitionCache) {
/* 1713 */     this.processDefinitionCache = processDefinitionCache;
/* 1714 */     return this;
/*      */   }
/*      */ 
/*      */   public int getKnowledgeBaseCacheLimit() {
/* 1718 */     return this.knowledgeBaseCacheLimit;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setKnowledgeBaseCacheLimit(int knowledgeBaseCacheLimit) {
/* 1722 */     this.knowledgeBaseCacheLimit = knowledgeBaseCacheLimit;
/* 1723 */     return this;
/*      */   }
/*      */ 
/*      */   public DeploymentCache<Object> getKnowledgeBaseCache() {
/* 1727 */     return this.knowledgeBaseCache;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setKnowledgeBaseCache(DeploymentCache<Object> knowledgeBaseCache) {
/* 1731 */     this.knowledgeBaseCache = knowledgeBaseCache;
/* 1732 */     return this;
/*      */   }
/*      */ 
/*      */   public boolean isEnableSafeBpmnXml() {
/* 1736 */     return this.enableSafeBpmnXml;
/*      */   }
/*      */ 
/*      */   public ProcessEngineConfigurationImpl setEnableSafeBpmnXml(boolean enableSafeBpmnXml) {
/* 1740 */     this.enableSafeBpmnXml = enableSafeBpmnXml;
/* 1741 */     return this;
/*      */   }
/*      */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl
 * JD-Core Version:    0.6.0
 */