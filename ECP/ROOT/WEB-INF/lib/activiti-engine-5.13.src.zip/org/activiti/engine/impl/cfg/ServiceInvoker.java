package org.activiti.engine.impl.cfg;

import java.util.Map;
import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
import org.activiti.engine.impl.persistence.entity.TaskEntity;

public abstract interface ServiceInvoker
{
  public abstract void invoke(String paramString, Map<String, Object> paramMap, ExecutionEntity paramExecutionEntity, TaskEntity paramTaskEntity);
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cfg.ServiceInvoker
 * JD-Core Version:    0.6.0
 */