/*    */ package org.activiti.engine.impl.cfg;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ 
/*    */ public class SpringBeanFactoryProxyMap
/*    */   implements Map<Object, Object>
/*    */ {
/*    */   protected BeanFactory beanFactory;
/*    */ 
/*    */   public SpringBeanFactoryProxyMap(BeanFactory beanFactory)
/*    */   {
/* 32 */     this.beanFactory = beanFactory;
/*    */   }
/*    */ 
/*    */   public Object get(Object key) {
/* 36 */     if ((key == null) || (!String.class.isAssignableFrom(key.getClass()))) {
/* 37 */       return null;
/*    */     }
/* 39 */     return this.beanFactory.getBean((String)key);
/*    */   }
/*    */ 
/*    */   public boolean containsKey(Object key) {
/* 43 */     if ((key == null) || (!String.class.isAssignableFrom(key.getClass()))) {
/* 44 */       return false;
/*    */     }
/* 46 */     return this.beanFactory.containsBean((String)key);
/*    */   }
/*    */ 
/*    */   public Set<Object> keySet() {
/* 50 */     throw new ActivitiException("unsupported operation on configuration beans");
/*    */   }
/*    */ 
/*    */   public void clear()
/*    */   {
/* 56 */     throw new ActivitiException("can't clear configuration beans");
/*    */   }
/*    */ 
/*    */   public boolean containsValue(Object value) {
/* 60 */     throw new ActivitiException("can't search values in configuration beans");
/*    */   }
/*    */ 
/*    */   public Set<Map.Entry<Object, Object>> entrySet() {
/* 64 */     throw new ActivitiException("unsupported operation on configuration beans");
/*    */   }
/*    */ 
/*    */   public boolean isEmpty() {
/* 68 */     throw new ActivitiException("unsupported operation on configuration beans");
/*    */   }
/*    */ 
/*    */   public Object put(Object key, Object value) {
/* 72 */     throw new ActivitiException("unsupported operation on configuration beans");
/*    */   }
/*    */ 
/*    */   public void putAll(Map<? extends Object, ? extends Object> m) {
/* 76 */     throw new ActivitiException("unsupported operation on configuration beans");
/*    */   }
/*    */ 
/*    */   public Object remove(Object key) {
/* 80 */     throw new ActivitiException("unsupported operation on configuration beans");
/*    */   }
/*    */ 
/*    */   public int size() {
/* 84 */     throw new ActivitiException("unsupported operation on configuration beans");
/*    */   }
/*    */ 
/*    */   public Collection<Object> values() {
/* 88 */     throw new ActivitiException("unsupported operation on configuration beans");
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cfg.SpringBeanFactoryProxyMap
 * JD-Core Version:    0.6.0
 */