/*    */ package org.activiti.engine.impl.cfg;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.activiti.engine.impl.interceptor.CommandContextInterceptor;
/*    */ import org.activiti.engine.impl.interceptor.CommandInterceptor;
/*    */ import org.activiti.engine.impl.interceptor.LogInterceptor;
/*    */ 
/*    */ public class StandaloneProcessEngineConfiguration extends ProcessEngineConfigurationImpl
/*    */ {
/*    */   protected Collection<? extends CommandInterceptor> getDefaultCommandInterceptorsTxRequired()
/*    */   {
/* 31 */     return createDefaultCommandInterceptors(true);
/*    */   }
/*    */ 
/*    */   protected Collection<? extends CommandInterceptor> getDefaultCommandInterceptorsTxRequiresNew() {
/* 35 */     return createDefaultCommandInterceptors(false);
/*    */   }
/*    */ 
/*    */   protected Collection<? extends CommandInterceptor> createDefaultCommandInterceptors(boolean contextReusePossible) {
/* 39 */     List defaultCommandInterceptorsTxRequired = new ArrayList();
/* 40 */     defaultCommandInterceptorsTxRequired.add(new LogInterceptor());
/*    */ 
/* 42 */     CommandContextInterceptor commandContextInterceptor = new CommandContextInterceptor(this.commandContextFactory, this);
/* 43 */     commandContextInterceptor.setContextReusePossible(contextReusePossible);
/* 44 */     defaultCommandInterceptorsTxRequired.add(commandContextInterceptor);
/*    */ 
/* 46 */     return defaultCommandInterceptorsTxRequired;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cfg.StandaloneProcessEngineConfiguration
 * JD-Core Version:    0.6.0
 */