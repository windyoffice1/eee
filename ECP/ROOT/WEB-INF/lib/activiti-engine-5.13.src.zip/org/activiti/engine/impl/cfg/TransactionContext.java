package org.activiti.engine.impl.cfg;

public abstract interface TransactionContext
{
  public abstract void commit();

  public abstract void rollback();

  public abstract void addTransactionListener(TransactionState paramTransactionState, TransactionListener paramTransactionListener);
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cfg.TransactionContext
 * JD-Core Version:    0.6.0
 */