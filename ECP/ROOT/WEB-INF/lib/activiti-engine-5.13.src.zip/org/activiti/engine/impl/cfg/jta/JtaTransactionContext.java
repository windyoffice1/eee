/*     */ package org.activiti.engine.impl.cfg.jta;
/*     */ 
/*     */ import javax.transaction.RollbackException;
/*     */ import javax.transaction.Synchronization;
/*     */ import javax.transaction.SystemException;
/*     */ import javax.transaction.Transaction;
/*     */ import javax.transaction.TransactionManager;
/*     */ import org.activiti.engine.ActivitiException;
/*     */ import org.activiti.engine.impl.cfg.TransactionContext;
/*     */ import org.activiti.engine.impl.cfg.TransactionListener;
/*     */ import org.activiti.engine.impl.cfg.TransactionState;
/*     */ import org.activiti.engine.impl.context.Context;
/*     */ import org.activiti.engine.impl.interceptor.CommandContext;
/*     */ 
/*     */ public class JtaTransactionContext
/*     */   implements TransactionContext
/*     */ {
/*     */   protected final TransactionManager transactionManager;
/*     */ 
/*     */   public JtaTransactionContext(TransactionManager transactionManager)
/*     */   {
/*  38 */     this.transactionManager = transactionManager;
/*     */   }
/*     */ 
/*     */   public void commit()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void rollback()
/*     */   {
/*     */     try {
/*  48 */       Transaction transaction = getTransaction();
/*  49 */       int status = transaction.getStatus();
/*  50 */       if ((status != 6) && (status != 4))
/*  51 */         transaction.setRollbackOnly();
/*     */     }
/*     */     catch (IllegalStateException e) {
/*  54 */       throw new ActivitiException("Unexpected IllegalStateException while marking transaction rollback only");
/*     */     } catch (SystemException e) {
/*  56 */       throw new ActivitiException("SystemException while marking transaction rollback only");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Transaction getTransaction() {
/*     */     try {
/*  62 */       return this.transactionManager.getTransaction(); } catch (SystemException e) {
/*     */     }
/*  64 */     throw new ActivitiException("SystemException while getting transaction ", e);
/*     */   }
/*     */ 
/*     */   public void addTransactionListener(TransactionState transactionState, TransactionListener transactionListener)
/*     */   {
/*  69 */     Transaction transaction = getTransaction();
/*  70 */     CommandContext commandContext = Context.getCommandContext();
/*     */     try {
/*  72 */       transaction.registerSynchronization(new TransactionStateSynchronization(transactionState, transactionListener, commandContext));
/*     */     } catch (IllegalStateException e) {
/*  74 */       throw new ActivitiException("IllegalStateException while registering synchronization ", e);
/*     */     } catch (RollbackException e) {
/*  76 */       throw new ActivitiException("RollbackException while registering synchronization ", e);
/*     */     } catch (SystemException e) {
/*  78 */       throw new ActivitiException("SystemException while registering synchronization ", e);
/*     */     }
/*     */   }
/*     */   public static class TransactionStateSynchronization implements Synchronization {
/*     */     protected final TransactionListener transactionListener;
/*     */     protected final TransactionState transactionState;
/*     */     private final CommandContext commandContext;
/*     */ 
/*     */     public TransactionStateSynchronization(TransactionState transactionState, TransactionListener transactionListener, CommandContext commandContext) {
/*  89 */       this.transactionState = transactionState;
/*  90 */       this.transactionListener = transactionListener;
/*  91 */       this.commandContext = commandContext;
/*     */     }
/*     */ 
/*     */     public void beforeCompletion() {
/*  95 */       if ((TransactionState.COMMITTING.equals(this.transactionState)) || (TransactionState.ROLLINGBACK.equals(this.transactionState)))
/*     */       {
/*  97 */         this.transactionListener.execute(this.commandContext);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void afterCompletion(int status) {
/* 102 */       if ((4 == status) && (TransactionState.ROLLED_BACK.equals(this.transactionState)))
/* 103 */         this.transactionListener.execute(this.commandContext);
/* 104 */       else if ((3 == status) && (TransactionState.COMMITTED.equals(this.transactionState)))
/* 105 */         this.transactionListener.execute(this.commandContext);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cfg.jta.JtaTransactionContext
 * JD-Core Version:    0.6.0
 */