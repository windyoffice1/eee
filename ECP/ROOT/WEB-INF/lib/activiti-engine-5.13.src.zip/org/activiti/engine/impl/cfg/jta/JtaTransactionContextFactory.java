/*    */ package org.activiti.engine.impl.cfg.jta;
/*    */ 
/*    */ import javax.transaction.TransactionManager;
/*    */ import org.activiti.engine.impl.cfg.TransactionContext;
/*    */ import org.activiti.engine.impl.cfg.TransactionContextFactory;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ 
/*    */ public class JtaTransactionContextFactory
/*    */   implements TransactionContextFactory
/*    */ {
/*    */   protected final TransactionManager transactionManager;
/*    */ 
/*    */   public JtaTransactionContextFactory(TransactionManager transactionManager)
/*    */   {
/* 31 */     this.transactionManager = transactionManager;
/*    */   }
/*    */ 
/*    */   public TransactionContext openTransactionContext(CommandContext commandContext) {
/* 35 */     return new JtaTransactionContext(this.transactionManager);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cfg.jta.JtaTransactionContextFactory
 * JD-Core Version:    0.6.0
 */