/*    */ package org.activiti.engine.impl.cfg.standalone;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.activiti.engine.impl.cfg.TransactionContext;
/*    */ import org.activiti.engine.impl.cfg.TransactionListener;
/*    */ import org.activiti.engine.impl.cfg.TransactionState;
/*    */ import org.activiti.engine.impl.db.DbSqlSession;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class StandaloneMybatisTransactionContext
/*    */   implements TransactionContext
/*    */ {
/* 34 */   private static Logger log = LoggerFactory.getLogger(StandaloneMybatisTransactionContext.class);
/*    */   protected CommandContext commandContext;
/* 37 */   protected Map<TransactionState, List<TransactionListener>> stateTransactionListeners = null;
/*    */ 
/*    */   public StandaloneMybatisTransactionContext(CommandContext commandContext) {
/* 40 */     this.commandContext = commandContext;
/*    */   }
/*    */ 
/*    */   public void addTransactionListener(TransactionState transactionState, TransactionListener transactionListener) {
/* 44 */     if (this.stateTransactionListeners == null) {
/* 45 */       this.stateTransactionListeners = new HashMap();
/*    */     }
/* 47 */     List transactionListeners = (List)this.stateTransactionListeners.get(transactionState);
/* 48 */     if (transactionListeners == null) {
/* 49 */       transactionListeners = new ArrayList();
/* 50 */       this.stateTransactionListeners.put(transactionState, transactionListeners);
/*    */     }
/* 52 */     transactionListeners.add(transactionListener);
/*    */   }
/*    */ 
/*    */   public void commit() {
/* 56 */     log.debug("firing event committing...");
/* 57 */     fireTransactionEvent(TransactionState.COMMITTING);
/* 58 */     log.debug("committing the ibatis sql session...");
/* 59 */     getDbSqlSession().commit();
/* 60 */     log.debug("firing event committed...");
/* 61 */     fireTransactionEvent(TransactionState.COMMITTED);
/*    */   }
/*    */ 
/*    */   protected void fireTransactionEvent(TransactionState transactionState) {
/* 65 */     if (this.stateTransactionListeners == null) {
/* 66 */       return;
/*    */     }
/* 68 */     List transactionListeners = (List)this.stateTransactionListeners.get(transactionState);
/* 69 */     if (transactionListeners == null) {
/* 70 */       return;
/*    */     }
/* 72 */     for (TransactionListener transactionListener : transactionListeners)
/* 73 */       transactionListener.execute(this.commandContext);
/*    */   }
/*    */ 
/*    */   private DbSqlSession getDbSqlSession()
/*    */   {
/* 78 */     return (DbSqlSession)this.commandContext.getSession(DbSqlSession.class);
/*    */   }
/*    */ 
/*    */   public void rollback() {
/*    */     try {
/*    */       try {
/* 84 */         log.debug("firing event rolling back...");
/* 85 */         fireTransactionEvent(TransactionState.ROLLINGBACK);
/*    */       }
/*    */       catch (Throwable exception) {
/* 88 */         log.info("Exception during transaction: {}", exception.getMessage());
/* 89 */         this.commandContext.exception(exception);
/*    */       } finally {
/* 91 */         log.debug("rolling back ibatis sql session...");
/* 92 */         getDbSqlSession().rollback();
/*    */       }
/*    */     }
/*    */     catch (Throwable exception) {
/* 96 */       log.info("Exception during transaction: {}", exception.getMessage());
/* 97 */       this.commandContext.exception(exception);
/*    */     }
/*    */     finally {
/* 100 */       log.debug("firing event rolled back...");
/* 101 */       fireTransactionEvent(TransactionState.ROLLED_BACK);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cfg.standalone.StandaloneMybatisTransactionContext
 * JD-Core Version:    0.6.0
 */