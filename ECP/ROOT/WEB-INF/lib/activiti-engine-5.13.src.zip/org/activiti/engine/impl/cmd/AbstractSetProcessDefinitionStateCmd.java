/*     */ package org.activiti.engine.impl.cmd;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import org.activiti.engine.ActivitiException;
/*     */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*     */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*     */ import org.activiti.engine.impl.ProcessDefinitionQueryImpl;
/*     */ import org.activiti.engine.impl.ProcessInstanceQueryImpl;
/*     */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*     */ import org.activiti.engine.impl.context.Context;
/*     */ import org.activiti.engine.impl.interceptor.Command;
/*     */ import org.activiti.engine.impl.interceptor.CommandContext;
/*     */ import org.activiti.engine.impl.jobexecutor.TimerChangeProcessDefinitionSuspensionStateJobHandler;
/*     */ import org.activiti.engine.impl.persistence.deploy.DeploymentCache;
/*     */ import org.activiti.engine.impl.persistence.deploy.DeploymentManager;
/*     */ import org.activiti.engine.impl.persistence.entity.JobEntityManager;
/*     */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*     */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntityManager;
/*     */ import org.activiti.engine.impl.persistence.entity.SuspensionState;
/*     */ import org.activiti.engine.impl.persistence.entity.SuspensionState.SuspensionStateUtil;
/*     */ import org.activiti.engine.impl.persistence.entity.TimerEntity;
/*     */ import org.activiti.engine.repository.ProcessDefinition;
/*     */ import org.activiti.engine.runtime.ProcessInstance;
/*     */ import org.activiti.engine.runtime.ProcessInstanceQuery;
/*     */ 
/*     */ public abstract class AbstractSetProcessDefinitionStateCmd
/*     */   implements Command<Void>
/*     */ {
/*     */   protected String processDefinitionId;
/*     */   protected String processDefinitionKey;
/*     */   protected ProcessDefinitionEntity processDefinitionEntity;
/*  47 */   protected boolean includeProcessInstances = false;
/*     */   protected Date executionDate;
/*     */ 
/*     */   public AbstractSetProcessDefinitionStateCmd(ProcessDefinitionEntity processDefinitionEntity, boolean includeProcessInstances, Date executionDate)
/*     */   {
/*  52 */     this.processDefinitionEntity = processDefinitionEntity;
/*  53 */     this.includeProcessInstances = includeProcessInstances;
/*  54 */     this.executionDate = executionDate;
/*     */   }
/*     */ 
/*     */   public AbstractSetProcessDefinitionStateCmd(String processDefinitionId, String processDefinitionKey, boolean includeProcessInstances, Date executionDate)
/*     */   {
/*  59 */     this.processDefinitionId = processDefinitionId;
/*  60 */     this.processDefinitionKey = processDefinitionKey;
/*  61 */     this.includeProcessInstances = includeProcessInstances;
/*  62 */     this.executionDate = executionDate;
/*     */   }
/*     */ 
/*     */   public Void execute(CommandContext commandContext)
/*     */   {
/*  67 */     List processDefinitions = findProcessDefinition(commandContext);
/*     */ 
/*  69 */     if (this.executionDate != null)
/*  70 */       createTimerForDelayedExecution(commandContext, processDefinitions);
/*     */     else {
/*  72 */       changeProcessDefinitionState(commandContext, processDefinitions);
/*     */     }
/*     */ 
/*  75 */     return null;
/*     */   }
/*     */ 
/*     */   protected List<ProcessDefinitionEntity> findProcessDefinition(CommandContext commandContext)
/*     */   {
/*  82 */     if (this.processDefinitionEntity != null) {
/*  83 */       return Arrays.asList(new ProcessDefinitionEntity[] { this.processDefinitionEntity });
/*     */     }
/*     */ 
/*  87 */     if ((this.processDefinitionId == null) && (this.processDefinitionKey == null)) {
/*  88 */       throw new ActivitiIllegalArgumentException("Process definition id or key cannot be null");
/*     */     }
/*     */ 
/*  91 */     List processDefinitionEntities = new ArrayList();
/*  92 */     ProcessDefinitionEntityManager processDefinitionManager = commandContext.getProcessDefinitionEntityManager();
/*     */ 
/*  94 */     if (this.processDefinitionId != null)
/*     */     {
/*  96 */       ProcessDefinitionEntity processDefinitionEntity = processDefinitionManager.findProcessDefinitionById(this.processDefinitionId);
/*  97 */       if (processDefinitionEntity == null) {
/*  98 */         throw new ActivitiObjectNotFoundException("Cannot find process definition for id '" + this.processDefinitionId + "'", ProcessDefinition.class);
/*     */       }
/* 100 */       processDefinitionEntities.add(processDefinitionEntity);
/*     */     }
/*     */     else
/*     */     {
/* 104 */       List processDefinitions = new ProcessDefinitionQueryImpl(commandContext).processDefinitionKey(this.processDefinitionKey).list();
/*     */ 
/* 108 */       if (processDefinitions.size() == 0) {
/* 109 */         throw new ActivitiException("Cannot find process definition for key '" + this.processDefinitionKey + "'");
/*     */       }
/*     */ 
/* 112 */       for (ProcessDefinition processDefinition : processDefinitions) {
/* 113 */         processDefinitionEntities.add((ProcessDefinitionEntity)processDefinition);
/*     */       }
/*     */     }
/*     */ 
/* 117 */     return processDefinitionEntities;
/*     */   }
/*     */ 
/*     */   protected void createTimerForDelayedExecution(CommandContext commandContext, List<ProcessDefinitionEntity> processDefinitions) {
/* 121 */     for (ProcessDefinitionEntity processDefinition : processDefinitions) {
/* 122 */       TimerEntity timer = new TimerEntity();
/* 123 */       timer.setProcessDefinitionId(processDefinition.getId());
/* 124 */       timer.setDuedate(this.executionDate);
/* 125 */       timer.setJobHandlerType(getDelayedExecutionJobHandlerType());
/* 126 */       timer.setJobHandlerConfiguration(TimerChangeProcessDefinitionSuspensionStateJobHandler.createJobHandlerConfiguration(this.includeProcessInstances));
/*     */ 
/* 128 */       commandContext.getJobEntityManager().schedule(timer);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void changeProcessDefinitionState(CommandContext commandContext, List<ProcessDefinitionEntity> processDefinitions) {
/* 133 */     for (ProcessDefinitionEntity processDefinition : processDefinitions)
/*     */     {
/* 135 */       SuspensionState.SuspensionStateUtil.setSuspensionState(processDefinition, getProcessDefinitionSuspensionState());
/*     */ 
/* 138 */       Context.getProcessEngineConfiguration().getDeploymentManager().getProcessDefinitionCache().remove(processDefinition.getId());
/*     */ 
/* 145 */       if (this.includeProcessInstances)
/*     */       {
/* 147 */         int currentStartIndex = 0;
/* 148 */         List processInstances = fetchProcessInstancesPage(commandContext, processDefinition, currentStartIndex);
/* 149 */         while (processInstances.size() > 0)
/*     */         {
/* 151 */           for (ProcessInstance processInstance : processInstances) {
/* 152 */             AbstractSetProcessInstanceStateCmd processInstanceCmd = getProcessInstanceChangeStateCmd(processInstance);
/* 153 */             processInstanceCmd.execute(commandContext);
/*     */           }
/*     */ 
/* 157 */           currentStartIndex += processInstances.size();
/* 158 */           processInstances = fetchProcessInstancesPage(commandContext, processDefinition, currentStartIndex);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected List<ProcessInstance> fetchProcessInstancesPage(CommandContext commandContext, ProcessDefinition processDefinition, int currentPageStartIndex)
/*     */   {
/* 168 */     if (SuspensionState.ACTIVE.equals(getProcessDefinitionSuspensionState())) {
/* 169 */       return new ProcessInstanceQueryImpl(commandContext).processDefinitionId(processDefinition.getId()).suspended().listPage(currentPageStartIndex, Context.getProcessEngineConfiguration().getBatchSizeProcessInstances());
/*     */     }
/*     */ 
/* 174 */     return new ProcessInstanceQueryImpl(commandContext).processDefinitionId(processDefinition.getId()).active().listPage(currentPageStartIndex, Context.getProcessEngineConfiguration().getBatchSizeProcessInstances());
/*     */   }
/*     */ 
/*     */   protected abstract SuspensionState getProcessDefinitionSuspensionState();
/*     */ 
/*     */   protected abstract String getDelayedExecutionJobHandlerType();
/*     */ 
/*     */   protected abstract AbstractSetProcessInstanceStateCmd getProcessInstanceChangeStateCmd(ProcessInstance paramProcessInstance);
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.AbstractSetProcessDefinitionStateCmd
 * JD-Core Version:    0.6.0
 */