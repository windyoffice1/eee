/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntityManager;
/*    */ import org.activiti.engine.impl.persistence.entity.SuspensionState;
/*    */ import org.activiti.engine.impl.persistence.entity.SuspensionState.SuspensionStateUtil;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntityManager;
/*    */ import org.activiti.engine.runtime.Execution;
/*    */ 
/*    */ public abstract class AbstractSetProcessInstanceStateCmd
/*    */   implements Command<Void>
/*    */ {
/*    */   protected final String executionId;
/*    */ 
/*    */   public AbstractSetProcessInstanceStateCmd(String executionId)
/*    */   {
/* 38 */     this.executionId = executionId;
/*    */   }
/*    */ 
/*    */   public Void execute(CommandContext commandContext)
/*    */   {
/* 43 */     if (this.executionId == null) {
/* 44 */       throw new ActivitiIllegalArgumentException("ProcessInstanceId cannot be null.");
/*    */     }
/*    */ 
/* 47 */     ExecutionEntity executionEntity = commandContext.getExecutionEntityManager().findExecutionById(this.executionId);
/*    */ 
/* 50 */     if (executionEntity == null) {
/* 51 */       throw new ActivitiObjectNotFoundException("Cannot find processInstance for id '" + this.executionId + "'.", Execution.class);
/*    */     }
/* 53 */     if (!executionEntity.isProcessInstanceType()) {
/* 54 */       throw new ActivitiException("Cannot set suspension state for execution '" + this.executionId + "': not a process instance.");
/*    */     }
/*    */ 
/* 57 */     SuspensionState.SuspensionStateUtil.setSuspensionState(executionEntity, getNewState());
/*    */ 
/* 60 */     List childExecutions = commandContext.getExecutionEntityManager().findChildExecutionsByProcessInstanceId(this.executionId);
/* 61 */     for (ExecutionEntity childExecution : childExecutions) {
/* 62 */       if (!childExecution.getId().equals(this.executionId)) {
/* 63 */         SuspensionState.SuspensionStateUtil.setSuspensionState(childExecution, getNewState());
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 68 */     List tasks = commandContext.getTaskEntityManager().findTasksByProcessInstanceId(this.executionId);
/* 69 */     for (TaskEntity taskEntity : tasks) {
/* 70 */       SuspensionState.SuspensionStateUtil.setSuspensionState(taskEntity, getNewState());
/*    */     }
/*    */ 
/* 73 */     return null;
/*    */   }
/*    */ 
/*    */   protected abstract SuspensionState getNewState();
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.AbstractSetProcessInstanceStateCmd
 * JD-Core Version:    0.6.0
 */