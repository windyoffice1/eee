/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.GregorianCalendar;
/*    */ import java.util.List;
/*    */ import org.activiti.engine.impl.Page;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.jobexecutor.AcquiredJobs;
/*    */ import org.activiti.engine.impl.jobexecutor.JobExecutor;
/*    */ import org.activiti.engine.impl.persistence.entity.JobEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.JobEntityManager;
/*    */ import org.activiti.engine.impl.util.ClockUtil;
/*    */ 
/*    */ public class AcquireJobsCmd
/*    */   implements Command<AcquiredJobs>
/*    */ {
/*    */   private final JobExecutor jobExecutor;
/*    */ 
/*    */   public AcquireJobsCmd(JobExecutor jobExecutor)
/*    */   {
/* 38 */     this.jobExecutor = jobExecutor;
/*    */   }
/*    */ 
/*    */   public AcquiredJobs execute(CommandContext commandContext)
/*    */   {
/* 43 */     String lockOwner = this.jobExecutor.getLockOwner();
/* 44 */     int lockTimeInMillis = this.jobExecutor.getLockTimeInMillis();
/* 45 */     int maxNonExclusiveJobsPerAcquisition = this.jobExecutor.getMaxJobsPerAcquisition();
/*    */ 
/* 47 */     AcquiredJobs acquiredJobs = new AcquiredJobs();
/* 48 */     List jobs = commandContext.getJobEntityManager().findNextJobsToExecute(new Page(0, maxNonExclusiveJobsPerAcquisition));
/*    */ 
/* 52 */     for (JobEntity job : jobs) {
/* 53 */       List jobIds = new ArrayList();
/* 54 */       if ((job != null) && (!acquiredJobs.contains(job.getId()))) {
/* 55 */         if ((job.isExclusive()) && (job.getProcessInstanceId() != null))
/*    */         {
/* 58 */           List exclusiveJobs = commandContext.getJobEntityManager().findExclusiveJobsToExecute(job.getProcessInstanceId());
/*    */ 
/* 60 */           for (JobEntity exclusiveJob : exclusiveJobs)
/* 61 */             if (exclusiveJob != null) {
/* 62 */               lockJob(exclusiveJob, lockOwner, lockTimeInMillis);
/* 63 */               jobIds.add(exclusiveJob.getId());
/*    */             }
/*    */         }
/*    */         else {
/* 67 */           lockJob(job, lockOwner, lockTimeInMillis);
/* 68 */           jobIds.add(job.getId());
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/* 73 */       acquiredJobs.addJobIdBatch(jobIds);
/*    */     }
/*    */ 
/* 76 */     return acquiredJobs;
/*    */   }
/*    */ 
/*    */   protected void lockJob(JobEntity job, String lockOwner, int lockTimeInMillis) {
/* 80 */     job.setLockOwner(lockOwner);
/* 81 */     GregorianCalendar gregorianCalendar = new GregorianCalendar();
/* 82 */     gregorianCalendar.setTime(ClockUtil.getCurrentTime());
/* 83 */     gregorianCalendar.add(14, lockTimeInMillis);
/* 84 */     job.setLockExpirationTime(gregorianCalendar.getTime());
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.AcquireJobsCmd
 * JD-Core Version:    0.6.0
 */