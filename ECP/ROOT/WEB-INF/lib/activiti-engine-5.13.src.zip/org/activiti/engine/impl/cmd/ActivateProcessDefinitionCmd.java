/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.util.Date;
/*    */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.SuspensionState;
/*    */ import org.activiti.engine.runtime.ProcessInstance;
/*    */ 
/*    */ public class ActivateProcessDefinitionCmd extends AbstractSetProcessDefinitionStateCmd
/*    */ {
/*    */   public ActivateProcessDefinitionCmd(ProcessDefinitionEntity processDefinitionEntity, boolean includeProcessInstances, Date executionDate)
/*    */   {
/* 30 */     super(processDefinitionEntity, includeProcessInstances, executionDate);
/*    */   }
/*    */ 
/*    */   public ActivateProcessDefinitionCmd(String processDefinitionId, String processDefinitionKey, boolean includeProcessInstances, Date executionDate)
/*    */   {
/* 35 */     super(processDefinitionId, processDefinitionKey, includeProcessInstances, executionDate);
/*    */   }
/*    */ 
/*    */   protected SuspensionState getProcessDefinitionSuspensionState() {
/* 39 */     return SuspensionState.ACTIVE;
/*    */   }
/*    */ 
/*    */   protected String getDelayedExecutionJobHandlerType() {
/* 43 */     return "activate-processdefinition";
/*    */   }
/*    */ 
/*    */   protected AbstractSetProcessInstanceStateCmd getProcessInstanceChangeStateCmd(ProcessInstance processInstance) {
/* 47 */     return new ActivateProcessInstanceCmd(processInstance.getId());
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.ActivateProcessDefinitionCmd
 * JD-Core Version:    0.6.0
 */