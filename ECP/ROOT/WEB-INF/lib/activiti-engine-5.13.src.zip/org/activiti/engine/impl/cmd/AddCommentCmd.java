/*     */ package org.activiti.engine.impl.cmd;
/*     */ 
/*     */ import org.activiti.engine.ActivitiException;
/*     */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*     */ import org.activiti.engine.impl.context.Context;
/*     */ import org.activiti.engine.impl.identity.Authentication;
/*     */ import org.activiti.engine.impl.interceptor.Command;
/*     */ import org.activiti.engine.impl.interceptor.CommandContext;
/*     */ import org.activiti.engine.impl.persistence.entity.CommentEntity;
/*     */ import org.activiti.engine.impl.persistence.entity.CommentEntityManager;
/*     */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*     */ import org.activiti.engine.impl.persistence.entity.ExecutionEntityManager;
/*     */ import org.activiti.engine.impl.persistence.entity.TaskEntity;
/*     */ import org.activiti.engine.impl.persistence.entity.TaskEntityManager;
/*     */ import org.activiti.engine.impl.util.ClockUtil;
/*     */ import org.activiti.engine.runtime.Execution;
/*     */ import org.activiti.engine.task.Comment;
/*     */ import org.activiti.engine.task.Task;
/*     */ 
/*     */ public class AddCommentCmd
/*     */   implements Command<Comment>
/*     */ {
/*     */   protected String taskId;
/*     */   protected String processInstanceId;
/*     */   protected String message;
/*     */ 
/*     */   public AddCommentCmd(String taskId, String processInstanceId, String message)
/*     */   {
/*  42 */     this.taskId = taskId;
/*  43 */     this.processInstanceId = processInstanceId;
/*  44 */     this.message = message;
/*     */   }
/*     */ 
/*     */   public Comment execute(CommandContext commandContext)
/*     */   {
/*  50 */     if (this.taskId != null) {
/*  51 */       TaskEntity task = Context.getCommandContext().getTaskEntityManager().findTaskById(this.taskId);
/*     */ 
/*  53 */       if (task == null) {
/*  54 */         throw new ActivitiObjectNotFoundException("Cannot find task with id " + this.taskId, Task.class);
/*     */       }
/*     */ 
/*  57 */       if (task.isSuspended()) {
/*  58 */         throw new ActivitiException(getSuspendedTaskException());
/*     */       }
/*     */     }
/*     */ 
/*  62 */     if (this.processInstanceId != null) {
/*  63 */       ExecutionEntity execution = commandContext.getExecutionEntityManager().findExecutionById(this.processInstanceId);
/*     */ 
/*  65 */       if (execution == null) {
/*  66 */         throw new ActivitiObjectNotFoundException("execution " + this.processInstanceId + " doesn't exist", Execution.class);
/*     */       }
/*     */ 
/*  69 */       if (execution.isSuspended()) {
/*  70 */         throw new ActivitiException(getSuspendedExceptionMessage());
/*     */       }
/*     */     }
/*     */ 
/*  74 */     String userId = Authentication.getAuthenticatedUserId();
/*  75 */     CommentEntity comment = new CommentEntity();
/*  76 */     comment.setUserId(userId);
/*  77 */     comment.setType("comment");
/*  78 */     comment.setTime(ClockUtil.getCurrentTime());
/*  79 */     comment.setTaskId(this.taskId);
/*  80 */     comment.setProcessInstanceId(this.processInstanceId);
/*  81 */     comment.setAction("AddComment");
/*     */ 
/*  83 */     String eventMessage = this.message.replaceAll("\\s+", " ");
/*  84 */     if (eventMessage.length() > 163) {
/*  85 */       eventMessage = eventMessage.substring(0, 160) + "...";
/*     */     }
/*  87 */     comment.setMessage(eventMessage);
/*     */ 
/*  89 */     comment.setFullMessage(this.message);
/*     */ 
/*  91 */     commandContext.getCommentEntityManager().insert(comment);
/*     */ 
/*  95 */     return comment;
/*     */   }
/*     */ 
/*     */   protected String getSuspendedTaskException() {
/*  99 */     return "Cannot add a comment to a suspended task";
/*     */   }
/*     */ 
/*     */   protected String getSuspendedExceptionMessage() {
/* 103 */     return "Cannot add a comment to a suspended execution";
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.AddCommentCmd
 * JD-Core Version:    0.6.0
 */