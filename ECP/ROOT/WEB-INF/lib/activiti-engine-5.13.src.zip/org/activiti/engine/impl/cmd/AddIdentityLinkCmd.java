/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.impl.history.HistoryManager;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntity;
/*    */ 
/*    */ public class AddIdentityLinkCmd extends NeedsActiveTaskCmd<Void>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String userId;
/*    */   protected String groupId;
/*    */   protected String type;
/*    */ 
/*    */   public AddIdentityLinkCmd(String taskId, String userId, String groupId, String type)
/*    */   {
/* 35 */     super(taskId);
/* 36 */     validateParams(userId, groupId, type, taskId);
/* 37 */     this.taskId = taskId;
/* 38 */     this.userId = userId;
/* 39 */     this.groupId = groupId;
/* 40 */     this.type = type;
/*    */   }
/*    */ 
/*    */   protected void validateParams(String userId, String groupId, String type, String taskId) {
/* 44 */     if (taskId == null) {
/* 45 */       throw new ActivitiIllegalArgumentException("taskId is null");
/*    */     }
/*    */ 
/* 48 */     if (type == null) {
/* 49 */       throw new ActivitiIllegalArgumentException("type is required when adding a new task identity link");
/*    */     }
/*    */ 
/* 53 */     if ("assignee".equals(type)) {
/* 54 */       if (groupId != null) {
/* 55 */         throw new ActivitiIllegalArgumentException("Incompatible usage: cannot use ASSIGNEE together with a groupId");
/*    */       }
/*    */ 
/*    */     }
/* 59 */     else if ((userId == null) && (groupId == null))
/* 60 */       throw new ActivitiIllegalArgumentException("userId and groupId cannot both be null");
/*    */   }
/*    */ 
/*    */   protected Void execute(CommandContext commandContext, TaskEntity task)
/*    */   {
/* 67 */     boolean assignedToNoOne = false;
/* 68 */     if ("assignee".equals(this.type)) {
/* 69 */       task.setAssignee(this.userId);
/* 70 */       assignedToNoOne = this.userId == null;
/* 71 */     } else if ("owner".equals(this.type)) {
/* 72 */       task.setOwner(this.userId);
/*    */     } else {
/* 74 */       task.addIdentityLink(this.userId, this.groupId, this.type);
/*    */     }
/*    */ 
/* 77 */     if (assignedToNoOne)
/*    */     {
/* 79 */       commandContext.getHistoryManager().createIdentityLinkComment(this.taskId, this.userId, this.groupId, this.type, false, true);
/*    */     }
/* 81 */     else commandContext.getHistoryManager().createIdentityLinkComment(this.taskId, this.userId, this.groupId, this.type, true);
/*    */ 
/* 84 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.AddIdentityLinkCmd
 * JD-Core Version:    0.6.0
 */