/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntityManager;
/*    */ import org.activiti.engine.repository.ProcessDefinition;
/*    */ 
/*    */ public class AddIdentityLinkForProcessDefinitionCmd
/*    */   implements Command<Void>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String processDefinitionId;
/*    */   protected String userId;
/*    */   protected String groupId;
/*    */ 
/*    */   public AddIdentityLinkForProcessDefinitionCmd(String processDefinitionId, String userId, String groupId)
/*    */   {
/* 40 */     validateParams(userId, groupId, processDefinitionId);
/* 41 */     this.processDefinitionId = processDefinitionId;
/* 42 */     this.userId = userId;
/* 43 */     this.groupId = groupId;
/*    */   }
/*    */ 
/*    */   protected void validateParams(String userId, String groupId, String processDefinitionId) {
/* 47 */     if (processDefinitionId == null) {
/* 48 */       throw new ActivitiIllegalArgumentException("processDefinitionId is null");
/*    */     }
/*    */ 
/* 51 */     if ((userId == null) && (groupId == null))
/* 52 */       throw new ActivitiIllegalArgumentException("userId and groupId cannot both be null");
/*    */   }
/*    */ 
/*    */   public Void execute(CommandContext commandContext)
/*    */   {
/* 57 */     ProcessDefinitionEntity processDefinition = Context.getCommandContext().getProcessDefinitionEntityManager().findProcessDefinitionById(this.processDefinitionId);
/*    */ 
/* 62 */     if (processDefinition == null) {
/* 63 */       throw new ActivitiObjectNotFoundException("Cannot find process definition with id " + this.processDefinitionId, ProcessDefinition.class);
/*    */     }
/*    */ 
/* 66 */     processDefinition.addIdentityLink(this.userId, this.groupId);
/*    */ 
/* 68 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.AddIdentityLinkForProcessDefinitionCmd
 * JD-Core Version:    0.6.0
 */