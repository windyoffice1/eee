/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntityManager;
/*    */ 
/*    */ public class AddIdentityLinkForProcessInstanceCmd
/*    */   implements Command<Void>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String processInstanceId;
/*    */   protected String userId;
/*    */   protected String type;
/*    */ 
/*    */   public AddIdentityLinkForProcessInstanceCmd(String processInstanceId, String userId, String type)
/*    */   {
/* 39 */     validateParams(processInstanceId, userId);
/* 40 */     this.processInstanceId = processInstanceId;
/* 41 */     this.userId = userId;
/* 42 */     this.type = type;
/*    */   }
/*    */ 
/*    */   protected void validateParams(String processInstanceId, String userId) {
/* 46 */     if (processInstanceId == null) {
/* 47 */       throw new ActivitiIllegalArgumentException("processInstanceId is null");
/*    */     }
/*    */ 
/* 50 */     if (userId == null)
/* 51 */       throw new ActivitiIllegalArgumentException("userId cannot be null");
/*    */   }
/*    */ 
/*    */   public Void execute(CommandContext commandContext)
/*    */   {
/* 56 */     ExecutionEntity processInstance = Context.getCommandContext().getExecutionEntityManager().findExecutionById(this.processInstanceId);
/*    */ 
/* 61 */     if (processInstance == null) {
/* 62 */       throw new ActivitiObjectNotFoundException("Cannot find process instance with id " + this.processInstanceId, ExecutionEntity.class);
/*    */     }
/*    */ 
/* 65 */     processInstance.addIdentityLink(this.userId, this.type);
/*    */ 
/* 67 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.AddIdentityLinkForProcessInstanceCmd
 * JD-Core Version:    0.6.0
 */