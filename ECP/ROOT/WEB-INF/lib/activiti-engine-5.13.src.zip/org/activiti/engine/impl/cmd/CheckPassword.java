/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.UserIdentityManager;
/*    */ 
/*    */ public class CheckPassword
/*    */   implements Command<Boolean>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   String userId;
/*    */   String password;
/*    */ 
/*    */   public CheckPassword(String userId, String password)
/*    */   {
/* 32 */     this.userId = userId;
/* 33 */     this.password = password;
/*    */   }
/*    */ 
/*    */   public Boolean execute(CommandContext commandContext) {
/* 37 */     return commandContext.getUserIdentityManager().checkPassword(this.userId, this.password);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.CheckPassword
 * JD-Core Version:    0.6.0
 */