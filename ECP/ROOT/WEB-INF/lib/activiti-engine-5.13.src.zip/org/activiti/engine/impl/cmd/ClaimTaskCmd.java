/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import org.activiti.engine.ActivitiTaskAlreadyClaimedException;
/*    */ import org.activiti.engine.impl.history.HistoryManager;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntity;
/*    */ 
/*    */ public class ClaimTaskCmd extends NeedsActiveTaskCmd<Void>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String userId;
/*    */ 
/*    */   public ClaimTaskCmd(String taskId, String userId)
/*    */   {
/* 30 */     super(taskId);
/* 31 */     this.userId = userId;
/*    */   }
/*    */ 
/*    */   protected Void execute(CommandContext commandContext, TaskEntity task)
/*    */   {
/* 36 */     if (this.userId != null) {
/* 37 */       if (task.getAssignee() != null) {
/* 38 */         if (!task.getAssignee().equals(this.userId))
/*    */         {
/* 41 */           throw new ActivitiTaskAlreadyClaimedException(task.getId(), task.getAssignee());
/*    */         }
/*    */       }
/* 44 */       else task.setAssignee(this.userId);
/*    */     }
/*    */     else
/*    */     {
/* 48 */       task.setAssignee(null);
/*    */     }
/*    */ 
/* 52 */     commandContext.getHistoryManager().recordTaskClaim(this.taskId);
/*    */ 
/* 54 */     return null;
/*    */   }
/*    */ 
/*    */   protected String getSuspendedTaskException()
/*    */   {
/* 59 */     return "Cannot claim a suspended task";
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.ClaimTaskCmd
 * JD-Core Version:    0.6.0
 */