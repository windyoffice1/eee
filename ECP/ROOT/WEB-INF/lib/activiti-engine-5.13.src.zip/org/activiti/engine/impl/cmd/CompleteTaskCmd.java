/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntity;
/*    */ 
/*    */ public class CompleteTaskCmd extends NeedsActiveTaskCmd<Void>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected Map<String, Object> variables;
/*    */ 
/*    */   public CompleteTaskCmd(String taskId, Map<String, Object> variables)
/*    */   {
/* 30 */     super(taskId);
/* 31 */     this.variables = variables;
/*    */   }
/*    */ 
/*    */   protected Void execute(CommandContext commandContext, TaskEntity task) {
/* 35 */     if (this.variables != null) {
/* 36 */       task.setExecutionVariables(this.variables);
/*    */     }
/*    */ 
/* 39 */     task.complete();
/* 40 */     return null;
/*    */   }
/*    */ 
/*    */   protected String getSuspendedTaskException()
/*    */   {
/* 45 */     return "Cannot complete a suspended task";
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.CompleteTaskCmd
 * JD-Core Version:    0.6.0
 */