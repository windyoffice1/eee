/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.db.DbSqlSession;
/*    */ import org.activiti.engine.impl.history.HistoryManager;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.AttachmentEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ByteArrayEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntityManager;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntityManager;
/*    */ import org.activiti.engine.impl.util.IoUtil;
/*    */ import org.activiti.engine.runtime.ProcessInstance;
/*    */ import org.activiti.engine.task.Attachment;
/*    */ import org.activiti.engine.task.Task;
/*    */ 
/*    */ public class CreateAttachmentCmd
/*    */   implements Command<Attachment>
/*    */ {
/*    */   protected String attachmentType;
/*    */   protected String taskId;
/*    */   protected String processInstanceId;
/*    */   protected String attachmentName;
/*    */   protected String attachmentDescription;
/*    */   protected InputStream content;
/*    */   protected String url;
/*    */ 
/*    */   public CreateAttachmentCmd(String attachmentType, String taskId, String processInstanceId, String attachmentName, String attachmentDescription, InputStream content, String url)
/*    */   {
/* 50 */     this.attachmentType = attachmentType;
/* 51 */     this.taskId = taskId;
/* 52 */     this.processInstanceId = processInstanceId;
/* 53 */     this.attachmentName = attachmentName;
/* 54 */     this.attachmentDescription = attachmentDescription;
/* 55 */     this.content = content;
/* 56 */     this.url = url;
/*    */   }
/*    */ 
/*    */   public Attachment execute(CommandContext commandContext)
/*    */   {
/* 61 */     verifyParameters(commandContext);
/*    */ 
/* 63 */     AttachmentEntity attachment = new AttachmentEntity();
/* 64 */     attachment.setName(this.attachmentName);
/* 65 */     attachment.setDescription(this.attachmentDescription);
/* 66 */     attachment.setType(this.attachmentType);
/* 67 */     attachment.setTaskId(this.taskId);
/* 68 */     attachment.setProcessInstanceId(this.processInstanceId);
/* 69 */     attachment.setUrl(this.url);
/*    */ 
/* 71 */     DbSqlSession dbSqlSession = commandContext.getDbSqlSession();
/* 72 */     dbSqlSession.insert(attachment);
/*    */ 
/* 74 */     if (this.content != null) {
/* 75 */       byte[] bytes = IoUtil.readInputStream(this.content, this.attachmentName);
/* 76 */       ByteArrayEntity byteArray = ByteArrayEntity.createAndInsert(bytes);
/* 77 */       attachment.setContentId(byteArray.getId());
/*    */     }
/*    */ 
/* 80 */     commandContext.getHistoryManager().createAttachmentComment(this.taskId, this.processInstanceId, this.attachmentName, true);
/*    */ 
/* 83 */     return attachment;
/*    */   }
/*    */ 
/*    */   private void verifyParameters(CommandContext commandContext) {
/* 87 */     if (this.taskId != null) {
/* 88 */       TaskEntity task = Context.getCommandContext().getTaskEntityManager().findTaskById(this.taskId);
/*    */ 
/* 90 */       if (task == null) {
/* 91 */         throw new ActivitiObjectNotFoundException("Cannot find task with id " + this.taskId, Task.class);
/*    */       }
/*    */ 
/* 94 */       if (task.isSuspended()) {
/* 95 */         throw new ActivitiException("It is not allowed to add an attachment to a suspended task");
/*    */       }
/*    */     }
/*    */ 
/* 99 */     if (this.processInstanceId != null) {
/* 100 */       ExecutionEntity execution = commandContext.getExecutionEntityManager().findExecutionById(this.processInstanceId);
/*    */ 
/* 102 */       if (execution == null) {
/* 103 */         throw new ActivitiObjectNotFoundException("Process instance " + this.processInstanceId + " doesn't exist", ProcessInstance.class);
/*    */       }
/*    */ 
/* 106 */       if (execution.isSuspended())
/* 107 */         throw new ActivitiException("It is not allowed to add an attachment to a suspended process instance");
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.CreateAttachmentCmd
 * JD-Core Version:    0.6.0
 */