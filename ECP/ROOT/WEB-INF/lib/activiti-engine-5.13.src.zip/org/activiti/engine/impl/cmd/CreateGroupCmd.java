/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.identity.Group;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.GroupIdentityManager;
/*    */ 
/*    */ public class CreateGroupCmd
/*    */   implements Command<Group>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String groupId;
/*    */ 
/*    */   public CreateGroupCmd(String groupId)
/*    */   {
/* 34 */     if (groupId == null) {
/* 35 */       throw new ActivitiIllegalArgumentException("groupId is null");
/*    */     }
/* 37 */     this.groupId = groupId;
/*    */   }
/*    */ 
/*    */   public Group execute(CommandContext commandContext) {
/* 41 */     return commandContext.getGroupIdentityManager().createNewGroup(this.groupId);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.CreateGroupCmd
 * JD-Core Version:    0.6.0
 */