/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.identity.User;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.UserIdentityManager;
/*    */ 
/*    */ public class CreateUserCmd
/*    */   implements Command<User>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String userId;
/*    */ 
/*    */   public CreateUserCmd(String userId)
/*    */   {
/* 34 */     if (userId == null) {
/* 35 */       throw new ActivitiIllegalArgumentException("userId is null");
/*    */     }
/* 37 */     this.userId = userId;
/*    */   }
/*    */ 
/*    */   public User execute(CommandContext commandContext) {
/* 41 */     return commandContext.getUserIdentityManager().createNewUser(this.userId);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.CreateUserCmd
 * JD-Core Version:    0.6.0
 */