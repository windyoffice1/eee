/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.identity.UserQuery;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.UserIdentityManager;
/*    */ 
/*    */ public class CreateUserQueryCmd
/*    */   implements Command<UserQuery>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public UserQuery execute(CommandContext commandContext)
/*    */   {
/* 31 */     return commandContext.getUserIdentityManager().createNewUserQuery();
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.CreateUserQueryCmd
 * JD-Core Version:    0.6.0
 */