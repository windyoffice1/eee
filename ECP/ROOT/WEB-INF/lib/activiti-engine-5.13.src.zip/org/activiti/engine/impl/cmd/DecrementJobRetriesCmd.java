/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ import java.io.StringWriter;
/*    */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*    */ import org.activiti.engine.impl.cfg.TransactionContext;
/*    */ import org.activiti.engine.impl.cfg.TransactionState;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.jobexecutor.JobExecutor;
/*    */ import org.activiti.engine.impl.jobexecutor.MessageAddedNotification;
/*    */ import org.activiti.engine.impl.persistence.entity.JobEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.JobEntityManager;
/*    */ 
/*    */ public class DecrementJobRetriesCmd
/*    */   implements Command<Object>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String jobId;
/*    */   protected Throwable exception;
/*    */ 
/*    */   public DecrementJobRetriesCmd(String jobId, Throwable exception)
/*    */   {
/* 38 */     this.jobId = jobId;
/* 39 */     this.exception = exception;
/*    */   }
/*    */ 
/*    */   public Object execute(CommandContext commandContext) {
/* 43 */     JobEntity job = Context.getCommandContext().getJobEntityManager().findJobById(this.jobId);
/*    */ 
/* 47 */     job.setRetries(job.getRetries() - 1);
/* 48 */     job.setLockOwner(null);
/* 49 */     job.setLockExpirationTime(null);
/*    */ 
/* 51 */     if (this.exception != null) {
/* 52 */       job.setExceptionMessage(this.exception.getMessage());
/* 53 */       job.setExceptionStacktrace(getExceptionStacktrace());
/*    */     }
/*    */ 
/* 56 */     JobExecutor jobExecutor = Context.getProcessEngineConfiguration().getJobExecutor();
/* 57 */     MessageAddedNotification messageAddedNotification = new MessageAddedNotification(jobExecutor);
/* 58 */     TransactionContext transactionContext = commandContext.getTransactionContext();
/* 59 */     transactionContext.addTransactionListener(TransactionState.COMMITTED, messageAddedNotification);
/*    */ 
/* 61 */     return null;
/*    */   }
/*    */ 
/*    */   private String getExceptionStacktrace() {
/* 65 */     StringWriter stringWriter = new StringWriter();
/* 66 */     this.exception.printStackTrace(new PrintWriter(stringWriter));
/* 67 */     return stringWriter.toString();
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.DecrementJobRetriesCmd
 * JD-Core Version:    0.6.0
 */