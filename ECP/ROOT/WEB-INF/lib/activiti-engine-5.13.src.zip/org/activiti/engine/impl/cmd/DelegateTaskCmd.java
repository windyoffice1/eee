/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntity;
/*    */ 
/*    */ public class DelegateTaskCmd extends NeedsActiveTaskCmd<Object>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String userId;
/*    */ 
/*    */   public DelegateTaskCmd(String taskId, String userId)
/*    */   {
/* 29 */     super(taskId);
/* 30 */     this.userId = userId;
/*    */   }
/*    */ 
/*    */   protected Object execute(CommandContext commandContext, TaskEntity task) {
/* 34 */     task.delegate(this.userId);
/* 35 */     return null;
/*    */   }
/*    */ 
/*    */   protected String getSuspendedTaskException()
/*    */   {
/* 40 */     return "Cannot delegate a suspended task";
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.DelegateTaskCmd
 * JD-Core Version:    0.6.0
 */