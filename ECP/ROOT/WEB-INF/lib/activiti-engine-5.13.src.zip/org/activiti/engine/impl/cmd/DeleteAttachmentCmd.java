/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.impl.db.DbSqlSession;
/*    */ import org.activiti.engine.impl.history.HistoryManager;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.AttachmentEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ByteArrayEntityManager;
/*    */ 
/*    */ public class DeleteAttachmentCmd
/*    */   implements Command<Object>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String attachmentId;
/*    */ 
/*    */   public DeleteAttachmentCmd(String attachmentId)
/*    */   {
/* 33 */     this.attachmentId = attachmentId;
/*    */   }
/*    */ 
/*    */   public Object execute(CommandContext commandContext) {
/* 37 */     AttachmentEntity attachment = (AttachmentEntity)commandContext.getDbSqlSession().selectById(AttachmentEntity.class, this.attachmentId);
/*    */ 
/* 41 */     commandContext.getDbSqlSession().delete(attachment);
/*    */ 
/* 45 */     if (attachment.getContentId() != null) {
/* 46 */       commandContext.getByteArrayEntityManager().deleteByteArrayById(attachment.getContentId());
/*    */     }
/*    */ 
/* 51 */     if (attachment.getTaskId() != null) {
/* 52 */       commandContext.getHistoryManager().createAttachmentComment(attachment.getTaskId(), attachment.getProcessInstanceId(), attachment.getName(), false);
/*    */     }
/*    */ 
/* 56 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.DeleteAttachmentCmd
 * JD-Core Version:    0.6.0
 */