/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.ArrayList;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.CommentEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.CommentEntityManager;
/*    */ import org.activiti.engine.task.Comment;
/*    */ 
/*    */ public class DeleteCommentCmd
/*    */   implements Command<Void>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String taskId;
/*    */   protected String processInstanceId;
/*    */   protected String commentId;
/*    */ 
/*    */   public DeleteCommentCmd(String taskId, String processInstanceId, String commentId)
/*    */   {
/* 36 */     this.taskId = taskId;
/* 37 */     this.processInstanceId = processInstanceId;
/* 38 */     this.commentId = commentId;
/*    */   }
/*    */ 
/*    */   public Void execute(CommandContext commandContext) {
/* 42 */     CommentEntityManager commentManager = commandContext.getCommentEntityManager();
/*    */ 
/* 44 */     if (this.commentId != null)
/*    */     {
/* 46 */       Comment comment = commentManager.findComment(this.commentId);
/* 47 */       if (comment == null) {
/* 48 */         throw new ActivitiObjectNotFoundException("Comment with id '" + this.commentId + "' doesn't exists.", Comment.class);
/*    */       }
/* 50 */       commentManager.delete((CommentEntity)comment);
/*    */     }
/*    */     else
/*    */     {
/* 54 */       ArrayList comments = new ArrayList();
/* 55 */       if (this.processInstanceId != null) {
/* 56 */         comments.addAll(commentManager.findCommentsByProcessInstanceId(this.processInstanceId));
/*    */       }
/* 58 */       if (this.taskId != null) {
/* 59 */         comments.addAll(commentManager.findCommentsByTaskId(this.taskId));
/*    */       }
/*    */ 
/* 62 */       for (Comment comment : comments) {
/* 63 */         commentManager.delete((CommentEntity)comment);
/*    */       }
/*    */     }
/* 66 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.DeleteCommentCmd
 * JD-Core Version:    0.6.0
 */