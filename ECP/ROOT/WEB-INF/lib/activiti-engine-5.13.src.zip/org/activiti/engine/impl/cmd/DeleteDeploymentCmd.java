/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.deploy.DeploymentManager;
/*    */ 
/*    */ public class DeleteDeploymentCmd
/*    */   implements Command<Void>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String deploymentId;
/*    */   protected boolean cascade;
/*    */ 
/*    */   public DeleteDeploymentCmd(String deploymentId, boolean cascade)
/*    */   {
/* 32 */     this.deploymentId = deploymentId;
/* 33 */     this.cascade = cascade;
/*    */   }
/*    */ 
/*    */   public Void execute(CommandContext commandContext) {
/* 37 */     if (this.deploymentId == null) {
/* 38 */       throw new ActivitiIllegalArgumentException("deploymentId is null");
/*    */     }
/*    */ 
/* 42 */     Context.getProcessEngineConfiguration().getDeploymentManager().removeDeployment(this.deploymentId, this.cascade);
/*    */ 
/* 47 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.DeleteDeploymentCmd
 * JD-Core Version:    0.6.0
 */