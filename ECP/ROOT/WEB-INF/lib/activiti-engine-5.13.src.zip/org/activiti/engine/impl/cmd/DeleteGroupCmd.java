/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.GroupIdentityManager;
/*    */ 
/*    */ public class DeleteGroupCmd
/*    */   implements Command<Void>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   String groupId;
/*    */ 
/*    */   public DeleteGroupCmd(String groupId)
/*    */   {
/* 31 */     this.groupId = groupId;
/*    */   }
/*    */ 
/*    */   public Void execute(CommandContext commandContext) {
/* 35 */     if (this.groupId == null) {
/* 36 */       throw new ActivitiIllegalArgumentException("groupId is null");
/*    */     }
/* 38 */     commandContext.getGroupIdentityManager().deleteGroup(this.groupId);
/*    */ 
/* 42 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.DeleteGroupCmd
 * JD-Core Version:    0.6.0
 */