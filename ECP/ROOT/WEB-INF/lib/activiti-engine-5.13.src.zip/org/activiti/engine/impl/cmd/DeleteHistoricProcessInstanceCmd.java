/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.history.HistoricProcessInstance;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.HistoricProcessInstanceEntityManager;
/*    */ 
/*    */ public class DeleteHistoricProcessInstanceCmd
/*    */   implements Command<Object>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String processInstanceId;
/*    */ 
/*    */   public DeleteHistoricProcessInstanceCmd(String processInstanceId)
/*    */   {
/* 34 */     this.processInstanceId = processInstanceId;
/*    */   }
/*    */ 
/*    */   public Object execute(CommandContext commandContext) {
/* 38 */     if (this.processInstanceId == null) {
/* 39 */       throw new ActivitiIllegalArgumentException("processInstanceId is null");
/*    */     }
/*    */ 
/* 42 */     HistoricProcessInstance instance = commandContext.getHistoricProcessInstanceEntityManager().findHistoricProcessInstance(this.processInstanceId);
/*    */ 
/* 46 */     if (instance == null) {
/* 47 */       throw new ActivitiObjectNotFoundException("No historic process instance found with id: " + this.processInstanceId, HistoricProcessInstance.class);
/*    */     }
/* 49 */     if (instance.getEndTime() == null) {
/* 50 */       throw new ActivitiException("Process instance is still running, cannot delete historic process instance: " + this.processInstanceId);
/*    */     }
/*    */ 
/* 53 */     commandContext.getHistoricProcessInstanceEntityManager().deleteHistoricProcessInstanceById(this.processInstanceId);
/*    */ 
/* 57 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.DeleteHistoricProcessInstanceCmd
 * JD-Core Version:    0.6.0
 */