/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.impl.history.HistoryManager;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntity;
/*    */ 
/*    */ public class DeleteIdentityLinkCmd extends NeedsActiveTaskCmd<Void>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String userId;
/*    */   protected String groupId;
/*    */   protected String type;
/*    */ 
/*    */   public DeleteIdentityLinkCmd(String taskId, String userId, String groupId, String type)
/*    */   {
/* 38 */     super(taskId);
/* 39 */     validateParams(userId, groupId, type, taskId);
/* 40 */     this.taskId = taskId;
/* 41 */     this.userId = userId;
/* 42 */     this.groupId = groupId;
/* 43 */     this.type = type;
/*    */   }
/*    */ 
/*    */   protected void validateParams(String userId, String groupId, String type, String taskId) {
/* 47 */     if (taskId == null) {
/* 48 */       throw new ActivitiIllegalArgumentException("taskId is null");
/*    */     }
/*    */ 
/* 51 */     if (type == null) {
/* 52 */       throw new ActivitiIllegalArgumentException("type is required when adding a new task identity link");
/*    */     }
/*    */ 
/* 56 */     if (("assignee".equals(type)) || ("owner".equals(type))) {
/* 57 */       if (groupId != null) {
/* 58 */         throw new ActivitiIllegalArgumentException("Incompatible usage: cannot use type '" + type + "' together with a groupId");
/*    */       }
/*    */ 
/*    */     }
/* 62 */     else if ((userId == null) && (groupId == null))
/* 63 */       throw new ActivitiIllegalArgumentException("userId and groupId cannot both be null");
/*    */   }
/*    */ 
/*    */   protected Void execute(CommandContext commandContext, TaskEntity task)
/*    */   {
/* 70 */     if ("assignee".equals(this.type))
/* 71 */       task.setAssignee(null);
/* 72 */     else if ("owner".equals(this.type))
/* 73 */       task.setOwner(null);
/*    */     else {
/* 75 */       task.deleteIdentityLink(this.userId, this.groupId, this.type);
/*    */     }
/*    */ 
/* 78 */     commandContext.getHistoryManager().createIdentityLinkComment(this.taskId, this.userId, this.groupId, this.type, false);
/*    */ 
/* 81 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.DeleteIdentityLinkCmd
 * JD-Core Version:    0.6.0
 */