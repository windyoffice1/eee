/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntityManager;
/*    */ import org.activiti.engine.repository.ProcessDefinition;
/*    */ 
/*    */ public class DeleteIdentityLinkForProcessDefinitionCmd
/*    */   implements Command<Object>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String processDefinitionId;
/*    */   protected String userId;
/*    */   protected String groupId;
/*    */ 
/*    */   public DeleteIdentityLinkForProcessDefinitionCmd(String processDefinitionId, String userId, String groupId)
/*    */   {
/* 41 */     validateParams(userId, groupId, processDefinitionId);
/* 42 */     this.processDefinitionId = processDefinitionId;
/* 43 */     this.userId = userId;
/* 44 */     this.groupId = groupId;
/*    */   }
/*    */ 
/*    */   protected void validateParams(String userId, String groupId, String processDefinitionId) {
/* 48 */     if (processDefinitionId == null) {
/* 49 */       throw new ActivitiIllegalArgumentException("processDefinitionId is null");
/*    */     }
/*    */ 
/* 52 */     if ((userId == null) && (groupId == null))
/* 53 */       throw new ActivitiIllegalArgumentException("userId and groupId cannot both be null");
/*    */   }
/*    */ 
/*    */   public Void execute(CommandContext commandContext)
/*    */   {
/* 58 */     ProcessDefinitionEntity processDefinition = Context.getCommandContext().getProcessDefinitionEntityManager().findProcessDefinitionById(this.processDefinitionId);
/*    */ 
/* 63 */     if (processDefinition == null) {
/* 64 */       throw new ActivitiObjectNotFoundException("Cannot find process definition with id " + this.processDefinitionId, ProcessDefinition.class);
/*    */     }
/*    */ 
/* 67 */     processDefinition.deleteIdentityLink(this.userId, this.groupId);
/*    */ 
/* 69 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.DeleteIdentityLinkForProcessDefinitionCmd
 * JD-Core Version:    0.6.0
 */