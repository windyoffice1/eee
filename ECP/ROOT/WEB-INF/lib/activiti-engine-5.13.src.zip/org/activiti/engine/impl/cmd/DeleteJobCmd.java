/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.JobEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.JobEntityManager;
/*    */ import org.activiti.engine.runtime.Job;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class DeleteJobCmd
/*    */   implements Command<Object>, Serializable
/*    */ {
/* 22 */   private static final Logger log = LoggerFactory.getLogger(DeleteJobCmd.class);
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String jobId;
/*    */ 
/*    */   public DeleteJobCmd(String jobId)
/*    */   {
/* 28 */     this.jobId = jobId;
/*    */   }
/*    */ 
/*    */   public Object execute(CommandContext commandContext) {
/* 32 */     if (this.jobId == null) {
/* 33 */       throw new ActivitiIllegalArgumentException("jobId is null");
/*    */     }
/* 35 */     if (log.isDebugEnabled()) {
/* 36 */       log.debug("Deleting job {}", this.jobId);
/*    */     }
/*    */ 
/* 39 */     JobEntity job = commandContext.getJobEntityManager().findJobById(this.jobId);
/* 40 */     if (job == null) {
/* 41 */       throw new ActivitiObjectNotFoundException("No job found with id '" + this.jobId + "'", Job.class);
/*    */     }
/*    */ 
/* 47 */     if ((job.getLockOwner() != null) || (job.getLockExpirationTime() != null))
/*    */     {
/* 49 */       throw new ActivitiException("Cannot delete job when the job is being executed. Try again later.");
/*    */     }
/*    */ 
/* 52 */     job.delete();
/* 53 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.DeleteJobCmd
 * JD-Core Version:    0.6.0
 */