/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.JobEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.JobEntityManager;
/*    */ 
/*    */ public class DeleteJobsCmd
/*    */   implements Command<Void>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   List<String> jobIds;
/*    */ 
/*    */   public DeleteJobsCmd(List<String> jobIds)
/*    */   {
/* 34 */     this.jobIds = jobIds;
/*    */   }
/*    */ 
/*    */   public DeleteJobsCmd(String jobId) {
/* 38 */     this.jobIds = new ArrayList();
/* 39 */     this.jobIds.add(jobId);
/*    */   }
/*    */ 
/*    */   public Void execute(CommandContext commandContext) {
/* 43 */     JobEntity jobToDelete = null;
/* 44 */     for (String jobId : this.jobIds) {
/* 45 */       jobToDelete = Context.getCommandContext().getJobEntityManager().findJobById(jobId);
/*    */ 
/* 50 */       if (jobToDelete != null)
/*    */       {
/* 52 */         jobToDelete.delete();
/*    */       }
/*    */     }
/* 55 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.DeleteJobsCmd
 * JD-Core Version:    0.6.0
 */