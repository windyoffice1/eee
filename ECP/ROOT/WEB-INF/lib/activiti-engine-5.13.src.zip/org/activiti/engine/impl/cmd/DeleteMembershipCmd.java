/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.MembershipIdentityManager;
/*    */ 
/*    */ public class DeleteMembershipCmd
/*    */   implements Command<Void>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   String userId;
/*    */   String groupId;
/*    */ 
/*    */   public DeleteMembershipCmd(String userId, String groupId)
/*    */   {
/* 32 */     this.userId = userId;
/* 33 */     this.groupId = groupId;
/*    */   }
/*    */ 
/*    */   public Void execute(CommandContext commandContext) {
/* 37 */     if (this.userId == null) {
/* 38 */       throw new ActivitiIllegalArgumentException("userId is null");
/*    */     }
/* 40 */     if (this.groupId == null) {
/* 41 */       throw new ActivitiIllegalArgumentException("groupId is null");
/*    */     }
/*    */ 
/* 44 */     commandContext.getMembershipIdentityManager().deleteMembership(this.userId, this.groupId);
/*    */ 
/* 48 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.DeleteMembershipCmd
 * JD-Core Version:    0.6.0
 */