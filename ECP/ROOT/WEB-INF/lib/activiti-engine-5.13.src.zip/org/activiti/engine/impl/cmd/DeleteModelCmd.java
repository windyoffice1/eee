/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.ModelEntityManager;
/*    */ 
/*    */ public class DeleteModelCmd
/*    */   implements Command<Void>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   String modelId;
/*    */ 
/*    */   public DeleteModelCmd(String modelId)
/*    */   {
/* 31 */     this.modelId = modelId;
/*    */   }
/*    */ 
/*    */   public Void execute(CommandContext commandContext) {
/* 35 */     if (this.modelId == null) {
/* 36 */       throw new ActivitiIllegalArgumentException("modelId is null");
/*    */     }
/* 38 */     commandContext.getModelEntityManager().deleteModel(this.modelId);
/*    */ 
/* 40 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.DeleteModelCmd
 * JD-Core Version:    0.6.0
 */