/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntityManager;
/*    */ 
/*    */ public class DeleteProcessInstanceCmd
/*    */   implements Command<Void>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String processInstanceId;
/*    */   protected String deleteReason;
/*    */ 
/*    */   public DeleteProcessInstanceCmd(String processInstanceId, String deleteReason)
/*    */   {
/* 32 */     this.processInstanceId = processInstanceId;
/* 33 */     this.deleteReason = deleteReason;
/*    */   }
/*    */ 
/*    */   public Void execute(CommandContext commandContext) {
/* 37 */     if (this.processInstanceId == null) {
/* 38 */       throw new ActivitiIllegalArgumentException("processInstanceId is null");
/*    */     }
/*    */ 
/* 41 */     commandContext.getExecutionEntityManager().deleteProcessInstance(this.processInstanceId, this.deleteReason);
/*    */ 
/* 44 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.DeleteProcessInstanceCmd
 * JD-Core Version:    0.6.0
 */