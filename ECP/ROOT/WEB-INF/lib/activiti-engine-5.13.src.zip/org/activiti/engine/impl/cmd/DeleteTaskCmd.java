/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Collection;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntityManager;
/*    */ 
/*    */ public class DeleteTaskCmd
/*    */   implements Command<Void>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String taskId;
/*    */   protected Collection<String> taskIds;
/*    */   protected boolean cascade;
/*    */   protected String deleteReason;
/*    */ 
/*    */   public DeleteTaskCmd(String taskId, String deleteReason, boolean cascade)
/*    */   {
/* 36 */     this.taskId = taskId;
/* 37 */     this.cascade = cascade;
/* 38 */     this.deleteReason = deleteReason;
/*    */   }
/*    */ 
/*    */   public DeleteTaskCmd(Collection<String> taskIds, String deleteReason, boolean cascade) {
/* 42 */     this.taskIds = taskIds;
/* 43 */     this.cascade = cascade;
/* 44 */     this.deleteReason = deleteReason;
/*    */   }
/*    */ 
/*    */   public Void execute(CommandContext commandContext) {
/* 48 */     if (this.taskId != null)
/* 49 */       deleteTask(this.taskId);
/* 50 */     else if (this.taskIds != null) {
/* 51 */       for (String taskId : this.taskIds)
/* 52 */         deleteTask(taskId);
/*    */     }
/*    */     else {
/* 55 */       throw new ActivitiIllegalArgumentException("taskId and taskIds are null");
/*    */     }
/*    */ 
/* 59 */     return null;
/*    */   }
/*    */ 
/*    */   protected void deleteTask(String taskId) {
/* 63 */     Context.getCommandContext().getTaskEntityManager().deleteTask(taskId, this.deleteReason, this.cascade);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.DeleteTaskCmd
 * JD-Core Version:    0.6.0
 */