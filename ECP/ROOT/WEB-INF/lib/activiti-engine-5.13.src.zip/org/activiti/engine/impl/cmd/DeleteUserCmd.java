/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.UserIdentityManager;
/*    */ 
/*    */ public class DeleteUserCmd
/*    */   implements Command<Void>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   String userId;
/*    */ 
/*    */   public DeleteUserCmd(String userId)
/*    */   {
/* 31 */     this.userId = userId;
/*    */   }
/*    */ 
/*    */   public Void execute(CommandContext commandContext) {
/* 35 */     if (this.userId == null) {
/* 36 */       throw new ActivitiIllegalArgumentException("userId is null");
/*    */     }
/* 38 */     commandContext.getUserIdentityManager().deleteUser(this.userId);
/*    */ 
/* 42 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.DeleteUserCmd
 * JD-Core Version:    0.6.0
 */