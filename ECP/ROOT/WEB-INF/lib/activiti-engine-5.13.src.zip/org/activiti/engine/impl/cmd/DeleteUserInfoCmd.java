/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.IdentityInfoEntityManager;
/*    */ 
/*    */ public class DeleteUserInfoCmd
/*    */   implements Command<Object>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String userId;
/*    */   protected String key;
/*    */ 
/*    */   public DeleteUserInfoCmd(String userId, String key)
/*    */   {
/* 32 */     this.userId = userId;
/* 33 */     this.key = key;
/*    */   }
/*    */ 
/*    */   public String execute(CommandContext commandContext) {
/* 37 */     commandContext.getIdentityInfoEntityManager().deleteUserInfoByUserIdAndKey(this.userId, this.key);
/*    */ 
/* 40 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.DeleteUserInfoCmd
 * JD-Core Version:    0.6.0
 */