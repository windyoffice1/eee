/*     */ package org.activiti.engine.impl.cmd;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*     */ import org.activiti.engine.impl.context.Context;
/*     */ import org.activiti.engine.impl.interceptor.Command;
/*     */ import org.activiti.engine.impl.interceptor.CommandContext;
/*     */ import org.activiti.engine.impl.persistence.deploy.DeploymentManager;
/*     */ import org.activiti.engine.impl.persistence.entity.DeploymentEntity;
/*     */ import org.activiti.engine.impl.persistence.entity.DeploymentEntityManager;
/*     */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*     */ import org.activiti.engine.impl.persistence.entity.ResourceEntity;
/*     */ import org.activiti.engine.impl.repository.DeploymentBuilderImpl;
/*     */ import org.activiti.engine.impl.util.ClockUtil;
/*     */ import org.activiti.engine.repository.Deployment;
/*     */ 
/*     */ public class DeployCmd<T>
/*     */   implements Command<Deployment>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected DeploymentBuilderImpl deploymentBuilder;
/*     */ 
/*     */   public DeployCmd(DeploymentBuilderImpl deploymentBuilder)
/*     */   {
/*  39 */     this.deploymentBuilder = deploymentBuilder;
/*     */   }
/*     */ 
/*     */   public Deployment execute(CommandContext commandContext) {
/*  43 */     DeploymentEntity deployment = this.deploymentBuilder.getDeployment();
/*     */ 
/*  45 */     deployment.setDeploymentTime(ClockUtil.getCurrentTime());
/*     */ 
/*  47 */     if (this.deploymentBuilder.isDuplicateFilterEnabled()) {
/*  48 */       DeploymentEntity existingDeployment = Context.getCommandContext().getDeploymentEntityManager().findLatestDeploymentByName(deployment.getName());
/*     */ 
/*  53 */       if ((existingDeployment != null) && (!deploymentsDiffer(deployment, existingDeployment)))
/*     */       {
/*  55 */         return existingDeployment;
/*     */       }
/*     */     }
/*     */ 
/*  59 */     deployment.setNew(true);
/*     */ 
/*  62 */     Context.getCommandContext().getDeploymentEntityManager().insertDeployment(deployment);
/*     */ 
/*  68 */     Context.getProcessEngineConfiguration().getDeploymentManager().deploy(deployment);
/*     */ 
/*  73 */     if (this.deploymentBuilder.getProcessDefinitionsActivationDate() != null) {
/*  74 */       scheduleProcessDefinitionActivation(commandContext, deployment);
/*     */     }
/*     */ 
/*  77 */     return deployment;
/*     */   }
/*     */ 
/*     */   protected boolean deploymentsDiffer(DeploymentEntity deployment, DeploymentEntity saved)
/*     */   {
/*  82 */     if ((deployment.getResources() == null) || (saved.getResources() == null)) {
/*  83 */       return true;
/*     */     }
/*     */ 
/*  86 */     Map resources = deployment.getResources();
/*  87 */     Map savedResources = saved.getResources();
/*     */ 
/*  89 */     for (String resourceName : resources.keySet()) {
/*  90 */       ResourceEntity savedResource = (ResourceEntity)savedResources.get(resourceName);
/*     */ 
/*  92 */       if (savedResource == null) return true;
/*     */ 
/*  94 */       if (!savedResource.isGenerated()) {
/*  95 */         ResourceEntity resource = (ResourceEntity)resources.get(resourceName);
/*     */ 
/*  97 */         byte[] bytes = resource.getBytes();
/*  98 */         byte[] savedBytes = savedResource.getBytes();
/*  99 */         if (!Arrays.equals(bytes, savedBytes)) {
/* 100 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 104 */     return false;
/*     */   }
/*     */ 
/*     */   protected void scheduleProcessDefinitionActivation(CommandContext commandContext, DeploymentEntity deployment) {
/* 108 */     for (ProcessDefinitionEntity processDefinitionEntity : deployment.getDeployedArtifacts(ProcessDefinitionEntity.class))
/*     */     {
/* 111 */       SuspendProcessDefinitionCmd suspendProcessDefinitionCmd = new SuspendProcessDefinitionCmd(processDefinitionEntity, false, null);
/*     */ 
/* 113 */       suspendProcessDefinitionCmd.execute(commandContext);
/*     */ 
/* 116 */       ActivateProcessDefinitionCmd activateProcessDefinitionCmd = new ActivateProcessDefinitionCmd(processDefinitionEntity, false, this.deploymentBuilder.getProcessDefinitionsActivationDate());
/*     */ 
/* 118 */       activateProcessDefinitionCmd.execute(commandContext);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.DeployCmd
 * JD-Core Version:    0.6.0
 */