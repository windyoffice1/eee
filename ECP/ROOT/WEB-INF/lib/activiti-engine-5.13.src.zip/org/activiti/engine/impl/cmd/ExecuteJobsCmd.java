/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.JobNotFoundException;
/*    */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*    */ import org.activiti.engine.impl.cfg.TransactionContext;
/*    */ import org.activiti.engine.impl.cfg.TransactionState;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.interceptor.CommandExecutor;
/*    */ import org.activiti.engine.impl.jobexecutor.FailedJobListener;
/*    */ import org.activiti.engine.impl.jobexecutor.JobExecutorContext;
/*    */ import org.activiti.engine.impl.persistence.entity.JobEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.JobEntityManager;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class ExecuteJobsCmd
/*    */   implements Command<Object>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 38 */   private static Logger log = LoggerFactory.getLogger(ExecuteJobsCmd.class);
/*    */   protected String jobId;
/*    */ 
/*    */   public ExecuteJobsCmd(String jobId)
/*    */   {
/* 43 */     this.jobId = jobId;
/*    */   }
/*    */ 
/*    */   public Object execute(CommandContext commandContext)
/*    */   {
/* 48 */     if (this.jobId == null) {
/* 49 */       throw new ActivitiIllegalArgumentException("jobId is null");
/*    */     }
/*    */ 
/* 52 */     if (log.isDebugEnabled()) {
/* 53 */       log.debug("Executing job {}", this.jobId);
/*    */     }
/*    */ 
/* 56 */     JobEntity job = commandContext.getJobEntityManager().findJobById(this.jobId);
/*    */ 
/* 60 */     if (job == null) {
/* 61 */       throw new JobNotFoundException(this.jobId);
/*    */     }
/*    */ 
/* 64 */     JobExecutorContext jobExecutorContext = Context.getJobExecutorContext();
/* 65 */     if (jobExecutorContext != null) {
/* 66 */       jobExecutorContext.setCurrentJob(job);
/*    */     }
/*    */     try
/*    */     {
/* 70 */       job.execute(commandContext);
/*    */     }
/*    */     catch (RuntimeException exception) {
/* 73 */       CommandExecutor commandExecutor = Context.getProcessEngineConfiguration().getCommandExecutorTxRequiresNew();
/*    */ 
/* 77 */       commandContext.getTransactionContext().addTransactionListener(TransactionState.ROLLED_BACK, new FailedJobListener(commandExecutor, this.jobId, exception));
/*    */ 
/* 82 */       throw exception;
/*    */     } finally {
/* 84 */       if (jobExecutorContext != null) {
/* 85 */         jobExecutorContext.setCurrentJob(null);
/*    */       }
/*    */     }
/* 88 */     return null;
/*    */   }
/*    */ 
/*    */   public String getJobId() {
/* 92 */     return this.jobId;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.ExecuteJobsCmd
 * JD-Core Version:    0.6.0
 */