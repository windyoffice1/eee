/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntityManager;
/*    */ import org.activiti.engine.runtime.Execution;
/*    */ 
/*    */ public class FindActiveActivityIdsCmd
/*    */   implements Command<List<String>>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String executionId;
/*    */ 
/*    */   public FindActiveActivityIdsCmd(String executionId)
/*    */   {
/* 36 */     this.executionId = executionId;
/*    */   }
/*    */ 
/*    */   public List<String> execute(CommandContext commandContext) {
/* 40 */     if (this.executionId == null) {
/* 41 */       throw new ActivitiIllegalArgumentException("executionId is null");
/*    */     }
/*    */ 
/* 44 */     ExecutionEntity execution = commandContext.getExecutionEntityManager().findExecutionById(this.executionId);
/*    */ 
/* 48 */     if (execution == null) {
/* 49 */       throw new ActivitiObjectNotFoundException("execution " + this.executionId + " doesn't exist", Execution.class);
/*    */     }
/*    */ 
/* 52 */     return execution.findActiveActivityIds();
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.FindActiveActivityIdsCmd
 * JD-Core Version:    0.6.0
 */