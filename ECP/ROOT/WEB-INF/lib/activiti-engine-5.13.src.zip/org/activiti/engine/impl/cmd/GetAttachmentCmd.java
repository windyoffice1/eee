/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.impl.db.DbSqlSession;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.AttachmentEntity;
/*    */ import org.activiti.engine.task.Attachment;
/*    */ 
/*    */ public class GetAttachmentCmd
/*    */   implements Command<Attachment>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String attachmentId;
/*    */ 
/*    */   public GetAttachmentCmd(String attachmentId)
/*    */   {
/* 33 */     this.attachmentId = attachmentId;
/*    */   }
/*    */ 
/*    */   public Attachment execute(CommandContext commandContext) {
/* 37 */     return (Attachment)commandContext.getDbSqlSession().selectById(AttachmentEntity.class, this.attachmentId);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetAttachmentCmd
 * JD-Core Version:    0.6.0
 */