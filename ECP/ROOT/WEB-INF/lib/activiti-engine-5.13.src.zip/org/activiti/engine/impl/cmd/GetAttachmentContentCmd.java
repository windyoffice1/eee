/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.InputStream;
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.impl.db.DbSqlSession;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.AttachmentEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ByteArrayEntity;
/*    */ 
/*    */ public class GetAttachmentContentCmd
/*    */   implements Command<InputStream>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String attachmentId;
/*    */ 
/*    */   public GetAttachmentContentCmd(String attachmentId)
/*    */   {
/* 36 */     this.attachmentId = attachmentId;
/*    */   }
/*    */ 
/*    */   public InputStream execute(CommandContext commandContext) {
/* 40 */     DbSqlSession dbSqlSession = commandContext.getDbSqlSession();
/* 41 */     AttachmentEntity attachment = (AttachmentEntity)dbSqlSession.selectById(AttachmentEntity.class, this.attachmentId);
/*    */ 
/* 43 */     String contentId = attachment.getContentId();
/* 44 */     if (contentId == null) {
/* 45 */       return null;
/*    */     }
/*    */ 
/* 48 */     ByteArrayEntity byteArray = (ByteArrayEntity)dbSqlSession.selectById(ByteArrayEntity.class, contentId);
/* 49 */     byte[] bytes = byteArray.getBytes();
/*    */ 
/* 51 */     return new ByteArrayInputStream(bytes);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetAttachmentContentCmd
 * JD-Core Version:    0.6.0
 */