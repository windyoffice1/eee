/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.Serializable;
/*    */ import org.activiti.bpmn.converter.BpmnXMLConverter;
/*    */ import org.activiti.bpmn.model.BpmnModel;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.DeploymentEntityManager;
/*    */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntityManager;
/*    */ import org.activiti.engine.impl.persistence.entity.ResourceEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ResourceEntityManager;
/*    */ import org.activiti.engine.impl.util.io.BytesStreamSource;
/*    */ import org.activiti.engine.repository.Deployment;
/*    */ 
/*    */ public class GetBpmnModelCmd
/*    */   implements Command<BpmnModel>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 8167762371289445046L;
/*    */   protected String processDefinitionId;
/*    */ 
/*    */   public GetBpmnModelCmd(String processDefinitionId)
/*    */   {
/* 39 */     this.processDefinitionId = processDefinitionId;
/*    */   }
/*    */ 
/*    */   public BpmnModel execute(CommandContext commandContext) {
/* 43 */     if (this.processDefinitionId == null) {
/* 44 */       throw new ActivitiIllegalArgumentException("processDefinitionId is null");
/*    */     }
/*    */ 
/* 48 */     ProcessDefinitionEntity processDefinitionEntity = commandContext.getProcessDefinitionEntityManager().findProcessDefinitionById(this.processDefinitionId);
/*    */ 
/* 52 */     if (processDefinitionEntity == null) {
/* 53 */       throw new ActivitiObjectNotFoundException("Process definition does not exist: " + this.processDefinitionId, ProcessDefinitionEntity.class);
/*    */     }
/*    */ 
/* 57 */     String resourceName = processDefinitionEntity.getResourceName();
/* 58 */     ResourceEntity resource = commandContext.getResourceEntityManager().findResourceByDeploymentIdAndResourceName(processDefinitionEntity.getDeploymentId(), resourceName);
/*    */ 
/* 60 */     if (resource == null) {
/* 61 */       if (commandContext.getDeploymentEntityManager().findDeploymentById(processDefinitionEntity.getDeploymentId()) == null) {
/* 62 */         throw new ActivitiObjectNotFoundException("deployment for process definition does not exist: " + processDefinitionEntity.getDeploymentId(), Deployment.class);
/*    */       }
/*    */ 
/* 65 */       throw new ActivitiObjectNotFoundException("no resource found with name '" + resourceName + "' in deployment '" + processDefinitionEntity.getDeploymentId() + "'", InputStream.class);
/*    */     }
/*    */ 
/* 71 */     BpmnXMLConverter bpmnXMLConverter = new BpmnXMLConverter();
/* 72 */     return bpmnXMLConverter.convertToBpmnModel(new BytesStreamSource(resource.getBytes()), false, false);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetBpmnModelCmd
 * JD-Core Version:    0.6.0
 */