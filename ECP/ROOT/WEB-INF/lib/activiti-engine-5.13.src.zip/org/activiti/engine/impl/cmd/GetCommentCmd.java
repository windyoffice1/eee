/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.CommentEntityManager;
/*    */ import org.activiti.engine.task.Comment;
/*    */ 
/*    */ public class GetCommentCmd
/*    */   implements Command<Comment>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String commentId;
/*    */ 
/*    */   public GetCommentCmd(String commentId)
/*    */   {
/* 33 */     this.commentId = commentId;
/*    */ 
/* 35 */     if (commentId == null)
/* 36 */       throw new ActivitiIllegalArgumentException("commentId is null");
/*    */   }
/*    */ 
/*    */   public Comment execute(CommandContext commandContext)
/*    */   {
/* 41 */     return commandContext.getCommentEntityManager().findComment(this.commentId);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetCommentCmd
 * JD-Core Version:    0.6.0
 */