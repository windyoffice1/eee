/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.deploy.DeploymentManager;
/*    */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class GetDeploymentProcessDiagramCmd
/*    */   implements Command<InputStream>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 37 */   private static Logger log = LoggerFactory.getLogger(GetDeploymentProcessDiagramCmd.class);
/*    */   protected String processDefinitionId;
/*    */ 
/*    */   public GetDeploymentProcessDiagramCmd(String processDefinitionId)
/*    */   {
/* 42 */     if ((processDefinitionId == null) || (processDefinitionId.length() < 1)) {
/* 43 */       throw new ActivitiIllegalArgumentException("The process definition id is mandatory, but '" + processDefinitionId + "' has been provided.");
/*    */     }
/* 45 */     this.processDefinitionId = processDefinitionId;
/*    */   }
/*    */ 
/*    */   public InputStream execute(CommandContext commandContext) {
/* 49 */     ProcessDefinitionEntity processDefinition = Context.getProcessEngineConfiguration().getDeploymentManager().findDeployedProcessDefinitionById(this.processDefinitionId);
/*    */ 
/* 53 */     String deploymentId = processDefinition.getDeploymentId();
/* 54 */     String resourceName = processDefinition.getDiagramResourceName();
/* 55 */     if (resourceName == null) {
/* 56 */       log.info("Resource name is null! No process diagram stream exists.");
/* 57 */       return null;
/*    */     }
/* 59 */     InputStream processDiagramStream = new GetDeploymentResourceCmd(deploymentId, resourceName).execute(commandContext);
/*    */ 
/* 62 */     return processDiagramStream;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetDeploymentProcessDiagramCmd
 * JD-Core Version:    0.6.0
 */