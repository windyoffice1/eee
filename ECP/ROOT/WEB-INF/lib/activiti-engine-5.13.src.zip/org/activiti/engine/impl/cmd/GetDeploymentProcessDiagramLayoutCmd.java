/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.impl.bpmn.diagram.ProcessDiagramLayoutFactory;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.repository.DiagramLayout;
/*    */ 
/*    */ public class GetDeploymentProcessDiagramLayoutCmd
/*    */   implements Command<DiagramLayout>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String processDefinitionId;
/*    */ 
/*    */   public GetDeploymentProcessDiagramLayoutCmd(String processDefinitionId)
/*    */   {
/* 39 */     if ((processDefinitionId == null) || (processDefinitionId.length() < 1)) {
/* 40 */       throw new ActivitiException("The process definition id is mandatory, but '" + processDefinitionId + "' has been provided.");
/*    */     }
/* 42 */     this.processDefinitionId = processDefinitionId;
/*    */   }
/*    */ 
/*    */   public DiagramLayout execute(CommandContext commandContext) {
/* 46 */     InputStream processModelStream = new GetDeploymentProcessModelCmd(this.processDefinitionId).execute(commandContext);
/*    */ 
/* 49 */     InputStream processDiagramStream = new GetDeploymentProcessDiagramCmd(this.processDefinitionId).execute(commandContext);
/*    */ 
/* 52 */     return new ProcessDiagramLayoutFactory().getProcessDiagramLayout(processModelStream, processDiagramStream);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetDeploymentProcessDiagramLayoutCmd
 * JD-Core Version:    0.6.0
 */