/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.deploy.DeploymentManager;
/*    */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*    */ 
/*    */ public class GetDeploymentProcessModelCmd
/*    */   implements Command<InputStream>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String processDefinitionId;
/*    */ 
/*    */   public GetDeploymentProcessModelCmd(String processDefinitionId)
/*    */   {
/* 38 */     if ((processDefinitionId == null) || (processDefinitionId.length() < 1)) {
/* 39 */       throw new ActivitiIllegalArgumentException("The process definition id is mandatory, but '" + processDefinitionId + "' has been provided.");
/*    */     }
/* 41 */     this.processDefinitionId = processDefinitionId;
/*    */   }
/*    */ 
/*    */   public InputStream execute(CommandContext commandContext) {
/* 45 */     ProcessDefinitionEntity processDefinition = Context.getProcessEngineConfiguration().getDeploymentManager().findDeployedProcessDefinitionById(this.processDefinitionId);
/*    */ 
/* 49 */     String deploymentId = processDefinition.getDeploymentId();
/* 50 */     String resourceName = processDefinition.getResourceName();
/* 51 */     InputStream processModelStream = new GetDeploymentResourceCmd(deploymentId, resourceName).execute(commandContext);
/*    */ 
/* 54 */     return processModelStream;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetDeploymentProcessModelCmd
 * JD-Core Version:    0.6.0
 */