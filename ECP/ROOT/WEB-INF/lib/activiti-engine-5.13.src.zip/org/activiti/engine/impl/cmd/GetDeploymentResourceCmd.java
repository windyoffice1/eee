/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.InputStream;
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.DeploymentEntityManager;
/*    */ import org.activiti.engine.impl.persistence.entity.ResourceEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ResourceEntityManager;
/*    */ import org.activiti.engine.repository.Deployment;
/*    */ 
/*    */ public class GetDeploymentResourceCmd
/*    */   implements Command<InputStream>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String deploymentId;
/*    */   protected String resourceName;
/*    */ 
/*    */   public GetDeploymentResourceCmd(String deploymentId, String resourceName)
/*    */   {
/* 37 */     this.deploymentId = deploymentId;
/* 38 */     this.resourceName = resourceName;
/*    */   }
/*    */ 
/*    */   public InputStream execute(CommandContext commandContext) {
/* 42 */     if (this.deploymentId == null) {
/* 43 */       throw new ActivitiIllegalArgumentException("deploymentId is null");
/*    */     }
/* 45 */     if (this.resourceName == null) {
/* 46 */       throw new ActivitiIllegalArgumentException("resourceName is null");
/*    */     }
/*    */ 
/* 49 */     ResourceEntity resource = commandContext.getResourceEntityManager().findResourceByDeploymentIdAndResourceName(this.deploymentId, this.resourceName);
/*    */ 
/* 52 */     if (resource == null) {
/* 53 */       if (commandContext.getDeploymentEntityManager().findDeploymentById(this.deploymentId) == null) {
/* 54 */         throw new ActivitiObjectNotFoundException("deployment does not exist: " + this.deploymentId, Deployment.class);
/*    */       }
/*    */ 
/* 58 */       throw new ActivitiObjectNotFoundException("no resource found with name '" + this.resourceName + "' in deployment '" + this.deploymentId + "'", InputStream.class);
/*    */     }
/*    */ 
/* 61 */     return new ByteArrayInputStream(resource.getBytes());
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetDeploymentResourceCmd
 * JD-Core Version:    0.6.0
 */