/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.DeploymentEntityManager;
/*    */ 
/*    */ public class GetDeploymentResourceNamesCmd
/*    */   implements Command<List>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String deploymentId;
/*    */ 
/*    */   public GetDeploymentResourceNamesCmd(String deploymentId)
/*    */   {
/* 34 */     this.deploymentId = deploymentId;
/*    */   }
/*    */ 
/*    */   public List execute(CommandContext commandContext) {
/* 38 */     if (this.deploymentId == null) {
/* 39 */       throw new ActivitiIllegalArgumentException("deploymentId is null");
/*    */     }
/*    */ 
/* 42 */     return Context.getCommandContext().getDeploymentEntityManager().getDeploymentResourceNames(this.deploymentId);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetDeploymentResourceNamesCmd
 * JD-Core Version:    0.6.0
 */