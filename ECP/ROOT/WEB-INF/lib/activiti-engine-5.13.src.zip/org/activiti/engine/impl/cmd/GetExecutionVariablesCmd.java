/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntityManager;
/*    */ import org.activiti.engine.runtime.Execution;
/*    */ 
/*    */ public class GetExecutionVariablesCmd
/*    */   implements Command<Map<String, Object>>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String executionId;
/*    */   protected Collection<String> variableNames;
/*    */   protected boolean isLocal;
/*    */ 
/*    */   public GetExecutionVariablesCmd(String executionId, Collection<String> variableNames, boolean isLocal)
/*    */   {
/* 39 */     this.executionId = executionId;
/* 40 */     this.variableNames = variableNames;
/* 41 */     this.isLocal = isLocal;
/*    */   }
/*    */ 
/*    */   public Map<String, Object> execute(CommandContext commandContext) {
/* 45 */     if (this.executionId == null) {
/* 46 */       throw new ActivitiIllegalArgumentException("executionId is null");
/*    */     }
/*    */ 
/* 49 */     ExecutionEntity execution = commandContext.getExecutionEntityManager().findExecutionById(this.executionId);
/*    */ 
/* 53 */     if (execution == null)
/* 54 */       throw new ActivitiObjectNotFoundException("execution " + this.executionId + " doesn't exist", Execution.class);
/*    */     Map executionVariables;
/*    */     Map executionVariables;
/* 58 */     if (this.isLocal)
/* 59 */       executionVariables = execution.getVariablesLocal();
/*    */     else {
/* 61 */       executionVariables = execution.getVariables();
/*    */     }
/*    */ 
/* 64 */     if ((this.variableNames != null) && (this.variableNames.size() > 0))
/*    */     {
/* 66 */       Map tempVariables = new HashMap();
/* 67 */       for (String variableName : this.variableNames) {
/* 68 */         if (executionVariables.containsKey(variableName)) {
/* 69 */           tempVariables.put(variableName, executionVariables.get(variableName));
/*    */         }
/*    */       }
/* 72 */       executionVariables = tempVariables;
/*    */     }
/*    */ 
/* 75 */     return executionVariables;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetExecutionVariablesCmd
 * JD-Core Version:    0.6.0
 */