/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.delegate.Expression;
/*    */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.form.DefaultFormHandler;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.deploy.DeploymentManager;
/*    */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*    */ import org.activiti.engine.impl.task.TaskDefinition;
/*    */ 
/*    */ public class GetFormKeyCmd
/*    */   implements Command<String>
/*    */ {
/*    */   protected String taskDefinitionKey;
/*    */   protected String processDefinitionId;
/*    */ 
/*    */   public GetFormKeyCmd(String processDefinitionId)
/*    */   {
/* 39 */     setProcessDefinitionId(processDefinitionId);
/*    */   }
/*    */ 
/*    */   public GetFormKeyCmd(String processDefinitionId, String taskDefinitionKey)
/*    */   {
/* 46 */     setProcessDefinitionId(processDefinitionId);
/* 47 */     if ((taskDefinitionKey == null) || (taskDefinitionKey.length() < 1)) {
/* 48 */       throw new ActivitiIllegalArgumentException("The task definition key is mandatory, but '" + taskDefinitionKey + "' has been provided.");
/*    */     }
/* 50 */     this.taskDefinitionKey = taskDefinitionKey;
/*    */   }
/*    */ 
/*    */   protected void setProcessDefinitionId(String processDefinitionId) {
/* 54 */     if ((processDefinitionId == null) || (processDefinitionId.length() < 1)) {
/* 55 */       throw new ActivitiIllegalArgumentException("The process definition id is mandatory, but '" + processDefinitionId + "' has been provided.");
/*    */     }
/* 57 */     this.processDefinitionId = processDefinitionId;
/*    */   }
/*    */ 
/*    */   public String execute(CommandContext commandContext) {
/* 61 */     ProcessDefinitionEntity processDefinition = Context.getProcessEngineConfiguration().getDeploymentManager().findDeployedProcessDefinitionById(this.processDefinitionId);
/*    */     DefaultFormHandler formHandler;
/*    */     DefaultFormHandler formHandler;
/* 66 */     if (this.taskDefinitionKey == null)
/*    */     {
/* 68 */       formHandler = (DefaultFormHandler)processDefinition.getStartFormHandler();
/*    */     } else {
/* 70 */       TaskDefinition taskDefinition = (TaskDefinition)processDefinition.getTaskDefinitions().get(this.taskDefinitionKey);
/*    */ 
/* 72 */       formHandler = (DefaultFormHandler)taskDefinition.getTaskFormHandler();
/*    */     }
/* 74 */     String formKey = null;
/* 75 */     if (formHandler.getFormKey() != null) {
/* 76 */       formKey = formHandler.getFormKey().getExpressionText();
/*    */     }
/* 78 */     return formKey;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetFormKeyCmd
 * JD-Core Version:    0.6.0
 */