/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.history.HistoricIdentityLink;
/*    */ import org.activiti.engine.history.HistoricTaskInstance;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.HistoricIdentityLinkEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.HistoricIdentityLinkEntityManager;
/*    */ import org.activiti.engine.impl.persistence.entity.HistoricTaskInstanceEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.HistoricTaskInstanceEntityManager;
/*    */ 
/*    */ public class GetHistoricIdentityLinksForTaskCmd
/*    */   implements Command<List<HistoricIdentityLink>>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String taskId;
/*    */   protected String processInstanceId;
/*    */ 
/*    */   public GetHistoricIdentityLinksForTaskCmd(String taskId, String processInstanceId)
/*    */   {
/* 40 */     if ((taskId == null) && (processInstanceId == null)) {
/* 41 */       throw new ActivitiIllegalArgumentException("taskId or processInstanceId is required");
/*    */     }
/* 43 */     this.taskId = taskId;
/* 44 */     this.processInstanceId = processInstanceId;
/*    */   }
/*    */ 
/*    */   public List<HistoricIdentityLink> execute(CommandContext commandContext) {
/* 48 */     if (this.taskId != null) {
/* 49 */       return getLinksForTask();
/*    */     }
/* 51 */     return getLinksForProcessInstance();
/*    */   }
/*    */ 
/*    */   protected List<HistoricIdentityLink> getLinksForTask()
/*    */   {
/* 57 */     HistoricTaskInstanceEntity task = Context.getCommandContext().getHistoricTaskInstanceEntityManager().findHistoricTaskInstanceById(this.taskId);
/*    */ 
/* 62 */     if (task == null) {
/* 63 */       throw new ActivitiObjectNotFoundException("No historic task exists with the given id: " + this.taskId, HistoricTaskInstance.class);
/*    */     }
/*    */ 
/* 66 */     List identityLinks = Context.getCommandContext().getHistoricIdentityLinkEntityManager().findHistoricIdentityLinksByTaskId(this.taskId);
/*    */ 
/* 71 */     if (task.getAssignee() != null) {
/* 72 */       HistoricIdentityLinkEntity identityLink = new HistoricIdentityLinkEntity();
/* 73 */       identityLink.setUserId(task.getAssignee());
/* 74 */       identityLink.setTaskId(task.getId());
/* 75 */       identityLink.setType("assignee");
/* 76 */       identityLinks.add(identityLink);
/*    */     }
/* 78 */     if (task.getOwner() != null) {
/* 79 */       HistoricIdentityLinkEntity identityLink = new HistoricIdentityLinkEntity();
/* 80 */       identityLink.setTaskId(task.getId());
/* 81 */       identityLink.setUserId(task.getOwner());
/* 82 */       identityLink.setType("owner");
/* 83 */       identityLinks.add(identityLink);
/*    */     }
/*    */ 
/* 86 */     return identityLinks;
/*    */   }
/*    */ 
/*    */   protected List<HistoricIdentityLink> getLinksForProcessInstance()
/*    */   {
/* 91 */     return Context.getCommandContext().getHistoricIdentityLinkEntityManager().findHistoricIdentityLinksByProcessInstanceId(this.processInstanceId);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetHistoricIdentityLinksForTaskCmd
 * JD-Core Version:    0.6.0
 */