/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntityManager;
/*    */ import org.activiti.engine.repository.ProcessDefinition;
/*    */ import org.activiti.engine.task.IdentityLink;
/*    */ 
/*    */ public class GetIdentityLinksForProcessDefinitionCmd
/*    */   implements Command<List<IdentityLink>>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String processDefinitionId;
/*    */ 
/*    */   public GetIdentityLinksForProcessDefinitionCmd(String processDefinitionId)
/*    */   {
/* 36 */     this.processDefinitionId = processDefinitionId;
/*    */   }
/*    */ 
/*    */   public List<IdentityLink> execute(CommandContext commandContext)
/*    */   {
/* 41 */     ProcessDefinitionEntity processDefinition = Context.getCommandContext().getProcessDefinitionEntityManager().findProcessDefinitionById(this.processDefinitionId);
/*    */ 
/* 46 */     if (processDefinition == null) {
/* 47 */       throw new ActivitiObjectNotFoundException("Cannot find process definition with id " + this.processDefinitionId, ProcessDefinition.class);
/*    */     }
/*    */ 
/* 50 */     List identityLinks = processDefinition.getIdentityLinks();
/* 51 */     return identityLinks;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetIdentityLinksForProcessDefinitionCmd
 * JD-Core Version:    0.6.0
 */