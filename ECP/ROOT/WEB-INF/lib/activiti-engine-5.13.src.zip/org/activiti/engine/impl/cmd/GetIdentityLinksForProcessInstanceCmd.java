/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntityManager;
/*    */ import org.activiti.engine.task.IdentityLink;
/*    */ 
/*    */ public class GetIdentityLinksForProcessInstanceCmd
/*    */   implements Command<List<IdentityLink>>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String processInstanceId;
/*    */ 
/*    */   public GetIdentityLinksForProcessInstanceCmd(String processInstanceId)
/*    */   {
/* 36 */     this.processInstanceId = processInstanceId;
/*    */   }
/*    */ 
/*    */   public List<IdentityLink> execute(CommandContext commandContext)
/*    */   {
/* 41 */     ExecutionEntity processInstance = Context.getCommandContext().getExecutionEntityManager().findExecutionById(this.processInstanceId);
/*    */ 
/* 46 */     if (processInstance == null) {
/* 47 */       throw new ActivitiObjectNotFoundException("Cannot find process definition with id " + this.processInstanceId, ExecutionEntity.class);
/*    */     }
/*    */ 
/* 50 */     return processInstance.getIdentityLinks();
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetIdentityLinksForProcessInstanceCmd
 * JD-Core Version:    0.6.0
 */