/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.IdentityLinkEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntityManager;
/*    */ import org.activiti.engine.task.IdentityLink;
/*    */ 
/*    */ public class GetIdentityLinksForTaskCmd
/*    */   implements Command<List<IdentityLink>>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String taskId;
/*    */ 
/*    */   public GetIdentityLinksForTaskCmd(String taskId)
/*    */   {
/* 37 */     this.taskId = taskId;
/*    */   }
/*    */ 
/*    */   public List<IdentityLink> execute(CommandContext commandContext)
/*    */   {
/* 42 */     TaskEntity task = Context.getCommandContext().getTaskEntityManager().findTaskById(this.taskId);
/*    */ 
/* 47 */     List identityLinks = task.getIdentityLinks();
/*    */ 
/* 57 */     if (task.getAssignee() != null) {
/* 58 */       IdentityLinkEntity identityLink = new IdentityLinkEntity();
/* 59 */       identityLink.setUserId(task.getAssignee());
/* 60 */       identityLink.setType("assignee");
/* 61 */       identityLink.setTaskId(task.getId());
/* 62 */       identityLinks.add(identityLink);
/*    */     }
/* 64 */     if (task.getOwner() != null) {
/* 65 */       IdentityLinkEntity identityLink = new IdentityLinkEntity();
/* 66 */       identityLink.setUserId(task.getOwner());
/* 67 */       identityLink.setTaskId(task.getId());
/* 68 */       identityLink.setType("owner");
/* 69 */       identityLinks.add(identityLink);
/*    */     }
/*    */ 
/* 72 */     return task.getIdentityLinks();
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetIdentityLinksForTaskCmd
 * JD-Core Version:    0.6.0
 */