/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.JobEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.JobEntityManager;
/*    */ import org.activiti.engine.runtime.Job;
/*    */ 
/*    */ public class GetJobExceptionStacktraceCmd
/*    */   implements Command<String>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String jobId;
/*    */ 
/*    */   public GetJobExceptionStacktraceCmd(String jobId)
/*    */   {
/* 35 */     this.jobId = jobId;
/*    */   }
/*    */ 
/*    */   public String execute(CommandContext commandContext)
/*    */   {
/* 40 */     if (this.jobId == null) {
/* 41 */       throw new ActivitiIllegalArgumentException("jobId is null");
/*    */     }
/*    */ 
/* 44 */     JobEntity job = commandContext.getJobEntityManager().findJobById(this.jobId);
/*    */ 
/* 48 */     if (job == null) {
/* 49 */       throw new ActivitiObjectNotFoundException("No job found with id " + this.jobId, Job.class);
/*    */     }
/*    */ 
/* 52 */     return job.getExceptionStacktrace();
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetJobExceptionStacktraceCmd
 * JD-Core Version:    0.6.0
 */