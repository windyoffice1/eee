/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.ModelEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ModelEntityManager;
/*    */ 
/*    */ public class GetModelCmd
/*    */   implements Command<ModelEntity>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String modelId;
/*    */ 
/*    */   public GetModelCmd(String modelId)
/*    */   {
/* 33 */     this.modelId = modelId;
/*    */   }
/*    */ 
/*    */   public ModelEntity execute(CommandContext commandContext) {
/* 37 */     return Context.getCommandContext().getModelEntityManager().findModelById(this.modelId);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetModelCmd
 * JD-Core Version:    0.6.0
 */