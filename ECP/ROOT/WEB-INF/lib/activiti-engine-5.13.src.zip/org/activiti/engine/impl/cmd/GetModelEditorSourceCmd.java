/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.ModelEntityManager;
/*    */ 
/*    */ public class GetModelEditorSourceCmd
/*    */   implements Command<byte[]>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String modelId;
/*    */ 
/*    */   public GetModelEditorSourceCmd(String modelId)
/*    */   {
/* 31 */     this.modelId = modelId;
/*    */   }
/*    */ 
/*    */   public byte[] execute(CommandContext commandContext) {
/* 35 */     if (this.modelId == null) {
/* 36 */       throw new ActivitiIllegalArgumentException("modelId is null");
/*    */     }
/*    */ 
/* 39 */     byte[] bytes = commandContext.getModelEntityManager().findEditorSourceByModelId(this.modelId);
/*    */ 
/* 43 */     return bytes;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetModelEditorSourceCmd
 * JD-Core Version:    0.6.0
 */