/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import org.activiti.engine.impl.db.IdBlock;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.PropertyEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.PropertyEntityManager;
/*    */ 
/*    */ public class GetNextIdBlockCmd
/*    */   implements Command<IdBlock>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected int idBlockSize;
/*    */ 
/*    */   public GetNextIdBlockCmd(int idBlockSize)
/*    */   {
/* 30 */     this.idBlockSize = idBlockSize;
/*    */   }
/*    */ 
/*    */   public IdBlock execute(CommandContext commandContext) {
/* 34 */     PropertyEntity property = commandContext.getPropertyEntityManager().findPropertyById("next.dbid");
/*    */ 
/* 37 */     long oldValue = Long.parseLong(property.getValue());
/* 38 */     long newValue = oldValue + this.idBlockSize;
/* 39 */     property.setValue(Long.toString(newValue));
/* 40 */     return new IdBlock(oldValue, newValue - 1L);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetNextIdBlockCmd
 * JD-Core Version:    0.6.0
 */