/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.activiti.engine.impl.db.DbSqlSession;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.PropertyEntity;
/*    */ 
/*    */ public class GetPropertiesCmd
/*    */   implements Command<Map<String, String>>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public Map<String, String> execute(CommandContext commandContext)
/*    */   {
/* 35 */     List propertyEntities = commandContext.getDbSqlSession().selectList("selectProperties");
/*    */ 
/* 39 */     Map properties = new HashMap();
/* 40 */     for (PropertyEntity propertyEntity : propertyEntities) {
/* 41 */       properties.put(propertyEntity.getName(), propertyEntity.getValue());
/*    */     }
/* 43 */     return properties;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetPropertiesCmd
 * JD-Core Version:    0.6.0
 */