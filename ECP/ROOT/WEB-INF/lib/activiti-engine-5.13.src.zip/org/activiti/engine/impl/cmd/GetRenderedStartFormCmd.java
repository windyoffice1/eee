/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Map;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.form.StartFormData;
/*    */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.form.FormEngine;
/*    */ import org.activiti.engine.impl.form.StartFormHandler;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.deploy.DeploymentManager;
/*    */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*    */ import org.activiti.engine.repository.ProcessDefinition;
/*    */ 
/*    */ public class GetRenderedStartFormCmd
/*    */   implements Command<Object>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String processDefinitionId;
/*    */   protected String formEngineName;
/*    */ 
/*    */   public GetRenderedStartFormCmd(String processDefinitionId, String formEngineName)
/*    */   {
/* 40 */     this.processDefinitionId = processDefinitionId;
/* 41 */     this.formEngineName = formEngineName;
/*    */   }
/*    */ 
/*    */   public Object execute(CommandContext commandContext) {
/* 45 */     ProcessDefinitionEntity processDefinition = Context.getProcessEngineConfiguration().getDeploymentManager().findDeployedProcessDefinitionById(this.processDefinitionId);
/*    */ 
/* 49 */     if (processDefinition == null) {
/* 50 */       throw new ActivitiObjectNotFoundException("Process Definition '" + this.processDefinitionId + "' not found", ProcessDefinition.class);
/*    */     }
/* 52 */     StartFormHandler startFormHandler = processDefinition.getStartFormHandler();
/* 53 */     if (startFormHandler == null) {
/* 54 */       return null;
/*    */     }
/*    */ 
/* 57 */     FormEngine formEngine = (FormEngine)Context.getProcessEngineConfiguration().getFormEngines().get(this.formEngineName);
/*    */ 
/* 62 */     if (formEngine == null) {
/* 63 */       throw new ActivitiException("No formEngine '" + this.formEngineName + "' defined process engine configuration");
/*    */     }
/*    */ 
/* 66 */     StartFormData startForm = startFormHandler.createStartFormData(processDefinition);
/*    */ 
/* 68 */     return formEngine.renderStartForm(startForm);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetRenderedStartFormCmd
 * JD-Core Version:    0.6.0
 */