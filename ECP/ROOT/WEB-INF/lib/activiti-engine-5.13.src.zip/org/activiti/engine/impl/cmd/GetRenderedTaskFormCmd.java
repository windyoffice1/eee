/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Map;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.form.TaskFormData;
/*    */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.form.FormEngine;
/*    */ import org.activiti.engine.impl.form.TaskFormHandler;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntityManager;
/*    */ import org.activiti.engine.impl.task.TaskDefinition;
/*    */ import org.activiti.engine.task.Task;
/*    */ 
/*    */ public class GetRenderedTaskFormCmd
/*    */   implements Command<Object>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String taskId;
/*    */   protected String formEngineName;
/*    */ 
/*    */   public GetRenderedTaskFormCmd(String taskId, String formEngineName)
/*    */   {
/* 40 */     this.taskId = taskId;
/* 41 */     this.formEngineName = formEngineName;
/*    */   }
/*    */ 
/*    */   public Object execute(CommandContext commandContext)
/*    */   {
/* 46 */     TaskEntity task = Context.getCommandContext().getTaskEntityManager().findTaskById(this.taskId);
/*    */ 
/* 50 */     if (task == null) {
/* 51 */       throw new ActivitiObjectNotFoundException("Task '" + this.taskId + "' not found", Task.class);
/*    */     }
/*    */ 
/* 54 */     if (task.getTaskDefinition() == null) {
/* 55 */       throw new ActivitiException("Task form definition for '" + this.taskId + "' not found");
/*    */     }
/*    */ 
/* 58 */     TaskFormHandler taskFormHandler = task.getTaskDefinition().getTaskFormHandler();
/* 59 */     if (taskFormHandler == null) {
/* 60 */       return null;
/*    */     }
/*    */ 
/* 63 */     FormEngine formEngine = (FormEngine)Context.getProcessEngineConfiguration().getFormEngines().get(this.formEngineName);
/*    */ 
/* 68 */     if (formEngine == null) {
/* 69 */       throw new ActivitiException("No formEngine '" + this.formEngineName + "' defined process engine configuration");
/*    */     }
/*    */ 
/* 72 */     TaskFormData taskForm = taskFormHandler.createTaskForm(task);
/*    */ 
/* 74 */     return formEngine.renderTaskForm(taskForm);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetRenderedTaskFormCmd
 * JD-Core Version:    0.6.0
 */