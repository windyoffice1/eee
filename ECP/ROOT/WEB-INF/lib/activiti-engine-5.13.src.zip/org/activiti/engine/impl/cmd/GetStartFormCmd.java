/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.form.StartFormData;
/*    */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.form.StartFormHandler;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.deploy.DeploymentManager;
/*    */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*    */ import org.activiti.engine.repository.ProcessDefinition;
/*    */ 
/*    */ public class GetStartFormCmd
/*    */   implements Command<StartFormData>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String processDefinitionId;
/*    */ 
/*    */   public GetStartFormCmd(String processDefinitionId)
/*    */   {
/* 38 */     this.processDefinitionId = processDefinitionId;
/*    */   }
/*    */ 
/*    */   public StartFormData execute(CommandContext commandContext) {
/* 42 */     ProcessDefinitionEntity processDefinition = Context.getProcessEngineConfiguration().getDeploymentManager().findDeployedProcessDefinitionById(this.processDefinitionId);
/*    */ 
/* 46 */     if (processDefinition == null) {
/* 47 */       throw new ActivitiObjectNotFoundException("No process definition found for id '" + this.processDefinitionId + "'", ProcessDefinition.class);
/*    */     }
/*    */ 
/* 50 */     StartFormHandler startFormHandler = processDefinition.getStartFormHandler();
/* 51 */     if (startFormHandler == null) {
/* 52 */       throw new ActivitiException("No startFormHandler defined in process '" + this.processDefinitionId + "'");
/*    */     }
/*    */ 
/* 56 */     return startFormHandler.createStartFormData(processDefinition);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetStartFormCmd
 * JD-Core Version:    0.6.0
 */