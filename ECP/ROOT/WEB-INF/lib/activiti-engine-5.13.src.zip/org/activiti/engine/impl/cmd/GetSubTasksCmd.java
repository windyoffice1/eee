/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntityManager;
/*    */ import org.activiti.engine.task.Task;
/*    */ 
/*    */ public class GetSubTasksCmd
/*    */   implements Command<List<Task>>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String parentTaskId;
/*    */ 
/*    */   public GetSubTasksCmd(String parentTaskId)
/*    */   {
/* 34 */     this.parentTaskId = parentTaskId;
/*    */   }
/*    */ 
/*    */   public List<Task> execute(CommandContext commandContext) {
/* 38 */     return Context.getCommandContext().getTaskEntityManager().findTasksByParentTaskId(this.parentTaskId);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetSubTasksCmd
 * JD-Core Version:    0.6.0
 */