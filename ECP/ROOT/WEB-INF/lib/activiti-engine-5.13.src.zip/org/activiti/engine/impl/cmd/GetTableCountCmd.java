/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Map;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.TableDataManager;
/*    */ 
/*    */ public class GetTableCountCmd
/*    */   implements Command<Map<String, Long>>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public Map<String, Long> execute(CommandContext commandContext)
/*    */   {
/* 30 */     return commandContext.getTableDataManager().getTableCount();
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetTableCountCmd
 * JD-Core Version:    0.6.0
 */