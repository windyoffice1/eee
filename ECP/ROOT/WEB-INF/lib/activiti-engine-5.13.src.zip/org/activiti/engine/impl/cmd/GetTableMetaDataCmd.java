/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.TableDataManager;
/*    */ import org.activiti.engine.management.TableMetaData;
/*    */ 
/*    */ public class GetTableMetaDataCmd
/*    */   implements Command<TableMetaData>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String tableName;
/*    */ 
/*    */   public GetTableMetaDataCmd(String tableName)
/*    */   {
/* 32 */     this.tableName = tableName;
/*    */   }
/*    */ 
/*    */   public TableMetaData execute(CommandContext commandContext) {
/* 36 */     if (this.tableName == null) {
/* 37 */       throw new ActivitiIllegalArgumentException("tableName is null");
/*    */     }
/* 39 */     return commandContext.getTableDataManager().getTableMetaData(this.tableName);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetTableMetaDataCmd
 * JD-Core Version:    0.6.0
 */