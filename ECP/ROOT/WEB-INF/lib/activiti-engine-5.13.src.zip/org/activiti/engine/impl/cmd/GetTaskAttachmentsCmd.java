/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.AttachmentEntityManager;
/*    */ import org.activiti.engine.task.Attachment;
/*    */ 
/*    */ public class GetTaskAttachmentsCmd
/*    */   implements Command<List<Attachment>>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String taskId;
/*    */ 
/*    */   public GetTaskAttachmentsCmd(String taskId)
/*    */   {
/* 33 */     this.taskId = taskId;
/*    */   }
/*    */ 
/*    */   public List<Attachment> execute(CommandContext commandContext) {
/* 37 */     return commandContext.getAttachmentEntityManager().findAttachmentsByTaskId(this.taskId);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetTaskAttachmentsCmd
 * JD-Core Version:    0.6.0
 */