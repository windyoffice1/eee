/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.CommentEntityManager;
/*    */ import org.activiti.engine.task.Comment;
/*    */ 
/*    */ public class GetTaskCommentsCmd
/*    */   implements Command<List<Comment>>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String taskId;
/*    */ 
/*    */   public GetTaskCommentsCmd(String taskId)
/*    */   {
/* 33 */     this.taskId = taskId;
/*    */   }
/*    */ 
/*    */   public List<Comment> execute(CommandContext commandContext) {
/* 37 */     return commandContext.getCommentEntityManager().findCommentsByTaskId(this.taskId);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetTaskCommentsCmd
 * JD-Core Version:    0.6.0
 */