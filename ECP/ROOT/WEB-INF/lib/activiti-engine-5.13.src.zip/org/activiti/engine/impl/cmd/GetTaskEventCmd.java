/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.CommentEntityManager;
/*    */ import org.activiti.engine.task.Event;
/*    */ 
/*    */ public class GetTaskEventCmd
/*    */   implements Command<Event>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String eventId;
/*    */ 
/*    */   public GetTaskEventCmd(String eventId)
/*    */   {
/* 33 */     this.eventId = eventId;
/*    */ 
/* 35 */     if (eventId == null)
/* 36 */       throw new ActivitiIllegalArgumentException("eventId is null");
/*    */   }
/*    */ 
/*    */   public Event execute(CommandContext commandContext)
/*    */   {
/* 41 */     return commandContext.getCommentEntityManager().findEvent(this.eventId);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetTaskEventCmd
 * JD-Core Version:    0.6.0
 */