/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.IdentityInfoEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.IdentityInfoEntityManager;
/*    */ 
/*    */ public class GetUserInfoCmd
/*    */   implements Command<String>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String userId;
/*    */   protected String key;
/*    */ 
/*    */   public GetUserInfoCmd(String userId, String key)
/*    */   {
/* 33 */     this.userId = userId;
/* 34 */     this.key = key;
/*    */   }
/*    */ 
/*    */   public String execute(CommandContext commandContext) {
/* 38 */     IdentityInfoEntity identityInfo = commandContext.getIdentityInfoEntityManager().findUserInfoByUserIdAndKey(this.userId, this.key);
/*    */ 
/* 42 */     return identityInfo != null ? identityInfo.getValue() : null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetUserInfoCmd
 * JD-Core Version:    0.6.0
 */