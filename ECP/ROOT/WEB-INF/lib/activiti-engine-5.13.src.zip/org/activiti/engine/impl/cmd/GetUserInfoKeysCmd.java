/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.IdentityInfoEntityManager;
/*    */ 
/*    */ public class GetUserInfoKeysCmd
/*    */   implements Command<List<String>>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String userId;
/*    */   protected String userInfoType;
/*    */ 
/*    */   public GetUserInfoKeysCmd(String userId, String userInfoType)
/*    */   {
/* 33 */     this.userId = userId;
/* 34 */     this.userInfoType = userInfoType;
/*    */   }
/*    */ 
/*    */   public List<String> execute(CommandContext commandContext) {
/* 38 */     return commandContext.getIdentityInfoEntityManager().findUserInfoKeysByUserIdAndType(this.userId, this.userInfoType);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetUserInfoKeysCmd
 * JD-Core Version:    0.6.0
 */