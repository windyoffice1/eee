/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.identity.Picture;
/*    */ import org.activiti.engine.identity.User;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.UserEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.UserIdentityManager;
/*    */ 
/*    */ public class GetUserPictureCmd
/*    */   implements Command<Picture>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String userId;
/*    */ 
/*    */   public GetUserPictureCmd(String userId)
/*    */   {
/* 36 */     this.userId = userId;
/*    */   }
/*    */ 
/*    */   public Picture execute(CommandContext commandContext) {
/* 40 */     if (this.userId == null) {
/* 41 */       throw new ActivitiIllegalArgumentException("userId is null");
/*    */     }
/* 43 */     UserEntity user = commandContext.getUserIdentityManager().findUserById(this.userId);
/*    */ 
/* 46 */     if (user == null) {
/* 47 */       throw new ActivitiObjectNotFoundException("user " + this.userId + " doesn't exist", User.class);
/*    */     }
/* 49 */     return user.getPicture();
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.GetUserPictureCmd
 * JD-Core Version:    0.6.0
 */