/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntityManager;
/*    */ import org.activiti.engine.runtime.Execution;
/*    */ 
/*    */ public class HasExecutionVariableCmd
/*    */   implements Command<Boolean>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String executionId;
/*    */   protected String variableName;
/*    */   protected boolean isLocal;
/*    */ 
/*    */   public HasExecutionVariableCmd(String executionId, String variableName, boolean isLocal)
/*    */   {
/* 36 */     this.executionId = executionId;
/* 37 */     this.variableName = variableName;
/* 38 */     this.isLocal = isLocal;
/*    */   }
/*    */ 
/*    */   public Boolean execute(CommandContext commandContext) {
/* 42 */     if (this.executionId == null) {
/* 43 */       throw new ActivitiIllegalArgumentException("executionId is null");
/*    */     }
/* 45 */     if (this.variableName == null) {
/* 46 */       throw new ActivitiIllegalArgumentException("variableName is null");
/*    */     }
/*    */ 
/* 49 */     ExecutionEntity execution = commandContext.getExecutionEntityManager().findExecutionById(this.executionId);
/*    */ 
/* 53 */     if (execution == null) {
/* 54 */       throw new ActivitiObjectNotFoundException("execution " + this.executionId + " doesn't exist", Execution.class);
/*    */     }
/*    */ 
/* 57 */     boolean hasVariable = false;
/*    */ 
/* 59 */     if (this.isLocal)
/* 60 */       hasVariable = execution.hasVariableLocal(this.variableName);
/*    */     else {
/* 62 */       hasVariable = execution.hasVariable(this.variableName);
/*    */     }
/*    */ 
/* 65 */     return Boolean.valueOf(hasVariable);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.HasExecutionVariableCmd
 * JD-Core Version:    0.6.0
 */