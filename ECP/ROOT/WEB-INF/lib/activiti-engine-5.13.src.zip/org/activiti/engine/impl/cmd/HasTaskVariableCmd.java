/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntityManager;
/*    */ import org.activiti.engine.task.Task;
/*    */ 
/*    */ public class HasTaskVariableCmd
/*    */   implements Command<Boolean>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String taskId;
/*    */   protected String variableName;
/*    */   protected boolean isLocal;
/*    */ 
/*    */   public HasTaskVariableCmd(String taskId, String variableName, boolean isLocal)
/*    */   {
/* 38 */     this.taskId = taskId;
/* 39 */     this.variableName = variableName;
/* 40 */     this.isLocal = isLocal;
/*    */   }
/*    */ 
/*    */   public Boolean execute(CommandContext commandContext) {
/* 44 */     if (this.taskId == null) {
/* 45 */       throw new ActivitiIllegalArgumentException("taskId is null");
/*    */     }
/* 47 */     if (this.variableName == null) {
/* 48 */       throw new ActivitiIllegalArgumentException("variableName is null");
/*    */     }
/*    */ 
/* 51 */     TaskEntity task = Context.getCommandContext().getTaskEntityManager().findTaskById(this.taskId);
/*    */ 
/* 56 */     if (task == null) {
/* 57 */       throw new ActivitiObjectNotFoundException("task " + this.taskId + " doesn't exist", Task.class);
/*    */     }
/* 59 */     boolean hasVariable = false;
/*    */ 
/* 61 */     if (this.isLocal)
/* 62 */       hasVariable = task.hasVariableLocal(this.variableName);
/*    */     else {
/* 64 */       hasVariable = task.hasVariable(this.variableName);
/*    */     }
/*    */ 
/* 67 */     return Boolean.valueOf(hasVariable);
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.HasTaskVariableCmd
 * JD-Core Version:    0.6.0
 */