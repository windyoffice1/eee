/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.EventSubscriptionEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.EventSubscriptionEntityManager;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ 
/*    */ public class MessageEventReceivedCmd extends NeedsActiveExecutionCmd<Void>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected final Map<String, Object> processVariables;
/*    */   protected final String messageName;
/*    */ 
/*    */   public MessageEventReceivedCmd(String messageName, String executionId, Map<String, Object> processVariables)
/*    */   {
/* 40 */     super(executionId);
/* 41 */     this.messageName = messageName;
/* 42 */     this.processVariables = processVariables;
/*    */   }
/*    */ 
/*    */   protected Void execute(CommandContext commandContext, ExecutionEntity execution) {
/* 46 */     if (this.messageName == null) {
/* 47 */       throw new ActivitiIllegalArgumentException("messageName cannot be null");
/*    */     }
/*    */ 
/* 50 */     List eventSubscriptions = commandContext.getEventSubscriptionEntityManager().findEventSubscriptionsByNameAndExecution("message", this.messageName, this.executionId);
/*    */ 
/* 53 */     if (eventSubscriptions.isEmpty()) {
/* 54 */       throw new ActivitiException("Execution with id '" + this.executionId + "' does not have a subscription to a message event with name '" + this.messageName + "'");
/*    */     }
/*    */ 
/* 58 */     EventSubscriptionEntity eventSubscriptionEntity = (EventSubscriptionEntity)eventSubscriptions.get(0);
/*    */ 
/* 60 */     HashMap payload = null;
/* 61 */     if (this.processVariables != null) {
/* 62 */       payload = new HashMap(this.processVariables);
/*    */     }
/*    */ 
/* 65 */     eventSubscriptionEntity.eventReceived(payload, false);
/*    */ 
/* 67 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.MessageEventReceivedCmd
 * JD-Core Version:    0.6.0
 */