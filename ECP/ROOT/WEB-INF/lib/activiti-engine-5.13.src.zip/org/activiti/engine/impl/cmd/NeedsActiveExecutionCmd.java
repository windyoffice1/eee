/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntityManager;
/*    */ import org.activiti.engine.runtime.Execution;
/*    */ 
/*    */ public abstract class NeedsActiveExecutionCmd<T>
/*    */   implements Command<T>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String executionId;
/*    */ 
/*    */   public NeedsActiveExecutionCmd(String executionId)
/*    */   {
/* 35 */     this.executionId = executionId;
/*    */   }
/*    */ 
/*    */   public T execute(CommandContext commandContext) {
/* 39 */     if (this.executionId == null) {
/* 40 */       throw new ActivitiIllegalArgumentException("executionId is null");
/*    */     }
/*    */ 
/* 43 */     ExecutionEntity execution = commandContext.getExecutionEntityManager().findExecutionById(this.executionId);
/*    */ 
/* 47 */     if (execution == null) {
/* 48 */       throw new ActivitiObjectNotFoundException("execution " + this.executionId + " doesn't exist", Execution.class);
/*    */     }
/*    */ 
/* 51 */     if (execution.isSuspended()) {
/* 52 */       throw new ActivitiException(getSuspendedExceptionMessage());
/*    */     }
/*    */ 
/* 55 */     return execute(commandContext, execution);
/*    */   }
/*    */ 
/*    */   protected abstract T execute(CommandContext paramCommandContext, ExecutionEntity paramExecutionEntity);
/*    */ 
/*    */   protected String getSuspendedExceptionMessage()
/*    */   {
/* 69 */     return "Cannot execution operation because execution '" + this.executionId + "' is suspended";
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.NeedsActiveExecutionCmd
 * JD-Core Version:    0.6.0
 */