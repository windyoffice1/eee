/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.deploy.DeploymentManager;
/*    */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*    */ import org.activiti.engine.repository.ProcessDefinition;
/*    */ 
/*    */ public abstract class NeedsActiveProcessDefinitionCmd<T>
/*    */   implements Command<T>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String processDefinitionId;
/*    */ 
/*    */   public NeedsActiveProcessDefinitionCmd(String processDefinitionId)
/*    */   {
/* 35 */     this.processDefinitionId = processDefinitionId;
/*    */   }
/*    */ 
/*    */   public T execute(CommandContext commandContext) {
/* 39 */     ProcessDefinitionEntity processDefinition = Context.getProcessEngineConfiguration().getDeploymentManager().findDeployedProcessDefinitionById(this.processDefinitionId);
/*    */ 
/* 44 */     if (processDefinition == null) {
/* 45 */       throw new ActivitiObjectNotFoundException("No process definition found for id = '" + this.processDefinitionId + "'", ProcessDefinition.class);
/*    */     }
/*    */ 
/* 48 */     if (processDefinition.isSuspended()) {
/* 49 */       throw new ActivitiException("Cannot execute operation because process definition '" + processDefinition.getName() + "' (id=" + processDefinition.getId() + ") is supended");
/*    */     }
/*    */ 
/* 53 */     return execute(commandContext, processDefinition);
/*    */   }
/*    */ 
/*    */   protected abstract T execute(CommandContext paramCommandContext, ProcessDefinitionEntity paramProcessDefinitionEntity);
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.NeedsActiveProcessDefinitionCmd
 * JD-Core Version:    0.6.0
 */