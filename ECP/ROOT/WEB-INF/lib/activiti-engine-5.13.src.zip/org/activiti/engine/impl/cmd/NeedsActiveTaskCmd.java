/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntityManager;
/*    */ import org.activiti.engine.task.Task;
/*    */ 
/*    */ public abstract class NeedsActiveTaskCmd<T>
/*    */   implements Command<T>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String taskId;
/*    */ 
/*    */   public NeedsActiveTaskCmd(String taskId)
/*    */   {
/* 39 */     this.taskId = taskId;
/*    */   }
/*    */ 
/*    */   public T execute(CommandContext commandContext)
/*    */   {
/* 44 */     if (this.taskId == null) {
/* 45 */       throw new ActivitiIllegalArgumentException("taskId is null");
/*    */     }
/*    */ 
/* 48 */     TaskEntity task = Context.getCommandContext().getTaskEntityManager().findTaskById(this.taskId);
/*    */ 
/* 53 */     if (task == null) {
/* 54 */       throw new ActivitiObjectNotFoundException("Cannot find task with id " + this.taskId, Task.class);
/*    */     }
/*    */ 
/* 57 */     if (task.isSuspended()) {
/* 58 */       throw new ActivitiException(getSuspendedTaskException());
/*    */     }
/*    */ 
/* 61 */     return execute(commandContext, task);
/*    */   }
/*    */ 
/*    */   protected abstract T execute(CommandContext paramCommandContext, TaskEntity paramTaskEntity);
/*    */ 
/*    */   protected String getSuspendedTaskException()
/*    */   {
/* 75 */     return "Cannot execute operation: task is suspended";
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.NeedsActiveTaskCmd
 * JD-Core Version:    0.6.0
 */