/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ 
/*    */ public class RemoveExecutionVariablesCmd extends NeedsActiveExecutionCmd<Void>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private Collection<String> variableNames;
/*    */   private boolean isLocal;
/*    */ 
/*    */   public RemoveExecutionVariablesCmd(String executionId, Collection<String> variableNames, boolean isLocal)
/*    */   {
/* 20 */     super(executionId);
/* 21 */     this.variableNames = variableNames;
/* 22 */     this.isLocal = isLocal;
/*    */   }
/*    */ 
/*    */   protected Void execute(CommandContext commandContext, ExecutionEntity execution)
/*    */   {
/* 27 */     if (this.isLocal)
/* 28 */       execution.removeVariablesLocal(this.variableNames);
/*    */     else {
/* 30 */       execution.removeVariables(this.variableNames);
/*    */     }
/*    */ 
/* 33 */     return null;
/*    */   }
/*    */ 
/*    */   protected String getSuspendedExceptionMessage()
/*    */   {
/* 38 */     return "Cannot remove variables because execution '" + this.executionId + "' is suspended";
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.RemoveExecutionVariablesCmd
 * JD-Core Version:    0.6.0
 */