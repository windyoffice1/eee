/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntity;
/*    */ 
/*    */ public class RemoveTaskVariablesCmd extends NeedsActiveTaskCmd<Void>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final Collection<String> variableNames;
/*    */   private final boolean isLocal;
/*    */ 
/*    */   public RemoveTaskVariablesCmd(String taskId, Collection<String> variableNames, boolean isLocal)
/*    */   {
/* 20 */     super(taskId);
/* 21 */     this.variableNames = variableNames;
/* 22 */     this.isLocal = isLocal;
/*    */   }
/*    */ 
/*    */   protected Void execute(CommandContext commandContext, TaskEntity task)
/*    */   {
/* 27 */     if (this.isLocal)
/* 28 */       task.removeVariablesLocal(this.variableNames);
/*    */     else {
/* 30 */       task.removeVariables(this.variableNames);
/*    */     }
/*    */ 
/* 33 */     return null;
/*    */   }
/*    */ 
/*    */   protected String getSuspendedTaskException()
/*    */   {
/* 38 */     return "Cannot remove variables from a suspended task.";
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.RemoveTaskVariablesCmd
 * JD-Core Version:    0.6.0
 */