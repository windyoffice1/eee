/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntity;
/*    */ 
/*    */ public class ResolveTaskCmd extends NeedsActiveTaskCmd<Void>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected Map<String, Object> variables;
/*    */ 
/*    */   public ResolveTaskCmd(String taskId, Map<String, Object> variables)
/*    */   {
/* 32 */     super(taskId);
/* 33 */     this.variables = variables;
/*    */   }
/*    */ 
/*    */   protected Void execute(CommandContext commandContext, TaskEntity task) {
/* 37 */     if (this.variables != null) {
/* 38 */       task.setVariables(this.variables);
/*    */     }
/* 40 */     task.resolve();
/* 41 */     return null;
/*    */   }
/*    */ 
/*    */   protected String getSuspendedTaskException()
/*    */   {
/* 46 */     return "Cannot resolve a suspended task";
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.ResolveTaskCmd
 * JD-Core Version:    0.6.0
 */