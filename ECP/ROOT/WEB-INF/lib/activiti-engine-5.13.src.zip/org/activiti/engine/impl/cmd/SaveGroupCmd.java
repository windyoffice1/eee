/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.GroupEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.GroupIdentityManager;
/*    */ 
/*    */ public class SaveGroupCmd
/*    */   implements Command<Void>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected GroupEntity group;
/*    */ 
/*    */   public SaveGroupCmd(GroupEntity group)
/*    */   {
/* 32 */     this.group = group;
/*    */   }
/*    */ 
/*    */   public Void execute(CommandContext commandContext) {
/* 36 */     if (this.group == null) {
/* 37 */       throw new ActivitiIllegalArgumentException("group is null");
/*    */     }
/* 39 */     if (this.group.getRevision() == 0) {
/* 40 */       commandContext.getGroupIdentityManager().insertGroup(this.group);
/*    */     }
/*    */     else
/*    */     {
/* 44 */       commandContext.getGroupIdentityManager().updateGroup(this.group);
/*    */     }
/*    */ 
/* 49 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.SaveGroupCmd
 * JD-Core Version:    0.6.0
 */