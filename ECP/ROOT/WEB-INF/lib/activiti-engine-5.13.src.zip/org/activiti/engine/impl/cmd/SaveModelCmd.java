/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.ModelEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ModelEntityManager;
/*    */ 
/*    */ public class SaveModelCmd
/*    */   implements Command<Void>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected ModelEntity model;
/*    */ 
/*    */   public SaveModelCmd(ModelEntity model)
/*    */   {
/* 32 */     this.model = model;
/*    */   }
/*    */ 
/*    */   public Void execute(CommandContext commandContext) {
/* 36 */     if (this.model == null) {
/* 37 */       throw new ActivitiIllegalArgumentException("model is null");
/*    */     }
/* 39 */     if (this.model.getId() == null)
/* 40 */       commandContext.getModelEntityManager().insertModel(this.model);
/*    */     else {
/* 42 */       commandContext.getModelEntityManager().updateModel(this.model);
/*    */     }
/* 44 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.SaveModelCmd
 * JD-Core Version:    0.6.0
 */