/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntity;
/*    */ import org.activiti.engine.task.Task;
/*    */ 
/*    */ public class SaveTaskCmd
/*    */   implements Command<Void>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected TaskEntity task;
/*    */ 
/*    */   public SaveTaskCmd(Task task)
/*    */   {
/* 33 */     this.task = ((TaskEntity)task);
/*    */   }
/*    */ 
/*    */   public Void execute(CommandContext commandContext) {
/* 37 */     if (this.task == null) {
/* 38 */       throw new ActivitiIllegalArgumentException("task is null");
/*    */     }
/*    */ 
/* 41 */     if (this.task.getRevision() == 0)
/* 42 */       this.task.insert(null);
/*    */     else {
/* 44 */       this.task.update();
/*    */     }
/*    */ 
/* 47 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.SaveTaskCmd
 * JD-Core Version:    0.6.0
 */