/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ 
/*    */ public class SetExecutionVariablesCmd extends NeedsActiveExecutionCmd<Object>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected Map<String, ? extends Object> variables;
/*    */   protected boolean isLocal;
/*    */ 
/*    */   public SetExecutionVariablesCmd(String executionId, Map<String, ? extends Object> variables, boolean isLocal)
/*    */   {
/* 33 */     super(executionId);
/* 34 */     this.variables = variables;
/* 35 */     this.isLocal = isLocal;
/*    */   }
/*    */ 
/*    */   protected Object execute(CommandContext commandContext, ExecutionEntity execution) {
/* 39 */     if (this.isLocal)
/* 40 */       execution.setVariablesLocal(this.variables);
/*    */     else {
/* 42 */       execution.setVariables(this.variables);
/*    */     }
/*    */ 
/* 45 */     return null;
/*    */   }
/*    */ 
/*    */   protected String getSuspendedExceptionMessage()
/*    */   {
/* 50 */     return "Cannot set variables because execution '" + this.executionId + "' is suspended";
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.SetExecutionVariablesCmd
 * JD-Core Version:    0.6.0
 */