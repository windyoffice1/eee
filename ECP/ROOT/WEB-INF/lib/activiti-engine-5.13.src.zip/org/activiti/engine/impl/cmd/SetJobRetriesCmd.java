/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.JobEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.JobEntityManager;
/*    */ import org.activiti.engine.runtime.Job;
/*    */ 
/*    */ public class SetJobRetriesCmd
/*    */   implements Command<Void>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final String jobId;
/*    */   private final int retries;
/*    */ 
/*    */   public SetJobRetriesCmd(String jobId, int retries)
/*    */   {
/* 37 */     if ((jobId == null) || (jobId.length() < 1)) {
/* 38 */       throw new ActivitiIllegalArgumentException("The job id is mandatory, but '" + jobId + "' has been provided.");
/*    */     }
/* 40 */     if (retries < 0) {
/* 41 */       throw new ActivitiIllegalArgumentException("The number of job retries must be a non-negative Integer, but '" + retries + "' has been provided.");
/*    */     }
/* 43 */     this.jobId = jobId;
/* 44 */     this.retries = retries;
/*    */   }
/*    */ 
/*    */   public Void execute(CommandContext commandContext) {
/* 48 */     JobEntity job = commandContext.getJobEntityManager().findJobById(this.jobId);
/*    */ 
/* 51 */     if (job != null)
/* 52 */       job.setRetries(this.retries);
/*    */     else {
/* 54 */       throw new ActivitiObjectNotFoundException("No job found with id '" + this.jobId + "'.", Job.class);
/*    */     }
/* 56 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.SetJobRetriesCmd
 * JD-Core Version:    0.6.0
 */