/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.deploy.DeploymentCache;
/*    */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntityManager;
/*    */ import org.activiti.engine.repository.ProcessDefinition;
/*    */ 
/*    */ public class SetProcessDefinitionCategoryCmd
/*    */   implements Command<Void>
/*    */ {
/*    */   protected String processDefinitionId;
/*    */   protected String category;
/*    */ 
/*    */   public SetProcessDefinitionCategoryCmd(String processDefinitionId, String category)
/*    */   {
/* 33 */     this.processDefinitionId = processDefinitionId;
/* 34 */     this.category = category;
/*    */   }
/*    */ 
/*    */   public Void execute(CommandContext commandContext)
/*    */   {
/* 39 */     if (this.processDefinitionId == null) {
/* 40 */       throw new ActivitiIllegalArgumentException("Process definition id is null");
/*    */     }
/*    */ 
/* 43 */     ProcessDefinitionEntity processDefinition = Context.getCommandContext().getProcessDefinitionEntityManager().findProcessDefinitionById(this.processDefinitionId);
/*    */ 
/* 48 */     if (processDefinition == null) {
/* 49 */       throw new ActivitiObjectNotFoundException("No process definition found for id = '" + this.processDefinitionId + "'", ProcessDefinition.class);
/*    */     }
/*    */ 
/* 53 */     processDefinition.setCategory(this.category);
/*    */ 
/* 56 */     DeploymentCache processDefinitionCache = Context.getProcessEngineConfiguration().getProcessDefinitionCache();
/*    */ 
/* 58 */     if (processDefinitionCache != null) {
/* 59 */       processDefinitionCache.remove(this.processDefinitionId);
/*    */     }
/*    */ 
/* 62 */     return null;
/*    */   }
/*    */ 
/*    */   public String getProcessDefinitionId() {
/* 66 */     return this.processDefinitionId;
/*    */   }
/*    */ 
/*    */   public void setProcessDefinitionId(String processDefinitionId) {
/* 70 */     this.processDefinitionId = processDefinitionId;
/*    */   }
/*    */ 
/*    */   public String getCategory() {
/* 74 */     return this.category;
/*    */   }
/*    */ 
/*    */   public void setCategory(String category) {
/* 78 */     this.category = category;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.SetProcessDefinitionCategoryCmd
 * JD-Core Version:    0.6.0
 */