/*     */ package org.activiti.engine.impl.cmd;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.List;
/*     */ import org.activiti.engine.ActivitiException;
/*     */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*     */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*     */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*     */ import org.activiti.engine.impl.context.Context;
/*     */ import org.activiti.engine.impl.history.HistoryManager;
/*     */ import org.activiti.engine.impl.interceptor.Command;
/*     */ import org.activiti.engine.impl.interceptor.CommandContext;
/*     */ import org.activiti.engine.impl.persistence.deploy.DeploymentManager;
/*     */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*     */ import org.activiti.engine.impl.persistence.entity.ExecutionEntityManager;
/*     */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*     */ import org.activiti.engine.impl.persistence.entity.TaskEntity;
/*     */ import org.activiti.engine.impl.persistence.entity.TaskEntityManager;
/*     */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*     */ import org.activiti.engine.impl.pvm.process.ProcessDefinitionImpl;
/*     */ import org.activiti.engine.runtime.ProcessInstance;
/*     */ 
/*     */ public class SetProcessDefinitionVersionCmd
/*     */   implements Command<Void>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final String processInstanceId;
/*     */   private final Integer processDefinitionVersion;
/*     */ 
/*     */   public SetProcessDefinitionVersionCmd(String processInstanceId, Integer processDefinitionVersion)
/*     */   {
/*  68 */     if ((processInstanceId == null) || (processInstanceId.length() < 1)) {
/*  69 */       throw new ActivitiIllegalArgumentException("The process instance id is mandatory, but '" + processInstanceId + "' has been provided.");
/*     */     }
/*  71 */     if (processDefinitionVersion == null) {
/*  72 */       throw new ActivitiIllegalArgumentException("The process definition version is mandatory, but 'null' has been provided.");
/*     */     }
/*  74 */     if (processDefinitionVersion.intValue() < 1) {
/*  75 */       throw new ActivitiIllegalArgumentException("The process definition version must be positive, but '" + processDefinitionVersion + "' has been provided.");
/*     */     }
/*  77 */     this.processInstanceId = processInstanceId;
/*  78 */     this.processDefinitionVersion = processDefinitionVersion;
/*     */   }
/*     */ 
/*     */   public Void execute(CommandContext commandContext)
/*     */   {
/*  84 */     ExecutionEntityManager executionManager = commandContext.getExecutionEntityManager();
/*  85 */     ExecutionEntity processInstance = executionManager.findExecutionById(this.processInstanceId);
/*  86 */     if (processInstance == null)
/*  87 */       throw new ActivitiObjectNotFoundException("No process instance found for id = '" + this.processInstanceId + "'.", ProcessInstance.class);
/*  88 */     if (!processInstance.isProcessInstanceType()) {
/*  89 */       throw new ActivitiIllegalArgumentException("A process instance id is required, but the provided id '" + this.processInstanceId + "' " + "points to a child execution of process instance " + "'" + processInstance.getProcessInstanceId() + "'. " + "Please invoke the " + getClass().getSimpleName() + " with a root execution id.");
/*     */     }
/*     */ 
/*  96 */     ProcessDefinitionImpl currentProcessDefinitionImpl = processInstance.getProcessDefinition();
/*     */ 
/*  98 */     DeploymentManager deploymentCache = Context.getProcessEngineConfiguration().getDeploymentManager();
/*     */     ProcessDefinitionEntity currentProcessDefinition;
/*     */     ProcessDefinitionEntity currentProcessDefinition;
/* 102 */     if ((currentProcessDefinitionImpl instanceof ProcessDefinitionEntity))
/* 103 */       currentProcessDefinition = (ProcessDefinitionEntity)currentProcessDefinitionImpl;
/*     */     else {
/* 105 */       currentProcessDefinition = deploymentCache.findDeployedProcessDefinitionById(currentProcessDefinitionImpl.getId());
/*     */     }
/*     */ 
/* 108 */     ProcessDefinitionEntity newProcessDefinition = deploymentCache.findDeployedProcessDefinitionByKeyAndVersion(currentProcessDefinition.getKey(), this.processDefinitionVersion);
/*     */ 
/* 111 */     validateAndSwitchVersionOfExecution(commandContext, processInstance, newProcessDefinition);
/*     */ 
/* 114 */     commandContext.getHistoryManager().recordProcessDefinitionChange(this.processInstanceId, newProcessDefinition.getId());
/*     */ 
/* 117 */     List childExecutions = executionManager.findChildExecutionsByParentExecutionId(this.processInstanceId);
/*     */ 
/* 119 */     for (ExecutionEntity executionEntity : childExecutions) {
/* 120 */       validateAndSwitchVersionOfExecution(commandContext, executionEntity, newProcessDefinition);
/*     */     }
/*     */ 
/* 123 */     return null;
/*     */   }
/*     */ 
/*     */   protected void validateAndSwitchVersionOfExecution(CommandContext commandContext, ExecutionEntity execution, ProcessDefinitionEntity newProcessDefinition)
/*     */   {
/* 128 */     if ((execution.getActivity() != null) && (!newProcessDefinition.contains(execution.getActivity()))) {
/* 129 */       throw new ActivitiException("The new process definition (key = '" + newProcessDefinition.getKey() + "') " + "does not contain the current activity " + "(id = '" + execution.getActivity().getId() + "') " + "of the process instance " + "(id = '" + this.processInstanceId + "').");
/*     */     }
/*     */ 
/* 139 */     execution.setProcessDefinition(newProcessDefinition);
/*     */ 
/* 142 */     List tasks = commandContext.getTaskEntityManager().findTasksByExecutionId(execution.getId());
/* 143 */     for (TaskEntity taskEntity : tasks)
/* 144 */       taskEntity.setProcessDefinitionId(newProcessDefinition.getId());
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.SetProcessDefinitionVersionCmd
 * JD-Core Version:    0.6.0
 */