/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.util.Date;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntity;
/*    */ 
/*    */ public class SetTaskDueDateCmd extends NeedsActiveTaskCmd<Void>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected Date dueDate;
/*    */ 
/*    */   public SetTaskDueDateCmd(String taskId, Date dueDate)
/*    */   {
/* 31 */     super(taskId);
/* 32 */     this.dueDate = dueDate;
/*    */   }
/*    */ 
/*    */   protected Void execute(CommandContext commandContext, TaskEntity task) {
/* 36 */     task.setDueDate(this.dueDate);
/* 37 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.SetTaskDueDateCmd
 * JD-Core Version:    0.6.0
 */