/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntity;
/*    */ 
/*    */ public class SetTaskPriorityCmd extends NeedsActiveTaskCmd<Void>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected int priority;
/*    */ 
/*    */   public SetTaskPriorityCmd(String taskId, int priority)
/*    */   {
/* 29 */     super(taskId);
/* 30 */     this.priority = priority;
/*    */   }
/*    */ 
/*    */   protected Void execute(CommandContext commandContext, TaskEntity task) {
/* 34 */     task.setPriority(this.priority);
/* 35 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.SetTaskPriorityCmd
 * JD-Core Version:    0.6.0
 */