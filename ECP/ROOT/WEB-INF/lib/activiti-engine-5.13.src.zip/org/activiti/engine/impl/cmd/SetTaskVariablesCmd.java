/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntity;
/*    */ 
/*    */ public class SetTaskVariablesCmd extends NeedsActiveTaskCmd<Object>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected Map<String, ? extends Object> variables;
/*    */   protected boolean isLocal;
/*    */ 
/*    */   public SetTaskVariablesCmd(String taskId, Map<String, ? extends Object> variables, boolean isLocal)
/*    */   {
/* 34 */     super(taskId);
/* 35 */     this.taskId = taskId;
/* 36 */     this.variables = variables;
/* 37 */     this.isLocal = isLocal;
/*    */   }
/*    */ 
/*    */   protected Object execute(CommandContext commandContext, TaskEntity task)
/*    */   {
/* 42 */     if (this.isLocal)
/* 43 */       task.setVariablesLocal(this.variables);
/*    */     else {
/* 45 */       task.setVariables(this.variables);
/*    */     }
/*    */ 
/* 48 */     return null;
/*    */   }
/*    */ 
/*    */   protected String getSuspendedTaskException()
/*    */   {
/* 53 */     return "Cannot add variables to a suspended task";
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.SetTaskVariablesCmd
 * JD-Core Version:    0.6.0
 */