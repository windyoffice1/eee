/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.identity.Picture;
/*    */ import org.activiti.engine.identity.User;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.UserEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.UserIdentityManager;
/*    */ 
/*    */ public class SetUserPictureCmd
/*    */   implements Command<Object>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String userId;
/*    */   protected Picture picture;
/*    */ 
/*    */   public SetUserPictureCmd(String userId, Picture picture)
/*    */   {
/* 38 */     this.userId = userId;
/* 39 */     this.picture = picture;
/*    */   }
/*    */ 
/*    */   public Object execute(CommandContext commandContext) {
/* 43 */     if (this.userId == null) {
/* 44 */       throw new ActivitiIllegalArgumentException("userId is null");
/*    */     }
/* 46 */     UserEntity user = commandContext.getUserIdentityManager().findUserById(this.userId);
/*    */ 
/* 49 */     if (user == null) {
/* 50 */       throw new ActivitiObjectNotFoundException("user " + this.userId + " doesn't exist", User.class);
/*    */     }
/* 52 */     user.setPicture(this.picture);
/* 53 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.SetUserPictureCmd
 * JD-Core Version:    0.6.0
 */