/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ 
/*    */ public class SignalCmd extends NeedsActiveExecutionCmd<Object>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String signalName;
/*    */   protected Object signalData;
/*    */   protected final Map<String, Object> processVariables;
/*    */ 
/*    */   public SignalCmd(String executionId, String signalName, Object signalData, Map<String, Object> processVariables)
/*    */   {
/* 34 */     super(executionId);
/* 35 */     this.signalName = signalName;
/* 36 */     this.signalData = signalData;
/* 37 */     this.processVariables = processVariables;
/*    */   }
/*    */ 
/*    */   protected Object execute(CommandContext commandContext, ExecutionEntity execution) {
/* 41 */     if (this.processVariables != null) {
/* 42 */       execution.setVariables(this.processVariables);
/*    */     }
/*    */ 
/* 45 */     execution.signal(this.signalName, this.signalData);
/* 46 */     return null;
/*    */   }
/*    */ 
/*    */   protected String getSuspendedExceptionMessage()
/*    */   {
/* 51 */     return "Cannot signal an execution that is suspended";
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.SignalCmd
 * JD-Core Version:    0.6.0
 */