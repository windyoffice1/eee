/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.EventSubscriptionEntityManager;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntityManager;
/*    */ import org.activiti.engine.impl.persistence.entity.SignalEventSubscriptionEntity;
/*    */ import org.activiti.engine.runtime.Execution;
/*    */ 
/*    */ public class SignalEventReceivedCmd
/*    */   implements Command<Void>
/*    */ {
/*    */   protected final String eventName;
/*    */   protected final String executionId;
/*    */   protected final Map<String, Object> variables;
/*    */ 
/*    */   public SignalEventReceivedCmd(String eventName, String executionId, Map<String, Object> variables)
/*    */   {
/* 40 */     this.eventName = eventName;
/* 41 */     this.executionId = executionId;
/* 42 */     this.variables = variables;
/*    */   }
/*    */ 
/*    */   public Void execute(CommandContext commandContext)
/*    */   {
/* 47 */     List signalEvents = null;
/*    */ 
/* 49 */     if (this.executionId == null) {
/* 50 */       signalEvents = commandContext.getEventSubscriptionEntityManager().findSignalEventSubscriptionsByEventName(this.eventName);
/*    */     }
/*    */     else
/*    */     {
/* 54 */       ExecutionEntity execution = commandContext.getExecutionEntityManager().findExecutionById(this.executionId);
/*    */ 
/* 56 */       if (execution == null) {
/* 57 */         throw new ActivitiObjectNotFoundException("Cannot find execution with id '" + this.executionId + "'", Execution.class);
/*    */       }
/*    */ 
/* 60 */       if (execution.isSuspended()) {
/* 61 */         throw new ActivitiException("Cannot throw signal event '" + this.eventName + "' because execution '" + this.executionId + "' is suspended");
/*    */       }
/*    */ 
/* 65 */       signalEvents = commandContext.getEventSubscriptionEntityManager().findSignalEventSubscriptionsByNameAndExecution(this.eventName, this.executionId);
/*    */ 
/* 68 */       if (signalEvents.isEmpty()) {
/* 69 */         throw new ActivitiException("Execution '" + this.executionId + "' has not subscribed to a signal event with name '" + this.eventName + "'.");
/*    */       }
/*    */     }
/*    */ 
/* 73 */     HashMap payload = null;
/* 74 */     if (this.variables != null) {
/* 75 */       payload = new HashMap(this.variables);
/*    */     }
/* 77 */     for (SignalEventSubscriptionEntity signalEventSubscriptionEntity : signalEvents)
/*    */     {
/* 80 */       if (signalEventSubscriptionEntity.isGlobalScoped()) {
/* 81 */         signalEventSubscriptionEntity.eventReceived(payload, false);
/*    */       }
/*    */     }
/*    */ 
/* 85 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.SignalEventReceivedCmd
 * JD-Core Version:    0.6.0
 */