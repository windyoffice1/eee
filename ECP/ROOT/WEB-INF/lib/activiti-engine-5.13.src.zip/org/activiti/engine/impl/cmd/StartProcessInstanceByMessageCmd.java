/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.deploy.DeploymentManager;
/*    */ import org.activiti.engine.impl.persistence.entity.EventSubscriptionEntityManager;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.MessageEventSubscriptionEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*    */ import org.activiti.engine.impl.pvm.process.ActivityImpl;
/*    */ import org.activiti.engine.repository.ProcessDefinition;
/*    */ import org.activiti.engine.runtime.ProcessInstance;
/*    */ 
/*    */ public class StartProcessInstanceByMessageCmd
/*    */   implements Command<ProcessInstance>
/*    */ {
/*    */   protected final String messageName;
/*    */   protected final String businessKey;
/*    */   protected final Map<String, Object> processVariables;
/*    */ 
/*    */   public StartProcessInstanceByMessageCmd(String messageName, String businessKey, Map<String, Object> processVariables)
/*    */   {
/* 43 */     this.messageName = messageName;
/* 44 */     this.businessKey = businessKey;
/* 45 */     this.processVariables = processVariables;
/*    */   }
/*    */ 
/*    */   public ProcessInstance execute(CommandContext commandContext)
/*    */   {
/* 50 */     if (this.messageName == null) {
/* 51 */       throw new ActivitiIllegalArgumentException("Cannot start process instance by message: message name is null");
/*    */     }
/*    */ 
/* 54 */     MessageEventSubscriptionEntity messageEventSubscription = commandContext.getEventSubscriptionEntityManager().findMessageStartEventSubscriptionByName(this.messageName);
/*    */ 
/* 57 */     if (messageEventSubscription == null) {
/* 58 */       throw new ActivitiObjectNotFoundException("Cannot start process instance by message: no subscription to message with name '" + this.messageName + "' found.", MessageEventSubscriptionEntity.class);
/*    */     }
/*    */ 
/* 61 */     String processDefinitionId = messageEventSubscription.getConfiguration();
/* 62 */     if (processDefinitionId == null) {
/* 63 */       throw new ActivitiException("Cannot start process instance by message: subscription to message with name '" + this.messageName + "' is not a message start event.");
/*    */     }
/*    */ 
/* 66 */     DeploymentManager deploymentCache = Context.getProcessEngineConfiguration().getDeploymentManager();
/*    */ 
/* 70 */     ProcessDefinitionEntity processDefinition = deploymentCache.findDeployedProcessDefinitionById(processDefinitionId);
/* 71 */     if (processDefinition == null) {
/* 72 */       throw new ActivitiObjectNotFoundException("No process definition found for id '" + processDefinitionId + "'", ProcessDefinition.class);
/*    */     }
/*    */ 
/* 75 */     ActivityImpl startActivity = processDefinition.findActivity(messageEventSubscription.getActivityId());
/* 76 */     ExecutionEntity processInstance = processDefinition.createProcessInstance(this.businessKey, startActivity);
/*    */ 
/* 78 */     if (this.processVariables != null) {
/* 79 */       processInstance.setVariables(this.processVariables);
/*    */     }
/*    */ 
/* 82 */     processInstance.start();
/*    */ 
/* 84 */     return processInstance;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.StartProcessInstanceByMessageCmd
 * JD-Core Version:    0.6.0
 */