/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Map;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.ActivitiIllegalArgumentException;
/*    */ import org.activiti.engine.ActivitiObjectNotFoundException;
/*    */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.deploy.DeploymentManager;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*    */ import org.activiti.engine.repository.ProcessDefinition;
/*    */ import org.activiti.engine.runtime.ProcessInstance;
/*    */ 
/*    */ public class StartProcessInstanceCmd<T>
/*    */   implements Command<ProcessInstance>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String processDefinitionKey;
/*    */   protected String processDefinitionId;
/*    */   protected Map<String, Object> variables;
/*    */   protected String businessKey;
/*    */ 
/*    */   public StartProcessInstanceCmd(String processDefinitionKey, String processDefinitionId, String businessKey, Map<String, Object> variables)
/*    */   {
/* 45 */     this.processDefinitionKey = processDefinitionKey;
/* 46 */     this.processDefinitionId = processDefinitionId;
/* 47 */     this.businessKey = businessKey;
/* 48 */     this.variables = variables;
/*    */   }
/*    */ 
/*    */   public ProcessInstance execute(CommandContext commandContext) {
/* 52 */     DeploymentManager deploymentCache = Context.getProcessEngineConfiguration().getDeploymentManager();
/*    */ 
/* 57 */     ProcessDefinitionEntity processDefinition = null;
/* 58 */     if (this.processDefinitionId != null) {
/* 59 */       processDefinition = deploymentCache.findDeployedProcessDefinitionById(this.processDefinitionId);
/* 60 */       if (processDefinition == null)
/* 61 */         throw new ActivitiObjectNotFoundException("No process definition found for id = '" + this.processDefinitionId + "'", ProcessDefinition.class);
/*    */     }
/* 63 */     else if (this.processDefinitionKey != null) {
/* 64 */       processDefinition = deploymentCache.findDeployedLatestProcessDefinitionByKey(this.processDefinitionKey);
/* 65 */       if (processDefinition == null)
/* 66 */         throw new ActivitiObjectNotFoundException("No process definition found for key '" + this.processDefinitionKey + "'", ProcessDefinition.class);
/*    */     }
/*    */     else {
/* 69 */       throw new ActivitiIllegalArgumentException("processDefinitionKey and processDefinitionId are null");
/*    */     }
/*    */ 
/* 73 */     if (processDefinition.isSuspended()) {
/* 74 */       throw new ActivitiException("Cannot start process instance. Process definition " + processDefinition.getName() + " (id = " + processDefinition.getId() + ") is suspended");
/*    */     }
/*    */ 
/* 79 */     ExecutionEntity processInstance = processDefinition.createProcessInstance(this.businessKey);
/* 80 */     if (this.variables != null) {
/* 81 */       processInstance.setVariables(this.variables);
/*    */     }
/* 83 */     processInstance.start();
/*    */ 
/* 85 */     return processInstance;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.StartProcessInstanceCmd
 * JD-Core Version:    0.6.0
 */