/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.activiti.engine.impl.form.StartFormHandler;
/*    */ import org.activiti.engine.impl.history.HistoryManager;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*    */ import org.activiti.engine.runtime.ProcessInstance;
/*    */ 
/*    */ public class SubmitStartFormCmd extends NeedsActiveProcessDefinitionCmd<ProcessInstance>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected final String businessKey;
/*    */   protected Map<String, String> properties;
/*    */ 
/*    */   public SubmitStartFormCmd(String processDefinitionId, String businessKey, Map<String, String> properties)
/*    */   {
/* 38 */     super(processDefinitionId);
/* 39 */     this.businessKey = businessKey;
/* 40 */     this.properties = properties;
/*    */   }
/*    */ 
/*    */   protected ProcessInstance execute(CommandContext commandContext, ProcessDefinitionEntity processDefinition) {
/* 44 */     ExecutionEntity processInstance = null;
/* 45 */     if (this.businessKey != null)
/* 46 */       processInstance = processDefinition.createProcessInstance(this.businessKey);
/*    */     else {
/* 48 */       processInstance = processDefinition.createProcessInstance();
/*    */     }
/*    */ 
/* 51 */     commandContext.getHistoryManager().reportFormPropertiesSubmitted(processInstance, this.properties, null);
/*    */ 
/* 54 */     StartFormHandler startFormHandler = processDefinition.getStartFormHandler();
/* 55 */     startFormHandler.submitFormProperties(this.properties, processInstance);
/*    */ 
/* 57 */     processInstance.start();
/*    */ 
/* 59 */     return processInstance;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.SubmitStartFormCmd
 * JD-Core Version:    0.6.0
 */