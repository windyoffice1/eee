/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.activiti.engine.impl.form.TaskFormHandler;
/*    */ import org.activiti.engine.impl.history.HistoryManager;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.TaskEntity;
/*    */ import org.activiti.engine.impl.task.TaskDefinition;
/*    */ 
/*    */ public class SubmitTaskFormCmd extends NeedsActiveTaskCmd<Object>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String taskId;
/*    */   protected Map<String, String> properties;
/*    */ 
/*    */   public SubmitTaskFormCmd(String taskId, Map<String, String> properties)
/*    */   {
/* 35 */     super(taskId);
/* 36 */     this.taskId = taskId;
/* 37 */     this.properties = properties;
/*    */   }
/*    */ 
/*    */   protected Object execute(CommandContext commandContext, TaskEntity task) {
/* 41 */     commandContext.getHistoryManager().reportFormPropertiesSubmitted(task.getExecution(), this.properties, this.taskId);
/*    */ 
/* 44 */     TaskFormHandler taskFormHandler = task.getTaskDefinition().getTaskFormHandler();
/* 45 */     taskFormHandler.submitFormProperties(this.properties, task.getExecution());
/*    */ 
/* 47 */     task.complete();
/*    */ 
/* 49 */     return null;
/*    */   }
/*    */ 
/*    */   protected String getSuspendedTaskException()
/*    */   {
/* 54 */     return "Cannot submit a form to a suspended task";
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.SubmitTaskFormCmd
 * JD-Core Version:    0.6.0
 */