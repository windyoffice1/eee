/*    */ package org.activiti.engine.impl.cmd;
/*    */ 
/*    */ import org.activiti.engine.impl.persistence.entity.SuspensionState;
/*    */ 
/*    */ public class SuspendProcessInstanceCmd extends AbstractSetProcessInstanceStateCmd
/*    */ {
/*    */   public SuspendProcessInstanceCmd(String executionId)
/*    */   {
/* 24 */     super(executionId);
/*    */   }
/*    */ 
/*    */   protected SuspensionState getNewState()
/*    */   {
/* 29 */     return SuspensionState.SUSPENDED;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.cmd.SuspendProcessInstanceCmd
 * JD-Core Version:    0.6.0
 */