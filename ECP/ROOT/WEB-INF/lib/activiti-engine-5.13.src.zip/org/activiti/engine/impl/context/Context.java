/*    */ package org.activiti.engine.impl.context;
/*    */ 
/*    */ import java.util.Stack;
/*    */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.jobexecutor.JobExecutorContext;
/*    */ import org.activiti.engine.impl.pvm.runtime.InterpretableExecution;
/*    */ 
/*    */ public class Context
/*    */ {
/* 30 */   protected static ThreadLocal<Stack<CommandContext>> commandContextThreadLocal = new ThreadLocal();
/* 31 */   protected static ThreadLocal<Stack<ProcessEngineConfigurationImpl>> processEngineConfigurationStackThreadLocal = new ThreadLocal();
/* 32 */   protected static ThreadLocal<Stack<ExecutionContext>> executionContextStackThreadLocal = new ThreadLocal();
/* 33 */   protected static ThreadLocal<JobExecutorContext> jobExecutorContextThreadLocal = new ThreadLocal();
/*    */ 
/*    */   public static CommandContext getCommandContext() {
/* 36 */     Stack stack = getStack(commandContextThreadLocal);
/* 37 */     if (stack.isEmpty()) {
/* 38 */       return null;
/*    */     }
/* 40 */     return (CommandContext)stack.peek();
/*    */   }
/*    */ 
/*    */   public static void setCommandContext(CommandContext commandContext) {
/* 44 */     getStack(commandContextThreadLocal).push(commandContext);
/*    */   }
/*    */ 
/*    */   public static void removeCommandContext() {
/* 48 */     getStack(commandContextThreadLocal).pop();
/*    */   }
/*    */ 
/*    */   public static ProcessEngineConfigurationImpl getProcessEngineConfiguration() {
/* 52 */     Stack stack = getStack(processEngineConfigurationStackThreadLocal);
/* 53 */     if (stack.isEmpty()) {
/* 54 */       return null;
/*    */     }
/* 56 */     return (ProcessEngineConfigurationImpl)stack.peek();
/*    */   }
/*    */ 
/*    */   public static void setProcessEngineConfiguration(ProcessEngineConfigurationImpl processEngineConfiguration) {
/* 60 */     getStack(processEngineConfigurationStackThreadLocal).push(processEngineConfiguration);
/*    */   }
/*    */ 
/*    */   public static void removeProcessEngineConfiguration() {
/* 64 */     getStack(processEngineConfigurationStackThreadLocal).pop();
/*    */   }
/*    */ 
/*    */   public static ExecutionContext getExecutionContext() {
/* 68 */     return (ExecutionContext)getStack(executionContextStackThreadLocal).peek();
/*    */   }
/*    */ 
/*    */   public static void setExecutionContext(InterpretableExecution execution) {
/* 72 */     getStack(executionContextStackThreadLocal).push(new ExecutionContext(execution));
/*    */   }
/*    */ 
/*    */   public static void removeExecutionContext() {
/* 76 */     getStack(executionContextStackThreadLocal).pop();
/*    */   }
/*    */ 
/*    */   protected static <T> Stack<T> getStack(ThreadLocal<Stack<T>> threadLocal) {
/* 80 */     Stack stack = (Stack)threadLocal.get();
/* 81 */     if (stack == null) {
/* 82 */       stack = new Stack();
/* 83 */       threadLocal.set(stack);
/*    */     }
/* 85 */     return stack;
/*    */   }
/*    */ 
/*    */   public static JobExecutorContext getJobExecutorContext() {
/* 89 */     return (JobExecutorContext)jobExecutorContextThreadLocal.get();
/*    */   }
/*    */ 
/*    */   public static void setJobExecutorContext(JobExecutorContext jobExecutorContext) {
/* 93 */     jobExecutorContextThreadLocal.set(jobExecutorContext);
/*    */   }
/*    */ 
/*    */   public static void removeJobExecutorContext() {
/* 97 */     jobExecutorContextThreadLocal.remove();
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.context.Context
 * JD-Core Version:    0.6.0
 */