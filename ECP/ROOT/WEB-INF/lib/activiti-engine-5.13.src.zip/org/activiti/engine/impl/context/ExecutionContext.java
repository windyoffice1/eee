/*    */ package org.activiti.engine.impl.context;
/*    */ 
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.persistence.entity.DeploymentEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.DeploymentEntityManager;
/*    */ import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
/*    */ import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
/*    */ import org.activiti.engine.impl.pvm.runtime.InterpretableExecution;
/*    */ 
/*    */ public class ExecutionContext
/*    */ {
/*    */   protected ExecutionEntity execution;
/*    */ 
/*    */   public ExecutionContext(InterpretableExecution execution)
/*    */   {
/* 30 */     this.execution = ((ExecutionEntity)execution);
/*    */   }
/*    */ 
/*    */   public ExecutionEntity getExecution() {
/* 34 */     return this.execution;
/*    */   }
/*    */ 
/*    */   public ExecutionEntity getProcessInstance() {
/* 38 */     return this.execution.getProcessInstance();
/*    */   }
/*    */ 
/*    */   public ProcessDefinitionEntity getProcessDefinition() {
/* 42 */     return (ProcessDefinitionEntity)this.execution.getProcessDefinition();
/*    */   }
/*    */ 
/*    */   public DeploymentEntity getDeployment() {
/* 46 */     String deploymentId = getProcessDefinition().getDeploymentId();
/* 47 */     DeploymentEntity deployment = Context.getCommandContext().getDeploymentEntityManager().findDeploymentById(deploymentId);
/*    */ 
/* 51 */     return deployment;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.context.ExecutionContext
 * JD-Core Version:    0.6.0
 */