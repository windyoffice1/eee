/*    */ package org.activiti.engine.impl.db;
/*    */ 
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.interceptor.Session;
/*    */ 
/*    */ public abstract class AbstractDbSession
/*    */   implements Session
/*    */ {
/*    */   protected DbSqlSession dbSqlSession;
/*    */ 
/*    */   public AbstractDbSession()
/*    */   {
/* 28 */     this.dbSqlSession = ((DbSqlSession)Context.getCommandContext().getSession(DbSqlSession.class));
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.db.AbstractDbSession
 * JD-Core Version:    0.6.0
 */