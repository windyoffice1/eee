/*    */ package org.activiti.engine.impl.db;
/*    */ 
/*    */ import org.activiti.engine.impl.cfg.IdGenerator;
/*    */ import org.activiti.engine.impl.cmd.GetNextIdBlockCmd;
/*    */ import org.activiti.engine.impl.interceptor.CommandExecutor;
/*    */ 
/*    */ public class DbIdGenerator
/*    */   implements IdGenerator
/*    */ {
/*    */   protected int idBlockSize;
/* 27 */   protected long nextId = 0L;
/* 28 */   protected long lastId = -1L;
/*    */   protected CommandExecutor commandExecutor;
/*    */ 
/*    */   public synchronized String getNextId()
/*    */   {
/* 33 */     if (this.lastId < this.nextId) {
/* 34 */       getNewBlock();
/*    */     }
/* 36 */     long _nextId = this.nextId++;
/* 37 */     return Long.toString(_nextId);
/*    */   }
/*    */ 
/*    */   protected synchronized void getNewBlock() {
/* 41 */     IdBlock idBlock = (IdBlock)this.commandExecutor.execute(new GetNextIdBlockCmd(this.idBlockSize));
/* 42 */     this.nextId = idBlock.getNextId();
/* 43 */     this.lastId = idBlock.getLastId();
/*    */   }
/*    */ 
/*    */   public int getIdBlockSize() {
/* 47 */     return this.idBlockSize;
/*    */   }
/*    */ 
/*    */   public void setIdBlockSize(int idBlockSize) {
/* 51 */     this.idBlockSize = idBlockSize;
/*    */   }
/*    */ 
/*    */   public CommandExecutor getCommandExecutor() {
/* 55 */     return this.commandExecutor;
/*    */   }
/*    */ 
/*    */   public void setCommandExecutor(CommandExecutor commandExecutor) {
/* 59 */     this.commandExecutor = commandExecutor;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.db.DbIdGenerator
 * JD-Core Version:    0.6.0
 */