/*    */ package org.activiti.engine.impl.db;
/*    */ 
/*    */ import org.activiti.engine.ProcessEngineConfiguration;
/*    */ 
/*    */ public class DbSchemaCreate
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 26 */     ProcessEngineConfiguration.createProcessEngineConfigurationFromResourceDefault().setDatabaseSchemaUpdate("create").buildProcessEngine();
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.db.DbSchemaCreate
 * JD-Core Version:    0.6.0
 */