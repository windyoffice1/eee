/*    */ package org.activiti.engine.impl.db;
/*    */ 
/*    */ import org.activiti.engine.ProcessEngines;
/*    */ import org.activiti.engine.impl.ProcessEngineImpl;
/*    */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*    */ import org.activiti.engine.impl.interceptor.Command;
/*    */ import org.activiti.engine.impl.interceptor.CommandContext;
/*    */ import org.activiti.engine.impl.interceptor.CommandExecutor;
/*    */ 
/*    */ public class DbSchemaDrop
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 29 */     ProcessEngineImpl processEngine = (ProcessEngineImpl)ProcessEngines.getDefaultProcessEngine();
/* 30 */     CommandExecutor commandExecutor = processEngine.getProcessEngineConfiguration().getCommandExecutorTxRequired();
/* 31 */     commandExecutor.execute(new Command() {
/*    */       public Object execute(CommandContext commandContext) {
/* 33 */         ((DbSqlSession)commandContext.getSession(DbSqlSession.class)).dbSchemaDrop();
/*    */ 
/* 36 */         return null;
/*    */       }
/*    */     });
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.db.DbSchemaDrop
 * JD-Core Version:    0.6.0
 */