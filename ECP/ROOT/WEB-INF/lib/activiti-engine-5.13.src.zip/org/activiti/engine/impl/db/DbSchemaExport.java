/*    */ package org.activiti.engine.impl.db;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.PrintStream;
/*    */ import java.sql.Connection;
/*    */ import java.sql.DatabaseMetaData;
/*    */ import java.sql.DriverManager;
/*    */ import java.sql.ResultSet;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Properties;
/*    */ import java.util.SortedSet;
/*    */ import java.util.TreeSet;
/*    */ 
/*    */ public class DbSchemaExport
/*    */ {
/*    */   public static void main(String[] args)
/*    */     throws Exception
/*    */   {
/* 34 */     if ((args == null) || (args.length != 1)) {
/* 35 */       System.err.println("Syntax: java -cp ... org.activiti.engine.impl.db.DbSchemaExport <path-to-properties-file> <path-to-export-file>");
/* 36 */       return;
/*    */     }
/* 38 */     File propertiesFile = new File(args[0]);
/* 39 */     if (!propertiesFile.exists()) {
/* 40 */       System.err.println("File '" + args[0] + "' doesn't exist \n" + "Syntax: java -cp ... org.activiti.engine.impl.db.DbSchemaExport <path-to-properties-file> <path-to-export-file>\n");
/*    */ 
/* 42 */       return;
/*    */     }
/* 44 */     Properties properties = new Properties();
/* 45 */     properties.load(new FileInputStream(propertiesFile));
/*    */ 
/* 47 */     String jdbcDriver = properties.getProperty("jdbc.driver");
/* 48 */     String jdbcUrl = properties.getProperty("jdbc.url");
/* 49 */     String jdbcUsername = properties.getProperty("jdbc.username");
/* 50 */     String jdbcPassword = properties.getProperty("jdbc.password");
/*    */ 
/* 52 */     Class.forName(jdbcDriver);
/* 53 */     Connection connection = DriverManager.getConnection(jdbcUrl, jdbcUsername, jdbcPassword);
/*    */     try {
/* 55 */       meta = connection.getMetaData();
/*    */ 
/* 57 */       SortedSet tableNames = new TreeSet();
/* 58 */       ResultSet tables = meta.getTables(null, null, null, null);
/* 59 */       while (tables.next()) {
/* 60 */         String tableName = tables.getString(3);
/* 61 */         tableNames.add(tableName);
/*    */       }
/*    */ 
/* 64 */       System.out.println("TABLES");
/* 65 */       for (String tableName : tableNames) {
/* 66 */         Map columnDescriptions = new HashMap();
/* 67 */         ResultSet columns = meta.getColumns(null, null, tableName, null);
/* 68 */         while (columns.next()) {
/* 69 */           String columnName = columns.getString(4);
/* 70 */           String columnTypeAndSize = columns.getString(6) + " " + columns.getInt(7);
/* 71 */           columnDescriptions.put(columnName, columnTypeAndSize);
/*    */         }
/*    */ 
/* 74 */         System.out.println(tableName);
/* 75 */         for (String columnName : new TreeSet(columnDescriptions.keySet())) {
/* 76 */           System.out.println("  " + columnName + " " + (String)columnDescriptions.get(columnName));
/*    */         }
/*    */ 
/* 79 */         System.out.println("INDEXES");
/* 80 */         SortedSet indexNames = new TreeSet();
/* 81 */         ResultSet indexes = meta.getIndexInfo(null, null, tableName, false, true);
/* 82 */         while (indexes.next()) {
/* 83 */           String indexName = indexes.getString(6);
/* 84 */           indexNames.add(indexName);
/*    */         }
/* 86 */         for (String indexName : indexNames) {
/* 87 */           System.out.println(indexName);
/*    */         }
/* 89 */         System.out.println();
/*    */       }
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/*    */       DatabaseMetaData meta;
/* 94 */       e.printStackTrace();
/* 95 */       connection.close();
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.db.DbSchemaExport
 * JD-Core Version:    0.6.0
 */