/*      */ package org.activiti.engine.impl.db;
/*      */ 
/*      */ import java.io.BufferedReader;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.StringReader;
/*      */ import java.sql.Connection;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import org.activiti.engine.ActivitiException;
/*      */ import org.activiti.engine.ActivitiOptimisticLockingException;
/*      */ import org.activiti.engine.ActivitiWrongDbException;
/*      */ import org.activiti.engine.impl.DeploymentQueryImpl;
/*      */ import org.activiti.engine.impl.ExecutionQueryImpl;
/*      */ import org.activiti.engine.impl.GroupQueryImpl;
/*      */ import org.activiti.engine.impl.HistoricActivityInstanceQueryImpl;
/*      */ import org.activiti.engine.impl.HistoricDetailQueryImpl;
/*      */ import org.activiti.engine.impl.HistoricProcessInstanceQueryImpl;
/*      */ import org.activiti.engine.impl.HistoricTaskInstanceQueryImpl;
/*      */ import org.activiti.engine.impl.HistoricVariableInstanceQueryImpl;
/*      */ import org.activiti.engine.impl.JobQueryImpl;
/*      */ import org.activiti.engine.impl.ModelQueryImpl;
/*      */ import org.activiti.engine.impl.Page;
/*      */ import org.activiti.engine.impl.ProcessDefinitionQueryImpl;
/*      */ import org.activiti.engine.impl.ProcessInstanceQueryImpl;
/*      */ import org.activiti.engine.impl.TaskQueryImpl;
/*      */ import org.activiti.engine.impl.UserQueryImpl;
/*      */ import org.activiti.engine.impl.cfg.IdGenerator;
/*      */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*      */ import org.activiti.engine.impl.context.Context;
/*      */ import org.activiti.engine.impl.db.upgrade.DbUpgradeStep;
/*      */ import org.activiti.engine.impl.history.HistoryLevel;
/*      */ import org.activiti.engine.impl.interceptor.Session;
/*      */ import org.activiti.engine.impl.persistence.entity.PropertyEntity;
/*      */ import org.activiti.engine.impl.persistence.entity.VariableInstanceEntity;
/*      */ import org.activiti.engine.impl.util.IoUtil;
/*      */ import org.activiti.engine.impl.util.ReflectUtil;
/*      */ import org.activiti.engine.impl.variable.DeserializedObject;
/*      */ import org.apache.ibatis.session.SqlSession;
/*      */ import org.apache.ibatis.session.SqlSessionFactory;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ 
/*      */ public class DbSqlSession
/*      */   implements Session
/*      */ {
/*   78 */   private static final Logger log = LoggerFactory.getLogger(DbSqlSession.class);
/*      */ 
/*   80 */   private static final Pattern CLEAN_VERSION_REGEX = Pattern.compile("\\d\\.\\d*");
/*      */   protected SqlSession sqlSession;
/*      */   protected DbSqlSessionFactory dbSqlSessionFactory;
/*   84 */   protected List<PersistentObject> insertedObjects = new ArrayList();
/*   85 */   protected List<PersistentObject> updatedObjects = new ArrayList();
/*   86 */   protected Map<Class<?>, Map<String, CachedObject>> cachedObjects = new HashMap();
/*   87 */   protected List<DeleteOperation> deleteOperations = new ArrayList();
/*   88 */   protected List<DeserializedObject> deserializedObjects = new ArrayList();
/*      */   protected String connectionMetadataDefaultCatalog;
/*      */   protected String connectionMetadataDefaultSchema;
/*  699 */   public static String[] JDBC_METADATA_TABLE_TYPES = { "TABLE" };
/*      */ 
/*      */   public DbSqlSession(DbSqlSessionFactory dbSqlSessionFactory)
/*      */   {
/*   93 */     this.dbSqlSessionFactory = dbSqlSessionFactory;
/*   94 */     this.sqlSession = dbSqlSessionFactory.getSqlSessionFactory().openSession();
/*      */   }
/*      */ 
/*      */   public DbSqlSession(DbSqlSessionFactory dbSqlSessionFactory, Connection connection, String catalog, String schema)
/*      */   {
/*  100 */     this.dbSqlSessionFactory = dbSqlSessionFactory;
/*  101 */     this.sqlSession = dbSqlSessionFactory.getSqlSessionFactory().openSession(connection);
/*      */ 
/*  104 */     this.connectionMetadataDefaultCatalog = catalog;
/*  105 */     this.connectionMetadataDefaultSchema = schema;
/*      */   }
/*      */ 
/*      */   public void insert(PersistentObject persistentObject)
/*      */   {
/*  111 */     if (persistentObject.getId() == null) {
/*  112 */       String id = this.dbSqlSessionFactory.getIdGenerator().getNextId();
/*  113 */       persistentObject.setId(id);
/*      */     }
/*  115 */     this.insertedObjects.add(persistentObject);
/*  116 */     cachePut(persistentObject, false);
/*      */   }
/*      */ 
/*      */   public void update(PersistentObject persistentObject)
/*      */   {
/*  122 */     this.updatedObjects.add(persistentObject);
/*  123 */     cachePut(persistentObject, false);
/*      */   }
/*      */ 
/*      */   public void delete(String statement, Object parameter)
/*      */   {
/*  129 */     this.deleteOperations.add(new BulkDeleteOperation(statement, parameter));
/*      */   }
/*      */ 
/*      */   public void delete(PersistentObject persistentObject) {
/*  133 */     for (DeleteOperation deleteOperation : this.deleteOperations) {
/*  134 */       if (deleteOperation.sameIdentity(persistentObject)) {
/*  135 */         log.debug("skipping redundant delete: {}", persistentObject);
/*  136 */         return;
/*      */       }
/*      */     }
/*      */ 
/*  140 */     this.deleteOperations.add(new CheckedDeleteOperation(persistentObject));
/*      */   }
/*      */ 
/*      */   public List selectList(String statement)
/*      */   {
/*  246 */     return selectList(statement, null, 0, 2147483647);
/*      */   }
/*      */ 
/*      */   public List selectList(String statement, Object parameter)
/*      */   {
/*  251 */     return selectList(statement, parameter, 0, 2147483647);
/*      */   }
/*      */ 
/*      */   public List selectList(String statement, Object parameter, Page page)
/*      */   {
/*  256 */     if (page != null) {
/*  257 */       return selectList(statement, parameter, page.getFirstResult(), page.getMaxResults());
/*      */     }
/*  259 */     return selectList(statement, parameter, 0, 2147483647);
/*      */   }
/*      */ 
/*      */   public List selectList(String statement, ListQueryParameterObject parameter, Page page)
/*      */   {
/*  265 */     return selectList(statement, parameter);
/*      */   }
/*      */ 
/*      */   public List selectList(String statement, Object parameter, int firstResult, int maxResults)
/*      */   {
/*  270 */     return selectList(statement, new ListQueryParameterObject(parameter, firstResult, maxResults));
/*      */   }
/*      */ 
/*      */   public List selectList(String statement, ListQueryParameterObject parameter)
/*      */   {
/*  275 */     return selectListWithRawParameter(statement, parameter, parameter.getFirstResult(), parameter.getMaxResults());
/*      */   }
/*      */ 
/*      */   public List selectListWithRawParameter(String statement, Object parameter, int firstResult, int maxResults)
/*      */   {
/*  280 */     statement = this.dbSqlSessionFactory.mapStatement(statement);
/*  281 */     if ((firstResult == -1) || (maxResults == -1)) {
/*  282 */       return Collections.EMPTY_LIST;
/*      */     }
/*  284 */     List loadedObjects = this.sqlSession.selectList(statement, parameter);
/*  285 */     return filterLoadedObjects(loadedObjects);
/*      */   }
/*      */ 
/*      */   public Object selectOne(String statement, Object parameter) {
/*  289 */     statement = this.dbSqlSessionFactory.mapStatement(statement);
/*  290 */     Object result = this.sqlSession.selectOne(statement, parameter);
/*  291 */     if ((result instanceof PersistentObject)) {
/*  292 */       PersistentObject loadedObject = (PersistentObject)result;
/*  293 */       result = cacheFilter(loadedObject);
/*      */     }
/*  295 */     return result;
/*      */   }
/*      */ 
/*      */   public <T extends PersistentObject> T selectById(Class<T> entityClass, String id)
/*      */   {
/*  300 */     PersistentObject persistentObject = (PersistentObject)cacheGet(entityClass, id);
/*  301 */     if (persistentObject != null) {
/*  302 */       return persistentObject;
/*      */     }
/*  304 */     String selectStatement = this.dbSqlSessionFactory.getSelectStatement(entityClass);
/*  305 */     selectStatement = this.dbSqlSessionFactory.mapStatement(selectStatement);
/*  306 */     persistentObject = (PersistentObject)this.sqlSession.selectOne(selectStatement, id);
/*  307 */     if (persistentObject == null) {
/*  308 */       return null;
/*      */     }
/*  310 */     cachePut(persistentObject, true);
/*  311 */     return persistentObject;
/*      */   }
/*      */ 
/*      */   protected List filterLoadedObjects(List<Object> loadedObjects)
/*      */   {
/*  318 */     if (loadedObjects.isEmpty()) {
/*  319 */       return loadedObjects;
/*      */     }
/*  321 */     if (!(loadedObjects.get(0) instanceof PersistentObject)) {
/*  322 */       return loadedObjects;
/*      */     }
/*      */ 
/*  325 */     List filteredObjects = new ArrayList(loadedObjects.size());
/*  326 */     for (Iterator i$ = loadedObjects.iterator(); i$.hasNext(); ) { Object loadedObject = i$.next();
/*  327 */       PersistentObject cachedPersistentObject = cacheFilter((PersistentObject)loadedObject);
/*  328 */       filteredObjects.add(cachedPersistentObject);
/*      */     }
/*  330 */     return filteredObjects;
/*      */   }
/*      */ 
/*      */   protected CachedObject cachePut(PersistentObject persistentObject, boolean storeState) {
/*  334 */     Map classCache = (Map)this.cachedObjects.get(persistentObject.getClass());
/*  335 */     if (classCache == null) {
/*  336 */       classCache = new HashMap();
/*  337 */       this.cachedObjects.put(persistentObject.getClass(), classCache);
/*      */     }
/*  339 */     CachedObject cachedObject = new CachedObject(persistentObject, storeState);
/*  340 */     classCache.put(persistentObject.getId(), cachedObject);
/*  341 */     return cachedObject;
/*      */   }
/*      */ 
/*      */   protected PersistentObject cacheFilter(PersistentObject persistentObject)
/*      */   {
/*  348 */     PersistentObject cachedPersistentObject = (PersistentObject)cacheGet(persistentObject.getClass(), persistentObject.getId());
/*  349 */     if (cachedPersistentObject != null) {
/*  350 */       return cachedPersistentObject;
/*      */     }
/*  352 */     cachePut(persistentObject, true);
/*  353 */     return persistentObject;
/*      */   }
/*      */ 
/*      */   protected <T> T cacheGet(Class<T> entityClass, String id)
/*      */   {
/*  358 */     CachedObject cachedObject = null;
/*  359 */     Map classCache = (Map)this.cachedObjects.get(entityClass);
/*  360 */     if (classCache != null) {
/*  361 */       cachedObject = (CachedObject)classCache.get(id);
/*      */     }
/*  363 */     if (cachedObject != null) {
/*  364 */       return cachedObject.getPersistentObject();
/*      */     }
/*  366 */     return null;
/*      */   }
/*      */ 
/*      */   protected void cacheRemove(Class<?> persistentObjectClass, String persistentObjectId) {
/*  370 */     Map classCache = (Map)this.cachedObjects.get(persistentObjectClass);
/*  371 */     if (classCache == null) {
/*  372 */       return;
/*      */     }
/*  374 */     classCache.remove(persistentObjectId);
/*      */   }
/*      */ 
/*      */   public <T> List<T> findInCache(Class<T> entityClass)
/*      */   {
/*  379 */     Map classCache = (Map)this.cachedObjects.get(entityClass);
/*  380 */     if (classCache != null) {
/*  381 */       List entities = new ArrayList(classCache.size());
/*  382 */       for (CachedObject cachedObject : classCache.values()) {
/*  383 */         entities.add(cachedObject.getPersistentObject());
/*      */       }
/*  385 */       return entities;
/*      */     }
/*  387 */     return Collections.emptyList();
/*      */   }
/*      */ 
/*      */   public <T> T findInCache(Class<T> entityClass, String id) {
/*  391 */     return cacheGet(entityClass, id);
/*      */   }
/*      */ 
/*      */   public void addDeserializedObject(Object deserializedObject, byte[] serializedBytes, VariableInstanceEntity variableInstanceEntity)
/*      */   {
/*  417 */     this.deserializedObjects.add(new DeserializedObject(deserializedObject, serializedBytes, variableInstanceEntity));
/*      */   }
/*      */ 
/*      */   public void flush()
/*      */   {
/*  423 */     removeUnnecessaryOperations();
/*  424 */     flushDeserializedObjects();
/*  425 */     List updatedObjects = getUpdatedObjects();
/*      */ 
/*  427 */     if (log.isDebugEnabled()) {
/*  428 */       log.debug("flush summary: {} insert, {} update, {} delete.", new Object[] { Integer.valueOf(this.insertedObjects.size()), Integer.valueOf(updatedObjects.size()), Integer.valueOf(this.deleteOperations.size()) });
/*  429 */       for (PersistentObject insertedObject : this.insertedObjects) {
/*  430 */         log.debug("  insert {}", insertedObject);
/*      */       }
/*  432 */       for (PersistentObject updatedObject : updatedObjects) {
/*  433 */         log.debug("  update {}", updatedObject);
/*      */       }
/*  435 */       for (DeleteOperation deleteOperation : this.deleteOperations) {
/*  436 */         log.debug("  {}", deleteOperation);
/*      */       }
/*  438 */       log.debug("now executing flush...");
/*      */     }
/*      */ 
/*  441 */     flushInserts();
/*  442 */     flushUpdates(updatedObjects);
/*  443 */     flushDeletes();
/*      */   }
/*      */ 
/*      */   protected void removeUnnecessaryOperations()
/*      */   {
/*  452 */     for (Iterator deleteIt = this.deleteOperations.iterator(); deleteIt.hasNext(); ) {
/*  453 */       DeleteOperation deleteOperation = (DeleteOperation)deleteIt.next();
/*      */ 
/*  455 */       for (Iterator insertIt = this.insertedObjects.iterator(); insertIt.hasNext(); ) {
/*  456 */         PersistentObject insertedObject = (PersistentObject)insertIt.next();
/*      */ 
/*  459 */         if (deleteOperation.sameIdentity(insertedObject))
/*      */         {
/*  461 */           insertIt.remove();
/*  462 */           deleteIt.remove();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  467 */       deleteOperation.clearCache();
/*      */     }
/*      */ 
/*  470 */     for (PersistentObject insertedObject : this.insertedObjects)
/*  471 */       cacheRemove(insertedObject.getClass(), insertedObject.getId());
/*      */   }
/*      */ 
/*      */   protected void flushDeserializedObjects()
/*      */   {
/*  477 */     for (DeserializedObject deserializedObject : this.deserializedObjects)
/*  478 */       deserializedObject.flush();
/*      */   }
/*      */ 
/*      */   public List<PersistentObject> getUpdatedObjects()
/*      */   {
/*  483 */     List updatedObjects = new ArrayList();
/*  484 */     for (Class clazz : this.cachedObjects.keySet())
/*      */     {
/*  486 */       Map classCache = (Map)this.cachedObjects.get(clazz);
/*  487 */       for (CachedObject cachedObject : classCache.values())
/*      */       {
/*  489 */         PersistentObject persistentObject = cachedObject.getPersistentObject();
/*  490 */         if (!isPersistentObjectDeleted(persistentObject)) {
/*  491 */           Object originalState = cachedObject.getPersistentObjectState();
/*  492 */           if (!persistentObject.getPersistentState().equals(originalState))
/*  493 */             updatedObjects.add(persistentObject);
/*      */           else {
/*  495 */             log.trace("loaded object '{}' was not updated", persistentObject);
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  502 */     return updatedObjects;
/*      */   }
/*      */ 
/*      */   protected boolean isPersistentObjectDeleted(PersistentObject persistentObject) {
/*  506 */     for (DeleteOperation deleteOperation : this.deleteOperations) {
/*  507 */       if (deleteOperation.sameIdentity(persistentObject)) {
/*  508 */         return true;
/*      */       }
/*      */     }
/*  511 */     return false;
/*      */   }
/*      */ 
/*      */   public <T extends PersistentObject> List<T> pruneDeletedEntities(List<T> listToPrune) {
/*  515 */     List prunedList = new ArrayList(listToPrune);
/*  516 */     for (Iterator i$ = listToPrune.iterator(); i$.hasNext(); ) { potentiallyDeleted = (PersistentObject)i$.next();
/*  517 */       for (DeleteOperation deleteOperation : this.deleteOperations)
/*      */       {
/*  519 */         if (deleteOperation.sameIdentity(potentiallyDeleted))
/*  520 */           prunedList.remove(potentiallyDeleted);
/*      */       }
/*      */     }
/*      */     PersistentObject potentiallyDeleted;
/*  525 */     return prunedList;
/*      */   }
/*      */ 
/*      */   protected void flushInserts() {
/*  529 */     for (PersistentObject insertedObject : this.insertedObjects) {
/*  530 */       String insertStatement = this.dbSqlSessionFactory.getInsertStatement(insertedObject);
/*  531 */       insertStatement = this.dbSqlSessionFactory.mapStatement(insertStatement);
/*      */ 
/*  533 */       if (insertStatement == null) {
/*  534 */         throw new ActivitiException("no insert statement for " + insertedObject.getClass() + " in the ibatis mapping files");
/*      */       }
/*      */ 
/*  537 */       log.debug("inserting: {}", insertedObject);
/*  538 */       this.sqlSession.insert(insertStatement, insertedObject);
/*      */ 
/*  541 */       if ((insertedObject instanceof HasRevision)) {
/*  542 */         ((HasRevision)insertedObject).setRevision(((HasRevision)insertedObject).getRevisionNext());
/*      */       }
/*      */     }
/*  545 */     this.insertedObjects.clear();
/*      */   }
/*      */ 
/*      */   protected void flushUpdates(List<PersistentObject> updatedObjects) {
/*  549 */     for (PersistentObject updatedObject : updatedObjects) {
/*  550 */       String updateStatement = this.dbSqlSessionFactory.getUpdateStatement(updatedObject);
/*  551 */       updateStatement = this.dbSqlSessionFactory.mapStatement(updateStatement);
/*      */ 
/*  553 */       if (updateStatement == null) {
/*  554 */         throw new ActivitiException("no update statement for " + updatedObject.getClass() + " in the ibatis mapping files");
/*      */       }
/*      */ 
/*  557 */       log.debug("updating: {}", updatedObject);
/*  558 */       int updatedRecords = this.sqlSession.update(updateStatement, updatedObject);
/*  559 */       if (updatedRecords != 1) {
/*  560 */         throw new ActivitiOptimisticLockingException(updatedObject + " was updated by another transaction concurrently");
/*      */       }
/*      */ 
/*  564 */       if ((updatedObject instanceof HasRevision)) {
/*  565 */         ((HasRevision)updatedObject).setRevision(((HasRevision)updatedObject).getRevisionNext());
/*      */       }
/*      */     }
/*      */ 
/*  569 */     updatedObjects.clear();
/*      */   }
/*      */ 
/*      */   protected void flushDeletes() {
/*  573 */     for (DeleteOperation delete : this.deleteOperations) {
/*  574 */       log.debug("executing: {}", delete);
/*  575 */       delete.execute();
/*      */     }
/*  577 */     this.deleteOperations.clear();
/*      */   }
/*      */ 
/*      */   public void close() {
/*  581 */     this.sqlSession.close();
/*      */   }
/*      */ 
/*      */   public void commit() {
/*  585 */     this.sqlSession.commit();
/*      */   }
/*      */ 
/*      */   public void rollback() {
/*  589 */     this.sqlSession.rollback();
/*      */   }
/*      */ 
/*      */   public void dbSchemaCheckVersion()
/*      */   {
/*      */     try
/*      */     {
/*  596 */       String dbVersion = getDbVersion();
/*  597 */       if (!"5.13".equals(dbVersion)) {
/*  598 */         throw new ActivitiWrongDbException("5.13", dbVersion);
/*      */       }
/*      */ 
/*  601 */       String errorMessage = null;
/*  602 */       if (!isEngineTablePresent()) {
/*  603 */         errorMessage = addMissingComponent(errorMessage, "engine");
/*      */       }
/*  605 */       if ((this.dbSqlSessionFactory.isDbHistoryUsed()) && (!isHistoryTablePresent())) {
/*  606 */         errorMessage = addMissingComponent(errorMessage, "history");
/*      */       }
/*  608 */       if ((this.dbSqlSessionFactory.isDbIdentityUsed()) && (!isIdentityTablePresent())) {
/*  609 */         errorMessage = addMissingComponent(errorMessage, "identity");
/*      */       }
/*      */ 
/*  612 */       if (errorMessage != null)
/*  613 */         throw new ActivitiException("Activiti database problem: " + errorMessage);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  617 */       if (isMissingTablesException(e)) {
/*  618 */         throw new ActivitiException("no activiti tables in db. set <property name=\"databaseSchemaUpdate\" to value=\"true\" or value=\"create-drop\" (use create-drop for testing only!) in bean processEngineConfiguration in activiti.cfg.xml for automatic schema creation", e);
/*      */       }
/*  620 */       if ((e instanceof RuntimeException)) {
/*  621 */         throw ((RuntimeException)e);
/*      */       }
/*  623 */       throw new ActivitiException("couldn't get db schema version", e);
/*      */     }
/*      */ 
/*  628 */     log.debug("activiti db schema check successful");
/*      */   }
/*      */ 
/*      */   protected String addMissingComponent(String missingComponents, String component) {
/*  632 */     if (missingComponents == null) {
/*  633 */       return "Tables missing for component(s) " + component;
/*      */     }
/*  635 */     return missingComponents + ", " + component;
/*      */   }
/*      */ 
/*      */   protected String getDbVersion() {
/*  639 */     String selectSchemaVersionStatement = this.dbSqlSessionFactory.mapStatement("selectDbSchemaVersion");
/*  640 */     return (String)this.sqlSession.selectOne(selectSchemaVersionStatement);
/*      */   }
/*      */ 
/*      */   public void dbSchemaCreate() {
/*  644 */     ProcessEngineConfigurationImpl processEngineConfiguration = Context.getProcessEngineConfiguration();
/*      */ 
/*  646 */     if (isEngineTablePresent()) {
/*  647 */       String dbVersion = getDbVersion();
/*  648 */       if (!"5.13".equals(dbVersion))
/*  649 */         throw new ActivitiWrongDbException("5.13", dbVersion);
/*      */     }
/*      */     else {
/*  652 */       dbSchemaCreateEngine();
/*      */     }
/*      */ 
/*  655 */     if (processEngineConfiguration.getHistoryLevel() != HistoryLevel.NONE) {
/*  656 */       dbSchemaCreateHistory();
/*      */     }
/*      */ 
/*  659 */     if (processEngineConfiguration.isDbIdentityUsed())
/*  660 */       dbSchemaCreateIdentity();
/*      */   }
/*      */ 
/*      */   protected void dbSchemaCreateIdentity()
/*      */   {
/*  665 */     executeMandatorySchemaResource("create", "identity");
/*      */   }
/*      */ 
/*      */   protected void dbSchemaCreateHistory() {
/*  669 */     executeMandatorySchemaResource("create", "history");
/*      */   }
/*      */ 
/*      */   protected void dbSchemaCreateEngine() {
/*  673 */     executeMandatorySchemaResource("create", "engine");
/*      */   }
/*      */ 
/*      */   public void dbSchemaDrop() {
/*  677 */     executeMandatorySchemaResource("drop", "engine");
/*  678 */     if (this.dbSqlSessionFactory.isDbHistoryUsed()) {
/*  679 */       executeMandatorySchemaResource("drop", "history");
/*      */     }
/*  681 */     if (this.dbSqlSessionFactory.isDbIdentityUsed())
/*  682 */       executeMandatorySchemaResource("drop", "identity");
/*      */   }
/*      */ 
/*      */   public void dbSchemaPrune()
/*      */   {
/*  687 */     if ((isHistoryTablePresent()) && (!this.dbSqlSessionFactory.isDbHistoryUsed())) {
/*  688 */       executeMandatorySchemaResource("drop", "history");
/*      */     }
/*  690 */     if ((isIdentityTablePresent()) && (this.dbSqlSessionFactory.isDbIdentityUsed()))
/*  691 */       executeMandatorySchemaResource("drop", "identity");
/*      */   }
/*      */ 
/*      */   public void executeMandatorySchemaResource(String operation, String component)
/*      */   {
/*  696 */     executeSchemaResource(operation, component, getResourceForDbOperation(operation, operation, component), false);
/*      */   }
/*      */ 
/*      */   public String dbSchemaUpdate()
/*      */   {
/*  702 */     String feedback = null;
/*  703 */     String dbVersion = null;
/*  704 */     boolean isUpgradeNeeded = false;
/*      */ 
/*  706 */     if (isEngineTablePresent())
/*      */     {
/*  708 */       PropertyEntity dbVersionProperty = (PropertyEntity)selectById(PropertyEntity.class, "schema.version");
/*  709 */       dbVersion = dbVersionProperty.getValue();
/*  710 */       isUpgradeNeeded = isUpgradeNeeded(dbVersion);
/*      */ 
/*  712 */       if (isUpgradeNeeded) {
/*  713 */         dbVersionProperty.setValue("5.13");
/*      */         PropertyEntity dbHistoryProperty;
/*  716 */         if ("5.0".equals(dbVersion)) {
/*  717 */           PropertyEntity dbHistoryProperty = new PropertyEntity("schema.history", "create(5.0)");
/*  718 */           insert(dbHistoryProperty);
/*      */         } else {
/*  720 */           dbHistoryProperty = (PropertyEntity)selectById(PropertyEntity.class, "schema.history");
/*      */         }
/*      */ 
/*  723 */         String dbHistoryValue = dbHistoryProperty.getValue() + " upgrade(" + dbVersion + "->" + "5.13" + ")";
/*  724 */         dbHistoryProperty.setValue(dbHistoryValue);
/*      */ 
/*  726 */         dbSchemaUpgrade("engine", dbVersion);
/*      */ 
/*  728 */         feedback = "upgraded Activiti from " + dbVersion + " to " + "5.13";
/*      */       }
/*      */     } else {
/*  731 */       dbSchemaCreateEngine();
/*      */     }
/*      */ 
/*  734 */     if (isHistoryTablePresent()) {
/*  735 */       if (isUpgradeNeeded)
/*  736 */         dbSchemaUpgrade("history", dbVersion);
/*      */     }
/*  738 */     else if (this.dbSqlSessionFactory.isDbHistoryUsed()) {
/*  739 */       dbSchemaCreateHistory();
/*      */     }
/*      */ 
/*  742 */     if (isIdentityTablePresent()) {
/*  743 */       if (isUpgradeNeeded)
/*  744 */         dbSchemaUpgrade("identity", dbVersion);
/*      */     }
/*  746 */     else if (this.dbSqlSessionFactory.isDbIdentityUsed()) {
/*  747 */       dbSchemaCreateIdentity();
/*      */     }
/*      */ 
/*  750 */     return feedback;
/*      */   }
/*      */ 
/*      */   public boolean isEngineTablePresent() {
/*  754 */     return isTablePresent("ACT_RU_EXECUTION");
/*      */   }
/*      */   public boolean isHistoryTablePresent() {
/*  757 */     return isTablePresent("ACT_HI_PROCINST");
/*      */   }
/*      */   public boolean isIdentityTablePresent() {
/*  760 */     return isTablePresent("ACT_ID_USER");
/*      */   }
/*      */ 
/*      */   public boolean isTablePresent(String tableName) {
/*  764 */     tableName = prependDatabaseTablePrefix(tableName);
/*  765 */     Connection connection = null;
/*      */     try {
/*  767 */       connection = this.sqlSession.getConnection();
/*  768 */       DatabaseMetaData databaseMetaData = connection.getMetaData();
/*  769 */       ResultSet tables = null;
/*      */ 
/*  771 */       String schema = this.connectionMetadataDefaultSchema;
/*  772 */       if (this.dbSqlSessionFactory.getDatabaseSchema() != null) {
/*  773 */         schema = this.dbSqlSessionFactory.getDatabaseSchema();
/*      */       }
/*      */ 
/*  776 */       String databaseType = this.dbSqlSessionFactory.getDatabaseType();
/*      */ 
/*  778 */       if ("postgres".equals(databaseType)) {
/*  779 */         tableName = tableName.toLowerCase();
/*      */       }
/*      */       try
/*      */       {
/*  783 */         tables = databaseMetaData.getTables(this.connectionMetadataDefaultCatalog, schema, tableName, JDBC_METADATA_TABLE_TYPES);
/*  784 */         boolean bool = tables.next();
/*      */         return bool;
/*      */       }
/*      */       finally
/*      */       {
/*      */         try
/*      */         {
/*  787 */           tables.close();
/*      */         } catch (Exception e) {
/*  789 */           log.error("Error closing meta data tables", e);
/*      */         }
/*      */       }
/*      */     } catch (Exception e) {
/*      */     }
/*  794 */     throw new ActivitiException("couldn't check if tables are already present using metadata: " + e.getMessage(), e);
/*      */   }
/*      */ 
/*      */   protected boolean isUpgradeNeeded(String versionInDatabase)
/*      */   {
/*  799 */     if ("5.13".equals(versionInDatabase)) {
/*  800 */       return false;
/*      */     }
/*      */ 
/*  803 */     String cleanDbVersion = getCleanVersion(versionInDatabase);
/*  804 */     String[] cleanDbVersionSplitted = cleanDbVersion.split("\\.");
/*  805 */     int dbMajorVersion = Integer.valueOf(cleanDbVersionSplitted[0]).intValue();
/*  806 */     int dbMinorVersion = Integer.valueOf(cleanDbVersionSplitted[1]).intValue();
/*      */ 
/*  808 */     String cleanEngineVersion = getCleanVersion("5.13");
/*  809 */     String[] cleanEngineVersionSplitted = cleanEngineVersion.split("\\.");
/*  810 */     int engineMajorVersion = Integer.valueOf(cleanEngineVersionSplitted[0]).intValue();
/*  811 */     int engineMinorVersion = Integer.valueOf(cleanEngineVersionSplitted[1]).intValue();
/*      */ 
/*  813 */     if ((dbMajorVersion > engineMajorVersion) || ((dbMajorVersion <= engineMajorVersion) && (dbMinorVersion > engineMinorVersion)))
/*      */     {
/*  815 */       throw new ActivitiException("Version of activiti database (" + versionInDatabase + ") is more recent than the engine (" + "5.13" + ")");
/*  816 */     }if (cleanDbVersion.compareTo(cleanEngineVersion) == 0)
/*      */     {
/*  818 */       log.warn("Engine-version is the same, but not an exact match: {} vs. {}. Not performing database-upgrade.", versionInDatabase, "5.13");
/*  819 */       return false;
/*      */     }
/*  821 */     return true;
/*      */   }
/*      */ 
/*      */   protected String getCleanVersion(String versionString) {
/*  825 */     Matcher matcher = CLEAN_VERSION_REGEX.matcher(versionString);
/*  826 */     if (!matcher.find()) {
/*  827 */       throw new ActivitiException("Illegal format for version: " + versionString);
/*      */     }
/*      */ 
/*  830 */     String cleanString = matcher.group();
/*      */     try {
/*  832 */       Double.parseDouble(cleanString);
/*  833 */       return cleanString; } catch (NumberFormatException nfe) {
/*      */     }
/*  835 */     throw new ActivitiException("Illegal format for version: " + versionString);
/*      */   }
/*      */ 
/*      */   protected String prependDatabaseTablePrefix(String tableName)
/*      */   {
/*  840 */     return this.dbSqlSessionFactory.getDatabaseTablePrefix() + tableName;
/*      */   }
/*      */ 
/*      */   protected void dbSchemaUpgrade(String component, String dbVersion) {
/*  844 */     log.info("upgrading activiti {} schema from {} to {}", new Object[] { component, dbVersion, "5.13" });
/*      */ 
/*  846 */     if (dbVersion.endsWith("-SNAPSHOT")) {
/*  847 */       dbVersion = dbVersion.substring(0, dbVersion.length() - "-SNAPSHOT".length());
/*      */     }
/*  849 */     int minorDbVersionNumber = Integer.parseInt(dbVersion.substring(2));
/*      */ 
/*  851 */     String libraryVersion = "5.13";
/*  852 */     if ("5.13".endsWith("-SNAPSHOT")) {
/*  853 */       libraryVersion = "5.13".substring(0, "5.13".length() - "-SNAPSHOT".length());
/*      */     }
/*  855 */     int minorLibraryVersionNumber = Integer.parseInt(libraryVersion.substring(2));
/*      */ 
/*  857 */     while (minorDbVersionNumber < minorLibraryVersionNumber) {
/*  858 */       executeSchemaResource("upgrade", component, getResourceForDbOperation("upgrade", "upgradestep.5" + minorDbVersionNumber + ".to.5" + (minorDbVersionNumber + 1), component), true);
/*  859 */       minorDbVersionNumber++;
/*      */     }
/*      */   }
/*      */ 
/*      */   public String getResourceForDbOperation(String directory, String operation, String component) {
/*  864 */     String databaseType = this.dbSqlSessionFactory.getDatabaseType();
/*  865 */     return "org/activiti/db/" + directory + "/activiti." + databaseType + "." + operation + "." + component + ".sql";
/*      */   }
/*      */ 
/*      */   public void executeSchemaResource(String operation, String component, String resourceName, boolean isOptional) {
/*  869 */     InputStream inputStream = null;
/*      */     try {
/*  871 */       inputStream = ReflectUtil.getResourceAsStream(resourceName);
/*  872 */       if (inputStream == null) {
/*  873 */         if (isOptional)
/*  874 */           log.debug("no schema resource {} for {}", resourceName, operation);
/*      */         else
/*  876 */           throw new ActivitiException("resource '" + resourceName + "' is not available");
/*      */       }
/*      */       else
/*  879 */         executeSchemaResource(operation, component, resourceName, inputStream);
/*      */     }
/*      */     finally
/*      */     {
/*  883 */       IoUtil.closeSilently(inputStream);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void executeSchemaResource(String operation, String component, String resourceName, InputStream inputStream) {
/*  888 */     log.info("performing {} on {} with resource {}", new Object[] { operation, component, resourceName });
/*  889 */     String sqlStatement = null;
/*  890 */     String exceptionSqlStatement = null;
/*      */     try {
/*  892 */       Connection connection = this.sqlSession.getConnection();
/*  893 */       Exception exception = null;
/*  894 */       byte[] bytes = IoUtil.readInputStream(inputStream, resourceName);
/*  895 */       String ddlStatements = new String(bytes);
/*  896 */       BufferedReader reader = new BufferedReader(new StringReader(ddlStatements));
/*  897 */       String line = readNextTrimmedLine(reader);
/*  898 */       while (line != null) {
/*  899 */         if (line.startsWith("# ")) {
/*  900 */           log.debug(line.substring(2));
/*      */         }
/*  902 */         else if (line.startsWith("-- ")) {
/*  903 */           log.debug(line.substring(3));
/*      */         }
/*  905 */         else if (line.startsWith("execute java ")) {
/*  906 */           String upgradestepClassName = line.substring(13).trim();
/*  907 */           DbUpgradeStep dbUpgradeStep = null;
/*      */           try {
/*  909 */             dbUpgradeStep = (DbUpgradeStep)ReflectUtil.instantiate(upgradestepClassName);
/*      */           } catch (ActivitiException e) {
/*  911 */             throw new ActivitiException("database update java class '" + upgradestepClassName + "' can't be instantiated: " + e.getMessage(), e);
/*      */           }
/*      */           try {
/*  914 */             log.debug("executing upgrade step java class {}", upgradestepClassName);
/*  915 */             dbUpgradeStep.execute(this);
/*      */           } catch (Exception e) {
/*  917 */             throw new ActivitiException("error while executing database update java class '" + upgradestepClassName + "': " + e.getMessage(), e);
/*      */           }
/*      */         }
/*  920 */         else if (line.length() > 0)
/*      */         {
/*  922 */           if (line.endsWith(";")) {
/*  923 */             sqlStatement = addSqlStatementPiece(sqlStatement, line.substring(0, line.length() - 1));
/*  924 */             Statement jdbcStatement = connection.createStatement();
/*      */             try
/*      */             {
/*  927 */               log.debug("SQL: {}", sqlStatement);
/*  928 */               jdbcStatement.execute(sqlStatement);
/*  929 */               jdbcStatement.close();
/*      */             } catch (Exception e) {
/*  931 */               if (exception == null) {
/*  932 */                 exception = e;
/*  933 */                 exceptionSqlStatement = sqlStatement;
/*      */               }
/*  935 */               log.error("problem during schema {}, statement {}", new Object[] { operation, sqlStatement, e });
/*      */             } finally {
/*  937 */               sqlStatement = null;
/*      */             }
/*      */           } else {
/*  940 */             sqlStatement = addSqlStatementPiece(sqlStatement, line);
/*      */           }
/*      */         }
/*      */ 
/*  944 */         line = readNextTrimmedLine(reader);
/*      */       }
/*      */ 
/*  947 */       if (exception != null) {
/*  948 */         throw exception;
/*      */       }
/*      */ 
/*  951 */       log.debug("activiti db schema {} for component {} successful", operation, component);
/*      */     }
/*      */     catch (Exception e) {
/*  954 */       throw new ActivitiException("couldn't " + operation + " db schema: " + exceptionSqlStatement, e);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected String addSqlStatementPiece(String sqlStatement, String line) {
/*  959 */     if (sqlStatement == null) {
/*  960 */       return line;
/*      */     }
/*  962 */     return sqlStatement + " \n" + line;
/*      */   }
/*      */ 
/*      */   protected String readNextTrimmedLine(BufferedReader reader) throws IOException {
/*  966 */     String line = reader.readLine();
/*  967 */     if (line != null) {
/*  968 */       line = line.trim();
/*      */     }
/*  970 */     return line;
/*      */   }
/*      */ 
/*      */   protected boolean isMissingTablesException(Exception e) {
/*  974 */     String exceptionMessage = e.getMessage();
/*  975 */     if (e.getMessage() != null)
/*      */     {
/*  977 */       if ((exceptionMessage.indexOf("Table") != -1) && (exceptionMessage.indexOf("not found") != -1)) {
/*  978 */         return true;
/*      */       }
/*      */ 
/*  982 */       if (((exceptionMessage.indexOf("Table") != -1) || (exceptionMessage.indexOf("table") != -1)) && (exceptionMessage.indexOf("doesn't exist") != -1)) {
/*  983 */         return true;
/*      */       }
/*      */ 
/*  987 */       if (((exceptionMessage.indexOf("relation") != -1) || (exceptionMessage.indexOf("table") != -1)) && (exceptionMessage.indexOf("does not exist") != -1)) {
/*  988 */         return true;
/*      */       }
/*      */     }
/*  991 */     return false;
/*      */   }
/*      */ 
/*      */   public void performSchemaOperationsProcessEngineBuild() {
/*  995 */     String databaseSchemaUpdate = Context.getProcessEngineConfiguration().getDatabaseSchemaUpdate();
/*  996 */     if ("drop-create".equals(databaseSchemaUpdate))
/*      */       try {
/*  998 */         dbSchemaDrop();
/*      */       }
/*      */       catch (RuntimeException e)
/*      */       {
/*      */       }
/* 1003 */     if (("create-drop".equals(databaseSchemaUpdate)) || ("drop-create".equals(databaseSchemaUpdate)) || ("create".equals(databaseSchemaUpdate)))
/*      */     {
/* 1007 */       dbSchemaCreate();
/*      */     }
/* 1009 */     else if ("false".equals(databaseSchemaUpdate)) {
/* 1010 */       dbSchemaCheckVersion();
/*      */     }
/* 1012 */     else if ("true".equals(databaseSchemaUpdate))
/* 1013 */       dbSchemaUpdate();
/*      */   }
/*      */ 
/*      */   public void performSchemaOperationsProcessEngineClose()
/*      */   {
/* 1018 */     String databaseSchemaUpdate = Context.getProcessEngineConfiguration().getDatabaseSchemaUpdate();
/* 1019 */     if ("create-drop".equals(databaseSchemaUpdate))
/* 1020 */       dbSchemaDrop();
/*      */   }
/*      */ 
/*      */   public DeploymentQueryImpl createDeploymentQuery()
/*      */   {
/* 1027 */     return new DeploymentQueryImpl();
/*      */   }
/*      */   public ModelQueryImpl createModelQueryImpl() {
/* 1030 */     return new ModelQueryImpl();
/*      */   }
/*      */   public ProcessDefinitionQueryImpl createProcessDefinitionQuery() {
/* 1033 */     return new ProcessDefinitionQueryImpl();
/*      */   }
/*      */   public ProcessInstanceQueryImpl createProcessInstanceQuery() {
/* 1036 */     return new ProcessInstanceQueryImpl();
/*      */   }
/*      */   public ExecutionQueryImpl createExecutionQuery() {
/* 1039 */     return new ExecutionQueryImpl();
/*      */   }
/*      */   public TaskQueryImpl createTaskQuery() {
/* 1042 */     return new TaskQueryImpl();
/*      */   }
/*      */   public JobQueryImpl createJobQuery() {
/* 1045 */     return new JobQueryImpl();
/*      */   }
/*      */   public HistoricProcessInstanceQueryImpl createHistoricProcessInstanceQuery() {
/* 1048 */     return new HistoricProcessInstanceQueryImpl();
/*      */   }
/*      */   public HistoricActivityInstanceQueryImpl createHistoricActivityInstanceQuery() {
/* 1051 */     return new HistoricActivityInstanceQueryImpl();
/*      */   }
/*      */   public HistoricTaskInstanceQueryImpl createHistoricTaskInstanceQuery() {
/* 1054 */     return new HistoricTaskInstanceQueryImpl();
/*      */   }
/*      */   public HistoricDetailQueryImpl createHistoricDetailQuery() {
/* 1057 */     return new HistoricDetailQueryImpl();
/*      */   }
/*      */   public HistoricVariableInstanceQueryImpl createHistoricVariableInstanceQuery() {
/* 1060 */     return new HistoricVariableInstanceQueryImpl();
/*      */   }
/*      */   public UserQueryImpl createUserQuery() {
/* 1063 */     return new UserQueryImpl();
/*      */   }
/*      */   public GroupQueryImpl createGroupQuery() {
/* 1066 */     return new GroupQueryImpl();
/*      */   }
/*      */ 
/*      */   public SqlSession getSqlSession()
/*      */   {
/* 1072 */     return this.sqlSession;
/*      */   }
/*      */   public DbSqlSessionFactory getDbSqlSessionFactory() {
/* 1075 */     return this.dbSqlSessionFactory;
/*      */   }
/*      */ 
/*      */   public static class CachedObject
/*      */   {
/*      */     protected PersistentObject persistentObject;
/*      */     protected Object persistentObjectState;
/*      */ 
/*      */     public CachedObject(PersistentObject persistentObject, boolean storeState)
/*      */     {
/*  399 */       this.persistentObject = persistentObject;
/*  400 */       if (storeState)
/*  401 */         this.persistentObjectState = persistentObject.getPersistentState();
/*      */     }
/*      */ 
/*      */     public PersistentObject getPersistentObject()
/*      */     {
/*  406 */       return this.persistentObject;
/*      */     }
/*      */ 
/*      */     public Object getPersistentObjectState() {
/*  410 */       return this.persistentObjectState;
/*      */     }
/*      */   }
/*      */ 
/*      */   private class CheckedDeleteOperation
/*      */     implements DbSqlSession.DeleteOperation
/*      */   {
/*      */     private final PersistentObject persistentObject;
/*      */ 
/*      */     public CheckedDeleteOperation(PersistentObject persistentObject)
/*      */     {
/*  204 */       this.persistentObject = persistentObject;
/*      */     }
/*      */ 
/*      */     public boolean sameIdentity(PersistentObject other)
/*      */     {
/*  209 */       return (this.persistentObject.getClass().equals(other.getClass())) && (this.persistentObject.getId().equals(other.getId()));
/*      */     }
/*      */ 
/*      */     public void clearCache()
/*      */     {
/*  215 */       DbSqlSession.this.cacheRemove(this.persistentObject.getClass(), this.persistentObject.getId());
/*      */     }
/*      */ 
/*      */     public void execute() {
/*  219 */       String deleteStatement = DbSqlSession.this.dbSqlSessionFactory.getDeleteStatement(this.persistentObject.getClass());
/*  220 */       deleteStatement = DbSqlSession.this.dbSqlSessionFactory.mapStatement(deleteStatement);
/*  221 */       if (deleteStatement == null) {
/*  222 */         throw new ActivitiException("no delete statement for " + this.persistentObject.getClass() + " in the ibatis mapping files");
/*      */       }
/*      */ 
/*  226 */       if ((this.persistentObject instanceof HasRevision)) {
/*  227 */         int nrOfRowsDeleted = DbSqlSession.this.sqlSession.delete(deleteStatement, this.persistentObject);
/*  228 */         if (nrOfRowsDeleted == 0)
/*  229 */           throw new ActivitiOptimisticLockingException(this.persistentObject + " was updated by another transaction concurrently");
/*      */       }
/*      */       else {
/*  232 */         DbSqlSession.this.sqlSession.delete(deleteStatement, this.persistentObject);
/*      */       }
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/*  238 */       return "delete " + this.persistentObject;
/*      */     }
/*      */   }
/*      */ 
/*      */   private class BulkDeleteOperation
/*      */     implements DbSqlSession.DeleteOperation
/*      */   {
/*      */     private String statement;
/*      */     private Object parameter;
/*      */ 
/*      */     public BulkDeleteOperation(String statement, Object parameter)
/*      */     {
/*  170 */       this.statement = DbSqlSession.this.dbSqlSessionFactory.mapStatement(statement);
/*  171 */       this.parameter = parameter;
/*      */     }
/*      */ 
/*      */     public boolean sameIdentity(PersistentObject other)
/*      */     {
/*  177 */       return false;
/*      */     }
/*      */ 
/*      */     public void clearCache()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void execute()
/*      */     {
/*  187 */       DbSqlSession.this.sqlSession.delete(this.statement, this.parameter);
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/*  192 */       return "bulk delete: " + this.statement + "(" + this.parameter + ")";
/*      */     }
/*      */   }
/*      */ 
/*      */   private static abstract interface DeleteOperation
/*      */   {
/*      */     public abstract boolean sameIdentity(PersistentObject paramPersistentObject);
/*      */ 
/*      */     public abstract void clearCache();
/*      */ 
/*      */     public abstract void execute();
/*      */   }
/*      */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.db.DbSqlSession
 * JD-Core Version:    0.6.0
 */