/*     */ package org.activiti.engine.impl.db;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.activiti.engine.impl.cfg.IdGenerator;
/*     */ import org.activiti.engine.impl.interceptor.Session;
/*     */ import org.activiti.engine.impl.interceptor.SessionFactory;
/*     */ import org.apache.ibatis.session.SqlSessionFactory;
/*     */ 
/*     */ public class DbSqlSessionFactory
/*     */   implements SessionFactory
/*     */ {
/*  31 */   protected static final Map<String, Map<String, String>> databaseSpecificStatements = new HashMap();
/*     */ 
/*  33 */   public static final Map<String, String> databaseSpecificLimitBeforeStatements = new HashMap();
/*  34 */   public static final Map<String, String> databaseSpecificLimitAfterStatements = new HashMap();
/*  35 */   public static final Map<String, String> databaseSpecificLimitBetweenStatements = new HashMap();
/*  36 */   public static final Map<String, String> databaseSpecificOrderByStatements = new HashMap();
/*  37 */   public static final Map<String, String> databaseOuterJoinLimitBetweenStatements = new HashMap();
/*  38 */   public static final Map<String, String> databaseSpecificLimitBeforeNativeQueryStatements = new HashMap();
/*     */   protected String databaseType;
/* 147 */   protected String databaseTablePrefix = "";
/*     */   protected String databaseSchema;
/*     */   protected SqlSessionFactory sqlSessionFactory;
/*     */   protected IdGenerator idGenerator;
/*     */   protected Map<String, String> statementMappings;
/* 158 */   protected Map<Class<?>, String> insertStatements = new ConcurrentHashMap();
/* 159 */   protected Map<Class<?>, String> updateStatements = new ConcurrentHashMap();
/* 160 */   protected Map<Class<?>, String> deleteStatements = new ConcurrentHashMap();
/* 161 */   protected Map<Class<?>, String> selectStatements = new ConcurrentHashMap();
/* 162 */   protected boolean isDbIdentityUsed = true;
/* 163 */   protected boolean isDbHistoryUsed = true;
/*     */ 
/*     */   public Class<?> getSessionType() {
/* 166 */     return DbSqlSession.class;
/*     */   }
/*     */ 
/*     */   public Session openSession() {
/* 170 */     return new DbSqlSession(this);
/*     */   }
/*     */ 
/*     */   public String getInsertStatement(PersistentObject object)
/*     */   {
/* 176 */     return getStatement(object.getClass(), this.insertStatements, "insert");
/*     */   }
/*     */ 
/*     */   public String getUpdateStatement(PersistentObject object) {
/* 180 */     return getStatement(object.getClass(), this.updateStatements, "update");
/*     */   }
/*     */ 
/*     */   public String getDeleteStatement(Class<?> persistentObjectClass) {
/* 184 */     return getStatement(persistentObjectClass, this.deleteStatements, "delete");
/*     */   }
/*     */ 
/*     */   public String getSelectStatement(Class<?> persistentObjectClass) {
/* 188 */     return getStatement(persistentObjectClass, this.selectStatements, "select");
/*     */   }
/*     */ 
/*     */   private String getStatement(Class<?> persistentObjectClass, Map<Class<?>, String> cachedStatements, String prefix) {
/* 192 */     String statement = (String)cachedStatements.get(persistentObjectClass);
/* 193 */     if (statement != null) {
/* 194 */       return statement;
/*     */     }
/* 196 */     statement = prefix + persistentObjectClass.getSimpleName();
/* 197 */     statement = statement.substring(0, statement.length() - 6);
/* 198 */     cachedStatements.put(persistentObjectClass, statement);
/* 199 */     return statement;
/*     */   }
/*     */ 
/*     */   protected static void addDatabaseSpecificStatement(String databaseType, String activitiStatement, String ibatisStatement)
/*     */   {
/* 205 */     Map specificStatements = (Map)databaseSpecificStatements.get(databaseType);
/* 206 */     if (specificStatements == null) {
/* 207 */       specificStatements = new HashMap();
/* 208 */       databaseSpecificStatements.put(databaseType, specificStatements);
/*     */     }
/* 210 */     specificStatements.put(activitiStatement, ibatisStatement);
/*     */   }
/*     */ 
/*     */   public String mapStatement(String statement) {
/* 214 */     if (this.statementMappings == null) {
/* 215 */       return statement;
/*     */     }
/* 217 */     String mappedStatement = (String)this.statementMappings.get(statement);
/* 218 */     return mappedStatement != null ? mappedStatement : statement;
/*     */   }
/*     */ 
/*     */   public void setDatabaseType(String databaseType)
/*     */   {
/* 224 */     this.databaseType = databaseType;
/* 225 */     this.statementMappings = ((Map)databaseSpecificStatements.get(databaseType));
/*     */   }
/*     */ 
/*     */   public SqlSessionFactory getSqlSessionFactory()
/*     */   {
/* 231 */     return this.sqlSessionFactory;
/*     */   }
/*     */ 
/*     */   public void setSqlSessionFactory(SqlSessionFactory sqlSessionFactory) {
/* 235 */     this.sqlSessionFactory = sqlSessionFactory;
/*     */   }
/*     */ 
/*     */   public IdGenerator getIdGenerator() {
/* 239 */     return this.idGenerator;
/*     */   }
/*     */ 
/*     */   public void setIdGenerator(IdGenerator idGenerator) {
/* 243 */     this.idGenerator = idGenerator;
/*     */   }
/*     */ 
/*     */   public String getDatabaseType()
/*     */   {
/* 248 */     return this.databaseType;
/*     */   }
/*     */ 
/*     */   public Map<String, String> getStatementMappings()
/*     */   {
/* 253 */     return this.statementMappings;
/*     */   }
/*     */ 
/*     */   public void setStatementMappings(Map<String, String> statementMappings)
/*     */   {
/* 258 */     this.statementMappings = statementMappings;
/*     */   }
/*     */ 
/*     */   public Map<Class<?>, String> getInsertStatements()
/*     */   {
/* 263 */     return this.insertStatements;
/*     */   }
/*     */ 
/*     */   public void setInsertStatements(Map<Class<?>, String> insertStatements)
/*     */   {
/* 268 */     this.insertStatements = insertStatements;
/*     */   }
/*     */ 
/*     */   public Map<Class<?>, String> getUpdateStatements()
/*     */   {
/* 273 */     return this.updateStatements;
/*     */   }
/*     */ 
/*     */   public void setUpdateStatements(Map<Class<?>, String> updateStatements)
/*     */   {
/* 278 */     this.updateStatements = updateStatements;
/*     */   }
/*     */ 
/*     */   public Map<Class<?>, String> getDeleteStatements()
/*     */   {
/* 283 */     return this.deleteStatements;
/*     */   }
/*     */ 
/*     */   public void setDeleteStatements(Map<Class<?>, String> deleteStatements)
/*     */   {
/* 288 */     this.deleteStatements = deleteStatements;
/*     */   }
/*     */ 
/*     */   public Map<Class<?>, String> getSelectStatements()
/*     */   {
/* 293 */     return this.selectStatements;
/*     */   }
/*     */ 
/*     */   public void setSelectStatements(Map<Class<?>, String> selectStatements)
/*     */   {
/* 298 */     this.selectStatements = selectStatements;
/*     */   }
/*     */ 
/*     */   public boolean isDbIdentityUsed() {
/* 302 */     return this.isDbIdentityUsed;
/*     */   }
/*     */ 
/*     */   public void setDbIdentityUsed(boolean isDbIdentityUsed) {
/* 306 */     this.isDbIdentityUsed = isDbIdentityUsed;
/*     */   }
/*     */ 
/*     */   public boolean isDbHistoryUsed() {
/* 310 */     return this.isDbHistoryUsed;
/*     */   }
/*     */ 
/*     */   public void setDbHistoryUsed(boolean isDbHistoryUsed) {
/* 314 */     this.isDbHistoryUsed = isDbHistoryUsed;
/*     */   }
/*     */ 
/*     */   public void setDatabaseTablePrefix(String databaseTablePrefix) {
/* 318 */     this.databaseTablePrefix = databaseTablePrefix;
/*     */   }
/*     */ 
/*     */   public String getDatabaseTablePrefix() {
/* 322 */     return this.databaseTablePrefix;
/*     */   }
/*     */ 
/*     */   public String getDatabaseSchema() {
/* 326 */     return this.databaseSchema;
/*     */   }
/*     */ 
/*     */   public void setDatabaseSchema(String databaseSchema) {
/* 330 */     this.databaseSchema = databaseSchema;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  42 */     String defaultOrderBy = " order by ${orderBy} ";
/*     */ 
/*  45 */     databaseSpecificLimitBeforeStatements.put("h2", "");
/*  46 */     databaseSpecificLimitAfterStatements.put("h2", "LIMIT #{maxResults} OFFSET #{firstResult}");
/*  47 */     databaseSpecificLimitBetweenStatements.put("h2", "");
/*  48 */     databaseOuterJoinLimitBetweenStatements.put("h2", "");
/*  49 */     databaseSpecificOrderByStatements.put("h2", defaultOrderBy);
/*     */ 
/*  52 */     databaseSpecificLimitBeforeStatements.put("mysql", "");
/*  53 */     databaseSpecificLimitAfterStatements.put("mysql", "LIMIT #{maxResults} OFFSET #{firstResult}");
/*  54 */     databaseSpecificLimitBetweenStatements.put("mysql", "");
/*  55 */     databaseOuterJoinLimitBetweenStatements.put("mysql", "");
/*  56 */     databaseSpecificOrderByStatements.put("mysql", defaultOrderBy);
/*  57 */     addDatabaseSpecificStatement("mysql", "selectNextJobsToExecute", "selectNextJobsToExecute_mysql");
/*  58 */     addDatabaseSpecificStatement("mysql", "selectExclusiveJobsToExecute", "selectExclusiveJobsToExecute_mysql");
/*  59 */     addDatabaseSpecificStatement("mysql", "selectProcessDefinitionsByQueryCriteria", "selectProcessDefinitionsByQueryCriteria_mysql");
/*  60 */     addDatabaseSpecificStatement("mysql", "selectProcessDefinitionCountByQueryCriteria", "selectProcessDefinitionCountByQueryCriteria_mysql");
/*  61 */     addDatabaseSpecificStatement("mysql", "selectDeploymentsByQueryCriteria", "selectDeploymentsByQueryCriteria_mysql");
/*  62 */     addDatabaseSpecificStatement("mysql", "selectDeploymentCountByQueryCriteria", "selectDeploymentCountByQueryCriteria_mysql");
/*  63 */     addDatabaseSpecificStatement("mysql", "selectModelCountByQueryCriteria", "selectModelCountByQueryCriteria_mysql");
/*     */ 
/*  66 */     databaseSpecificLimitBeforeStatements.put("postgres", "");
/*  67 */     databaseSpecificLimitAfterStatements.put("postgres", "LIMIT #{maxResults} OFFSET #{firstResult}");
/*  68 */     databaseSpecificLimitBetweenStatements.put("postgres", "");
/*  69 */     databaseOuterJoinLimitBetweenStatements.put("postgres", "");
/*  70 */     databaseSpecificOrderByStatements.put("postgres", defaultOrderBy);
/*  71 */     addDatabaseSpecificStatement("postgres", "insertByteArray", "insertByteArray_postgres");
/*  72 */     addDatabaseSpecificStatement("postgres", "updateByteArray", "updateByteArray_postgres");
/*  73 */     addDatabaseSpecificStatement("postgres", "selectByteArray", "selectByteArray_postgres");
/*  74 */     addDatabaseSpecificStatement("postgres", "selectResourceByDeploymentIdAndResourceName", "selectResourceByDeploymentIdAndResourceName_postgres");
/*  75 */     addDatabaseSpecificStatement("postgres", "selectResourcesByDeploymentId", "selectResourcesByDeploymentId_postgres");
/*  76 */     addDatabaseSpecificStatement("postgres", "insertIdentityInfo", "insertIdentityInfo_postgres");
/*  77 */     addDatabaseSpecificStatement("postgres", "updateIdentityInfo", "updateIdentityInfo_postgres");
/*  78 */     addDatabaseSpecificStatement("postgres", "selectIdentityInfoById", "selectIdentityInfoById_postgres");
/*  79 */     addDatabaseSpecificStatement("postgres", "selectIdentityInfoByUserIdAndKey", "selectIdentityInfoByUserIdAndKey_postgres");
/*  80 */     addDatabaseSpecificStatement("postgres", "selectIdentityInfoByUserId", "selectIdentityInfoByUserId_postgres");
/*  81 */     addDatabaseSpecificStatement("postgres", "selectIdentityInfoDetails", "selectIdentityInfoDetails_postgres");
/*  82 */     addDatabaseSpecificStatement("postgres", "insertComment", "insertComment_postgres");
/*  83 */     addDatabaseSpecificStatement("postgres", "selectCommentsByTaskId", "selectCommentsByTaskId_postgres");
/*  84 */     addDatabaseSpecificStatement("postgres", "selectCommentsByProcessInstanceId", "selectCommentsByProcessInstanceId_postgres");
/*  85 */     addDatabaseSpecificStatement("postgres", "selectEventsByTaskId", "selectEventsByTaskId_postgres");
/*     */ 
/*  88 */     databaseSpecificLimitBeforeStatements.put("oracle", "select * from ( select a.*, ROWNUM rnum from (");
/*  89 */     databaseSpecificLimitAfterStatements.put("oracle", "  ) a where ROWNUM < #{lastRow}) where rnum  >= #{firstRow}");
/*  90 */     databaseSpecificLimitBetweenStatements.put("oracle", "");
/*  91 */     databaseOuterJoinLimitBetweenStatements.put("oracle", "");
/*  92 */     databaseSpecificOrderByStatements.put("oracle", defaultOrderBy);
/*  93 */     addDatabaseSpecificStatement("oracle", "selectExclusiveJobsToExecute", "selectExclusiveJobsToExecute_integerBoolean");
/*     */ 
/*  96 */     databaseSpecificLimitBeforeStatements.put("db2", "SELECT SUB.* FROM (");
/*  97 */     databaseSpecificLimitAfterStatements.put("db2", ")RES ) SUB WHERE SUB.rnk >= #{firstRow} AND SUB.rnk < #{lastRow}");
/*  98 */     databaseSpecificLimitBetweenStatements.put("db2", ", row_number() over (ORDER BY ${orderBy}) rnk FROM ( select distinct RES.* ");
/*  99 */     databaseOuterJoinLimitBetweenStatements.put("db2", ", row_number() over (ORDER BY ${mssqlOrDB2OrderBy}) rnk FROM ( select distinct ");
/* 100 */     databaseSpecificOrderByStatements.put("db2", "");
/* 101 */     databaseSpecificLimitBeforeNativeQueryStatements.put("db2", "SELECT SUB.* FROM ( select RES.* , row_number() over (ORDER BY ${orderBy}) rnk FROM (");
/* 102 */     addDatabaseSpecificStatement("db2", "selectExclusiveJobsToExecute", "selectExclusiveJobsToExecute_integerBoolean");
/* 103 */     addDatabaseSpecificStatement("db2", "selectExecutionByNativeQuery", "selectExecutionByNativeQuery_mssql_or_db2");
/* 104 */     addDatabaseSpecificStatement("db2", "selectHistoricActivityInstanceByNativeQuery", "selectHistoricActivityInstanceByNativeQuery_mssql_or_db2");
/* 105 */     addDatabaseSpecificStatement("db2", "selectHistoricProcessInstanceByNativeQuery", "selectHistoricProcessInstanceByNativeQuery_mssql_or_db2");
/* 106 */     addDatabaseSpecificStatement("db2", "selectHistoricTaskInstanceByNativeQuery", "selectHistoricTaskInstanceByNativeQuery_mssql_or_db2");
/* 107 */     addDatabaseSpecificStatement("db2", "selectTaskByNativeQuery", "selectTaskByNativeQuery_mssql_or_db2");
/* 108 */     addDatabaseSpecificStatement("db2", "selectProcessDefinitionByNativeQuery", "selectProcessDefinitionByNativeQuery_mssql_or_db2");
/* 109 */     addDatabaseSpecificStatement("db2", "selectDeploymentByNativeQuery", "selectDeploymentByNativeQuery_mssql_or_db2");
/* 110 */     addDatabaseSpecificStatement("db2", "selectGroupByNativeQuery", "selectGroupByNativeQuery_mssql_or_db2");
/* 111 */     addDatabaseSpecificStatement("db2", "selectUserByNativeQuery", "selectUserByNativeQuery_mssql_or_db2");
/* 112 */     addDatabaseSpecificStatement("db2", "selectModelByNativeQuery", "selectModelByNativeQuery_mssql_or_db2");
/* 113 */     addDatabaseSpecificStatement("db2", "selectHistoricDetailByNativeQuery", "selectHistoricDetailByNativeQuery_mssql_or_db2");
/* 114 */     addDatabaseSpecificStatement("db2", "selectHistoricVariableInstanceByNativeQuery", "selectHistoricVariableInstanceByNativeQuery_mssql_or_db2");
/* 115 */     addDatabaseSpecificStatement("db2", "selectTaskWithVariablesByQueryCriteria", "selectTaskWithVariablesByQueryCriteria_mssql_or_db2");
/* 116 */     addDatabaseSpecificStatement("db2", "selectProcessInstanceWithVariablesByQueryCriteria", "selectProcessInstanceWithVariablesByQueryCriteria_mssql_or_db2");
/* 117 */     addDatabaseSpecificStatement("db2", "selectHistoricProcessInstancesWithVariablesByQueryCriteria", "selectHistoricProcessInstancesWithVariablesByQueryCriteria_mssql_or_db2");
/* 118 */     addDatabaseSpecificStatement("db2", "selectHistoricTaskInstancesWithVariablesByQueryCriteria", "selectHistoricTaskInstancesWithVariablesByQueryCriteria_mssql_or_db2");
/*     */ 
/* 121 */     databaseSpecificLimitBeforeStatements.put("mssql", "SELECT SUB.* FROM (");
/* 122 */     databaseSpecificLimitAfterStatements.put("mssql", ")RES ) SUB WHERE SUB.rnk >= #{firstRow} AND SUB.rnk < #{lastRow}");
/* 123 */     databaseSpecificLimitBetweenStatements.put("mssql", ", row_number() over (ORDER BY ${orderBy}) rnk FROM ( select distinct RES.* ");
/* 124 */     databaseOuterJoinLimitBetweenStatements.put("mssql", ", row_number() over (ORDER BY ${mssqlOrDB2OrderBy}) rnk FROM ( select distinct ");
/* 125 */     databaseSpecificOrderByStatements.put("mssql", "");
/* 126 */     databaseSpecificLimitBeforeNativeQueryStatements.put("mssql", "SELECT SUB.* FROM ( select RES.* , row_number() over (ORDER BY ${orderBy}) rnk FROM (");
/* 127 */     addDatabaseSpecificStatement("mssql", "selectExclusiveJobsToExecute", "selectExclusiveJobsToExecute_integerBoolean");
/* 128 */     addDatabaseSpecificStatement("mssql", "selectExecutionByNativeQuery", "selectExecutionByNativeQuery_mssql_or_db2");
/* 129 */     addDatabaseSpecificStatement("mssql", "selectHistoricActivityInstanceByNativeQuery", "selectHistoricActivityInstanceByNativeQuery_mssql_or_db2");
/* 130 */     addDatabaseSpecificStatement("mssql", "selectHistoricProcessInstanceByNativeQuery", "selectHistoricProcessInstanceByNativeQuery_mssql_or_db2");
/* 131 */     addDatabaseSpecificStatement("mssql", "selectHistoricTaskInstanceByNativeQuery", "selectHistoricTaskInstanceByNativeQuery_mssql_or_db2");
/* 132 */     addDatabaseSpecificStatement("mssql", "selectTaskByNativeQuery", "selectTaskByNativeQuery_mssql_or_db2");
/* 133 */     addDatabaseSpecificStatement("mssql", "selectProcessDefinitionByNativeQuery", "selectProcessDefinitionByNativeQuery_mssql_or_db2");
/* 134 */     addDatabaseSpecificStatement("mssql", "selectDeploymentByNativeQuery", "selectDeploymentByNativeQuery_mssql_or_db2");
/* 135 */     addDatabaseSpecificStatement("mssql", "selectGroupByNativeQuery", "selectGroupByNativeQuery_mssql_or_db2");
/* 136 */     addDatabaseSpecificStatement("mssql", "selectUserByNativeQuery", "selectUserByNativeQuery_mssql_or_db2");
/* 137 */     addDatabaseSpecificStatement("mssql", "selectModelByNativeQuery", "selectModelByNativeQuery_mssql_or_db2");
/* 138 */     addDatabaseSpecificStatement("mssql", "selectHistoricDetailByNativeQuery", "selectHistoricDetailByNativeQuery_mssql_or_db2");
/* 139 */     addDatabaseSpecificStatement("mssql", "selectHistoricVariableInstanceByNativeQuery", "selectHistoricVariableInstanceByNativeQuery_mssql_or_db2");
/* 140 */     addDatabaseSpecificStatement("mssql", "selectTaskWithVariablesByQueryCriteria", "selectTaskWithVariablesByQueryCriteria_mssql_or_db2");
/* 141 */     addDatabaseSpecificStatement("mssql", "selectProcessInstanceWithVariablesByQueryCriteria", "selectProcessInstanceWithVariablesByQueryCriteria_mssql_or_db2");
/* 142 */     addDatabaseSpecificStatement("mssql", "selectHistoricProcessInstancesWithVariablesByQueryCriteria", "selectHistoricProcessInstancesWithVariablesByQueryCriteria_mssql_or_db2");
/* 143 */     addDatabaseSpecificStatement("mssql", "selectHistoricTaskInstancesWithVariablesByQueryCriteria", "selectHistoricTaskInstancesWithVariablesByQueryCriteria_mssql_or_db2");
/*     */   }
/*     */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.db.DbSqlSessionFactory
 * JD-Core Version:    0.6.0
 */