package org.activiti.engine.impl.db;

public abstract interface HasRevision
{
  public abstract void setRevision(int paramInt);

  public abstract int getRevision();

  public abstract int getRevisionNext();
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.db.HasRevision
 * JD-Core Version:    0.6.0
 */