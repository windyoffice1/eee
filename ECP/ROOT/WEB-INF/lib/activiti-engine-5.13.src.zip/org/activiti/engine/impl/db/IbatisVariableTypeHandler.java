/*    */ package org.activiti.engine.impl.db;
/*    */ 
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import org.activiti.engine.ActivitiException;
/*    */ import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
/*    */ import org.activiti.engine.impl.context.Context;
/*    */ import org.activiti.engine.impl.variable.VariableType;
/*    */ import org.activiti.engine.impl.variable.VariableTypes;
/*    */ import org.apache.ibatis.type.JdbcType;
/*    */ import org.apache.ibatis.type.TypeHandler;
/*    */ 
/*    */ public class IbatisVariableTypeHandler
/*    */   implements TypeHandler<VariableType>
/*    */ {
/*    */   protected VariableTypes variableTypes;
/*    */ 
/*    */   public VariableType getResult(ResultSet rs, String columnName)
/*    */     throws SQLException
/*    */   {
/* 37 */     String typeName = rs.getString(columnName);
/* 38 */     VariableType type = getVariableTypes().getVariableType(typeName);
/* 39 */     if ((type == null) && (typeName != null)) {
/* 40 */       throw new ActivitiException("unknown variable type name " + typeName);
/*    */     }
/* 42 */     return type;
/*    */   }
/*    */ 
/*    */   public VariableType getResult(CallableStatement cs, int columnIndex) throws SQLException {
/* 46 */     String typeName = cs.getString(columnIndex);
/* 47 */     VariableType type = getVariableTypes().getVariableType(typeName);
/* 48 */     if (type == null) {
/* 49 */       throw new ActivitiException("unknown variable type name " + typeName);
/*    */     }
/* 51 */     return type;
/*    */   }
/*    */ 
/*    */   public void setParameter(PreparedStatement ps, int i, VariableType parameter, JdbcType jdbcType) throws SQLException {
/* 55 */     String typeName = parameter.getTypeName();
/* 56 */     ps.setString(i, typeName);
/*    */   }
/*    */ 
/*    */   protected VariableTypes getVariableTypes() {
/* 60 */     if (this.variableTypes == null) {
/* 61 */       this.variableTypes = Context.getProcessEngineConfiguration().getVariableTypes();
/*    */     }
/*    */ 
/* 65 */     return this.variableTypes;
/*    */   }
/*    */ 
/*    */   public VariableType getResult(ResultSet resultSet, int columnIndex) throws SQLException {
/* 69 */     String typeName = resultSet.getString(columnIndex);
/* 70 */     VariableType type = getVariableTypes().getVariableType(typeName);
/* 71 */     if (type == null) {
/* 72 */       throw new ActivitiException("unknown variable type name " + typeName);
/*    */     }
/* 74 */     return type;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.db.IbatisVariableTypeHandler
 * JD-Core Version:    0.6.0
 */