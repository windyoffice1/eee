/*    */ package org.activiti.engine.impl.db;
/*    */ 
/*    */ public class IdBlock
/*    */ {
/*    */   long nextId;
/*    */   long lastId;
/*    */ 
/*    */   public IdBlock(long nextId, long lastId)
/*    */   {
/* 24 */     this.nextId = nextId;
/* 25 */     this.lastId = lastId;
/*    */   }
/*    */ 
/*    */   public long getNextId() {
/* 29 */     return this.nextId;
/*    */   }
/*    */   public long getLastId() {
/* 32 */     return this.lastId;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.db.IdBlock
 * JD-Core Version:    0.6.0
 */