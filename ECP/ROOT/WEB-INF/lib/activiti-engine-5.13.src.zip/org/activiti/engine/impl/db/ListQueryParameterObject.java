/*    */ package org.activiti.engine.impl.db;
/*    */ 
/*    */ public class ListQueryParameterObject
/*    */ {
/* 22 */   protected int maxResults = 2147483647;
/* 23 */   protected int firstResult = 0;
/*    */   protected Object parameter;
/*    */   protected String databaseType;
/*    */ 
/*    */   public ListQueryParameterObject()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ListQueryParameterObject(Object parameter, int firstResult, int maxResults)
/*    */   {
/* 31 */     this.parameter = parameter;
/* 32 */     this.firstResult = firstResult;
/* 33 */     this.maxResults = maxResults;
/*    */   }
/*    */ 
/*    */   public int getFirstResult() {
/* 37 */     return this.firstResult;
/*    */   }
/*    */ 
/*    */   public int getFirstRow() {
/* 41 */     return this.firstResult + 1;
/*    */   }
/*    */ 
/*    */   public int getLastRow() {
/* 45 */     if (this.maxResults == 2147483647) {
/* 46 */       return this.maxResults;
/*    */     }
/* 48 */     return this.firstResult + this.maxResults + 1;
/*    */   }
/*    */ 
/*    */   public int getMaxResults() {
/* 52 */     return this.maxResults;
/*    */   }
/*    */ 
/*    */   public Object getParameter() {
/* 56 */     return this.parameter;
/*    */   }
/*    */ 
/*    */   public void setFirstResult(int firstResult) {
/* 60 */     this.firstResult = firstResult;
/*    */   }
/*    */ 
/*    */   public void setMaxResults(int maxResults) {
/* 64 */     this.maxResults = maxResults;
/*    */   }
/*    */ 
/*    */   public void setParameter(Object parameter) {
/* 68 */     this.parameter = parameter;
/*    */   }
/*    */ 
/*    */   public String getOrderBy()
/*    */   {
/* 73 */     return "RES.ID_ asc";
/*    */   }
/*    */ 
/*    */   public void setDatabaseType(String databaseType) {
/* 77 */     this.databaseType = databaseType;
/*    */   }
/*    */ 
/*    */   public String getDatabaseType() {
/* 81 */     return this.databaseType;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.db.ListQueryParameterObject
 * JD-Core Version:    0.6.0
 */