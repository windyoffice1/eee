package org.activiti.engine.impl.db.upgrade;

import org.activiti.engine.impl.db.DbSqlSession;

public abstract interface DbUpgradeStep
{
  public abstract void execute(DbSqlSession paramDbSqlSession)
    throws Exception;
}

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.db.upgrade.DbUpgradeStep
 * JD-Core Version:    0.6.0
 */