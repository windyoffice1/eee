/*    */ package org.activiti.engine.impl.delegate;
/*    */ 
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityBehavior;
/*    */ import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
/*    */ 
/*    */ public class ActivityBehaviorInvocation extends DelegateInvocation
/*    */ {
/*    */   protected final ActivityBehavior behaviorInstance;
/*    */   protected final ActivityExecution execution;
/*    */ 
/*    */   public ActivityBehaviorInvocation(ActivityBehavior behaviorInstance, ActivityExecution execution)
/*    */   {
/* 29 */     this.behaviorInstance = behaviorInstance;
/* 30 */     this.execution = execution;
/*    */   }
/*    */ 
/*    */   protected void invoke() throws Exception {
/* 34 */     this.behaviorInstance.execute(this.execution);
/*    */   }
/*    */ 
/*    */   public Object getTarget() {
/* 38 */     return this.behaviorInstance;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.delegate.ActivityBehaviorInvocation
 * JD-Core Version:    0.6.0
 */