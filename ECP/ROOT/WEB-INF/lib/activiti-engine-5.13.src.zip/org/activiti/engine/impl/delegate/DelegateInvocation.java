/*    */ package org.activiti.engine.impl.delegate;
/*    */ 
/*    */ public abstract class DelegateInvocation
/*    */ {
/*    */   protected Object invocationResult;
/*    */   protected Object[] invocationParameters;
/*    */ 
/*    */   public void proceed()
/*    */     throws Exception
/*    */   {
/* 37 */     invoke();
/*    */   }
/*    */ 
/*    */   protected abstract void invoke()
/*    */     throws Exception;
/*    */ 
/*    */   public Object getInvocationResult()
/*    */   {
/* 47 */     return this.invocationResult;
/*    */   }
/*    */ 
/*    */   public Object[] getInvocationParameters()
/*    */   {
/* 55 */     return this.invocationParameters;
/*    */   }
/*    */ 
/*    */   public abstract Object getTarget();
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.delegate.DelegateInvocation
 * JD-Core Version:    0.6.0
 */