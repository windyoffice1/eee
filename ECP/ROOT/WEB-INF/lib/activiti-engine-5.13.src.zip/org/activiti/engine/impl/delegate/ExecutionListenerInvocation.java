/*    */ package org.activiti.engine.impl.delegate;
/*    */ 
/*    */ import org.activiti.engine.delegate.DelegateExecution;
/*    */ import org.activiti.engine.delegate.ExecutionListener;
/*    */ 
/*    */ public class ExecutionListenerInvocation extends DelegateInvocation
/*    */ {
/*    */   protected final ExecutionListener executionListenerInstance;
/*    */   protected final DelegateExecution execution;
/*    */ 
/*    */   public ExecutionListenerInvocation(ExecutionListener executionListenerInstance, DelegateExecution execution)
/*    */   {
/* 29 */     this.executionListenerInstance = executionListenerInstance;
/* 30 */     this.execution = execution;
/*    */   }
/*    */ 
/*    */   protected void invoke() throws Exception {
/* 34 */     this.executionListenerInstance.notify(this.execution);
/*    */   }
/*    */ 
/*    */   public Object getTarget() {
/* 38 */     return this.executionListenerInstance;
/*    */   }
/*    */ }

/* Location:           D:\miotojar\activiti所需要的jar包\activiti所需要的jar包\activiti所需要的jar包\activiti环境所需jar包\activiti-engine-5.13.jar
 * Qualified Name:     org.activiti.engine.impl.delegate.ExecutionListenerInvocation
 * JD-Core Version:    0.6.0
 */